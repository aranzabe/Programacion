package examenmarzo2021;

/**
 *
 * @author PON TU NOMBRE
 */
public class Lista {

    //**************************************************
    private class Nodo {

        private int dato;
        private Nodo sig;

        public Nodo(int dato) {
            this.dato = dato;
            this.sig = null;
        }
    }
    //**************************************************

    private Nodo l;

    public Lista() {
        this.l = null;
    }

    public void addPrimero(int e) {
        Nodo nuevo = new Nodo(e);
        if (this.l == null) {
            this.l = nuevo;
        }
        else {
            nuevo.sig = this.l;
            this.l = nuevo;
        }
    }

    @Override
    public String toString() {
        String cad = "";
        Nodo aux = this.l;

        while (aux != null) {
            cad += aux.dato + " --> ";
            aux = aux.sig;
        }
        cad += " null";
        return cad;
    }

}
