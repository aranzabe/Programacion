package examenmarzo2021;

/**
 *
 * @author PON TU NOMBRE
 */
public class ExamenMarzo2021 {

    public static void main(String[] args) {
        Lista l = new Lista();
        l.addPrimero(4);
        l.addPrimero(23);
        System.out.println(l.toString());
    }
    
}
