/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Jugadores;

import Cartas.Carta;
import java.util.LinkedList;

/**
 *
 * @author danie
 */
public class Jugador {
    
    private String tipo;
    private float puntos;
    private int victorias;
    private LinkedList<Carta> pilaCartas;

    public Jugador() {
        this.tipo = "";
        this.puntos = 0;
        this.victorias = 0;
        this.pilaCartas = new LinkedList();
    }

    public Jugador(String tipo) {
        this.tipo = tipo;
        this.puntos = 0;
        this.victorias = 0;
        this.pilaCartas = new LinkedList();
    }

    public void setVictorias(int victorias) {
        this.victorias = victorias;
    }

    public String getTipo() {
        return tipo;
    }

    public float getPuntos() {
        return puntos;
    }

    public void setPuntos(float puntos) {
        this.puntos = puntos;
    }
    
    public void addCarta(Carta c){
        this.pilaCartas.addFirst(c);
    }
    
    public void removeCarta(){
        this.pilaCartas.removeFirst();
    }
    
    public Carta getCarta(){
        return this.pilaCartas.getFirst();
    }
    
    public boolean isEmptyPilaCartas(){
        return this.pilaCartas.isEmpty();
    }
}
