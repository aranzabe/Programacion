/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MetodosAuxiliares;

import Cartas.*;
import java.util.LinkedList;

/**
 *
 * @author danie
 */
public class Auxiliar {
    
    public static LinkedList<Carta> generarBaraja(){
        LinkedList<Carta> baraja = new LinkedList();
        String palo = "";
        int numero = 0;
        for (int i = 1; i <= 4; i++) {
            switch (i){
                case 1: palo = "oros"; break;
                case 2: palo = "copas"; break;
                case 3: palo = "espadas"; break;
                case 4: palo = "bastos";
            }
            for (int j = 1; j <= 10; j++) {
                switch (j){
                    case 8: numero = 10; break;
                    case 9: numero = 11; break;
                    case 10: numero = 12;
                }
                baraja.addFirst(Factoria.factoriaCarta(palo, numero));
            }
        }
        return baraja;
    }
    
    public static LinkedList<Carta> barajearMazo(LinkedList<Carta> baraja){
        LinkedList<Carta> mazo = new LinkedList();
        while (!baraja.isEmpty()){
            int alea = (int) (Math.random() * baraja.size());
            mazo.addFirst(baraja.get(alea)); baraja.remove(alea);
        }
        return mazo;
    }
    
}
