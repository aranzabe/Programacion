/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MetodosAuxiliares;

import Cartas.*;
import Jugadores.*;

/**
 *
 * @author danie
 */
public class Factoria {
    
    public static Carta factoriaCarta(String palo, int numero){
        return new Carta(palo, numero);
    }
    
    public static Jugador factoriaJugador(int codTipo){
        String tipo = "";
        switch (codTipo){
            case 1: tipo = "Humano"; break;
            case 2: tipo = "Maquina";
        }
        return new Jugador(tipo);
    }
    
}
