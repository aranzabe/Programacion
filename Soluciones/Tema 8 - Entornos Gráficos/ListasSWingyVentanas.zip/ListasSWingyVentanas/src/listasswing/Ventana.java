package listasswing;

import javax.swing.DefaultListModel;

public class Ventana extends javax.swing.JFrame {

    public Ventana() {
        initComponents();
        DefaultListModel<String> mod = new DefaultListModel<>();
        this.lsLista.setModel(mod);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        lsLista = new javax.swing.JList<>();
        btAdd = new javax.swing.JButton();
        tfCaja = new javax.swing.JTextField();
        btSeleccionar = new javax.swing.JButton();
        btVen2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jScrollPane1.setViewportView(lsLista);

        btAdd.setText("Añadir");
        btAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAddActionPerformed(evt);
            }
        });

        btSeleccionar.setText("Seleccionar");
        btSeleccionar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSeleccionarActionPerformed(evt);
            }
        });

        btVen2.setText("Ventana2");
        btVen2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btVen2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(98, 98, 98)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btAdd)
                        .addGap(18, 18, 18)
                        .addComponent(btSeleccionar))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30)
                        .addComponent(btVen2))
                    .addComponent(tfCaja, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btVen2)
                        .addGap(68, 68, 68)))
                .addComponent(tfCaja, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btAdd)
                    .addComponent(btSeleccionar))
                .addGap(48, 48, 48))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAddActionPerformed
        String cad = this.tfCaja.getText();
        DefaultListModel mod = (DefaultListModel) this.lsLista.getModel();
        mod.addElement(cad);
        this.lsLista.setModel(mod);
    }//GEN-LAST:event_btAddActionPerformed

    private void btSeleccionarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSeleccionarActionPerformed
        if (this.lsLista.getSelectedIndex() != -1) {
            String cad = this.lsLista.getSelectedValue();
            this.tfCaja.setText(cad);
        }
    }//GEN-LAST:event_btSeleccionarActionPerformed

    private void btVen2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btVen2ActionPerformed
        if (this.lsLista.getSelectedIndex() != -1) {
            String cad = this.lsLista.getSelectedValue();
            V2 v = new V2(cad);
            v.setVisible(true);
        }
    }//GEN-LAST:event_btVen2ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btAdd;
    private javax.swing.JButton btSeleccionar;
    private javax.swing.JButton btVen2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList<String> lsLista;
    private javax.swing.JTextField tfCaja;
    // End of variables declaration//GEN-END:variables
}
