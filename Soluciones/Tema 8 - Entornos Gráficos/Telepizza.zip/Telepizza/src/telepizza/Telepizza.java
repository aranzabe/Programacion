/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package telepizza;

/**
 *
 * @author laura
 */
public class Telepizza {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      Pedidos p=new Pedidos();
      
      p.setVisible(true);
    }
    
}
