/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package telepizza;

import java.util.LinkedList;

/**
 *
 * @author faranzabe
 */
public class ColaRegistros {

    private LinkedList<Registro> cola;

    public ColaRegistros() {
        this.cola = new LinkedList();
    }

    public boolean estaVacia() {
        return this.cola.isEmpty();
    }

    public void insertarElemento(Registro e) {
        this.cola.addLast(e);
    }

    public Registro obtenerPrimero() {
        Registro c = new Registro();
        c = this.cola.getFirst();
        return c;
    }

    public Registro obtenerElemento(int i) {
        Registro c = new Registro();
        c = this.cola.get(i);
        return c;
    }

    public int Tamaño() {
        int tamaño;

        tamaño = this.cola.size();

        return tamaño;
    }

    public void borrarPrimero() {
        this.cola.removeFirst();
    }

    @Override
    public String toString() {
        String cad = "";

        if (!this.cola.isEmpty()) {
            cad += this.cola.toString();
        }
        return cad;
    }

}
