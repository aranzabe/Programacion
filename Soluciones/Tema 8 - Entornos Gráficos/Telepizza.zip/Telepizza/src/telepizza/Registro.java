/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package telepizza;

/**
 *
 * @author laura
 */
public class Registro {

    private String DNI;
    private String tipoPizza;
    private String Ingredientes;
    private String tamaño;
    private int precio;

    public Registro() {
        this.DNI = DNI;
        this.tamaño=tamaño;
        this.tipoPizza = tipoPizza;
        this.precio = precio;
    }

    public Registro(String DNI,String tamaño, String tipoPizza, int precio) {
        this.DNI = DNI;
        this.tamaño=tamaño;
        this.tipoPizza = tipoPizza;
        this.precio = precio;
    }


    
    public String getDNI() {
        return DNI;
    }

    public String getTipoPizza() {
        return tipoPizza;
    }

    public String getIngredientes() {
        return Ingredientes;
    }

    public void setIngredientes(String Ingredientes) {
        this.Ingredientes = Ingredientes;
    }

    public String getTamaño() {
        return tamaño;
    }

    public void setTamaño(String tamaño) {
        this.tamaño = tamaño;
    }



    public int getPrecio() {
        return precio;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }

    public void setTipoPizza(String tipoPizza) {
        this.tipoPizza = tipoPizza;
    }


    public void setPrecio(int precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        String cad = "";
        cad = "Registro:" + "\n";
        cad += "DNI Cliente: " + this.DNI + "\n";
        cad += "Tipo de pizza: " + this.tipoPizza + "\n";
        cad += "Precio: " + this.precio + "\n";
        cad += "Tamaño: " + this.tamaño + "\n";
        return cad;
    }

}
