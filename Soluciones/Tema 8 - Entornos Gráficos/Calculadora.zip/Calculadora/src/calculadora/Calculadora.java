/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadora;

/**
 *
 * @author usuarioa
 */
public class Calculadora extends javax.swing.JFrame {

    public Calculadora() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        LBNum1 = new javax.swing.JLabel();
        TFnum1 = new javax.swing.JTextField();
        LBNum2 = new javax.swing.JLabel();
        TFNum2 = new javax.swing.JTextField();
        LBSolucion = new javax.swing.JLabel();
        TFSolucion = new javax.swing.JTextField();
        BTSuma = new javax.swing.JButton();
        BTResta = new javax.swing.JButton();
        BTMultiplicar = new javax.swing.JButton();
        BTDividir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        LBNum1.setText("Numero 1:");

        TFnum1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TFnum1ActionPerformed(evt);
            }
        });

        LBNum2.setText("Numero 2:");

        LBSolucion.setText("Solución:");

        BTSuma.setText("+");
        BTSuma.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTSumaActionPerformed(evt);
            }
        });

        BTResta.setText("-");
        BTResta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTRestaActionPerformed(evt);
            }
        });

        BTMultiplicar.setText("*");
        BTMultiplicar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTMultiplicarActionPerformed(evt);
            }
        });

        BTDividir.setText("/");
        BTDividir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTDividirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(163, 163, 163)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(LBSolucion, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(LBNum2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(LBNum1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(BTSuma)
                        .addGap(11, 11, 11)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(BTResta)
                        .addGap(33, 33, 33)
                        .addComponent(BTMultiplicar)
                        .addGap(37, 37, 37)
                        .addComponent(BTDividir))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(TFnum1)
                        .addComponent(TFNum2)
                        .addComponent(TFSolucion, javax.swing.GroupLayout.DEFAULT_SIZE, 177, Short.MAX_VALUE)))
                .addContainerGap(151, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(68, 68, 68)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(TFnum1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LBNum1))
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(LBNum2)
                    .addComponent(TFNum2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(43, 43, 43)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(LBSolucion)
                    .addComponent(TFSolucion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(39, 39, 39)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BTSuma)
                    .addComponent(BTResta)
                    .addComponent(BTMultiplicar)
                    .addComponent(BTDividir))
                .addContainerGap(56, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void TFnum1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TFnum1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TFnum1ActionPerformed

    private void BTSumaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTSumaActionPerformed
        // TODO add your handling code here:
       int num1 = Integer.parseInt(this.TFnum1.getText());
       int num2 = Integer.parseInt(this.TFNum2.getText());
       int sol;
       
       sol = num1 + num2;
       this.TFSolucion.setText(String.valueOf(sol));
    }//GEN-LAST:event_BTSumaActionPerformed

    private void BTRestaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTRestaActionPerformed
        // TODO add your handling code here:
       int num1 = Integer.parseInt(this.TFnum1.getText());
       int num2 = Integer.parseInt(this.TFNum2.getText());
       int sol;
       
       sol = num1 - num2;
       this.TFSolucion.setText(String.valueOf(sol));
    }//GEN-LAST:event_BTRestaActionPerformed

    private void BTMultiplicarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTMultiplicarActionPerformed
        // TODO add your handling code here:
       int num1 = Integer.parseInt(this.TFnum1.getText());
       int num2 = Integer.parseInt(this.TFNum2.getText());
       int sol;
       
       sol = num1 * num2;
       this.TFSolucion.setText(String.valueOf(sol));
    }//GEN-LAST:event_BTMultiplicarActionPerformed

    private void BTDividirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTDividirActionPerformed
        // TODO add your handling code here:
       int num1 = Integer.parseInt(this.TFnum1.getText());
       int num2 = Integer.parseInt(this.TFNum2.getText());
       int sol = 0;
       
        if(num2 != 0){
            sol = num1 / num2;
        }else{
            System.out.println("No se puede realizar una division entre 0, introduzca otro numero");
            }
        this.TFSolucion.setText(String.valueOf(sol));
    }//GEN-LAST:event_BTDividirActionPerformed

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BTDividir;
    private javax.swing.JButton BTMultiplicar;
    private javax.swing.JButton BTResta;
    private javax.swing.JButton BTSuma;
    private javax.swing.JLabel LBNum1;
    private javax.swing.JLabel LBNum2;
    private javax.swing.JLabel LBSolucion;
    private javax.swing.JTextField TFNum2;
    private javax.swing.JTextField TFSolucion;
    private javax.swing.JTextField TFnum1;
    // End of variables declaration//GEN-END:variables
}
