package tablassw;

import javax.swing.table.DefaultTableModel;

/**
 *
 * @author fernando
 */
public class Ventana extends javax.swing.JFrame {

    public Ventana() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        TB_Sw = new javax.swing.JTable();
        BT_AddBlanco = new javax.swing.JButton();
        BT_BorrarFila = new javax.swing.JButton();
        BT_Sel = new javax.swing.JButton();
        BT_Cambiar = new javax.swing.JButton();
        TXT = new javax.swing.JTextField();
        SP = new javax.swing.JSpinner();
        CHB = new javax.swing.JCheckBox();
        BT_BorrarTodo = new javax.swing.JButton();
        BT_BorrarPrimero = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        TB_Sw.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "DNI", "Edad", "Alumno"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.Boolean.class
            };
            boolean[] canEdit = new boolean [] {
                false, true, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(TB_Sw);

        BT_AddBlanco.setText("Añadir fila");
        BT_AddBlanco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BT_AddBlancoActionPerformed(evt);
            }
        });

        BT_BorrarFila.setText("Borrar fila seleccionada");
        BT_BorrarFila.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BT_BorrarFilaActionPerformed(evt);
            }
        });

        BT_Sel.setText("Seleccionar datos");
        BT_Sel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BT_SelActionPerformed(evt);
            }
        });

        BT_Cambiar.setText("Cambiar datos");
        BT_Cambiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BT_CambiarActionPerformed(evt);
            }
        });

        CHB.setText("Alumno");

        BT_BorrarTodo.setText("Borrar Todo");
        BT_BorrarTodo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BT_BorrarTodoActionPerformed(evt);
            }
        });

        BT_BorrarPrimero.setText("Borrar Primero");
        BT_BorrarPrimero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BT_BorrarPrimeroActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(197, 197, 197)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(122, 122, 122)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(SP, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(CHB, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(BT_AddBlanco)
                                        .addGap(34, 34, 34)
                                        .addComponent(BT_BorrarFila))
                                    .addComponent(TXT, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(BT_Sel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(BT_BorrarPrimero, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(BT_Cambiar, javax.swing.GroupLayout.PREFERRED_SIZE, 130, Short.MAX_VALUE)
                                    .addComponent(BT_BorrarTodo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
                .addContainerGap(60, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BT_AddBlanco)
                    .addComponent(BT_BorrarFila)
                    .addComponent(BT_Sel)
                    .addComponent(BT_Cambiar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TXT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BT_BorrarTodo)
                    .addComponent(BT_BorrarPrimero))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(SP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(CHB)
                .addContainerGap(74, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BT_AddBlancoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BT_AddBlancoActionPerformed
        DefaultTableModel df = (DefaultTableModel) TB_Sw.getModel();
        Object fila[] = new Object[3];
        fila[0] = (String) this.TXT.getText();
        fila[1] = (int) this.SP.getValue();
        fila[2] = (boolean) this.CHB.isSelected();
        df.addRow(fila);
        TB_Sw.setModel(df);
    }//GEN-LAST:event_BT_AddBlancoActionPerformed

    private void BT_BorrarFilaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BT_BorrarFilaActionPerformed
        DefaultTableModel df = (DefaultTableModel) TB_Sw.getModel();
        System.out.println("Fila seleccionada: " + TB_Sw.getSelectedRow() + ", " + TB_Sw.getSelectedColumn());
        df.removeRow(TB_Sw.getSelectedRow());
        TB_Sw.setModel(df);
    }//GEN-LAST:event_BT_BorrarFilaActionPerformed

    private void BT_SelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BT_SelActionPerformed
        TXT.setText((String) TB_Sw.getValueAt(TB_Sw.getSelectedRow(), 0));
        SP.setValue(TB_Sw.getValueAt(TB_Sw.getSelectedRow(), 1));
        //Para obtener el valor boolean accedemos al modelo.
        DefaultTableModel df = (DefaultTableModel) TB_Sw.getModel();
        boolean var = (boolean) df.getValueAt(TB_Sw.getSelectedRow(), 2);
        CHB.setSelected(var);
    }//GEN-LAST:event_BT_SelActionPerformed

    private void BT_CambiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BT_CambiarActionPerformed
        TB_Sw.setValueAt(TXT.getText(), TB_Sw.getSelectedRow(), 0);
        TB_Sw.setValueAt(SP.getValue(), TB_Sw.getSelectedRow(), 1);
        TB_Sw.setValueAt(CHB.isSelected(), TB_Sw.getSelectedRow(), 2);
    }//GEN-LAST:event_BT_CambiarActionPerformed

    private void BT_BorrarTodoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BT_BorrarTodoActionPerformed
        DefaultTableModel df = (DefaultTableModel) TB_Sw.getModel();
        int total = df.getRowCount();
        for (int i = 0; i < total; i++) {
            df.removeRow(0);
        }
        TB_Sw.setModel(df);
    }//GEN-LAST:event_BT_BorrarTodoActionPerformed

    private void BT_BorrarPrimeroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BT_BorrarPrimeroActionPerformed
        try {
            DefaultTableModel df = (DefaultTableModel) TB_Sw.getModel();
            df.removeRow(0);
            TB_Sw.setModel(df);
        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(null, "No hay más elementos", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_BT_BorrarPrimeroActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BT_AddBlanco;
    private javax.swing.JButton BT_BorrarFila;
    private javax.swing.JButton BT_BorrarPrimero;
    private javax.swing.JButton BT_BorrarTodo;
    private javax.swing.JButton BT_Cambiar;
    private javax.swing.JButton BT_Sel;
    private javax.swing.JCheckBox CHB;
    private javax.swing.JSpinner SP;
    private javax.swing.JTable TB_Sw;
    private javax.swing.JTextField TXT;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
