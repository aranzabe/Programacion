/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package registrosusuarios;

/**
 *
 * @author laura
 */
public class Persona {

    private String DNI;
    private String Nombre;
    private String EstadoCivil;
    private int edad;
    private String Cargo;

    public Persona() {
        this.DNI = DNI;
        this.Nombre = Nombre;
        this.EstadoCivil = EstadoCivil;
        this.edad = edad;
        this.Cargo = Cargo;
    }

    public Persona(String DNI, String Nombre, String EstadoCivil, int edad, String Cargo) {
        this.DNI = DNI;
        this.Nombre = Nombre;
        this.EstadoCivil = EstadoCivil;
        this.edad = edad;
        this.Cargo = Cargo;
    }

    public String getDNI() {
        return DNI;
    }

    public String getNombre() {
        return Nombre;
    }

    public String getEstadoCivil() {
        return EstadoCivil;
    }

    public int getEdad() {
        return edad;
    }

    public String getCargo() {
        return Cargo;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public void setEstadoCivil(String EstadoCivil) {
        this.EstadoCivil = EstadoCivil;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setCargo(String Cargo) {
        this.Cargo = Cargo;
    }

    
    
    @Override
    public String toString() {
        String cad = "";

        cad += "DNI: " + this.DNI + "\n";
        cad = "Persona" + "\n";
        cad += "Nombre: " + this.Nombre + "\n";
        cad += "Estado civil: " + this.EstadoCivil + "\n";
        cad += "Edad: " + this.edad + "\n";
        cad += "Cargo: " + this.Cargo + "\n";

        return cad;
    }

}
