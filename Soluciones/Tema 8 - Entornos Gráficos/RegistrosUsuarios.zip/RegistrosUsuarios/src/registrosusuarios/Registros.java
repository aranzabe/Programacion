/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package registrosusuarios;

import java.util.LinkedList;
import javax.swing.DefaultListModel;
import javax.swing.JList;

/**
 *
 * @author laura
 */
public class Registros extends javax.swing.JFrame {

    /**
     * Creates new form Registros
     */
    public Registros() {
        initComponents();
        DefaultListModel mod = new DefaultListModel();
        this.lista1.setModel(mod);
        this.p = new <Persona>LinkedList();
    }

//    public Registros(Persona p) {
//        initComponents();
//        DefaultListModel mod = new DefaultListModel();
//        this.lista1.setModel(mod);
//
//        this.cajaTexto1.setText(p.getDNI());
//        this.cajaTexto2.setText(p.getNombre());
//        if (this.Soltero.equals("Soltero")) {
//            this.Soltero.setSelected(true);
//        } else {
//            if (this.Casado.equals("Casado")) {
//                this.Casado.setSelected(true);
//            }
//        }
//        this.spinner.setValue(p.getEdad());
//        this.combox.setSelectedItem(p.getCargo());
//    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        etiqueta1 = new javax.swing.JLabel();
        cajaDNI = new javax.swing.JTextField();
        etiqueta2 = new javax.swing.JLabel();
        cajaNombre = new javax.swing.JTextField();
        spinner = new javax.swing.JSpinner();
        etiqueta3 = new javax.swing.JLabel();
        etiqueta4 = new javax.swing.JLabel();
        combox = new javax.swing.JComboBox<>();
        botonAdd = new javax.swing.JButton();
        Soltero = new javax.swing.JRadioButton();
        Casado = new javax.swing.JRadioButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        lista1 = new javax.swing.JList<>();
        botonVerDNI = new javax.swing.JButton();
        botonBorrar = new javax.swing.JButton();
        etiqueta5 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        etiqueta1.setText("DNI:");

        etiqueta2.setText("Nombre:");

        etiqueta3.setText("Edad:");

        etiqueta4.setText("Cargo:");

        combox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Director", "Alumno", "Profesor" }));

        botonAdd.setText("Añadir");
        botonAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAddActionPerformed(evt);
            }
        });

        buttonGroup1.add(Soltero);
        Soltero.setText("Soltero");

        buttonGroup1.add(Casado);
        Casado.setText("Casado");

        jScrollPane1.setViewportView(lista1);

        botonVerDNI.setText("Ver DNI seleccionado");
        botonVerDNI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonVerDNIActionPerformed(evt);
            }
        });

        botonBorrar.setText("Borrar persona");
        botonBorrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonBorrarActionPerformed(evt);
            }
        });

        etiqueta5.setText("Estado civil");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(botonVerDNI)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(botonBorrar)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(etiqueta1)
                                            .addGap(18, 18, 18)
                                            .addComponent(cajaDNI, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                    .addComponent(etiqueta2)
                                                    .addComponent(etiqueta3)
                                                    .addComponent(etiqueta4))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                    .addComponent(combox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(cajaNombre)
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addComponent(spinner)
                                                        .addGap(40, 40, 40))))
                                            .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(etiqueta5)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(40, 40, 40))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGap(22, 22, 22)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Casado)
                                    .addComponent(Soltero))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 96, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(41, 41, 41))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(botonAdd)
                .addGap(26, 26, 26))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(etiqueta1)
                            .addComponent(cajaDNI, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(etiqueta2)
                            .addComponent(cajaNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 63, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(etiqueta5)
                            .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Soltero)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Casado))
                    .addComponent(jScrollPane1))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(botonBorrar)
                            .addComponent(botonVerDNI))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 45, Short.MAX_VALUE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(spinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(etiqueta3))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(etiqueta4)
                    .addComponent(combox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(botonAdd)
                .addGap(24, 24, 24))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonVerDNIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonVerDNIActionPerformed
        boolean conseguido = false;
        //Creamos una persona nula
        Persona persona = null;
        int i = 0;

        // Si hay algo seleccionado
        if (this.lista1.getSelectedIndex() != -1) {
            //Guardamos el DNI seleccionado en una cadena
            String cad = this.lista1.getSelectedValue();

            //Mientras i sea menor que la linked list y no conseguido
            while (i < p.size() && !conseguido) {
                //Guardamos en una persona auxiliar la persona de la posicion i
                Persona aux = (Persona) this.p.get(i);
                //Cuando el dni del auxiliar sea igual que el de la cadena
                if (aux.getDNI().equals(cad)) {
                    //En la persona que antes era nula se guardara la nueva persona
                    persona = (Persona) this.p.get(i);
                    conseguido = true;
                }
                i++;
            }
            if (conseguido) {
                //Creamos una ventana enviandole la persona guardada
                Ventana2 v = new Ventana2(persona);
                System.out.println(persona);
                //Hacemos visible la ventana
                v.setVisible(true);
            }

        }
    }//GEN-LAST:event_botonVerDNIActionPerformed

    private void limpiarCajas(){
        this.cajaDNI.setText("");
        this.cajaNombre.setText("");
        this.spinner.setValue(0);
        this.cajaDNI.requestFocus();
    }
    
    private void botonAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAddActionPerformed

        String cad = this.cajaDNI.getText();
        DefaultListModel mod = (DefaultListModel) this.lista1.getModel();
        String cargo = String.valueOf(this.combox.getSelectedItem());
        int edad = (int) this.spinner.getValue();
        String estadoc = "";

        if (this.Soltero.isSelected()) {
            estadoc = "Soltero";
        } else {
            if (this.Casado.isSelected()) {
                estadoc = "Casado";
            }
        }

        mod.addElement(cad);
        this.lista1.setModel(mod);
        Persona persona = new Persona(this.cajaDNI.getText(), this.cajaNombre.getText(), estadoc, edad, cargo);
        p.add(persona);
        System.out.println(p.toString());
    }//GEN-LAST:event_botonAddActionPerformed

    private void botonBorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonBorrarActionPerformed
        int i = 0;
        boolean conseguido = false;
        DefaultListModel m = null;

        if (this.lista1.getSelectedIndex() != -1) {
            String cad = String.valueOf(this.lista1.getSelectedValue());
            while (i < p.size() && !conseguido) {
                Persona aux = (Persona) this.p.get(i);
                if (aux.getDNI().equals(cad)) {
                    p.remove(i);
                    m = (DefaultListModel) this.lista1.getModel();
                    m.removeElement(cad);
                    this.lista1.setModel(m);
                }
                i++;
            }
            System.out.println(p);
        }
    }//GEN-LAST:event_botonBorrarActionPerformed

    private LinkedList p;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton Casado;
    private javax.swing.JRadioButton Soltero;
    private javax.swing.JButton botonAdd;
    private javax.swing.JButton botonBorrar;
    private javax.swing.JButton botonVerDNI;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JTextField cajaDNI;
    private javax.swing.JTextField cajaNombre;
    private javax.swing.JComboBox<String> combox;
    private javax.swing.JLabel etiqueta1;
    private javax.swing.JLabel etiqueta2;
    private javax.swing.JLabel etiqueta3;
    private javax.swing.JLabel etiqueta4;
    private javax.swing.JLabel etiqueta5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JList<String> lista1;
    private javax.swing.JSpinner spinner;
    // End of variables declaration//GEN-END:variables
}
