/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tableros;

/**
 *
 * @author usuariob
 */
public class Tablero {
    
    private String tab[][];

    public Tablero() {
        this.tab = new String[4][4];
    }
    
    public String getPos(int f, int c){
        return this.tab[f][c];
    }
    
    public void setPos(int f, int c, String e){
        this.tab[f][c] = e;
    }
    
    public int getDimF(){
        return this.tab.length;
    }
    
    public int getDimC(){
        return this.tab[0].length;
    }
    
    public void iniciarTablero(){
        for (int i = 0; i < this.getDimF(); i++) {
            for (int j = 0; j < this.getDimC(); j++) {
                this.setPos(i, j, "A");
            }
        }
    }
    
    public void colocarMoscaPistas(){
        int f = (int) (Math.random() * this.getDimF());
        int c = (int) (Math.random() * this.getDimC());
        for (int i = f - 1; i <= f + 1; i++) {
            for (int j = c - 1; j <= c + 1; j++) {
                if (existeLaPosicion(i, j)){
                    this.setPos(i, j, "!");
                }
            }
        }
        this.setPos(f, c, "*");
    }
    
    private boolean existeLaPosicion(int f, int c){
        return (f >= 0 && f < this.getDimF()) && (c >= 0 && c < this.getDimC());
    }
}
