/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aprendeamultiplicar;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.Timer;

/**
 *
 * @author laura
 */
public class TablaMultiplicar extends javax.swing.JFrame {

    /**
     * Creates new form TablaMultiplicar
     */
    public TablaMultiplicar() {
        initComponents();
        temporizador = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //
                barraTiempo.setValue(tiempo);
                tiempo++;
            }
        });
    }


    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Eti8 = new javax.swing.JLabel();
        Eti9 = new javax.swing.JLabel();
        Eti10 = new javax.swing.JLabel();
        Eti11 = new javax.swing.JLabel();
        CajaTextoNumero = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        boton1 = new javax.swing.JButton();
        boton2 = new javax.swing.JButton();
        boton3 = new javax.swing.JButton();
        panel1 = new javax.swing.JPanel();
        CajaTexto00 = new javax.swing.JTextField();
        CajaTexto01 = new javax.swing.JTextField();
        CajaTexto02 = new javax.swing.JTextField();
        CajaTexto03 = new javax.swing.JTextField();
        CajaTexto04 = new javax.swing.JTextField();
        CajaTexto05 = new javax.swing.JTextField();
        CajaTexto06 = new javax.swing.JTextField();
        CajaTexto07 = new javax.swing.JTextField();
        CajaTexto08 = new javax.swing.JTextField();
        CajaTexto09 = new javax.swing.JTextField();
        CajaTexto010 = new javax.swing.JTextField();
        Eti1 = new javax.swing.JLabel();
        Eti2 = new javax.swing.JLabel();
        Eti3 = new javax.swing.JLabel();
        Eti4 = new javax.swing.JLabel();
        Eti5 = new javax.swing.JLabel();
        Eti6 = new javax.swing.JLabel();
        Eti7 = new javax.swing.JLabel();
        panel2 = new javax.swing.JPanel();
        CajaTexto10 = new javax.swing.JTextField();
        CajaTexto11 = new javax.swing.JTextField();
        CajaTexto18 = new javax.swing.JTextField();
        CajaTexto19 = new javax.swing.JTextField();
        CajaTexto20 = new javax.swing.JTextField();
        CajaTexto12 = new javax.swing.JTextField();
        CajaTexto13 = new javax.swing.JTextField();
        CajaTexto14 = new javax.swing.JTextField();
        CajaTexto15 = new javax.swing.JTextField();
        CajaTexto16 = new javax.swing.JTextField();
        CajaTexto17 = new javax.swing.JTextField();
        intentos = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        barraTiempo = new javax.swing.JProgressBar();
        jLabel3 = new javax.swing.JLabel();
        limpiar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Aprende a Múltiplicar");

        Eti8.setText("x7=");

        Eti9.setText("x8=");

        Eti10.setText("x9=");

        Eti11.setText("x10=");

        CajaTextoNumero.setBackground(new java.awt.Color(255, 204, 255));
        CajaTextoNumero.setSelectedTextColor(new java.awt.Color(0, 0, 0));
        CajaTextoNumero.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                CajaTextoNumeroFocusLost(evt);
            }
        });

        jLabel1.setText("Número:");

        boton1.setText("Comprobar");
        boton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boton1ActionPerformed(evt);
            }
        });

        boton2.setText("Me Rindo");
        boton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boton2ActionPerformed(evt);
            }
        });

        boton3.setText("Nuevo");
        boton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boton3ActionPerformed(evt);
            }
        });

        CajaTexto00.setEditable(false);
        CajaTexto00.setActionCommand("<Not Set>");
        CajaTexto00.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        CajaTexto00.setName(""); // NOI18N

        CajaTexto01.setEditable(false);

        CajaTexto02.setEditable(false);

        CajaTexto03.setEditable(false);

        CajaTexto04.setEditable(false);

        CajaTexto05.setEditable(false);

        CajaTexto06.setEditable(false);

        CajaTexto07.setEditable(false);

        CajaTexto08.setEditable(false);

        CajaTexto09.setEditable(false);

        CajaTexto010.setEditable(false);

        javax.swing.GroupLayout panel1Layout = new javax.swing.GroupLayout(panel1);
        panel1.setLayout(panel1Layout);
        panel1Layout.setHorizontalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(CajaTexto010, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CajaTexto09, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CajaTexto08, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CajaTexto07, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CajaTexto06, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CajaTexto05, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CajaTexto04, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CajaTexto03, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CajaTexto02, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CajaTexto01, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CajaTexto00, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panel1Layout.setVerticalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(CajaTexto00, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(CajaTexto01, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(CajaTexto02, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(CajaTexto03, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(CajaTexto04, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(CajaTexto05, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(CajaTexto06, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(9, 9, 9)
                .addComponent(CajaTexto07, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(CajaTexto08, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(CajaTexto09, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CajaTexto010, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(49, Short.MAX_VALUE))
        );

        CajaTexto00.getAccessibleContext().setAccessibleName("");

        Eti1.setText("x0=");

        Eti2.setText("x1=");

        Eti3.setText("x2=");

        Eti4.setText("x3=");

        Eti5.setText("x4=");

        Eti6.setText("x5=");

        Eti7.setText("x6=");

        javax.swing.GroupLayout panel2Layout = new javax.swing.GroupLayout(panel2);
        panel2.setLayout(panel2Layout);
        panel2Layout.setHorizontalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(CajaTexto15, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CajaTexto20, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CajaTexto10, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CajaTexto12, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CajaTexto11, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CajaTexto19, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CajaTexto13, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CajaTexto16, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CajaTexto14, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CajaTexto18, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CajaTexto17, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panel2Layout.setVerticalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel2Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(CajaTexto15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(13, 13, 13)
                .addComponent(CajaTexto20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(CajaTexto10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(13, 13, 13)
                .addComponent(CajaTexto12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(CajaTexto11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(CajaTexto19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(CajaTexto13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(CajaTexto16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CajaTexto14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(CajaTexto18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(CajaTexto17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        intentos.setEditable(false);

        jLabel2.setText("Intentos:");

        barraTiempo.setMaximum(50);

        jLabel3.setText("Tiempo Restante:");

        limpiar.setText("Limpiar");
        limpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                limpiarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(panel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Eti9)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(Eti7)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Eti6)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(Eti2)
                                        .addComponent(Eti1)
                                        .addComponent(Eti3)
                                        .addComponent(Eti4)
                                        .addComponent(Eti5)))
                                .addComponent(Eti8))
                            .addComponent(Eti10)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Eti11)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(18, 18, 18)
                                .addComponent(CajaTextoNumero, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(intentos, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(limpiar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(boton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(boton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(boton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGap(57, 57, 57))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(barraTiempo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(CajaTextoNumero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel1))
                                .addGap(48, 48, 48)
                                .addComponent(boton1)
                                .addGap(18, 18, 18)
                                .addComponent(boton2)
                                .addGap(18, 18, 18)
                                .addComponent(boton3)
                                .addGap(18, 18, 18)
                                .addComponent(limpiar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel2)
                                    .addComponent(intentos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(2, 2, 2))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(4, 4, 4)
                                .addComponent(Eti1)
                                .addGap(18, 18, 18)
                                .addComponent(Eti2)
                                .addGap(18, 18, 18)
                                .addComponent(Eti3)
                                .addGap(18, 18, 18)
                                .addComponent(Eti4)
                                .addGap(18, 18, 18)
                                .addComponent(Eti5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(Eti6)
                                .addGap(18, 18, 18)
                                .addComponent(Eti7)
                                .addGap(18, 18, 18)
                                .addComponent(Eti8)
                                .addGap(19, 19, 19)
                                .addComponent(Eti9)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(Eti10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Eti11, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(barraTiempo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(49, 49, 49))))
                    .addComponent(panel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     **Esta funcion nos permite comprobar el resultado
     *
     * @param evt
     */
    private void boton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boton1ActionPerformed

        try {
            int numero = Integer.parseInt(this.CajaTextoNumero.getText());
            JTextField j = new JTextField();
            JTextField j2 = new JTextField();
            int aciertos = 0;

            //PANEL1
            if (CONT <= 3 && tiempo < 50) {
                for (int i = 0; i < this.panel1.getComponentCount(); i++) {
                    j2 = (JTextField) this.panel1.getComponent(i);
                    j2.setText(String.valueOf(numero));
                }

                //PANEL2
                for (int i = 0; i < this.panel2.getComponentCount(); i++) {

                    String mult = String.valueOf(numero * i);
                    j2 = (JTextField) this.panel2.getComponent(i);

                    if (mult.equals(j2.getText())) {
                        this.panel2.getComponent(i).setBackground(Color.green);
                        j.setText(String.valueOf(this.panel2.getComponent(i)));
                        aciertos++;
                    } else {
                        this.panel2.getComponent(i).setBackground(Color.red);
                        j.setText(String.valueOf(this.panel2.getComponent(i)));
                    }
                }

                if (aciertos < 11) {
                    CONT++;
                } else {
                    JOptionPane.showMessageDialog(null, "Lo has hecho muy bien! Felicidades", "Victoria", JOptionPane.INFORMATION_MESSAGE);
                    this.boton1.setEnabled(false);
                    this.boton2.setEnabled(false);
                    this.limpiar.setEnabled(false);
                    temporizador.stop();
                }
            } else {
                if (CONT == 4) {
                    this.boton1.setEnabled(false);
                    JOptionPane.showMessageDialog(null, "Has perdido", "Derrota", JOptionPane.INFORMATION_MESSAGE);
                    CONT = 0;
                }
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Campo numerico incorrecto", "Error", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_boton1ActionPerformed

//-----------------------------------------------------------------------------//
    //-----------------------------------------------------------------------------//
    /**
     * Esta funcion asignada al boton Me rindo que nos permite mostrar todos los
     * resultados
     *
     * @param evt
     */
    private void boton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boton2ActionPerformed
        try {
            if (CONT <= 3 && tiempo < 50) {
                int numero;
                JTextField j = new JTextField();
                JTextField j2 = new JTextField();

                numero = Integer.parseInt(this.CajaTextoNumero.getText());

                //rellenamos todas las posiciones del panel con el numero
                for (int i = 0; i < this.panel1.getComponentCount(); i++) {
                    j = (JTextField) this.panel1.getComponent(i);
                    j.setText(String.valueOf(numero));

                    j2 = (JTextField) this.panel2.getComponent(i);
                    j2.setText(String.valueOf(numero * i));
                }

                CONT++;
                this.intentos.setText(String.valueOf(CONT));
            } else {
                if (CONT == 4) {
                    this.boton1.setEnabled(false);
                    JOptionPane.showMessageDialog(null, "Has perdido", "Derrota", JOptionPane.ERROR_MESSAGE);
                    CONT = 0;
                    //boton1ActionPerformed(java.awt.event.ActionEvent evt);

                }
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Campo numerico incorrecto", "Error", JOptionPane.ERROR_MESSAGE);
        }


    }//GEN-LAST:event_boton2ActionPerformed
//-----------------------------------------------------------------------------//
//-----------------------------------------------------------------------------//

    /**
     * Esta funcion asignada al boton Nuevo nos permite vaciar todos los campos
     * de texto
     *
     * @param evt
     */
    private void boton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boton3ActionPerformed

        //JTextField es un objeto mas como int o String 
        JTextField j = new JTextField();

        //Hacemos un for, hasta el final del numero de elementos que he puesto
        //en el primer panel
        for (int i = 0; i < this.panel1.getComponentCount(); i++) {
            //guardamos en esta variable el contenido de la caja de texto del panel empezando desde la 0
            j = (JTextField) this.panel1.getComponent(i);
            //vaciamos esa variable
            j.setText("");

        }

        for (int i = 0; i < this.panel2.getComponentCount(); i++) {
            //guardamos en esta variable el contenido de la caja de texto del panel empezando desde la 0
            j = (JTextField) this.panel2.getComponent(i);
            this.panel2.getComponent(i).setBackground(Color.white);
            //vaciamos esa variable
            j.setText("");

        }

        CONT = 0;
        this.boton1.setEnabled(true);
        this.boton2.setEnabled(true);
        this.limpiar.setEnabled(true);
        this.temporizador.stop();
        tiempo = 0;
    }//GEN-LAST:event_boton3ActionPerformed
//-----------------------------------------------------------------------------//
//-----------------------------------------------------------------------------//

    /**
     * Cuando la caja del numero pierde el focus, el numero que haya dentro sera
     * reflejado en las cajas de texto del primer panel
     *
     * @param evt
     */
    private void CajaTextoNumeroFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_CajaTextoNumeroFocusLost
        JTextField j2 = new JTextField();
        int numero = Integer.parseInt(this.CajaTextoNumero.getText());

        for (int i = 0; i < this.panel1.getComponentCount(); i++) {
            j2 = (JTextField) this.panel1.getComponent(i);
            j2.setText(String.valueOf(numero));
        }
        temporizador.start();
    }//GEN-LAST:event_CajaTextoNumeroFocusLost

//-----------------------------------------------------------------------------//
//-----------------------------------------------------------------------------//
    /**
     * Esto nos permite limpiar las cajas de texto sin aumentar los intentos,
     * por si nos arrepentimos de algo y queremos cambiarlo
     *
     * @param evt
     */
    private void limpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_limpiarActionPerformed
        JTextField j = new JTextField();

        for (int i = 0; i < this.panel2.getComponentCount(); i++) {
            this.panel2.getComponent(i).setBackground(Color.white);
            j = (JTextField) this.panel2.getComponent(i);
            j.setText("");
        }
    }//GEN-LAST:event_limpiarActionPerformed

    private int CONT = 0;
    private Timer temporizador;
    private int tiempo;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField CajaTexto00;
    private javax.swing.JTextField CajaTexto01;
    private javax.swing.JTextField CajaTexto010;
    private javax.swing.JTextField CajaTexto02;
    private javax.swing.JTextField CajaTexto03;
    private javax.swing.JTextField CajaTexto04;
    private javax.swing.JTextField CajaTexto05;
    private javax.swing.JTextField CajaTexto06;
    private javax.swing.JTextField CajaTexto07;
    private javax.swing.JTextField CajaTexto08;
    private javax.swing.JTextField CajaTexto09;
    private javax.swing.JTextField CajaTexto10;
    private javax.swing.JTextField CajaTexto11;
    private javax.swing.JTextField CajaTexto12;
    private javax.swing.JTextField CajaTexto13;
    private javax.swing.JTextField CajaTexto14;
    private javax.swing.JTextField CajaTexto15;
    private javax.swing.JTextField CajaTexto16;
    private javax.swing.JTextField CajaTexto17;
    private javax.swing.JTextField CajaTexto18;
    private javax.swing.JTextField CajaTexto19;
    private javax.swing.JTextField CajaTexto20;
    private javax.swing.JTextField CajaTextoNumero;
    private javax.swing.JLabel Eti1;
    private javax.swing.JLabel Eti10;
    private javax.swing.JLabel Eti11;
    private javax.swing.JLabel Eti2;
    private javax.swing.JLabel Eti3;
    private javax.swing.JLabel Eti4;
    private javax.swing.JLabel Eti5;
    private javax.swing.JLabel Eti6;
    private javax.swing.JLabel Eti7;
    private javax.swing.JLabel Eti8;
    private javax.swing.JLabel Eti9;
    private javax.swing.JProgressBar barraTiempo;
    private javax.swing.JButton boton1;
    private javax.swing.JButton boton2;
    private javax.swing.JButton boton3;
    private javax.swing.JTextField intentos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JButton limpiar;
    private javax.swing.JPanel panel1;
    private javax.swing.JPanel panel2;
    // End of variables declaration//GEN-END:variables
}
