/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package encuesta;

import javax.swing.JOptionPane;

/**
 *
 * @author laura
 */
public class Encuesta extends javax.swing.JFrame {

    /**
     * Creates new form Encuesta
     */
    public Encuesta() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        dialogo = new javax.swing.JDialog();
        etiqueta1 = new javax.swing.JLabel();
        Rbutton1 = new javax.swing.JRadioButton();
        Rbutton2 = new javax.swing.JRadioButton();
        Rbutton3 = new javax.swing.JRadioButton();
        jSeparator1 = new javax.swing.JSeparator();
        etiqueta2 = new javax.swing.JLabel();
        checkbox1 = new javax.swing.JCheckBox();
        checkbox2 = new javax.swing.JCheckBox();
        checkbox3 = new javax.swing.JCheckBox();
        jSeparator2 = new javax.swing.JSeparator();
        etiqueta3 = new javax.swing.JLabel();
        button = new javax.swing.JButton();
        slider1 = new javax.swing.JSlider();

        javax.swing.GroupLayout dialogoLayout = new javax.swing.GroupLayout(dialogo.getContentPane());
        dialogo.getContentPane().setLayout(dialogoLayout);
        dialogoLayout.setHorizontalGroup(
            dialogoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        dialogoLayout.setVerticalGroup(
            dialogoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        etiqueta1.setText("Elige un sistema operativo:");

        buttonGroup1.add(Rbutton1);
        Rbutton1.setText("Windows");

        buttonGroup1.add(Rbutton2);
        Rbutton2.setText("Linux");

        buttonGroup1.add(Rbutton3);
        Rbutton3.setText("Mac");

        etiqueta2.setText("Elige tu especialidad:");

        checkbox1.setText("Programación");

        checkbox2.setText("Diseño gráfico");

        checkbox3.setText("Administración");

        etiqueta3.setText("Horas que dedicas en el ordenador:");

        button.setText("Generar");
        button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonActionPerformed(evt);
            }
        });

        slider1.setMajorTickSpacing(1);
        slider1.setMaximum(10);
        slider1.setPaintLabels(true);
        slider1.setPaintTicks(true);
        slider1.setToolTipText("");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(53, 53, 53)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(Rbutton3)
                                .addComponent(Rbutton2)
                                .addComponent(Rbutton1)
                                .addComponent(etiqueta1, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(layout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(jSeparator1, javax.swing.GroupLayout.DEFAULT_SIZE, 244, Short.MAX_VALUE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(56, 56, 56)
                            .addComponent(etiqueta2))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(48, 48, 48)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(checkbox2)
                                .addComponent(checkbox1)
                                .addComponent(checkbox3)))
                        .addGroup(layout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(jSeparator2)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addComponent(etiqueta3))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(86, 86, 86)
                        .addComponent(button))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(slider1, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(etiqueta1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Rbutton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Rbutton2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Rbutton3)
                .addGap(18, 18, 18)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(etiqueta2)
                .addGap(18, 18, 18)
                .addComponent(checkbox1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(checkbox2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(checkbox3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(etiqueta3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(slider1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, Short.MAX_VALUE)
                .addGap(13, 13, 13)
                .addComponent(button)
                .addContainerGap())
        );

        slider1.getAccessibleContext().setAccessibleName("");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonActionPerformed
        int n = this.slider1.getValue();
        String so = "";
        String especialidad = "";
        //---------------------------------------RADIO BUTTONS------------------------//
        //----------------------------------------------------------------------------//
        if (this.Rbutton1.isSelected()) {
            so = "Windows";
        } else {
            if (this.Rbutton2.isSelected()) {
                so = "Linux";
            } else {
                if (this.Rbutton3.isSelected()) {
                    so = "Mac";
                }
            }
        }
        //---------------------------------------CHECK BOX------------------------//
        //----------------------------------------------------------------------------//
        if (this.checkbox1.isSelected()) {
            especialidad += "Programacion ";
        }
        if (this.checkbox2.isSelected()) {
            especialidad += "Diseño gráfico ";
        }
        if (this.checkbox3.isSelected()) {
            especialidad += "Administración ";
        }

        JOptionPane.showMessageDialog(null, "Tu sistema operativo favorito es: " + so + "\n"
                + "Tus especialidades son: " + especialidad + "\n" + " y el numero de horas dedicadas son: " + n);
    }//GEN-LAST:event_buttonActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton Rbutton1;
    private javax.swing.JRadioButton Rbutton2;
    private javax.swing.JRadioButton Rbutton3;
    private javax.swing.JButton button;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JCheckBox checkbox1;
    private javax.swing.JCheckBox checkbox2;
    private javax.swing.JCheckBox checkbox3;
    private javax.swing.JDialog dialogo;
    private javax.swing.JLabel etiqueta1;
    private javax.swing.JLabel etiqueta2;
    private javax.swing.JLabel etiqueta3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSlider slider1;
    // End of variables declaration//GEN-END:variables
}
