/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejer14;

import java.util.Scanner;

/**
 *
 * @author carli
 */
public class Ejer14 {

    public static boolean esPrimo(int numero) {
        int cont;
        cont = 2;
        boolean loes;

        loes = true;
        do {
            if (numero % cont == 0) {
                loes = false;
            }
            cont++;
        } while (cont < numero && loes);

        return loes;
    }


    //************************************************************
    //******************** Programa principal ********************
    //************************************************************

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int numero = 1;
        boolean res;

        do {
            res = esPrimo(numero);

            if (res == true) {
                System.out.println(numero);
            }
            numero++;
        } while (numero <= 100);

    }

}
