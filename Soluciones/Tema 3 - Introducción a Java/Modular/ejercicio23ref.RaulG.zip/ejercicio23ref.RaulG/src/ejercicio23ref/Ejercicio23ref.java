/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio23ref;

import java.util.Scanner;

/**
 *
 * @author usuarioa
 */
public class Ejercicio23ref {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int n1,n2,suma,suma2;
        boolean comp;
        comp=false;
        Scanner sc=new Scanner(System.in);
        
        System.out.print("Dame numero 1: ");
        n1=sc.nextInt();
        System.out.print("Dame numero 2 ");
        n2=sc.nextInt();
        
        suma=sumadig(n1);
        suma2=sumadig(n2);
        
        if(suma==suma2) System.out.println("Son iguales");
        else comp=comprobacion(suma,suma2);
        
        if (comp==true) System.out.println(suma + " es mayor");
        else System.out.println(suma2 + " es mayor");

    }

    public static int sumadig(int num) {
       int suma,dig;
       suma=0;
       while(num>0){
           dig=num %10;
           suma=suma+dig;
           num/=10;
       }
       return suma;
    }

    public static boolean comprobacion(int s, int s2) {
        if(s>s2)return true;
        else return false;
    }
    
}
