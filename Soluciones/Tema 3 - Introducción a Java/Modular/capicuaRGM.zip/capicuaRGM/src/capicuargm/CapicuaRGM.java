/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capicuargm;

import static java.lang.Double.sum;
import java.util.Scanner;

/**
 *
 * @author usuarioa
 */
public class CapicuaRGM {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc=new Scanner (System.in);
        int n,cifras;
        int inv = 0;
        boolean comprobar,soniguales;
        System.out.print("Dime un numero: ");
        n=sc.nextInt();
        
        comprobar=comprobarnumero(n);
        
        
        if(comprobar==true){
            cifras=cuantascifras(n);
            inv=invertir(n,cifras);
        }
        else System.out.println("Numero no valido");
        
        soniguales=comprobacion(inv,n);
        
        if(soniguales==false) System.out.println("No son iguales");
        if (soniguales==true) System.out.println("Son iguales");
        
        
    }

    public static int invertir(int num,int c) {
            int sum = 0;
            int cont = 0,dig;
            c--;
        while(num>0){
            dig =num%10;
            sum=(int) (sum+dig*Math.pow(10, c));
            c--;
            num=num/10;
        }
        return sum;
    }

    public static boolean comprobarnumero(int n) {
            int cont = 0;
            
            while(n>0){
                n=n/10;
                cont++;
            }
            
            if(cont<=5)return true;
            else return false;
    }

    public static boolean comprobacion(int inv, int n) {
        if(inv!=n)return false;
        else return true;
    }

    public static int cuantascifras(int n) {
        int cont=0;
        
        while(n>0){
            n=n/10;
            cont++;
        }
        return cont;
    }
    
}
