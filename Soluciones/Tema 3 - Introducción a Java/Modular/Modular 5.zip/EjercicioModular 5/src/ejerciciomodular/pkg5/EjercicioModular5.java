/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciomodular.pkg5;

import java.util.Scanner;

/**
 *
 * @author Laura
 */
public class EjercicioModular5 {

    public static boolean Bisiesto(int n) {

        boolean bisi;

        if (n % 4 == 0) {

            bisi = true;
        } else {

            bisi = false;
        }

        return bisi;
    }

    public static void main(String[] args) {

        boolean bis;
        int n;
        Scanner sc = new Scanner(System.in);

        System.out.println("Dame un numero");
        n = sc.nextInt();

        bis = Bisiesto(n);

        if (bis == true) {

            System.out.println("Este numero es bisiesto");
        } else {

            System.out.println("Este numero no es bisiesto");
        }

    }

}
