/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_ejercicio03;

import java.util.Scanner;

/**
 *
 * @author danie
 */
public class DJC_Ejercicio03 {

    public static boolean esPositivo(int num){
        boolean pos;
        
        if (num < 0){
            pos = false;
        } else {
            pos = true;
        }
        return pos;
//        return (num >= 0);
    }
    
    public static void main(String[] args) {
        int n;
        boolean posit;
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Este programa determina si un número es positivo o no");
        System.out.print("Dame un número: ");
        n = sc.nextInt();
        posit = esPositivo(n);
        
        if (posit){ //if (posit == true)
            System.out.println(n + " es positivo");
        } else {
            System.out.println(n + " es negativo");
        }
    }
    
}
