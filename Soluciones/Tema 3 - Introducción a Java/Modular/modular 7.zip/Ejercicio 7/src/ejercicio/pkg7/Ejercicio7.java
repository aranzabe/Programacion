/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg7;

import java.util.Scanner;

/**
 *
 * @author Laura
 */
public class Ejercicio7 {
    public static float ConvertCent(float n){
    
    float result;
    
    result= (n-32)*(float)5/9;
    
    return result;
    
}
    
    
    
     public static float ConvertFare(float n){
    
    float result;
    
    result= ((float)9 / 5 * n)+32;
    
    return result;
    
}
  
     
     
    public static void main(String[] args) {
        
        char type;
        float n, c, f;
        Scanner entrada= new Scanner(System.in);
        
        
        
        System.out.println("Dime el tipo al que quieres convertir, F/f - C/c");
        type=entrada.nextLine().charAt(0);
        System.out.println("Dime el tipo al que quieres convertir, F/f - C/c");
        n=entrada.nextFloat();
                
       
        
        if (type=='C' || type=='c'){
            c=ConvertCent(n);
            System.out.println("El resultado es:" +c);   
            
        }
        if (type=='F' || type=='f'){
            f=ConvertFare(n);
            System.out.println("El resultado es:" +f);   
        }
        if (type!='F' || type!='f' || type!='c' || type!='C'){
         System.out.println("No has introducido un tipo correcto");}
            
        
    }
    
}
