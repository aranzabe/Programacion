/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciomodular.pkg23;

import java.util.Scanner;

/**
 *
 * @author 34671
 */
public class EjercicioModular23 {

    public static int sumaDigitos(int n) {
        int digito;

        digito = 0;

        do {

            digito = n % 10 + digito;
            n = n / 10;

        } while (n != 0);

        return digito;
    }

    public static int digitoMayor(int n) {

        int digito;

        digito = 0;

        do {

            digito = n % 10;
            n = n / 10;

        } while (n != 0);

        return digito;
    }

    public static void main(String[] args) {

        int n;
        int digitos;
        int mayor;

        Scanner sc = new Scanner(System.in);

        System.out.println("Dame un nuemro");
        n = sc.nextInt();

        digitos = sumaDigitos(n);
        System.out.println("La suma de los digitos es :" + digitos);

        mayor = digitoMayor(n);
        System.out.println("El digito mayor es : " + mayor);

    }

}
