/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_noviembre20_1;

import java.util.Scanner;

/**
 *
 * @author usuariob
 */
public class DJC_Noviembre20_1 {

    /*----------------------Contador de cifras--------------------------*/
    public static int cuantasCifras(int n) {
        int cifras = 0;

        while (n != 0) {
            n = n / 10;
            cifras++;
        }
        return cifras;
    }

    /*----------------------Comprobador capicúa-------------------------*/
    public static boolean esCapicua(int n0) {
        int n1, dig, exp, res = 0;
        boolean esCapicua = false;

        n1 = n0;
        exp = cuantasCifras(n0) - 1;
        do {
            dig = n1 % 10;
            res = (int) (res + dig * Math.pow(10, exp));
            n1 = n1 / 10;
            exp--;
        } while (n1 != 0);

        return res == n0;
    }

//---------------------------Algoritmo principal-------------------------------
    public static void main(String[] args) {
        int num;
        Scanner sc = new Scanner(System.in);

        System.out.println("Este programa comprueba si un número es capicúa");
        do {
            System.out.print("Dame un número de 5 cifras o menos: ");
            num = sc.nextInt();
            if (cuantasCifras(num) > 5) {
                System.out.println("Necesito que me des un número de 5 cifras o menos.");
            }
        } while (cuantasCifras(num) > 5);

        if (esCapicua(num)) {
            System.out.println(num + " es capicúa");
        } else {
            System.out.println(num + " no es capicúa");
        }
    }

}
