/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciomodular.pkg4;

import java.util.Scanner;

/**
 *
 * @author Laura
 */
public class EjercicioModular4 {

    public static boolean Negativ(float n) {

        boolean corrector;

        if (n >= 0) {

            corrector = true;
        } else {

            corrector = false;
        }

        return corrector;

    }

    public static void main(String[] args) {

        float n;
        float raiz;
        boolean correct;

        Scanner sc = new Scanner(System.in);

        System.out.println("Dame un numero");
        n = sc.nextFloat();

        correct = Negativ(n);
        if (correct == true) {

            raiz = (float) Math.sqrt(n);
            System.out.println("El resultado es: " + raiz);

        } else {

            System.out.println("Introduce un numero valido");
        }

    }

}
