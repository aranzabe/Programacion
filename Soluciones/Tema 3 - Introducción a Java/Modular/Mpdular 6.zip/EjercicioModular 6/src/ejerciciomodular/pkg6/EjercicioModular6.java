/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciomodular.pkg6;

import java.util.Scanner;

/**
 *
 * @author Laura
 */
public class EjercicioModular6 {

    public static boolean Deci(float n) {

        int entero;
        boolean dec;

        entero = (int) n;

        if (entero != n) {

            dec = true;

        } else {

            dec = false;
        }

        return dec;
    }

    public static void main(String[] args) {

        float n;
        boolean decimal;
        Scanner sc = new Scanner(System.in);

        System.out.println("Dame un numero");
        n = sc.nextFloat();

        decimal = Deci(n);

        if (decimal == true) {
            System.out.println("Este numero tiene decimales");
        } else {
            System.out.println("Este numero no tiene decimales");
        }
    }

}
