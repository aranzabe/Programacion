/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.modular.pkg3;

import java.util.Scanner;

/**
 *
 * @author Laura
 */
public class EjercicioModular3 {

    public static boolean Res(int n) {

        boolean res;

        if (n > 0) {

            res = true;
        } else {

            res = false;
        }

        return res;
    }

    public static void main(String[] args) {

        int n;
        boolean result;

        Scanner sc = new Scanner(System.in);

        System.out.println("Dame un numero");
        n = sc.nextInt();

        result = Res(n);

        if (result == true) {

            System.out.println(+n + " Es positivo");
        } else {
            System.out.println(+n + " Es negativo");
        }

    }

}
