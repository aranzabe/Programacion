/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_ejercicio15;

import java.util.Scanner;

/**
 *
 * @author danie
 */
public class DJC_Ejercicio15 {

    public static int calculaDiv(int re[], int dividen, int divisor) {
        int cont=0;
        
        while (dividen >= divisor) {
           dividen = dividen - divisor;
           cont++;
        }
        
        re[0] = dividen;
        return cont;
    }
    
    
    public static void calculaDiv2(int coc[], int re[], int dividen, int divisor) {
        int cont=0;
        
        while (dividen >= divisor) {
           dividen = dividen - divisor;
           cont++;
        }
        
        re[0] = dividen;
        coc[0] = cont;
    }
    
//------------------------------------Algoritmo principal------------------------------------

    public static void main(String[] args) {
        int resto[] = new int[1];
        int dividendo, divisor, cociente;
        int coci[] = new int[1];
        Scanner sc = new Scanner(System.in);

        System.out.println("Este programa hace una división mediante restas sucesivas");
        System.out.print("Dame el dividendo: ");
        dividendo = sc.nextInt();
        System.out.print("Dame el divisor: ");
        divisor = sc.nextInt();

        cociente = calculaDiv(resto, dividendo, divisor);
        System.out.println("La división tiene como cociente " + cociente + " y como resto " + resto[0]);
        
        calculaDiv2(coci, resto, dividendo, divisor);
        System.out.println("La división (con el proc) tiene como cociente " + coci[0] + " y como resto " + resto[0]);
    }

}
