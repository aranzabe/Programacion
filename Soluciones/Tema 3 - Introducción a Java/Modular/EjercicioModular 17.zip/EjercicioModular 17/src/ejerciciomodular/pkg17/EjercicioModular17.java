/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciomodular.pkg17;

import java.util.Scanner;

/**
 *
 * @author Laura
 */
public class EjercicioModular17 {

    public static int solucionEcuacion(float a, float b, float c, float x1[], float x2[]) {
        float dentro = (float) Math.pow(b, 2) - 4 * a * c;
        int cuantasSoluciones = 0;

        if (dentro == 0) {
            cuantasSoluciones = 1;
            x1[0] = (float) (-b / (2 * a));
        }
        if (dentro > 0) {
            cuantasSoluciones = 2;
            x1[0] = (float) ((-b + Math.sqrt(dentro)) / (2 * a));
            x2[0] = (float) ((-b - Math.sqrt(dentro)) / (2 * a));
        }
        if (dentro < 0) {
            cuantasSoluciones = 0;
        }
        return cuantasSoluciones;
    }

    /*------------------------------Algoritmo Principal---------------------------------------------*/
    public static void main(String[] args) {
        float a, b, c;
        float x1[] = new float[1];
        float x2[] = new float[1];
        float dentro;
        int cuantas;

        Scanner sc = new Scanner(System.in);

        System.out.println("Dame los tres coeficientes: ");
        a = sc.nextFloat();
        b = sc.nextFloat();
        c = sc.nextFloat();

        cuantas = solucionEcuacion(a, b, c, x1, x2);

        if (cuantas == 0) {
            System.out.println("No tiene solucion");
        }
        if (cuantas == 1) {
            System.out.println("Tiene una solucion y es; " + x1[0]);
        }
        if (cuantas == 2) {
            System.out.println("Tiene dos soluciones  y son; " + x1[0] + "y" + x2[0]);
        }

    }

}
