package ejer_11;

import java.util.Scanner;

public class Ejer_9 {

    public static int Factorial(int x) {
        int factorial = 1;

        while (x >= 1) {
            factorial = factorial * x;
            x--;
        }
        return factorial;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int num;
        System.out.println("Dame un numero :");
        num = input.nextInt();

        System.out.println("!" + num + " = " + Factorial(num));

    }
}
