/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pasosporreferenciayprocedimientos;

/**
 *
 * @author faranzabe
 */
public class PasosporReferenciayProcedimientos {

    public static void procedimiento(int n, int a[]) {
        n++;
        System.out.println("Valor por argumento: " + a[0]);
        a[0]=a[0] + 1;
        System.out.println("Estoy en el procedimiento: " + n);
    }

    public static int funcion(int n, int a[]) {
        n++;
        System.out.println("Estoy en la función: " + n);
        a[0] = a[0] + 2;
        return n;
    }

    public static void main(String[] args) {
        int num = 9;
        int ar[] = new int[1];

        ar[0] = 23;
        System.out.println("Antes: " + ar[0]);
        procedimiento(num, ar);
        System.out.println("Después: " + ar[0]);
        funcion(num, ar);
        System.out.println("Número en el main: " + num);
    }

}
