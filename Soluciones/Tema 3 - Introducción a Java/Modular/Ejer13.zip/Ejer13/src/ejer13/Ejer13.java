/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejer13;

import java.util.Scanner;

/**
 *
 * @author carli
 */
public class Ejer13 {

    public static boolean esPrimo(int numero) {
        int cont;
        cont = 2;
        boolean loes;

        loes = true;
        do {
            if (numero % cont == 0) {
                loes = false;
            }
            cont++;
        } while (cont < numero && loes);

        return loes;
    }

    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int numero;
        boolean res;
        System.out.println("Dime un numero");
        numero = sc.nextInt();
        
        
        //res = esPrimo(numero);
        if (!esPrimo(numero)) {
            System.out.println("No es primo");
        } else {
            System.out.println("Es un numero primo");
        }

    }

}
