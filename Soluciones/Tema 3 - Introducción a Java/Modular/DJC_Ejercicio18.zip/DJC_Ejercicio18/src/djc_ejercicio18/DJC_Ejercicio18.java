/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_ejercicio18;

import java.util.Scanner;

/**
 *
 * @author danie
 */
public class DJC_Ejercicio18 {

    public static int cuantasMon(float din[], float valorMon) {
        int monedas = 0;

        while (din[0] > valorMon) {
            din[0] = din[0] - valorMon;
            monedas++;
        }
        return monedas;
    }
//--------------------------------Algoritmo principal----------------------------------------    

    public static void main(String[] args) {
        float din[] = new float[1];
        Scanner sc = new Scanner(System.in);

        System.out.println("Este programa te pide dinero y te da el cambio");
        System.out.print("¿Cuánto dinero tienes? ");
        din[0] = sc.nextFloat();

        System.out.println("Monedas de 2€: " + cuantasMon(din, 2));
        System.out.println("Monedas de 1€: " + cuantasMon(din, 1));
        System.out.println("Monedas de 50cts: " + cuantasMon(din, (float) 0.5));
        System.out.println("Monedas de 20cts: " + cuantasMon(din, (float) 0.2));
        System.out.println("Monedas de 10cts: " + cuantasMon(din, (float) 0.1));
        System.out.println("Monedas de 5cts: " + cuantasMon(din, (float) 0.05));
        System.out.println("Monedas de 2cts: " + cuantasMon(din, (float) 0.02));
        System.out.println("Monedas de 1cts: " + cuantasMon(din, (float) 0.01));
    }

}
