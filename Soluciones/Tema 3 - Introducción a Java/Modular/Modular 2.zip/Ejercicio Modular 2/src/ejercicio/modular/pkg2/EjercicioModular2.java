/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.modular.pkg2;

import java.util.Scanner;

/**
 *
 * @author Laura
 */
public class EjercicioModular2 {

    public static float Area(float r) {

        float area;

        area = (float) (Math.pow(r, 2) * Math.PI);

        return area;
    }

    public static float Circun(float r) {

        float circu;

        circu = (float) (2 * Math.PI * r);

        return circu;
    }

    public static void main(String[] args) {

        float a, c, r;
        Scanner sc = new Scanner(System.in);

        System.out.println("Dame el radio");
        r = sc.nextFloat();

        a = Area(r);
        System.out.println("El area es:" + a);
        c = Circun(r);
        System.out.println("La circunferencia es:" + c);
    }

}
