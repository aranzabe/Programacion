/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciomodular.pkg21;

import java.util.Scanner;

/**
 *
 * @author Laura
 */
public class EjercicioModular21 {

    /*--------------------------------CONVERTOR BINARIO----------------------------------------------*/
    public static int convertorBinario(int n) {

        int cont;
        int result;
        int resto;

        cont = 0;
        result = 0;

        do {
            resto = n % 2;
            n = n / 2;
            result = (int) (resto * Math.pow(10, cont) + result);
            cont++;

        } while (n != 0);

        return result;

    }

    /*--------------------------------CONVERTOR DECIMAL----------------------------------------------*/
    public static int convertorDecimal(int n) {

        int cont;
        int result;
        int resto;

        cont = 0;
        result = 0;

        do {
            resto = n % 10;
            n = n / 10;
            result = (int) (resto * Math.pow(2, cont) + result);
            cont++;
        } while (n != 0);

        return result;

    }

    /*-------------------------------ALGORITMO PRINCIPAL-------------------------------------*/
    public static void main(String[] args) {

        char type;
        int n;
        int result;
        Scanner entrada = new Scanner(System.in);

        System.out.println("¿Quieres convertir a Binario(B/b) o a decimal(D/d)");
        type = entrada.nextLine().charAt(0);

        System.out.print("Dime el numero a convertir ");
        n = entrada.nextInt();

        if (type == 'D' || type == 'd') {

            result = convertorDecimal(n);
            System.out.println("El resultado es :" + result);
        }
        if (type == 'B' || type == 'b') {

            result = convertorBinario(n);
            System.out.println("El resultado es :" + result);
        }

    }

}
