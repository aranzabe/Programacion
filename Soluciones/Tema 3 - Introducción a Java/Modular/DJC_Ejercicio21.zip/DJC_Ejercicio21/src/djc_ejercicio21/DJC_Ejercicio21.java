/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_ejercicio21;

import java.util.Scanner;

/**
 *
 * @author danie
 */
public class DJC_Ejercicio21 {

    public static boolean esBinario(int n) {
        int dig;
        boolean esBinario = true;

        do {
            dig = n % 10;
            if (dig != 0 && dig != 1) {
                esBinario = false;
            }
            n = n / 10;
        } while (n != 0 && esBinario);
        return esBinario;
    }

    public static int convierteNum(int base, int n) {
        int otraBase, dig, res = 0;
        int exp = 0;

        if (base == 2) {
            otraBase = 10;
        } else {
            otraBase = 2;
        }
        do {
            dig = n % otraBase;
            res = (int) (res + dig * Math.pow(base, exp));
            n = n / otraBase;
            exp++;
        } while (n != 0);
        return res;
    }
//------------------------------------Algoritmo principal----------------------------------------

    public static void main(String[] args) {
        int num, base;

        Scanner sc = new Scanner(System.in);

        System.out.println("Conversor de números binarios y decimales");
        do {
            System.out.print("¿En qué base está tu número? 10: decimal, 2: binario. ");
            base = sc.nextInt();
            if (base != 10 && base != 2) {
                System.out.println("No te he entendido bien.");
            }
        } while (base != 10 && base != 2);
        do {
            System.out.print("Dame tu número: ");
            num = sc.nextInt();
            if (base == 2 && !esBinario(num)) {
                System.out.println("Antes me has dicho que el número era binario y no lo es. Prueba de nuevo.");
            }
        } while (base == 2 && !esBinario(num));

        System.out.println(num + " --> " + convierteNum(base, num));
    }

}
