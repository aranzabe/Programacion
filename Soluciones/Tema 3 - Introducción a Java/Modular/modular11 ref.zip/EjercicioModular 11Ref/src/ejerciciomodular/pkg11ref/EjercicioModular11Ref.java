/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciomodular.pkg11ref;

import java.util.Scanner;

/**
 *
 * @author 34671
 */
public class EjercicioModular11Ref {

    public static void calculaFactorial(int n[]) {

        int multiplicador;
        multiplicador = n[0] - 1;

        do {
            n[0] = n[0] * multiplicador;
            multiplicador--;
        } while (multiplicador > 0);

    }

    public static void main(String[] args) {
        int n[] = new int[1];
        Scanner sc = new Scanner(System.in);

        System.out.print("Dame un numero: ");
        n[0] = sc.nextInt();

        calculaFactorial(n);
        System.out.println("El factorial es: " + n[0]);
    }

}
