/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio16;

import java.util.Scanner;

/**
 *
 * @author faranzabe
 */
public class Ejercicio16 {

    public static void tictac(int h[], int m[], int s[]){
        s[0] = s[0] + 1;
        if (s[0] == 60){
            s[0] = 0;
            m[0] = m[0] + 1;
        }
        if (m[0] == 60){
            m[0] = 0;
            h[0]++; //h[0] = h[0] + 1;
        }
        if (h[0] == 24){
            h[0] = 0;
        }
    }
    
    public static void main(String[] args) {
        int hora[] = new int[1];
        int min[] = new int[1];
        int seg[] = new int[1];
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Hora: ");
        hora[0] = sc.nextInt();
        System.out.print("Minutos: ");
        min[0] = sc.nextInt();
        System.out.print("Segundos: ");
        seg[0] = sc.nextInt();
        
        tictac(hora, min, seg);
        System.out.println("Hora actual: " + hora[0] + ":" + min[0] + ":" + seg[0]);
        
    }
    
}
