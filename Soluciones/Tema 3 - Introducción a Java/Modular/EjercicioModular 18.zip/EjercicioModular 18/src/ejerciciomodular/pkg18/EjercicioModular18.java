/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciomodular.pkg18;

import java.util.Scanner;

/**
 *
 * @author Laura
 */
public class EjercicioModular18 {

    public static int devolucionMonedas(float dinero[], float valor_moneda) {

        int contmoneda;

        contmoneda = 0;

        while (dinero[0] >= valor_moneda) {
            dinero[0] = dinero[0] - valor_moneda;
            contmoneda++;
        }

        return contmoneda;

    }

    public static void main(String[] args) {
        float dinero[] = new float[1];
        float valor_moneda;
        int num_moneda;
        Scanner sc = new Scanner(System.in);

        System.out.print("Inserte su dinero: ");
        dinero[0] = sc.nextFloat();

        num_moneda = devolucionMonedas(dinero, 2);
        System.out.println("Monedas de 2 euros: " + num_moneda);
        num_moneda = devolucionMonedas(dinero, 1);
        System.out.println("Monedas 1 euro: " + num_moneda);
        num_moneda = devolucionMonedas(dinero, (float) 0.50);
        System.out.println("Monedas de 0,50 centimos: " + num_moneda);
        num_moneda = devolucionMonedas(dinero, (float) 0.20);
        System.out.println("Monedas de 0,20 centimos: " + num_moneda);
        num_moneda = devolucionMonedas(dinero, (float) 0.10);
        System.out.println("Monedas de 0,10 centimos: " + num_moneda);
        num_moneda = devolucionMonedas(dinero, (float) 0.05);
        System.out.println("Monedas de 0,05 centimos: " + num_moneda);
        num_moneda = devolucionMonedas(dinero, (float) 0.02);
        System.out.println("Monedas de 0,02 centimos: " + num_moneda);
        num_moneda = devolucionMonedas(dinero, (float) 0.01);
        System.out.println("Monedas de 0,01 centimos: " + num_moneda);

    }

}
