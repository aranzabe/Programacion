/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg1.modular;

import java.util.Scanner;

/**
 *
 * @author Laura
 */
public class EjercicioModular1 {

    public static float Superficie(float lado) {

        float sup;

        sup = lado * lado;

        return sup;

    }

    public static float Perimetro(float lado) {

        float per;

        per = lado * 4;

        return per;
    }

    public static void main(String[] args) {

        float l, s, p;
        Scanner sc = new Scanner(System.in);

        System.out.println("Dame el lado");
        l = sc.nextFloat();

        s = Superficie(l);
        System.out.println("La superficie es :" + s);
        p = Perimetro(l);
        System.out.println("El Perimetro es :" + p);
    }

}
