/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciomodular.pkg14;

import java.util.Scanner;

/**
 *
 * @author 34671
 */
public class EjercicioModular14 {

    public static boolean esPrimo(int n) {
        int cont;
        boolean prim;

        cont = 2;

        do {
            if (n % cont == 0) {

                prim = false;

            } else {
                prim = true;
            }
            cont++;
        } while (prim == true && n > cont);

        return prim;
    }

    public static void main(String[] args) {

        int n;
        boolean primo;
        

        n = 3;

        do {

            primo = esPrimo(n);

            if (primo == true) {

                System.out.println(+n);
            }
            n++;
        } while (n < 100);
    }

}
