/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_noviembre17_robot;

/**
 *
 * @author usuariob
 */
public class DJC_Noviembre17_Robot {

    public static void recibirPedido(int cant[]) {
        cant[0] = (int) (Math.random() * 4);
    }

    public static boolean detectarCaja(int f, int c) {
        boolean existeCaja = true;
        int alea;
        alea = (int) (Math.random() * 10);
        if (alea == 0) {
            existeCaja = false;
        }
        return existeCaja;
    }

    public static void cogerCaja(int f, int c) {
        System.out.println("Cogiendo la caja que hay en: " + f + "," + c);
    }

    public static void apilarPosicion(int pos) {
        System.out.println("Apilando la caja en la posición: " + pos);
    }

    public static void posicionInicial() {
        System.out.println("Colocando el brazo en la posición inicial.");
    }

    public static void main(String[] args) {
        int totalCajas = 150;
        int filaActual = 1, colActual = 1;
        boolean error = false;
        int pedido[] = new int[1];
        int pos;

        while (totalCajas > 0 && !error) {
            pos = 1;
            recibirPedido(pedido);
            if (pedido[0] > 0) {
                do {
                    error = !detectarCaja(filaActual, colActual);
                    if (!error) {
                        cogerCaja(filaActual, colActual);
                        apilarPosicion(pos);
                        pos++;
                        colActual++;
                        if (colActual == 16) {
                            colActual = 1;
                            filaActual++;
                        }
                    }
                    pedido[0]--;
                } while (pedido[0] > 0);
            }
        }
        if (error) {
            System.out.println("El proceso ha finalizado debido a un error");
        } else {
            if (totalCajas == 0) {
                System.out.println("El proceso ha finalizado porque nos hemos quedado sin cajas");
            }
        }
        if (pedido[0] > 0) {
            System.out.println("El último pedido no ha podido finalizarse");
        } else {
            System.out.println("El último pedido ha podido finalizarse");
        }
    }

}
