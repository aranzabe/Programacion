/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciomodular.pkg11ref;

import java.util.Scanner;

/**
 *
 * @author 34671
 */
public class EjercicioModular11Ref {

    public static void calculaFactorial(int n, int f[]) {

        f[0] = 1;
        int i;
        
        for (i = 1; i <= n; i++) {
            f[0] = f[0] * i;
        }
    }

    public static void main(String[] args) {
        int n;
        int fact[] = new int[1];
        Scanner sc = new Scanner(System.in);

        System.out.print("Dame un numero: ");
        n = sc.nextInt();

        calculaFactorial(n, fact);
        System.out.println("El factorial es: " + fact[0]);
    }

}
