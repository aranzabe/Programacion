/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciomodular.pkg23;

import java.util.Scanner;

/**
 *
 * @author 34671
 */
public class EjercicioModular23 {

    public static int sumaDigitos(int n) {
        int suma;

        suma = 0;
        do {
            suma = n % 10 + suma;
            n = n / 10;
        } while (n != 0);

        return suma;
    }
    
    
    public static void main(String[] args) {

        int n1, n2, sumn1, sumn2;
        Scanner sc = new Scanner(System.in);

        System.out.println("Dame un nuemro");
        n1 = sc.nextInt();
        System.out.println("Dame otro");
        n2 = sc.nextInt();

        sumn1 = sumaDigitos(n1);
        sumn2 = sumaDigitos(n2);

        if (sumn1 > sumn2) {
            System.out.println("La suma de los digitos del primero es la mayor");
        }
        if (sumn1 < sumn2) {
            System.out.println("La suma de los digitos del segundo es la mayor");
        }
        if (sumn1 == sumn2) {
            System.out.println("La suma de los digitos son iguales");
        }

    }

}
