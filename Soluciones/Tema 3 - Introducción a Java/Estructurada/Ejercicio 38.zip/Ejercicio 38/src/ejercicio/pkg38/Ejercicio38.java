/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg38;

import java.util.Scanner;

/**
 *
 * @author Laura
 */
public class Ejercicio38 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        int ejercicio;
        int op;
        char respu;
        Scanner sc = new Scanner(System.in);;
        respu = 'n';

        int num;
        int cont;
        int res = 1;
        int intentos, secret, n;

        do {

            System.out.println("¿Que ejercicio deseas hacer?, recuerde pulsar 50 si lo que desea es salir");
            System.out.println("23 29 31?");
            ejercicio = sc.nextInt();
            sc.nextLine();

            switch (ejercicio) {

                case 23:
                    System.out.println("Este programa calcula el factorial de un número");
                    System.out.print("Dame un número: ");
                    num = sc.nextInt();

                    for (cont = num; cont > 0; cont--) {
                        res = res * cont;
                    }
                    System.out.println(num + "! = " + res);
                    break;
                case 29:
                    System.out.println("Este programa pide números hasta que le das uno del 1 al 5");
                    do {
                        System.out.print("Dame un número: ");
                        num = sc.nextInt();
                    } while (num < 1 || num > 5);
                    break;
                case 31:
                    do {
                        intentos = 0;
                        secret = (int) (Math.random() * 100) + 1;
                        do {
                            System.out.println("Dime que numero crees que es");
                            n = sc.nextInt();
                            sc.nextLine();
                            intentos++;

                            if (n > secret) {
                                System.out.println("Mi numero es mas pequeño");
                            }
                            if (n < secret) {
                                System.out.println("Mi numero es mas grande");
                            }
                        } while (intentos != 5 && n != secret);

                        if (n == secret) {
                            System.out.println("Has acertado! enhorabuena");
                        } else {
                            System.out.println("Has perdido, has superado tus 5 intentos, el número era: " + secret);
                        }

                        System.out.println("¿Quieres hechar otra?");
                        respu = sc.nextLine().charAt(0);

                    } while (respu == 's' || respu == 'S');
                    break;
                case 50:
                    System.out.println("¿Quieres salir?");
                    respu = sc.nextLine().charAt(0);
            }
        } while (respu == 'n' || respu == 'N');

    }

}
