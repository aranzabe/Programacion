/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg17;

import java.util.Scanner;

/**
 *
 * @author laura
 */
public class Ejercicio17 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int a, b, c;
        float x1 = 0, x2 = 0;
        float dentro;
        Scanner sc = new Scanner(System.in);

        System.out.println("Dame tres coeficientes");

        a = sc.nextInt();
        b = sc.nextInt();
        c = sc.nextInt();

        dentro = (float) (Math.pow(b, 2) - 4 * c);

        if (dentro < 0) {
            System.out.println("No tiene solucion");
        } 
        if (dentro == 0)  {
            x1 =  - b  / (2 * a);
            System.out.println("Tiene una solucion y es:" + x1);
        }
        if (dentro > 0)  {
            x1 = (float) (- b + Math.sqrt(dentro) / (2 * a));
            x2 = (float) (- b - Math.sqrt(dentro) / (2 * a));
            System.out.println("Tiene dos soluciones y son:" + x1 + "," + x2);
        }

    }

}
