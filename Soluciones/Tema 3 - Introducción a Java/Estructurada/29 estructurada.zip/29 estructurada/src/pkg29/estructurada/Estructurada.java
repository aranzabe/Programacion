/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg29.estructurada;

import java.util.Scanner;

/**
 *
 * @author carli
 */
public class Estructurada {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int notas;
        notas = 0;
        int aprobado, suspenso, bien, notable, sobre;
        aprobado = 0;
        suspenso = 0;
        bien = 0;
        notable = 0;
        sobre = 0;
        do {
            System.out.println("Dime una nota");
            notas = sc.nextInt();
            if (notas >= 5 && notas <= 10) {
                aprobado++;
                if (notas >= 6 && notas < 7) {
                    bien++;
                }
                if ((notas >= 7) && (notas < 8.5)) {
                    notable++;
                }
                if (notas >= 8.5 && notas <= 10) {
                    sobre++;
                }
            }
            if (notas >= 0 && notas < 5) {
                suspenso++;
            }
        } while (notas >= 0);
        System.out.println("Hay " + aprobado + " aprobados");
        System.out.println("Hay " + bien + " bienes");
        System.out.println("Hay " + notable + " notables");
        System.out.println("Hay " + sobre + " sobresalientes");
        System.out.println("Hay " + suspenso + " suspensos");
    }

}
