/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1;

import java.util.Scanner;

/**
 *
 * @author faranzabe
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int lado;
        int superficie, perimetro;
        Scanner entrada = new Scanner(System.in);
        
        
        System.out.print("Dame el lado: ");
        lado = entrada.nextInt(); //Leer lado
        
        
        superficie = lado * lado;
        perimetro = lado * 4;
        
        
        System.out.println("La superficie del cuadrado es: " + superficie); //Escribir 
        System.out.println("El perímetro es: " + perimetro);
    }
    
}
