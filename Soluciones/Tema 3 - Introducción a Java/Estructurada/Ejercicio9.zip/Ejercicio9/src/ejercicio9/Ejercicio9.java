/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio9;

import java.util.Scanner;

/**
 *
 * @author Laura
 */
public class Ejercicio9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int nA, nB;
        int suma;
        Scanner sc = new Scanner(System.in);

        System.out.println("Dame dos numeros");
        nA = sc.nextInt();
        nB = sc.nextInt();

        if (nA > nB) {
            suma = nA - nB;
            System.out.println("el numero A es mayor que B y el resultado es" + suma);
        } else {
            suma = nB - nA;
            System.out.println("el numero B es mayor que A y el resultado es" + suma);
        }

    }

   
}
