/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio4;

import java.util.Scanner;

/**
 *
 * @author Laura
 */
public class Ejercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
     float num1 ,num2 ,num3;
     float resdecimal;
     int resentero;
     Scanner sc= new Scanner(System.in);
     
     System.out.println("Dame tres numeros");
     
     num1= sc.nextFloat();
     num2= sc.nextFloat();
     num3= sc.nextFloat();
     
     resdecimal = (num1 + num2 + num3) / 3;
     resentero = Math.round(resdecimal);
     
     System.out.println("El resultado es: " + resdecimal);
     System.out.println("El resultado redondeado es: " + resentero);
     
     
    }

    
}
