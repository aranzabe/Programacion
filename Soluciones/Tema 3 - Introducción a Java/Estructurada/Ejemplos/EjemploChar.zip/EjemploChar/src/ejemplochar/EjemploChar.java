/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplochar;

import java.util.Scanner;

/**
 *
 * @author faranzabe
 */
public class EjemploChar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        char letra;
        int num;
        Scanner entrada = new Scanner(System.in);
        
        
        System.out.print("Dame un número: ");
        num = entrada.nextInt();
        entrada.nextLine();
        System.out.print("Dame una letra: ");
        letra = entrada.nextLine().charAt(0);
        

        System.out.println("La letra es: " + letra);
        System.out.println("Y el número es: " + num);
    }

}
