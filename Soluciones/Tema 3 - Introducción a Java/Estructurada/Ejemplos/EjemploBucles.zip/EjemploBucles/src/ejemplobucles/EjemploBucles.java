/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplobucles;

/**
 *
 * @author faranzabe
 */
public class EjemploBucles {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Mientras
        int cont=1;
        while(cont <= 4){
            System.out.println("Hola con el while");
            //cont = cont + 1;
            cont++;
        }//Fin del while
        
        cont = 1;
        do {
            System.out.println("Hola con repetir");
            cont = cont + 1;
        }while(cont <= 4);
        
        for (cont = 1; cont <= 4; cont++) {
            System.out.println("Hola con el for");
        }
    }
    
}
