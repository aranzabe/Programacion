/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplofiltros;

import java.util.Scanner;

/**
 *
 * @author faranzabe
 */
public class EjemploFiltros {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        float radio;
        float sup, circ;
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Dame el radio: ");
        radio = sc.nextFloat();
        
        sup = (float) (Math.PI * radio * radio);
        System.out.println("La superficie es: " + sup);
        
    }
    
}
