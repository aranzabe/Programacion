/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemploinicial;

import java.util.Scanner;

/**
 * 
 * @author faranzabe
 */
public class EjemploInicial {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int numero, numero2;
        Scanner entrada = new Scanner(System.in);
    
        System.out.println("Dame un número: ");
        numero = entrada.nextInt();  //Leer numero
        numero2 = numero - 2;
        
       
        
        //Escribir "El valor de la suma es: ", numero2
        System.out.println("El valor de la suma es: " + numero2);
    }
    
}
