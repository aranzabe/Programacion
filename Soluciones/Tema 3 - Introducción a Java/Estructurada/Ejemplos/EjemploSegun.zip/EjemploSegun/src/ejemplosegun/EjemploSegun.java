/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplosegun;

/**
 *
 * @author faranzabe
 */
public class EjemploSegun {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int opcion = 7;

        switch (opcion) {
            case 1:
                System.out.println("Vale uno");
                break;
            case 2:
            case 3:
                System.out.println("Vale dos");
                for (int i = 0; i < 3; i++) {
                    System.out.println(i);
                }
                break;
//            default:
//                System.out.println("Caso por defecto. No valga nada de lo anterior");
        }//Fin del switch
        System.out.println("Fin del programa");
    }

}
