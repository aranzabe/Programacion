/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esperarandom;

/**
 *
 * @author faranzabe
 */
public class EsperaRandom {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        int n;
        n = (int) (Math.random() * 4) + 1; //1 - 4
        System.out.println(n);
//System.out.println(Math.random() * 50); //0 - 49

        Thread.sleep(1000);//Espera 1 segundo
        System.out.println("Después de un segundo");
        
    }

}
