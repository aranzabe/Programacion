/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_ejercicio31;

import java.util.Scanner;

/**
 *
 * @author danie
 */
public class DJC_Ejercicio31 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int num, divisor;
        boolean primo = true;
        Scanner sc = new Scanner(System.in);

        System.out.println("Este programa te dice si un número es primo o no");
//        System.out.print("Dame un número: ");
//        num = sc.nextInt();
        for (num = 2; num < 100; num++) {
            divisor = 2;
            primo = true;
            while (divisor < num && primo == true) {
                if (num % divisor == 0) {
                    primo = false;
                }
                divisor++;
            }
            if (primo == false) {
                //System.out.println(num + " no es primo");
            } else {
                //System.out.println(num + " es primo");
                System.out.println(num);
            }
        }

    }

}
