/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg36;

import java.util.Scanner;

/**
 *
 * @author Laura
 */
public class Ejercicio36 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        float n1, n2, operacion;
        char operador, respuesta;
        Scanner entrada = new Scanner(System.in);

        operacion = 0;

        do {
            System.out.println("Dame dos numeros");
            n1 = entrada.nextFloat();
            n2 = entrada.nextFloat();
            entrada.nextLine(); //Limpia de buffer.

            System.out.println("Dame un operador");
            operador = entrada.nextLine().charAt(0);

            /*
            if (operador == '+') {
                operacion = n1 + n2;
                System.out.println("El resultado es:" + operacion);
            }
            if (operador == '-') {
                operacion = n1 - n2;
                System.out.println("El resultado es:" + operacion);
            }
            if (operador == '*') {
                operacion = n1 * n2;
                System.out.println("El resultado es:" + operacion);
            }
            if (operador == '/') {
                if (n2 == 0) {
                    System.out.println("No se puede dividir entre 0");
                } else {
                    operacion = n1 / n2;
                    System.out.println("El resultado es:" + operacion);
                }
            }
             */
            switch (operador) {
                case '+':
                    operacion = n1 + n2;
                    System.out.println("El resultado es:" + operacion);
                    break;
                case '-':
                    operacion = n1 - n2;
                    System.out.println("El resultado es:" + operacion);
                    break;
                case '*':
                    operacion = n1 * n2;
                    System.out.println("El resultado es:" + operacion);
                    break;
                case '/':
                    if (n2 == 0) {
                        System.out.println("No se puede dividir entre 0");
                    } else {
                        operacion = n1 / n2;
                        System.out.println("El resultado es:" + operacion);
                    }
                    break;
                default:
                    System.out.println("Operación incorrecta.");
            }

            System.out.println("Desea terminar?");
            respuesta = entrada.nextLine().charAt(0);

        } while (respuesta == 'n' || respuesta == 'N');
    }

}
