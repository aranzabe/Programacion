/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio3;

import java.util.Scanner;

/**
 *
 * @author laura
 */
public class Ejercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {//Algoritmo principal.
        // TODO code application logic here
        float area, circunferencia;
        int radio;
        Scanner sc = new Scanner(System.in);

        System.out.println("Dame el radio");
        radio = sc.nextInt();

        area = (float) (Math.pow(radio,2) * Math.PI);
        circunferencia = (float) (2 * Math.PI * radio);

        System.out.print("El area es; " + area);
        System.out.print("la circunferencia es; " + circunferencia);
    }

}
