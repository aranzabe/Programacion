/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_ejericio17;

import java.util.Scanner;

/**
 *
 * @author usuariob
 */
public class DJC_EJericio17 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        float a, b, c;
        float dentroRaiz;
        float x1, x2;
        Scanner sc = new Scanner(System.in);

        System.out.println("Este programa calcula una ecuación de segundo grado");
        System.out.println("Dame los cocientes a, b y c, en ese orden:");
        a = sc.nextFloat();
        b = sc.nextFloat();
        c = sc.nextFloat();

        dentroRaiz = (float) (Math.pow(b, 2) - 4 * a * c);
        if (dentroRaiz < 0) {
            System.out.println("La ecuación no tiene solución real");
        } else {
            x1 = (float) ((-b + (Math.sqrt(dentroRaiz))) / (2 * a));
            x2 = (float) ((-b - (Math.sqrt(dentroRaiz))) / (2 * a));
            if (x1 == x2) {
                System.out.println("La ecuación tiene una solución, que es: " + x1);
            } else {
                System.out.println("La ecuación tiene dos soluciones reales");
                System.out.println("x1 = " + x1);
                System.out.println("x2 = " + x2);
            }
        }

    }

}
