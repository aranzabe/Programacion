/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg38;

import java.util.Scanner;

/**
 *
 * @author Laura
 */
public class Ejercicio38 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int ejercicio;
        int op;
        char respu;
         Scanner entrada = new Scanner(System.in);
         respu='n';
         
        
        do{
         
        System.out.println("¿Que ejercicio deseas hacer?, recuerde pulsar 50 si lo que desea es salir");
        
        ejercicio=entrada.nextInt();
        entrada.nextLine();
        
        switch(ejercicio){
            
            
            
            case 23: op=5+10; 
                    System.out.println("la respuesta es:"+op); 
            break;
            case 29: op=5-10; 
                     System.out.println("La respuesta es:"+op);
            break;
            case 31: op=5*10;  
                     System.out.println("La respuesta es:"+op);
            break;
            case 50: System.out.println("¿Quieres salir?");  
                     respu=entrada.nextLine().charAt(0);
        }
        }while(respu== 'n' || respu=='N');
        
    }
    
}
