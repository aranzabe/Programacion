/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_ejercicio33;

/**
 *
 * @author danie
 */
public class DJC_Ejercicio33 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int n1, n2, n3, n4, n5, n6;
        
        System.out.println("Este programa genera una combinación al azar de la lotería");
//        n1 = (int) (Math.random() * 49) + 1;
//        n2 = (int) (Math.random() * 49) + 1;
//        n3 = (int) (Math.random() * 49) + 1;
//        n4 = (int) (Math.random() * 49) + 1;
//        n5 = (int) (Math.random() * 49) + 1;
//        n6 = (int) (Math.random() * 49) + 1;
//        
//        System.out.println(n1 + " " + n2 + " " + n3 + " " + n4 +" " + n5 + " " + n6);
//        
        for (int i = 0; i < 6; i++) {
            n1 =  (int) (Math.random() * 49) + 1;
            System.out.print(n1 + " ");
        }
        System.out.println("");
    }
    
}
