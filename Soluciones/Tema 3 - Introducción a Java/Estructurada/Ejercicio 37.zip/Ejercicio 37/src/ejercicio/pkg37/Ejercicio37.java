/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg37;

import java.util.Scanner;

/**
 *
 * @author Laura
 */
public class Ejercicio37 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        int intentos, secret, n;
        char respu;
        Scanner entrada = new Scanner(System.in);

        do {
            intentos = 0;
            secret = (int) (Math.random() * 100) + 1;
            do {
                System.out.println("Dime que numero crees que es");
                n = entrada.nextInt();
                entrada.nextLine();
                intentos++;

                if (n > secret) {
                    System.out.println("Mi numero es mas pequeño");
                }
                if (n < secret) {
                    System.out.println("Mi numero es mas grande");
                }
            } while (intentos != 5 && n != secret);

            if (n == secret) {
                System.out.println("Has acertado! enhorabuena");
            } else {
                System.out.println("Has perdido, has superado tus 5 intentos, el número era: " + secret);
            }

            System.out.println("¿Quieres hechar otra?");
            respu = entrada.nextLine().charAt(0);

        } while (respu == 's' || respu == 'S');
    }

}
