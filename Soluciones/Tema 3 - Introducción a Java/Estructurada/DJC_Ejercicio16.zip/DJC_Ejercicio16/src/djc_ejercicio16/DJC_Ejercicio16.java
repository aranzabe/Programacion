/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_ejercicio16;

import java.util.Scanner;

/**
 *
 * @author usuariob
 */
public class DJC_Ejercicio16 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int hora, min, seg;
        boolean correcto = true;
        Scanner sc = new Scanner(System.in);

        System.out.println("Este programa pide una hora y le suma un segundo");
//        do {
        System.out.print("Dame las horas: ");
        hora = sc.nextInt();
        System.out.print("Dame los minutos: ");
        min = sc.nextInt();
        System.out.print("Dame los segundos: ");
        seg = sc.nextInt();

//            if ((hora < 0 || hora > 23) && (min < 0 || min > 59) && (seg < 0 || seg > 59)) {
//                correcto = false;
//                System.out.println("Has introducido mal la hora. Vuelve a intentarlo");
//            }
//        } while (correcto == false);


        seg++;
        if (seg == 60) {
            seg = 0;
            min++;
        }
        if (min == 60) {
            min = 0;
            hora++;
        }
        if (hora == 24) {
            hora = 0;
        }
        System.out.println("Son las " + hora + ":" + min + ":" + seg);
    }

}
