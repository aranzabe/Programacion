/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_ejercicio35;

/**
 *
 * @author danie
 */
public class DJC_Ejercicio35 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int res, apu, cont, acierto = 0;

        System.out.println("Este programa genera una apuesta y unos resultados al azar en una quiniela");
        for (cont = 1; cont <= 15; cont++) {
            apu = (int) (Math.random() * 3);
            res = (int) (Math.random() * 3);

            System.out.print("Tu apuesta/resultado: ");
            switch (apu) {
                case 0:
                    System.out.print('X' + " ");
                    break;
                case 1:
                case 2:
                    System.out.print(apu + " ");
            }
            //System.out.print("El resultado: ");
            switch (res) {
                case 0:
                    System.out.println('X');
                    break;
                case 1:
                case 2:
                    System.out.println(res);
            }
            if (apu == res) {
                acierto++;
            }

        }
        System.out.println("Has acertado " + acierto + " veces.");
    }

}
