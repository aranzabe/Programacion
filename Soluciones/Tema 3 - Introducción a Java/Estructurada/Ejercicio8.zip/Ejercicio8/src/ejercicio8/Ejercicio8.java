/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio8;

import java.util.Scanner;

/**
 *
 * @author Laura
 */
public class Ejercicio8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        float n;
        int ntrunc;
        Scanner sc = new Scanner(System.in);

        System.out.print("Dame un numero");
        n = sc.nextFloat();

        ntrunc =  (int) n;

        if (n != ntrunc) {
            System.out.println("El numero tiene decimales");
        } else {
            System.out.println("El numero no tiene decimales");
        }

    }

}
