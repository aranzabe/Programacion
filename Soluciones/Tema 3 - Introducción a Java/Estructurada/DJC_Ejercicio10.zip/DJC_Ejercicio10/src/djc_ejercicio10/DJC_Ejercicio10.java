/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_ejercicio10;

import java.util.Scanner;

/**
 *
 * @author danie
 */
public class DJC_Ejercicio10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        float temp, res;
        char tipo;
        Scanner sc = new Scanner(System.in);

        System.out.println("Este programa convierte entre grados centígrados y Farenheit");
        System.out.print("¿En qué unidades está la temperatura que me vas a dar? 0 para centígrados, 1 para Farenheit: ");
        tipo = sc.nextLine().charAt(0);
        System.out.print("¿Cuál es la temperatura? ");
        temp = sc.nextFloat();

        if (tipo == 'F' || tipo == 'f') {
            res = (((float) 9 / 5) * temp) + 32;
            System.out.println(temp + " ºC = " + res + " ºF");
        } else {
            if (tipo == 'C' || tipo == 'c') {
                res = (((float) 5 / 9) * temp) - 32;
                System.out.println(temp + " ºF = " + res + " ºC");
            } else {
                System.out.println("Vuelve a ejecutar el programa introduciendo bien las unidades de temperatura");
            }
        }
    }

}
