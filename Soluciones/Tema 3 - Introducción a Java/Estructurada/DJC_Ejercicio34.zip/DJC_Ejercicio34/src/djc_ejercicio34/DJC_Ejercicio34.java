/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_ejercicio34;

/**
 *
 * @author danie
 */
public class DJC_Ejercicio34 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int res, cont;
        
        System.out.println("Este programa muestra los resultados de una quiniela");
        for (cont = 1; cont <= 15; cont++) {
            res = (int) (Math.random() * 3);//0, 1, 2
            switch(res){
                case 0: System.out.println("X");
                        break;
                case 1:
                case 2: System.out.println(res);
            }
//            if(res == 0){
//                System.out.println('X');
//            }else{
//                System.out.println(res);
//            }
        }
    }
    
}
