/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio6;

import java.util.Scanner;

/**
 *
 * @author Laura
 */
public class Ejercicio6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        float n, result;
        Scanner sc = new Scanner(System.in);

        System.out.print("Dame un numero: ");
        n = sc.nextFloat();

        System.out.println("Comprobaremos si un numero es positivo o negativo");

        if (n >= 0) {
            result = (float) Math.sqrt(n);
            System.out.println("La raiz cuadrada de n es: " + result);
        } else {
            System.out.println("El numero introducido no puede ser negativo");
        }

    }

}
