/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg26;

import java.util.Scanner;

/**
 *
 * @author 34671
 */
public class Ejercicio26 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        char terminar;
        Scanner entrada = new Scanner(System.in);
        
        do{
        
        System.out.println("¿Desea terminar s/n?");
        
        terminar= entrada.nextLine().charAt(0);
        
        }while (terminar=='n'|| terminar=='N');
    
}
}
