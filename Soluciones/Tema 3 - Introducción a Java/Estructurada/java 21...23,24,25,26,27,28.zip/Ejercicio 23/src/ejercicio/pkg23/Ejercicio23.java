/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg23;

import java.util.Scanner;

/**
 *
 * @author 34671
 */
public class Ejercicio23 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int n;
        int res;
        Scanner sc= new Scanner(System.in);
       
        System.out.print("Dame un numero");
        n= sc.nextInt();
        res= n - 1;
        
        
        while(res>0){
            n = n * res;
             res--;
                    
        }
        
        System.out.println("El factorial de n es:" +n);
        
        
        
        
        
        
    }
    
    
    
    
}
