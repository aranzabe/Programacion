/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg24;

import java.util.Scanner;

/**
 *
 * @author 34671
 */
public class Ejercicio24 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int numeros;
        int suma, cont;
        float media, n;
        Scanner sc= new Scanner(System.in);
        
        suma=0;
        cont=0;
        
        System.out.println("Indica cuantas notas hay");
        numeros=sc.nextInt();
        
        
        do{
            System.out.println("Indica las notas");
            n=sc.nextFloat();

            suma= (int) n + suma;
            cont++;
        }while(cont<numeros);
        
        media=(float)suma/numeros;
        System.out.println("La media es:" + media);
        
        
        
        
        
    }
    
}
