/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg25;

import java.util.Scanner;

/**
 *
 * @author 34671
 */
public class Ejercicio25 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int suma, cont;
        float media, n;
        Scanner sc= new Scanner(System.in);
        
        suma=0;
        cont=0;

        
        
        do{
            System.out.println("Indica las notas");
            
            n=sc.nextFloat();
            suma= (int) n + suma;
            cont++;
            
        }while(n>0);
        
        media=(float)suma/cont;
        System.out.println("La media es:" + media);
        
    }
    
}
