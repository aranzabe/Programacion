/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg21;

/**
 *
 * @author 34671
 */
public class Ejercicio21 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int n;
        n=1;      
        
                while(n <= 20){
                    if (n%2==0){
                        System.out.println(+ n);
                    }
                    n++;
                }
                
               
    }
    
}
