/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2;

import java.util.Scanner;

/**
 *
 * @author faranzabe
 */
public class Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {//Algoritmo principal.
        int base, altura;
        int superficie, perimetro;
        Scanner sc = new Scanner(System.in); 
        
        System.out.print("Dame la base: "); //Escribir "Dame la base"
        base = sc.nextInt();                    //Leer base
        System.out.print("Dame la altura: ");
        altura = sc.nextInt();
        
        superficie = base * altura;
        perimetro  = 2 * base + 2 * altura;
        
        System.out.println("La superficies es: " + superficie + " y el perímetro: " + perimetro);
        //Escribir "La superficie es", superficie, " y el perímetro: ", perimetro
        
    }
    
}
