/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Animales;


/**
 *
 * @author laura
 */
public class Factoria {

    public static Gato factoriaGatos() {
        int alea;
        String nombre = "";
        int peso = 0;
        String color = "";
        String raza = "";

        alea = (int) (Math.random() * 4);

        switch (alea) {
            case 0:
                nombre = "Bola";
                raza = "Angora";
                peso = 6;
                color = "Ocre";
                break;
            case 1:
                nombre = "Garras";
                raza = "Atigrado";
                peso = 4;
                color = "Negro y gris";
                break;
            case 2:
                nombre = "Mordisquitos";
                raza = "Extraterrestre";
                peso = 7;
                color = "Ocre";
                break;
            case 3:
                nombre = "Garfield";
                raza = "Persa";
                peso = 10;
                color = "Naranja";
        }

       Gato g = new Gato(nombre, raza, peso, color);

        return g;
    }

    public static Perro factoriaPerro() {
        int alea;
        String nombre = "";
        int peso = 0;
        String color = "";
        String raza = "";

        alea = (int) (Math.random() * 4);

        switch (alea) {
            case 0:
                nombre = "Rufo";
                raza = "Perro de aguas";
                peso = 6;
                color = "Marron pomposo";
                break;
            case 1:
                nombre = "Tony Tony Chopper";
                raza = "Desconocida";
                peso = 8;
                color = "Marron clarito";
                break;
            case 2:
                nombre = "Ideafix";
                raza = "Schnauzer miniatura";
                peso = 4;
                color = "Blanco";
                break;
            case 3:
                nombre = "Valentin";
                raza = "Jack Russell terrier";
                peso = 6;
                color = "Marron y Blanco";
        }

        Perro p = new Animales.Perro(nombre, raza, peso, color);

        return p;
    }

    public static Elefante factoriaElefante() {
        int alea;
        String nombre = "";
        int peso = 0;
        String color = "";
        String raza = "";

        alea = (int) (Math.random() * 3);

        switch (alea) {
            case 0:
                nombre = "Dumbo";
                raza = "Elephas maximus sumatranus";
                peso = 60000;
                color = "Gris";
                break;
            case 1:
                nombre = "Trompi";
                raza = "Elephas maximus maximus.";
                peso = 70000;
                color = "Gris oscuro";
                break;
            case 2:
                nombre = "Oretochas";
                raza = "Elephas maximus indicus";
                peso = 65000;
                color = "Gris azulado";
        }

        Elefante e = new Elefante(nombre, raza, peso, color);

        return e;
    }

}
