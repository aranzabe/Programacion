/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Animales;

import herencias.pkg1.Metodos;

/**
 *
 * @author laura
 */
public class Gato extends Animal implements Metodos{

    public Gato(String nombre, String raza, int peso, String color) {
        super(nombre, raza, peso, color);
    }

    public String hacerRuido() {
        String ruido = "MEEEOOOOOOOW";

        return ruido;
    }

    public boolean hacerCaso() {
        int alea;
        boolean casito = true;

        alea = (int) (Math.random() * 100);

        if (alea <= 5) {
            casito = true;
        } else {
            casito = false;
        }

        return casito;
    }

    public String ToserBolaPelo() {
        int alea;
        String vomito = "";
        boolean SeHizoLaCatastrofe = false;
        alea = (int) (Math.random() * 100);

        if (alea >= 30) {
            SeHizoLaCatastrofe = true;
            vomito = "Mami he gomitado";

        } else {
            SeHizoLaCatastrofe = false;
            vomito = "Aun no he gomitado";
        }
        return vomito;
    }

    @Override
    public String toString() {
        return super.toString();
    }

    @Override
    public boolean comer() {
                int alea;
        boolean TieneHambre = false;
        alea = (int) (Math.random() * 10);

        if (alea >= 5) {
            TieneHambre = true;
        }

        return TieneHambre;
    }

    @Override
    public boolean dormir() {
               int alea;
        boolean TieneCheño = false;
        alea = (int) (Math.random() * 10);

        if (alea >= 5) {
            TieneCheño = true;
        }

        return TieneCheño;
    }

}
