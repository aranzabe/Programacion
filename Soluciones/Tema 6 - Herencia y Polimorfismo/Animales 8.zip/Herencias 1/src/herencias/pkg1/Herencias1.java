/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herencias.pkg1;

import Animales.Factoria;
import Animales.Elefante;
import Animales.Perro;
import Animales.Gato;
import Animales.Animal;

/**
 *
 * @author laura
 */
public class Herencias1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {

        int t = 0;
        int alea;
        boolean conseguido = false;
        Parque pa = new Parque();

        

        while (t <= 40) {

//-------------------------------------------------------------2 SEG
            if (t % 2 == 0) {

            }

//-------------------------------------------------------------10 SEG
            if (t % 10 == 0) {
                alea = (int) (Math.random() * 3);

                switch (alea) {
                    case 0:
                        Gato g = Factoria.factoriaGatos();
                        conseguido = pa.addAnimal(g);
                        break;
                    case 1:
                        Perro p = Factoria.factoriaPerro();
                        conseguido = pa.addAnimal(p);
                        break;
                    case 2:
                        Elefante e = Factoria.factoriaElefante();
                        conseguido = pa.addAnimal(e);
                }
                if (conseguido) {
                    System.out.println("Un animal se ha unido");
                    System.out.println(pa.toString());
                } else {
                    System.out.println("Un animal se ha ido por que no habia hueco");
                }
            }
//-------------------------------------------------------------15 SEG
            if (t % 15 == 0) {
                alea = (int) (Math.random() * pa.returnMax());
                conseguido = pa.moverAnimal(alea);
                if (conseguido) {
                    System.out.println("Un animal se ha movido");
                    System.out.println(pa.toString());
                } else {
                    System.out.println("El animal no ha podido moverse");
                }
            }
//-------------------------------------------------------------20 SEG
            if (t % 20 == 0) {
                alea = (int) (Math.random() * 100);
                if (alea <= 100) {
                    conseguido = pa.dropAnimal();
                    if (conseguido) {
                        System.out.println("Un animal se ha ido del parque ");
                        System.out.println(pa.toString());
                    }
                }
            }
           
            t++;
            Thread.sleep(1000);
        }
    }
}
