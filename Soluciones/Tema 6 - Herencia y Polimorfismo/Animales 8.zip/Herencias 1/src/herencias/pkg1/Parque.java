/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herencias.pkg1;

import Animales.Animal;

/**
 *
 * @author laura
 */
public class Parque {

    private Animales.Animal a[];

    public Parque() {
        this.a = new Animal[20];
    }

    public Parque(int tam) {
        this.a = new Animal[tam];
    }

    public Animal[] getA() {
        return a;
    }

    public boolean addAnimal(Animal a) {
        boolean conseguido = false;
        int i;

        while (!conseguido) {
            i = (int) (Math.random() * this.a.length);

            if (this.a[i] == null) {
                this.a[i] = a;
                conseguido = true;
            } 
        }
        return conseguido;
    }

    public boolean dropAnimal() {
        boolean conseguido = false;
        while (!conseguido) {
            int i = (int) (Math.random() * this.a.length);
            if (this.a[i] != null) {
                this.a[i] = null;
                conseguido = true;
            }
        }
        return conseguido;
    }

    public boolean moverAnimal(int i) {
        boolean conseguido = false;
        int j = i + 1;

        while (!conseguido) {
            if (this.a[i] != null) {
                if (j < this.a.length && this.a[j] == null) {
                    this.a[j] = this.a[i];
                    conseguido = true;
                }
            }
        }
        return conseguido;
    }

    public int returnMax() {
        return this.a.length;
    }

    @Override
    public String toString() {
        String cad = "";

        for (int i = 0; i < a.length; i++) {
            cad += this.a[i] + " " + "\n";
        }
        cad += " ";

        return cad;
    }

}
