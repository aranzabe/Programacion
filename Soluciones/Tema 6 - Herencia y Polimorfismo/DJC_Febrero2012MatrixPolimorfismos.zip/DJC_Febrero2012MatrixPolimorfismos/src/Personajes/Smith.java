/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Personajes;

/**
 *
 * @author danie
 */
public class Smith extends Personaje {
    
    private int capacidadInfeccion;

    public Smith() {
        this.nombre = "Smith";
        this.edad = 40;
        this.localizacion = new Localizacion();
        this.probabilidadVivir = 100;
        this.capacidadInfeccion = 0;
    }
    
    public Smith(Localizacion localizacion) {
        this.nombre = "Smith";
        this.edad = 40;
        this.localizacion = localizacion;
        this.probabilidadVivir = 100;
        this.capacidadInfeccion = 0;
    }

    public int getCapacidadInfeccion() {
        return capacidadInfeccion;
    }

    public void setCapacidadInfeccion(int capacidadInfeccion) {
        this.capacidadInfeccion = capacidadInfeccion;
    }
    
    public void generarCapacidadInfeccion(){
        this.capacidadInfeccion = (int) (Math.random() * 9) + 1;
    }
    
    @Override
    public String toString() {
        return super.toString();
    }
}
