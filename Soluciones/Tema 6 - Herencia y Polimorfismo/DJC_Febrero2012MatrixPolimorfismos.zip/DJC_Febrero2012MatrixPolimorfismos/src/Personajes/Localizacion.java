/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Personajes;

/**
 *
 * @author danie
 */
public class Localizacion {
    private String latitud;
    private String longitud;
    private String ciudadNacimiento;


    public Localizacion() {
        this.latitud = "";
        this.longitud = "";
        this.ciudadNacimiento = "";
    }

    public Localizacion(String latitud, String longitud, String ciudadNacimiento) {
        this.latitud = latitud;
        this.longitud = longitud;
        this.ciudadNacimiento = ciudadNacimiento;
    }

    public String getLatitud() {
        return latitud;
    }

    public void setLatitud(String latitud) {
        this.latitud = latitud;
    }

    public String getLongitud() {
        return longitud;
    }

    public void setLongitud(String longitud) {
        this.longitud = longitud;
    }
    
    public String getCiudadNacimiento(){
        return ciudadNacimiento;
    }

    @Override
    public String toString() {
        return ciudadNacimiento + '(' + latitud + ',' + longitud + ')';
    }
    
    
}
