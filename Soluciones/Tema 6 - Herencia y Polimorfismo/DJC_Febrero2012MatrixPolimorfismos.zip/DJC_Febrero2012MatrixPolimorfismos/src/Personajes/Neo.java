/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Personajes;

/**
 *
 * @author danie
 */
public class Neo extends Personaje {
    
    private boolean soyElElegido;

    public Neo() {
        this.nombre = "Neo";
        this.edad = 30;
        this.localizacion = new Localizacion();
        this.probabilidadVivir = 100;
        this.soyElElegido = false;
    }

    public Neo(Localizacion localizacion) {
        this.nombre = "Neo";
        this.edad = 30;
        this.localizacion = localizacion;
        this.probabilidadVivir = 100;
        this.soyElElegido = false;
    }
    
    public Neo(boolean soyElElegido) {
        this.nombre = "Neo";
        this.edad = 30;
        this.localizacion = new Localizacion();
        this.probabilidadVivir = 100;
        this.soyElElegido = soyElElegido;
    }

    public boolean isSoyElElegido() {
        return soyElElegido;
    }

    public void setSoyElElegido(boolean soyElElegido) {
        this.soyElElegido = soyElElegido;
    }

    public boolean serONoSerElElegido(){
        int alea = (int) (Math.random() * 2);
        if (alea == 0){
            this.soyElElegido = false;
        } else {
            this.soyElElegido = true;
        }
        return this.soyElElegido;
    }
    
    @Override
    public String toString() {
        String cad = "";
        
        cad += super.toString() + ' ';
        if (this.soyElElegido){
            cad += "Soy el elegido";
        } else {
            cad += "No soy el elegido";
        }
        return cad;
    }
    
    
}
