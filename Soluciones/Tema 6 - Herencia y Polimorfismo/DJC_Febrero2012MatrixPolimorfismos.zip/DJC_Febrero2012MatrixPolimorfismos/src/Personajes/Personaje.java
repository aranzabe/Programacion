/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Personajes;

/**
 *
 * @author danie
 */
public class Personaje {

    protected String nombre;
    protected Localizacion localizacion;
    protected int edad;
    protected int probabilidadVivir;
    protected static int CREADOS;

    static {
        CREADOS = 0;
    }

    public Personaje() {
        this.nombre = "";
        this.localizacion = new Localizacion();
        this.edad = 0;
        this.probabilidadVivir = 0;
        CREADOS++;
        
    }

    public Personaje(String nombre, Localizacion localizacion, int edad, int probabilidadVivir) {
        this.nombre = nombre;
        this.localizacion = localizacion;
        this.edad = edad;
        this.probabilidadVivir = probabilidadVivir;
        CREADOS++;
    }

    public String getNombre() {
        return nombre;
    }

    public Localizacion getLocalizacion() {
        return localizacion;
    }

    public int getEdad() {
        return edad;
    }

    public int getProbabilidadVivir() {
        return probabilidadVivir;
    }

    public static int getCREADOS() {
        return CREADOS;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setProbabilidadVivir(int probabilidadVivir) {
        this.probabilidadVivir = probabilidadVivir;
    }
    
    @Override
    public String toString() {
        return nombre + ", de " + localizacion.toString() + ", " + edad + " años, " + probabilidadVivir + '%';
    }
    
}
