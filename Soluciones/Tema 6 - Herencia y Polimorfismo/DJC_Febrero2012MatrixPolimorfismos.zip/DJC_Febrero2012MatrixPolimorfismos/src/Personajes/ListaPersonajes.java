/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Personajes;

/**
 *
 * @author faranzabe
 */
public class ListaPersonajes {

    //******************* Clase auxiliar ***********************
    private class Nodo {

        private Personaje dato;
        private Nodo sig;

        public Nodo(Personaje dato) {
            this.dato = dato;
            this.sig = null;
        }

    }
    //********* Fin de la declaración clase auxiliar *************
    private Nodo l;

    public ListaPersonajes() {
        this.l = null;
    }

    public void addDato(Personaje i) {
        Nodo nuevo = new Nodo(i);

        if (this.l == null) {
            this.l = nuevo;
        } else {
            nuevo.sig = l;
            this.l = nuevo;
        }
    }

    public void addDatoFinal(Personaje i) {
        Nodo nuevo = new Nodo(i);
        Nodo aux = null;

        if (this.l == null) {
            this.l = nuevo;
        } else {
            aux = this.l;
            while (aux.sig != null) {
                aux = aux.sig;
            }
            aux.sig = nuevo;
        }
    }

    public boolean borrarPrimero() {
        boolean conseguido = false;
        if (this.l != null) {
            this.l = this.l.sig;
            conseguido = true;
        }
        return conseguido;
    }

    public boolean borrarUltimo() {
        boolean conseguido = false;
        Nodo aux;

        if (this.l != null) {
            conseguido = true;
            if (this.l.sig == null) {
                this.l = null;
            } else {
                aux = this.l;
                while (aux.sig.sig != null) {
                    aux = aux.sig;
                }
                aux.sig = null;
            }
        }
        return conseguido;
    }

    public boolean borrarPosicion(int pos) {
        boolean conseguido = false;
        Nodo aux = this.l;
        Nodo ant = null;
        int cont = 0;

        while (cont != pos && aux != null) {
            ant = aux;
            aux = aux.sig;
            cont++;
        }
        if (pos == cont) {
            conseguido = true;
            if (pos == 0) {
                this.borrarPrimero();
            } else {
                ant.sig = aux.sig;
            }
        }
        return conseguido;
    }

    public boolean insertarPosicion(int pos, Personaje o) {
        boolean conseguido = false;
        Nodo aux = this.l;
        Nodo ant = null;
        Nodo nuevo = new Nodo(o);
        int cont = 0;

        while (cont != pos && aux != null) {
            ant = aux;
            aux = aux.sig;
            cont++;
        }
        if (pos == 0) {
            nuevo.sig = this.l;
            this.l = nuevo;
        } else {
            nuevo.sig = aux;
            ant.sig = nuevo;
        }
        conseguido = true;

        return conseguido;
    }

    @Override
    public String toString() {
        String cad = "";
        Nodo aux = this.l;
        while (aux != null) {
            cad += aux.dato.toString() + "\n";
            aux = aux.sig;
        }
        return cad;
    }

    public Personaje getPrimero() {
        Personaje n = null;
        if (this.l != null) {
            n = this.l.dato;
        }
        return n;
    }

    public Personaje getUltimo() {
        Personaje n = null;
        Nodo aux = this.l;
        while (aux.sig != null) {
            aux = aux.sig;
        }
        n = aux.dato;
        return n;
    }

    /**
     * Cantidad de nodos.
     *
     * @return
     */
    public int cuantosElementos() {
        int cuantos = 0;
        Nodo aux = this.l;

        while (aux != null) {
            aux = aux.sig;
            cuantos++;
        }

        return cuantos;
    }

    /**
     * El dato que hay en la posición i. Empezando a contar desde 0.
     *
     * @param i
     * @return
     */
    public Personaje getPos(int i) {
        int cont = 0;
        Nodo aux = this.l;

        while (cont < i && aux != null) {
            cont++;
            aux = aux.sig;
        }
        return aux.dato;
    }

    /**
     * Cambiar el dato que haya en la posición i por nuevoValor. Devolveremos
     * false si la posición no existe. v[i] = nuevoValor;
     *
     * @param i
     * @param nuevoValor
     * @return
     */
    public boolean setPos(int i, Personaje nuevoValor) {
        boolean conseguido = false;
        int cont = 0;
        Nodo aux = this.l;

        while (cont < i && aux != null) {
            cont++;
            aux = aux.sig;
        }
        if (cont == i && aux != null) {
            aux.dato = nuevoValor;
            conseguido = true;
        }
        return conseguido;
    }

//    public int buscarPosicion(String cad) {
//        int pos = 0;
//        boolean encontrado = false;
//        Nodo aux = this.l;
//
//        while (pos < this.cuantosElementos() && !encontrado) {
//            if (aux.dato.getNumSerie().equals(cad)) {
//                encontrado = true;
//            } else {
//                aux = aux.sig;
//                pos++;
//            }
//        }
//        return pos;
//    }
}
