/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mundo;

import Personajes.*;

/**
 *
 * @author danie
 * @deprecated 
 */
public class Casilla {

    private Personaje personaje;
    private Neo neo;
    private Smith smith;

    public Casilla() {
        this.personaje = null;
        this.neo = null;
        this.smith = null;
    }

    public Personaje getPersonaje() {
        return personaje;
    }

    public Neo getNeo() {
        return neo;
    }

    public Smith getSmith() {
        return smith;
    }

    public void setPersonaje(Personaje personaje) {
        this.personaje = personaje;
    }

    public void setNeo(Neo neo) {
        this.neo = neo;
    }

    public void setSmith(Smith smith) {
        this.smith = smith;
    }

    /**
     * Este método comprueba qué personaje hay en una casilla, si es que hay
     *
     * @return -1 si está vacía, 0 si hay un Neo, 1 si hay un Smith y 2 si hay
     * un personaje genérico
     */
    public int quienHayAhi() {
        int cod = -1;

        if (this.neo != null && this.smith == null && this.personaje == null) {
            cod = 0;
        } else if (this.smith != null && this.neo == null && this.personaje == null) {
            cod = 1;
        } else if (this.personaje != null && this.neo == null && this.smith == null) {
            cod = 2;
        }
        return cod;
    }

    @Override
    public String toString() {
        String cad = "";

        if (this.neo != null) {
            cad += neo.toString();
        } else if (this.smith != null) {
            cad += smith.toString();
        } else {
            cad += personaje.toString();
        }
        return cad;
    }

}
