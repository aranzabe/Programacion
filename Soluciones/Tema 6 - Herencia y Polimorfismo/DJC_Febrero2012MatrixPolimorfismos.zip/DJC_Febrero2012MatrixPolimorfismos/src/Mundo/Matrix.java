/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mundo;

import Personajes.*;
import Principal.Factoria;

/**
 *
 * @author danie
 */
public class Matrix {

    private Personaje[][] mapa;

    public Matrix() {
        this.mapa = new Personaje[5][5];
    }

    public Matrix(int f, int c) {
        this.mapa = new Personaje[f][c];
    }

    public int getDimensionFilas() {
        return this.mapa.length;
    }

    public int getDimensionColumnas() {
        return this.mapa[0].length;
    }

    public Personaje getPersonaje(int f, int c) {
        return this.mapa[f][c];
    }

    public int getNumCasillas() {
        return this.getDimensionFilas() * this.getDimensionColumnas();
    }

    public void setPersonaje(Personaje p, int f, int c){
        this.mapa[f][c] = p;
    }
    
    /**
     * Este método comprueba qué personaje hay en una casilla, si es que hay
     *
     * @return -1 si está vacía, 0 si hay un Neo, 1 si hay un Smith y 2 si hay
     * un personaje genérico
     */
    public int quienHayAhi(int f, int c) {
        int cod = -1;

        if (this.getPersonaje(f, c) != null) {
            cod = 2;
            if (this.getPersonaje(f, c) instanceof Neo) {
                cod = 0;
            } else if (this.getPersonaje(f, c) instanceof Smith) {
                cod = 1;
            }
        }
        return cod;
    }

    /**
     * Este método inicializa una casilla en una posición dada
     *
     * @param p la casilla
     * @param f la fila de la posición
     * @param c la columna de la posición
     * @return true si se ha conseguido, false si no
     */
    public boolean addCasilla(Personaje p, int f, int c) {
        boolean conseguido = false;

        if (this.getPersonaje(f, c) == null) {
            this.mapa[f][c] = p;
            conseguido = true;
        }
        return conseguido;
    }

    /**
     * Este método pone a un personaje sobre una casilla con determinada
     * posición
     *
     * @param p el personaje, Neo o Smith
     * @param f la fila de la posición
     * @param c la columna de la posición
     * @return true si lo ha conseguido, false si no
     */
    public boolean addPersonaje(Personaje p, int f, int c) {
        boolean conseguido = false;

        if (this.quienHayAhi(f,c) == -1) {
            this.setPersonaje(p,f,c);
            conseguido = true;
        }
        return conseguido;
    }

    /**
     * Este método saca un personaje del mundo real para meterlo en una casilla
     * de determinada posición de Matrix
     *
     * @param m el mundo real
     * @param f la fila de la posición
     * @param c la columna de la posición
     * @return true si lo ha conseguido, false si no
     */
    public boolean transferirPersonaje(MundoReal m, int f, int c) {
        boolean conseguido = false;

        if (this.quienHayAhi(f, c)== -1) {
            this.setPersonaje(m.getPersonaje(),f,c);
            m.borrarPersonaje();
            conseguido = true;
        }
        return conseguido;
    }

    public void evaluarSituacion(MundoReal m) {
        Personaje p = null;
        for (int i = 0; i < this.getDimensionFilas(); i++) {
            for (int j = 0; j < this.getDimensionColumnas(); j++) {
                p = this.getPersonaje(i, j);
                if (this.quienHayAhi(i, j) == 2) {
                    if (p.getProbabilidadVivir() < 30) {
                        this.setPersonaje(null, i, j);
                        this.transferirPersonaje(m, i, j);
                    } else {
                        p.setProbabilidadVivir(p.getProbabilidadVivir() - 10);
                    }
                }
            }
        }
    }

    public void infeccionSmiths() {
        Smith s = null;
        int infeccion = 0;
        //Recorro la matriz
        for (int i = 0; i < this.getDimensionFilas(); i++) {
            for (int j = 0; j < this.getDimensionColumnas(); j++) {
                //Si aquí hay un Smith...
                if (this.quienHayAhi(i, j) == 1) {
                    s = (Smith) this.getPersonaje(i, j);
                    s.generarCapacidadInfeccion();
                    infeccion = s.getCapacidadInfeccion();
                    //Se recorren las casillas circundantes
                    int k = i - 1;
                    while (k <= i + 1 && infeccion > 0) {
                        int l = j - 1;
                        while (l <= j + 1 && infeccion > 0) {
                            //Compruebo que las casillas están dentro de la matriz
                            if (k >= 0 && l >= 0 && k < this.getDimensionFilas() && l < this.getDimensionColumnas()) {
                                //Compruebo que ahí hay un personaje genérico
                                if (this.quienHayAhi(k, l) == 2) {
                                    this.setPersonaje(Factoria.factoriaPersonaje(1), k, l);
                                    infeccion--;
                                }
                            }
                            l++;
                        }
                        k++;
                    }
                }
            }
        }
    }

    public void asesinarSmiths(MundoReal m) {
        Neo n = null;
        //Recorro la matriz
        for (int i = 0; i < this.getDimensionFilas(); i++) {
            for (int j = 0; j < this.getDimensionColumnas(); j++) {
                //Si aquí hay un Neo...
                if (this.quienHayAhi(i, j) == 0) {
                    n = (Neo) this.getPersonaje(i, j);
                    //Se recorren las casillas circundantes
                    for (int k = i - 1; k <= i + 1; k++) {
                        for (int l = j - 1; l <= j + 1; l++) {
                            //Compruebo que las casillas están dentro de la matriz
                            if (k >= 0 && l >= 0 && k < this.getDimensionFilas() && l < this.getDimensionColumnas()) {
                                //Compruebo que ahí hay un Smith
                                if (this.quienHayAhi(k, l) == 1) {
                                    //Lo mato
                                    this.setPersonaje(null, k, l);
                                    //Pongo un personaje genérico en su lugar
                                    this.transferirPersonaje(m, k, l);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public int[] buscandoANeo() {
        boolean encontrado = false;
        int[] pos = new int[2];
        int i = 0, j = 0;

        while (!encontrado && i < this.getDimensionFilas()) {
            j = 0;
            while (!encontrado && j < this.getDimensionColumnas()) {
                if (this.quienHayAhi(i, j) == 0) {
                    pos[0] = i;
                    pos[1] = j;
                    encontrado = true;
                }
                j++;
            }
            i++;
        }
        return pos;
    }

    public void cambioPosicionNeo(MundoReal mundo, Neo neo) {
        int aleaF = (int) (Math.random() * this.getDimensionFilas());
        int aleaC = (int) (Math.random() * this.getDimensionColumnas());
        int[] pos = this.buscandoANeo();
        Personaje p = null;

        if (this.quienHayAhi(aleaF, aleaC) == 1) {
            this.setPersonaje(null, aleaF, aleaC);
            this.setPersonaje(neo, aleaF, aleaC);
            this.setPersonaje(null, pos[0], pos[1]);
            this.transferirPersonaje(mundo, pos[0], pos[1]);
        } else if (this.quienHayAhi(aleaF, aleaC) == 2) {
            p = this.getPersonaje(aleaF, aleaC);
            this.setPersonaje(null, aleaF, aleaC);
            this.setPersonaje(neo, aleaF, aleaC);
            this.setPersonaje(null, pos[0], pos[1]);
            this.setPersonaje(p, pos[0], pos[1]);
        }
    }

    @Override
    public String toString() {
        String cad = "Mapa de Matrix:\n";

        for (int i = 0; i < this.getDimensionFilas(); i++) {
            for (int j = 0; j < this.getDimensionColumnas(); j++) {
                cad += this.mapa[i][j].toString() + "  ";
            }
            cad += "\n";
        }
        return cad;
    }

}
