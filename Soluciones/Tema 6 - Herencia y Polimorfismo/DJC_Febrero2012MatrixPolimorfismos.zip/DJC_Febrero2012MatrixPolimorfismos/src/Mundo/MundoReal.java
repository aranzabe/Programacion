/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mundo;

import Personajes.*;

/**
 *
 * @author danie
 */
public class MundoReal {
    
    private ListaPersonajes personajes;

    public MundoReal() {
        this.personajes = new ListaPersonajes();
    }
    
    public void addPersonaje(Personaje p){
        this.personajes.addDatoFinal(p);
    }
    
    public void borrarPersonaje(){
        this.personajes.borrarPrimero();
    }
    
    public Personaje getPersonaje(){
        return this.personajes.getPrimero();
    }

    public Personaje obtenerPersonaje(){
        Personaje p = this.personajes.getPrimero();
        this.borrarPersonaje();
        return p;
    }
    
    @Override
    public String toString() {
        return this.personajes.toString();
    }
    
    
    
}
