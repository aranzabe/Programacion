/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Principal;

import Personajes.*;
import Mundo.*;
import Personajes.Localizacion;
import Personajes.Neo;
import Personajes.Personaje;
import Personajes.Smith;

/**
 *
 * @author usuariob
 */
public class Factoria {

    /**
     * Este método genera una localización aleatoria, compuesta por una latitud,
     * una longitud y una ciudad
     *
     * @return una localización generada al azar
     */
    public static Localizacion factoriaLocalizacion() {
        int aleaCiudad = (int) (Math.random() * 6);
        int aleaLati = (int) (Math.random() * 201) - 100;
        int aleaLong = (int) (Math.random() * 201) - 100;
        String latitud = "", longitud = "";
        String ciudad = "";

        switch (aleaCiudad) {
            case 0:
                ciudad = "Nueva York";
                break;
            case 1:
                ciudad = "Londres";
                break;
            case 2:
                ciudad = "Caracuel";
                break;
            case 3:
                ciudad = "Bilbao";
                break;
            case 4:
                ciudad = "Pekín";
                break;
            case 5:
                ciudad = "París";
        }
        if (aleaLati < 0) {
            latitud = Math.abs(aleaLati) + "S";
        } else {
            latitud = aleaLati + "N";
        }
        if (aleaLong < 0) {
            longitud = Math.abs(aleaLong) + "E";
        } else {
            longitud = aleaLati + "E";
        }

        return new Localizacion(latitud, longitud, ciudad);
    }

    /**
     * Este método genera un personaje con un nombre, una edad, una probabilidad
     * de supervivencia y una localización al azar
     *
     * @return un personaje al azar
     * @see factoriaLocalizacion()
     */
    public static Personaje factoriaPersonaje(int cod) {
        Personaje p = null;
        Localizacion l = null;
        int aleaNombre = 0;
        int edad = 0;
        int probVivir = 0;
        String nombre = "";

        switch (cod) {
            case 0:
                l = new Localizacion("500N", "500E", "Calzadilla de los Barros");
                p = new Neo(l);
                break;
            case 1:
                l = new Localizacion("500S", "500O", "Retuerta del Bullaque");
                p = new Smith(l);
                break;
            case 2:
                aleaNombre = (int) (Math.random() * 8);
                edad = (int) (Math.random() * 70) + 18;
                probVivir = (int) (Math.random() * 100) + 1;
                switch (aleaNombre) {
                    case 0:
                        nombre = "Pepe";
                        break;
                    case 1:
                        nombre = "José María";
                        break;
                    case 2:
                        nombre = "Mariví";
                        break;
                    case 3:
                        nombre = "Paquita Quicardia";
                        break;
                    case 4:
                        nombre = "Ester Colero";
                        break;
                    case 5:
                        nombre = "Chiquito";
                        break;
                    case 6:
                        nombre = "Lucifer";
                        break;
                    case 7:
                        nombre = "Elena";
                }
                p = new Personaje(nombre, factoriaLocalizacion(), edad, probVivir);
        }
        return p;
    }

    /**
     * Este método genera el mundo real y lo rellena con 200 personajes
     * genéricos
     *
     * @return Un objeto de clase MundoReal con 200 personajes genéricos
     * @see factoriaPersonaje()
     */
    public static MundoReal factoriaMundoReal() {
        MundoReal m = new MundoReal();
        for (int i = 0; i < 200; i++) {
            m.addPersonaje(factoriaPersonaje(2));
        }
        return m;
    }

    /**
     * Este método inicializa una casilla
     *
     * @return una casilla inicializada
     * @deprecated
     */
    public static Casilla factoriaCasilla() {
        return new Casilla();
    }

    /**
     * Este método genera Matrix, iniciando sus casillas y colocando al azar a
     * un Neo, un Smith y personajes genéricos hasta llenar la matriz
     *
     * @param mundo el mundo real del que se cogen los personajes genéricos
     * @param neo el personaje Neo
     * @return Matrix de 5x5 relleno
     * @see factoriaCasilla(), factoriaNeo(), factoriaSmith()
     */
    public static Matrix factoriaMatrix(MundoReal mundo, Personaje neo) {
        Matrix m = new Matrix();
        int personajes = m.getNumCasillas() - 2;
        int aleaF = 0, aleaC = 0;
        boolean insertado = false;
        boolean conseguido = false;

        //Colocamos los personajes
        while (personajes > 0) {

            Personaje pe = mundo.obtenerPersonaje();
            do {
                aleaF = (int) (Math.random() * m.getDimensionFilas());
                aleaC = (int) (Math.random() * m.getDimensionColumnas());
                conseguido = m.addPersonaje(pe, aleaF, aleaC);
                if (conseguido) {
                    personajes--;
                }
            } while (!conseguido);
        }

        //Colocamos a Neo y Smith
        while (!insertado) {
            aleaF = (int) (Math.random() * m.getDimensionFilas());
            aleaC = (int) (Math.random() * m.getDimensionColumnas());
            insertado = m.addPersonaje(neo, aleaF, aleaC);
        }
        insertado = false;
        while (!insertado) {
            aleaF = (int) (Math.random() * m.getDimensionFilas());
            aleaC = (int) (Math.random() * m.getDimensionColumnas());
            insertado = m.addPersonaje(factoriaPersonaje(1), aleaF, aleaC);
        }
        return m;
    }

    /**
     * Este método genera Matrix, iniciando sus casillas y colocando al azar a
     * un Neo, un Smith y personajes genéricos hasta llenar la matriz
     *
     * @param mundo el mundo real del que se cogen los personajes genéricos
     * @param f el número de filas del mapa de Matrix
     * @param c el número de columnas el mapa de Matrix
     * @return Matrix relleno
     * @see factoriaCasilla(), factoriaNeo(), factoriaSmith()
     */
    public static Matrix factoriaMatrix(MundoReal mundo, Neo neo, int f, int c) {
        Matrix m = new Matrix();
        int personajes = m.getNumCasillas() - 2;
        int aleaF = 0, aleaC = 0;
        boolean insertado = false;

        //Colocamos los personajes
        while (personajes > 0) {
            aleaF = (int) (Math.random() * m.getDimensionFilas());
            aleaC = (int) (Math.random() * m.getDimensionColumnas());
            if (m.transferirPersonaje(mundo, aleaF, aleaC)) {
                personajes--;
            }
        }

        //Colocamos a Neo y Smith
        while (!insertado) {
            aleaF = (int) (Math.random() * m.getDimensionFilas());
            aleaC = (int) (Math.random() * m.getDimensionColumnas());
            insertado = m.addPersonaje(neo, aleaF, aleaC);
        }
        insertado = false;
        while (!insertado) {
            aleaF = (int) (Math.random() * m.getDimensionFilas());
            aleaC = (int) (Math.random() * m.getDimensionColumnas());
            insertado = m.addPersonaje(factoriaPersonaje(1), aleaF, aleaC);
        }
        return m;
    }

}
