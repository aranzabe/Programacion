/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Principal;

import Personajes.*;
import Mundo.*;

/**
 *
 * @author danie
 */
public class DJC_Febrero2012Matrix {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        int t = 0;
        //Me interesa tener el Neo a mano, así que a éste si lo creo en el principal
        Neo neo = (Neo) Factoria.factoriaPersonaje(0);
        //Iniciamos el mundo real y Matrix
        MundoReal mundo = Factoria.factoriaMundoReal();
        System.out.println(mundo);
        Matrix matrix = Factoria.factoriaMatrix(mundo, neo);
        System.out.println(matrix);
        
        //Empieza la simulación
        while (t < 300){
            //Comprobación de personajes y sus probabilidades de vivir
            matrix.evaluarSituacion(mundo);
            //El agente Smith entra en acción
            if (t % 2 == 0){
                matrix.infeccionSmiths();
            }

            //Neo entra en acción
            if (t % 5 == 0){
                if (neo.serONoSerElElegido()){
                    matrix.asesinarSmiths(mundo);
                }
                matrix.cambioPosicionNeo(mundo, neo);
            }
            System.out.println(matrix);
            t++;
            Thread.sleep(1000);
        }
    }
    
}
