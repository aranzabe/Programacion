/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herencias.pkg1;

/**
 *
 * @author laura
 */
public class Animal {

    protected String nombre;
    protected String raza;
    protected int peso;
    protected String color;

    public Animal() {
        this.nombre = "";
        this.raza = "";
        this.peso = 0;
        this.color = "";
    }

    public Animal(String nombre, String raza, int peso, String color) {
        this.nombre = nombre;
        this.raza = raza;
        this.peso = peso;
        this.color = color;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public int getPeso() {
        return peso;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public boolean vacunar() {
        int alea;
        boolean YaLeTocaLaVacunita = false;
        alea = (int) (Math.random() * 10);

        if (alea >= 5) {
            YaLeTocaLaVacunita = true;
        }

        return YaLeTocaLaVacunita;
    }

    public boolean hacerCaso() {
        boolean casito = true;

        return casito;
    }

    @Override
    public String toString() {
        String cad = "";
        cad = "Nombre: " + this.nombre + "\n";
        cad += "Raza: " + this.raza + "\n";
        cad += "Peso: " + this.peso + "\n";
        cad += "Color: " + this.color + "\n";

        return cad;
    }

}
