/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herencias.pkg1;

/**
 *
 * @author laura
 */
public class Elefante extends Animal implements AnimalInterface{

    public Elefante(String nombre, String raza, int peso, String color) {
        super(nombre, raza, peso, color);
    }

    @Override
    public boolean comer() {
        int alea;
        boolean TieneHambre = false;
        alea = (int) (Math.random() * 10);

        if (alea >= 5) {
            TieneHambre = true;
        }

        return TieneHambre;
    }

    @Override
    public boolean dormir() {
        int alea;
        boolean TieneCheño = false;
        alea = (int) (Math.random() * 10);

        if (alea >= 5) {
            TieneCheño = true;
        }

        return TieneCheño;
    }

    @Override
    public String hacerRuido() {
        String ruido = "BARRITAAAA";

        return ruido;
    }

    public String EscupirAgua() {
        int alea;
        String escupir = "";

        alea = (int) (Math.random() * 10);

        if (alea <= 5) {
            escupir = "Escupe agua felizmente y te riega";
        } else {
            escupir = "No escupira agua de momento...";
        }

        return escupir;
    }

    public boolean hacerCaso() {
        int alea;
        boolean casito = true;

        alea = (int) (Math.random() * 100);

        if (alea <= 5) {
            casito = true;
        } else {
            casito = false;
        }

        return casito;
    }

    @Override
    public String toString() {
        String c = "";
        c = super.toString() + "\n";
        return c;
    }

}
