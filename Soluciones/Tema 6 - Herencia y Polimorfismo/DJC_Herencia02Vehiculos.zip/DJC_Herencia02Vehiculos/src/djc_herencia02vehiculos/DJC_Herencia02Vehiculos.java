/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_herencia02vehiculos;

import djc_herencia02vehiculos.Vehiculo.*;

/**
 *
 * @author usuariob
 */
public class DJC_Herencia02Vehiculos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Turismo t = new Turismo("Peugeot", "206", "Blanco", "1234AAA", 5);
        Camion c = new Camion("Audi", "A500", "Negro con llamas", "5678BBB", 10000);
        Motocicleta m = new Motocicleta("Yamaha", "El que sea", "Rosa chicle", "9012CCC", 125);
        System.out.println(t);
        System.out.println(c);
        System.out.println(m);
    }
    
}
