/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_herencia02vehiculos.Vehiculo;

/**
 *
 * @author usuariob
 */
public class Turismo extends VehiculoMotor {
    private int numPlazas;

    public Turismo() {
        super();
    }

    public Turismo(String marca, String modelo, String color, String matricula, int numPlazas) {
        super(marca, modelo, color, matricula);
        this.numPlazas = numPlazas;
    }

    public int getNumPlazas() {
        return numPlazas;
    }

    @Override
    public String toString() {
        return "Turismo{" + super.toString() + ", numPlazas=" + numPlazas + '}';
    }
    
    public String tipoDeUso(){
        String uso = "";
        int alea = (int) (Math.random() * 2);
        
        if (alea == 0){
            uso = "Particular";
        } else {
            uso = "Profesional";
        }
        return uso;
    }
}
