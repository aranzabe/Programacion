/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_herencia02vehiculos.Vehiculo;

/**
 *
 * @author usuariob
 */
public class Camion extends VehiculoMotor {

    private float pesoMax;

    public Camion() {
        super();
    }


    public Camion(String marca, String modelo, String color, String matricula, float pesoMax) {
        super(marca, modelo, color, matricula);
        this.pesoMax = pesoMax;
    }

    public float getPesoMax() {
        return pesoMax;
    }

    @Override
    public String toString() {
        return "Camion{" + super.toString() + ", pesoMax=" + pesoMax + '}';
    }
    
    public boolean esMercanciaPeligrosa() {
        return (int) (Math.random() * 100) < 10;
    }
}
