/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_herencia02vehiculos.Vehiculo;

/**
 *
 * @author usuariob
 */
public class VehiculoMotor {

    protected String marca;
    protected String modelo;
    protected String color;
    protected String matricula;
    protected boolean motorEncendido;
    protected int marchaActual;
    protected int velocidadActual;

    public VehiculoMotor() {
        this.marca = "";
        this.modelo = "";
        this.color = "";
        this.matricula = "";
    }

    public VehiculoMotor(String marca, String modelo, String color, String matricula) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.matricula = matricula;
    }

    @Override
    public String toString() {
        return "Vehículo{" + "marca=" + marca + ", modelo=" + modelo + ", color=" + color + ", matricula=" + matricula + ", motorEncendido=" + motorEncendido + ", marchaActual=" + marchaActual + ", velocidadActual=" + velocidadActual + '}';
    }

    public boolean isMotorEncendido() {
        return motorEncendido;
    }

//    public void setMotorEncendido(boolean motorEncendido) {
//        this.motorEncendido = motorEncendido;
//    }
    public void arrancarMotor() {
        this.motorEncendido = true;
    }

    public void pararMotor() {
        this.motorEncendido = false;
    }
    
    public int getMarchaActual() {
        return marchaActual;
    }

    public boolean subirMarcha() {
        boolean conseguido = false;
        if (this.marchaActual < 6) {
            this.marchaActual++;
            conseguido = true;
        }
        return conseguido;
    }

    public boolean bajarMarcha() {
        boolean conseguido = false;
        if (this.marchaActual > 0) {
            this.marchaActual--;
            conseguido = true;
        }
        return conseguido;
    }

    public int getVelocidadActual() {
        return velocidadActual;
    }

    public void acelera() {
        this.velocidadActual += 5;
    }

    public void frena() {
        this.velocidadActual -= 5;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public String getColor() {
        return color;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

}
