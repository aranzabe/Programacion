/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_herencia02vehiculos.Vehiculo;

/**
 *
 * @author usuariob
 */
public class Motocicleta extends VehiculoMotor {
    private int cilindrada;

    public Motocicleta() {
        super();
    }

    public Motocicleta(String marca, String modelo, String color, String matricula, int cilindrada) {
        super(marca, modelo, color, matricula);
        this.cilindrada = cilindrada;
    }

    public int getCilindrada() {
        return cilindrada;
    }

    @Override
    public String toString() {
        return "Motocicleta{" + super.toString() + ", cilindrada=" + cilindrada + '}';
    }
    
    public boolean necesitaCarnet(){
        return this.cilindrada >= 125;
    }
}
