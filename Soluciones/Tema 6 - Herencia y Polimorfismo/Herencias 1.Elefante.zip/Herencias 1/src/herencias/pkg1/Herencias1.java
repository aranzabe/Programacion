/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herencias.pkg1;

/**
 *
 * @author laura
 */
public class Herencias1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String result = "";
        boolean caso;
        Gato Bola = new Gato("Bola", "Angora", 6, "Ocre");
        Perro Rufo = new Perro("Rufo", "Perro de aguas", 20, "Marron pomposo");
        Elefante Dumbo = new Elefante("Dumbo", "Elephas maximus maximus", 6000, "Grisaceo");

        System.out.println(Bola);
        System.out.println(Rufo);
        System.out.println(Dumbo);

        //************************************GATO*****************************
        System.out.println("El gato: ");

        result = Bola.ToserBolaPelo();
        System.out.println("Las bolas de pelo: " + result);

        result = Bola.hacerRuido();
        System.out.println("El Gato hace: "+result);

        caso = Bola.hacerCaso();
        System.out.println("Caso: " + caso);

        //************************************PERRO*****************************
        System.out.println("El perrete: ");

        result = Rufo.sacarPaseo();
        System.out.println("El paseo: " + result);

        result = Rufo.hacerRuido();
        System.out.println("El Perro hace: "+result);

        caso = Rufo.hacerCaso();
        System.out.println("Caso: " + caso);

        //************************************ELEFANTE*****************************
        System.out.println("El elefante: ");

        result = Dumbo.EscupirAgua();
        System.out.println("El baño: " + result);

        result = Dumbo.hacerRuido();
        System.out.println("El Elefante hace: "+result);

        caso = Dumbo.hacerCaso();
        System.out.println("Caso: " + caso);
    }

}
