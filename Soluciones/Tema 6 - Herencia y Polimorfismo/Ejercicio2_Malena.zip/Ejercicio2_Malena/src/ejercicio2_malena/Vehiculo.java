/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2_malena;

/**
 *
 * @author Malena
 */
public class Vehiculo {
    protected String marca;
    protected String modelo;
    protected String color;
    protected String matricula;
    
    public Vehiculo() {
        this.marca = "";
        this.modelo = "";
        this.color = "";
        this.matricula = "";
    }

    public Vehiculo(String marca, String modelo, String color, String matricula) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.matricula = matricula;
    }

    @Override
    public String toString() {
        return "Vehiculo{" + "marca=" + marca + ", modelo=" + modelo + ", color=" + color + ", matricula=" + matricula + '}';
    }
    
    
}
