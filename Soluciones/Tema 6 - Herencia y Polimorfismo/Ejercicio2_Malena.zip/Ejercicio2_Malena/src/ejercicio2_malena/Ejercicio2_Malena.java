/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2_malena;

/**
 *
 * @author Malena
 */
public class Ejercicio2_Malena {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Turismo t = new Turismo(4, "Seat", "Ibiza", "Rojo", "123ABC");
        System.out.println(t);
        
        Camion c = new Camion(300, "Daf Trucks", "DF34", "Blanca", "564TYU");
        System.out.println(c);
        
        Motocicleta m = new Motocicleta (120, "Ducati", "Monster", "Roja", "BNM604");
        System.out.println(m);
        
        System.out.println("Mi coche tiene: " + t.getNumPlazas() + " plazas.");
        
        if(c.esMercanciaPeligrosa()){
            System.out.println("Es mercancia muy peligrosa...");
        }else{
            System.out.println("Esta mercancia no es peligrosa.");
        }
        
        System.out.println("La moto tiene de cilindrada: " + m.getCilindrada());
        
        if(m.necesitaCarnet()){
            System.out.println("No es necesario que tengas carnet.");
        }else{
            System.out.println("O te sacas el carnet o no conduces la moto.");
        }
        
        if (t.tipoUso() == 1){
            System.out.println("Su tipo es profesional.");
        }else{
            System.out.println("Su tipo es particular.");
        }
    }
    
}
