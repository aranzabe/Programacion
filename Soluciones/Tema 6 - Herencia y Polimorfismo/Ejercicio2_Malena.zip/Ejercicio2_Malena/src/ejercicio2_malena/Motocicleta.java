/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2_malena;

/**
 *
 * @author Malena
 */
public class Motocicleta extends Vehiculo{
    private int cilindrada;

    public Motocicleta() {
    }

    public Motocicleta(int cilindrada) {
        this.cilindrada = cilindrada;
    }

    public Motocicleta(int cilindrada, String marca, String modelo, String color, String matricula) {
        super(marca, modelo, color, matricula);
        this.cilindrada = cilindrada;
    }
    
    public int getCilindrada() {
        return cilindrada;
    }
    
    /**
     * Este metodo booleano nos devolvera si necesita carnet o no.
     * @return si tiene menos de 125 CC, NO lo necesita, si es al contrario, SI.
     */
    public boolean necesitaCarnet(){
        boolean loNecesita = false;
        int alea = (int)(Math.random() * 2000);
        if(alea > 125){
            loNecesita = true;
        }else{
            loNecesita = false;
        }
        return loNecesita;
    }

    @Override
    public String toString() {
        return "Motocicleta{" + super.toString() + "cilindrada=" + cilindrada + '}';
    }
    
    
}
