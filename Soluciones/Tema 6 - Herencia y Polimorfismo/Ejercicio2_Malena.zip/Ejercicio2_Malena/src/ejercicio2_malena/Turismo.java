/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2_malena;

/**
 *
 * @author Malena
 */
public class Turismo extends Vehiculo{
    private int numPlazas;
    

    public Turismo() {
        this.numPlazas = 0;
    }

    public Turismo(int numPlazas) {
        this.numPlazas = numPlazas;
    }

    public Turismo(int numPlazas, String marca, String modelo, String color, String matricula) {
        super(marca, modelo, color, matricula);
        this.numPlazas = numPlazas;
    }
        
    public int getNumPlazas() {
        return numPlazas;
    }
    
    /**
     * Este metodo nos dirá si el uso es profesional o particular.
     * @return 1 si es profesional, 2 si es particular.
     */
    public int tipoUso(){
        int tipo = 0;
        int alea = (int)(Math.random() * 1) + 1;
        switch(alea){
            case 1:
                tipo = 1;
                break;
            case 2:
                tipo = 2;
        }
        return tipo;
    }

    @Override
    public String toString() {
        return "Turismo{" + super.toString() + "numPlazas=" + numPlazas + '}';
    }
    
    
}
