/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2_malena;

/**
 *
 * @author Malena
 */
public class Camion extends Vehiculo{
    private int pesoMaxAutorizado;

    public Camion() {
    }

    public Camion(int pesoMaxAutorizado) {
        this.pesoMaxAutorizado = pesoMaxAutorizado;
    }

    public Camion(int pesoMaxAutorizado, String marca, String modelo, String color, String matricula) {
        super(marca, modelo, color, matricula);
        this.pesoMaxAutorizado = pesoMaxAutorizado;
    }
    
    public int getPesoMaxAutorizado() {
        return pesoMaxAutorizado;
    }
    
    /**
     * Este metodo booleano nos dira si su mercancia es peligrosa o no.
     * @return si es menor de 50, NO sera peligrosa, si es mayor, SI lo es.
     */
    public boolean esMercanciaPeligrosa(){
        boolean peligro = false;
        int alea = (int)(Math.random() * 100);
        if(alea < 50){
            peligro = true;
        }else{
            peligro = false;
        }
        return peligro;
    }

    @Override
    public String toString() {
        return "Camion{" + super.toString() + "pesoMaxAutorizado=" + pesoMaxAutorizado + '}';
    }
    
    
}
