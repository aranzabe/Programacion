/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemploherencia;

/**
 *
 * @author faranzabe
 */
public class EjemploHerencia {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Personaje per = new Personaje(); //Si Personaje es abstracta no se puede instanciar.
//        Jedi p = new Jedi(2,false,"Yoda",100,100);
//        Sith s = new Sith(99,true,"Darth Vader",100,100);
//        Wookie chubaca = new Wookie();
//        System.out.println(p);
//        p.metodo();
//        System.out.println(s);
//        p.manejarEspada();
//        s.manejarEspada();
//        chubaca.manejarEspada();

        Object vec[] = new Object[4];
        vec[0] = new Jedi(2, false, "Yoda", 100, 100);
        vec[1] = new Sith(99, true, "Darth Vader", 100, 100);
        vec[2] = new Wookie("Chubaca",20,40);
        vec[3] = new Nave("X","Wing");

        for (int i = 0; i < vec.length; i++) {
            if (vec[i] != null) {
                if (vec[i] instanceof Jedi){
                    Jedi j = (Jedi) vec[i];
                    j.setMaestro(true);
                }
                if (vec[i] instanceof Sith){
                    Sith s = (Sith) vec[i];
                    s.setMaldad(100);
                }
                if (vec[i] instanceof Nave){
                    Nave n = (Nave) vec[i];
                    n.setMarca("Meca");
                }
                System.out.println(vec[i].toString());
            }
            else {
                System.out.println("null");
            }
        }

    }

}
