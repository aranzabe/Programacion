/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemploherencia;

/**
 *
 * @author faranzabe
 */
public class Wookie extends Personaje {

    @Override
    public void manejarEspada() {
        System.out.println("GGGHHGGHERHHH");
    }

    public Wookie(String nombre, int midiclorianos, int nivelEspada) {
        super(nombre, midiclorianos, nivelEspada);
    }

    @Override
    public String toString() {
        return "Wookie{" + super.toString() + '}';
    }
    
    
    
}
