/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemploherencia;

/**
 *
 * @author faranzabe
 */
public class Sith extends Personaje {
    
    private int maldad;
    private boolean rayitos;

    public Sith(int maldad, boolean rayitos, String nombre, int midiclorianos, int nivelEspada) {
        super(nombre, midiclorianos, nivelEspada);
        this.maldad = maldad;
        this.rayitos = rayitos;
    }

    public int getMaldad() {
        return maldad;
    }

    public void setMaldad(int maldad) {
        this.maldad = maldad;
    }

    public boolean isRayitos() {
        return rayitos;
    }

    public void setRayitos(boolean rayitos) {
        this.rayitos = rayitos;
    }

    @Override
    public String toString() {
        return "Sith{" + super.toString() + ", maldad=" + maldad + ", rayitos=" + rayitos + '}';
    }

    @Override
    public void manejarEspada() {
        System.out.println("Manejo espada Sith.");
    }
    
    
}
