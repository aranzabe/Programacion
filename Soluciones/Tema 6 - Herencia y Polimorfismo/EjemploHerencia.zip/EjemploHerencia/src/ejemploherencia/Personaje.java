/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemploherencia;

/**
 *
 * @author faranzabe
 */
public abstract class Personaje {
    protected String nombre;
    protected int midiclorianos;
    protected int nivelEspada;

    public Personaje() {
        this.nombre = "";
    }

    public Personaje(String nombre, int midiclorianos, int nivelEspada) {
        this.nombre = nombre;
        this.midiclorianos = midiclorianos;
        this.nivelEspada = nivelEspada;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getMidiclorianos() {
        return midiclorianos;
    }

    public void setMidiclorianos(int midiclorianos) {
        this.midiclorianos = midiclorianos;
    }

    public int getNivelEspada() {
        return nivelEspada;
    }

    public void setNivelEspada(int nivelEspada) {
        this.nivelEspada = nivelEspada;
    }

    @Override
    public String toString() {
        return "Personaje{" + "nombre=" + nombre + ", midiclorianos=" + midiclorianos + ", nivelEspada=" + nivelEspada + '}';
    }
    
    public void metodo(){
        System.out.println("Este es de la clase Personaje");
    }
    
    public abstract void manejarEspada();
    
}
