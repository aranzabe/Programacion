/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemploherencia;

/**
 *
 * @author faranzabe
 */
public class Jedi extends Personaje {
    
    private int repelencia;
    private boolean maestro;

    public Jedi(int repelencia, boolean maestro, String nombre, int midiclorianos, int nivelEspada) {
        super(nombre, midiclorianos, nivelEspada);
        this.repelencia = repelencia;
        this.maestro = maestro;
    }

    public int getRepelencia() {
        return repelencia;
    }

    public void setRepelencia(int repelencia) {
        this.repelencia = repelencia;
    }

    public boolean isMaestro() {
        return maestro;
    }

    public void setMaestro(boolean maestro) {
        this.maestro = maestro;
    }

    @Override
    public String toString() {
        return "Jedi{" + super.toString() + ", repelencia=" + repelencia + ", maestro=" + maestro + '}';
    }
    
    @Override
    public void metodo(){
        super.metodo();
        System.out.println("Este es de la clase Jedi");
    }
    
    @Override
    public void manejarEspada(){
        System.out.println("Manejo de espada Jedi.");
    }
}
