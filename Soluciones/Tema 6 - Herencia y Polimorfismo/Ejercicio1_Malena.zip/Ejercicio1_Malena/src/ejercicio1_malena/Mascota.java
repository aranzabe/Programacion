/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1_malena;

/**
 *
 * @author Malena
 */
public class Mascota {
    protected String nombre;
    protected String raza;
    protected int peso;
    protected String color;

    public Mascota() {
        String nombre = "";
    }

    public Mascota(String nombre, String raza, int peso, String color) {
        this.nombre = nombre;
        this.raza = raza;
        this.peso = peso;
        this.color = color;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public int getPeso() {
        return peso;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Override
    public String toString() {
        return "Mascota{" + "nombre=" + nombre + ", raza=" + raza + ", peso=" + peso + ", color=" + color + '}';
    }
    
    public void vacunar(){
        
    }
    
    public void comer(){
        
    }
    
    public void dormir(){
        
    }
    
    public void hacerRuido(){
        System.out.println("Vamos a ver que ruido hace cada mascota:");
    }
    
    public boolean hacerCaso(){
        boolean conseguido = false;
        
        return conseguido;
    }
}
