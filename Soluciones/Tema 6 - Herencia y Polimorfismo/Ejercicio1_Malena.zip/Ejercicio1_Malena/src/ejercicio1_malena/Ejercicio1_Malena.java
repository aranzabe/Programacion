/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1_malena;

/**
 *
 * @author Malena
 */
public class Ejercicio1_Malena {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Gato g = new Gato ("Nathy", "Persa", 15, "Blanco");
        System.out.println(g);
        Perro p = new Perro("Shiva", "Labrador", 30, "Negro");
        System.out.println(p);
        
        p.hacerRuido();
        g.hacerRuido();
        
        p.sacarPaseo();
        g.toserBolaPelo();
        
        if(p.hacerCaso()){
            System.out.println("El perro nos ha hecho caso!");
        }else{
            System.out.println("Oh vaya, ha pasado de nosotros...");
        }
        
        if(g.hacerCaso()){
            System.out.println("El gato nos ha hecho caso, increible!");
        }else{
            System.out.println("Oh vaya, este gato pasa de nosotros...");
        }
    }
    
}
