/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1_malena;

/**
 *
 * @author Malena
 */
public class Perro extends Mascota{

    public Perro(String nombre, String raza, int peso, String color) {
        super(nombre, raza, peso, color);
        
    }
    
    @Override
    public void hacerRuido(){
        super.hacerRuido();
        System.out.println("El perro ladra (guau)");
    }
    
    @Override
    public boolean hacerCaso(){
        super.hacerCaso();
        boolean conseguido = false;
        int alea = (int) (Math.random() * 100);
        if(alea <90){
            conseguido = true;
        }else{
            conseguido = false;
        }
        return conseguido;
    }
    
    public void sacarPaseo(){
        System.out.println("Vamos a sacar al perrito de paseo.");
    }
}
