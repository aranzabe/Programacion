/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herencias.pkg2.vehiculos;

/**
 *
 * @author laura
 */
public class Camion extends Vehiculo {

    private int pesoMaxAutorizado;

    public Camion(int pesoMaxAutorizado, String tipoGasolina, String tipoRuedas, int numRuedas, String color, int velocidadMax, String marca, String modelo) {
        super(tipoGasolina, tipoRuedas, numRuedas, color, velocidadMax, marca, modelo);
        this.pesoMaxAutorizado = pesoMaxAutorizado;
    }

    public int getPesoMaxAutorizado() {
        return pesoMaxAutorizado;
    }

    public void setPesoMaxAutorizado(int pesoMaxAutorizado) {
        this.pesoMaxAutorizado = pesoMaxAutorizado;
    }

    public boolean esMercanciaPeligrosa() {
        boolean loEs = false;
        int alea;

        alea = (int) (Math.random() * 2);

        switch (alea) {
            case 0:
                loEs = true;
                break;
            case 1:
                loEs = false;
        }
        return loEs;
    }

    @Override
    public String toString() {
        String cad = "";

        cad = super.toString() + "\n";
        cad += "PesoMaxAutorizado: " + this.pesoMaxAutorizado + "\n";
        return cad;
    }

}
