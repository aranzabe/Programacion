/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herencias.pkg2.vehiculos;

/**
 *
 * @author laura
 */
public class Vehiculo {

    protected String tipoGasolina;
    protected String tipoRuedas;
    protected int numRuedas;
    protected String color;
    protected int velocidadMax;
    protected String marca;
    protected String modelo;

    public Vehiculo() {
        this.tipoGasolina = "";
        this.tipoRuedas = "";
        this.numRuedas = 0;
        this.color = "";
        this.velocidadMax = 0;
        this.marca = "";
        this.modelo = "";
    }

    public Vehiculo(String tipoGasolina, String tipoRuedas, int numRuedas, String color, int velocidadMax, String marca, String modelo) {
        this.tipoGasolina = tipoGasolina;
        this.tipoRuedas = tipoRuedas;
        this.numRuedas = numRuedas;
        this.color = color;
        this.velocidadMax = velocidadMax;
        this.marca = marca;
        this.modelo = modelo;
    }

    public String getTipoGasolina() {
        return tipoGasolina;
    }

    public String getTipoRuedas() {
        return tipoRuedas;
    }

    public int getNumRuedas() {
        return numRuedas;
    }

    public String getColor() {
        return color;
    }

    public int getVelocidadMax() {
        return velocidadMax;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setTipoRuedas(String tipoRuedas) {
        this.tipoRuedas = tipoRuedas;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Override
    public String toString() {
        String cad = "";

        cad = "tipoGasolina: " + this.tipoGasolina + "/n";
        cad += "tipoRuedas: " + this.tipoRuedas + "/n";
        cad += "numRuedas: " + this.numRuedas + "/n";
        cad += "color: " + this.color + "/n";
        cad += "velocidadMax: " + this.velocidadMax + "/n";
        cad += "marca: " + this.marca + "/n";
        cad += "modelo: " + this.modelo + "/n";

        return cad;
    }

}
