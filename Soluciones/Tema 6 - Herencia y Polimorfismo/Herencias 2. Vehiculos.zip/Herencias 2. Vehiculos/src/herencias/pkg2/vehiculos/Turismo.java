/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herencias.pkg2.vehiculos;

/**
 *
 * @author laura
 */
public class Turismo extends Vehiculo {

    private int numPlazas;

    public Turismo(int numPlazas, String tipoGasolina, String tipoRuedas, int numRuedas, String color, int velocidadMax, String marca, String modelo) {
        super(tipoGasolina, tipoRuedas, numRuedas, color, velocidadMax, marca, modelo);
        this.numPlazas = numPlazas;
    }

    public int getNumPlazas() {
        return numPlazas;
    }

    public String tipoUso() {
        int alea;
        String uso = "";

        alea = (int) (Math.random() * 2);

        switch (alea) {
            case 0:
                uso = "Particular";
                break;
            case 1:
                uso = "Profesional";
        }

        return uso;
    }

    @Override
    public String toString() {
        String cad = "";

        cad = super.toString() + "\n";
        cad += "Numero Plazas: " + this.numPlazas;

        return cad;
    }

}
