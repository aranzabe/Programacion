/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herencias.pkg2.vehiculos;

/**
 *
 * @author laura
 */
public class Motocicleta extends Vehiculo {

    private int cilindrada;

    public Motocicleta(int cilindrada, String tipoGasolina, String tipoRuedas, int numRuedas, String color, int velocidadMax, String marca, String modelo) {
        super(tipoGasolina, tipoRuedas, numRuedas, color, velocidadMax, marca, modelo);
        this.cilindrada = cilindrada;
    }

    public int getCilindrada() {
        return cilindrada;
    }

    public boolean necesitaCarnet() {
        int alea;
        boolean loNecesita = false;

        alea = (int) (Math.random() * 200);

        if (alea >= 125) {
            loNecesita = true;
        }

        return loNecesita;
    }

    @Override
    public String toString() {
        String cad = "";

        cad = super.toString() + "\n";
        cad += "Cilindrada: " + this.cilindrada + "\n";

        return cad;
    }

}
