/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Trabajador;

/**
 *
 * @author laura
 */
public class Trabajador {

    private String nombre;
    private String apellido;

    public Trabajador() {
        this.nombre = "";
        this.apellido = "";
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    @Override
    public String toString() {
        String cad = "";
        cad = "Nombre: " + this.nombre + "\n";
        cad += "Apellido: " + this.apellido + "\n";
        return cad;
    }

}
