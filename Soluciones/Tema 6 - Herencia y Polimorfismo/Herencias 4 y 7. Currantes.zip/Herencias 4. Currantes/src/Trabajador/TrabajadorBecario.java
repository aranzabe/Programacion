/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Trabajador;

import Trabajador.Trabajador;
import Metodos.Metodo;
import Metodos.Metodo2;

/**
 *
 * @author laura
 */
public class TrabajadorBecario extends Trabajador implements Metodo, Metodo2{

    public TrabajadorBecario() {
        super();
    }

    public TrabajadorBecario(String nombre, String apellido) {
        super();
    }

    @Override
    public int calculaSalario() {
        return 100;
    }

    @Override
    public String toString() {
        String c="";
        c= super.toString() + "\n";
        return c;
    }

    
}
