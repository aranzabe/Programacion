/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Trabajador;

import Trabajador.Trabajador;
import Metodos.Metodo;

/**
 *
 * @author laura
 */
public class TrabajadorAComision extends Trabajador implements Metodo{

    private int ventas;
    private int porcentaje;

    public TrabajadorAComision(String nombre, String apellido) {
        super();
    }

    public TrabajadorAComision(int ventas, int porcentaje) {
        this.ventas = ventas;
        this.porcentaje = porcentaje;
    }

    public TrabajadorAComision() {
        this.ventas = 0;
        this.porcentaje = 0;
    }

    public int getVentas() {
        return ventas;
    }

    public int getPorcentaje() {
        return porcentaje;
    }

    public void setPorcentaje(int porcentaje) {
        this.porcentaje = porcentaje;
    }

    @Override
    public String toString() {
        String cad = "";
        cad = super.toString() + "\n";
        cad += "Ventas: " + this.ventas + "\n";
        cad += "Porcentaje: " + this.porcentaje + "\n";
        return cad;
    }

    @Override
    public int calculaSalario() {
        return 300;
    }

}
