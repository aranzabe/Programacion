/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Trabajador;

import Trabajador.Trabajador;
import Metodos.Metodo;
import Metodos.Metodo2;

/**
 *
 * @author laura
 */
public class TrabajadorPorHoras extends Trabajador implements Metodo, Metodo2 {

    private int sueldoHora;
    private int horas;

    public TrabajadorPorHoras(String nombre, String apellido) {
        super();
    }

    public TrabajadorPorHoras() {
        this.sueldoHora = 0;
        this.horas = 0;
    }

    public TrabajadorPorHoras(int sueldoHora, int horas) {
        this.sueldoHora = sueldoHora;
        this.horas = horas;
    }

    public int getSueldoHora() {
        return sueldoHora;
    }

    public int getHoras() {
        return horas;
    }

    public void setSueldoHora(int sueldoHora) {
        this.sueldoHora = sueldoHora;
    }

    public void setHoras(int horas) {
        this.horas = horas;
    }

    @Override
    public String toString() {
        String cad = "";
        cad = super.toString() + "\n";
        cad += "SueldoHoras: " + this.sueldoHora + "\n";
        cad += "Horas: " + this.horas + "\n";
        return cad;
    }

    @Override
    public int calculaSalario() {
        return 200;
    }

}
