/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Trabajador;

import Trabajador.Trabajador;
import Metodos.Metodo;

/**
 *
 * @author laura
 */
public class TrabajadorFijo extends Trabajador implements Metodo {

    private int sueldo;

    public TrabajadorFijo(String nombre, String apellido) {
        super();
    }

    public TrabajadorFijo() {
        this.sueldo = 0;
    }

    public TrabajadorFijo(int sueldo) {
        this.sueldo = sueldo;
    }

    public int getSueldo() {
        return sueldo;
    }

    public void setSueldo(int sueldo) {
        this.sueldo = sueldo;
    }

    @Override
    public String toString() {
        String cad = "";

        cad = super.toString() + "\n";
        cad += "Sueldo: " + this.sueldo + "\n";

        return cad;
    }

    @Override
    public int calculaSalario() {
        return 250;
    }

}
