/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herencias.pkg1;

import Animalejos.Animal;
import Animalejos.Perro;
import Animalejos.Gato;

/**
 *
 * @author laura
 */
public class Herencias1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String result = "";
        boolean caso;
        Gato Bola = new Gato("Bola", "Angora", 6, "Ocre");
        Perro Rufo = new Perro("Rufo", "Perro de aguas", 20, "Marron pomposo");
        System.out.println(Bola);
        System.out.println(Rufo);
        System.out.println(Animal.HAB);
        System.out.println(Gato.HAB);
        System.out.println(Perro.HAB);

        //************************************GATO*****************************
        System.out.println("El gato: ");

        result = Bola.ToserBolaPelo();
        System.out.println("Las bolas de pelo: " +result);

        result = Bola.hacerRuido();
        System.out.println(result);

        caso = Bola.hacerCaso();
        System.out.println("Caso: " +caso);

        //************************************PERRO*****************************
        System.out.println("El perrete: ");
        
        result = Rufo.sacarPaseo();
        System.out.println("El paseo: " + result);
        
        result = Rufo.hacerRuido();
        System.out.println(result);
        
        caso = Rufo.hacerCaso();
         System.out.println("Caso: " +caso);
    }

}
