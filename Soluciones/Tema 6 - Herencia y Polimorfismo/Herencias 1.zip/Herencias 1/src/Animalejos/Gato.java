/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Animalejos;

import Animalejos.Animal;

/**
 *
 * @author laura
 */
public class Gato extends Animal {

    public static int LOQSEA;
    
    public Gato(String nombre, String raza, int peso, String color) {
        super(nombre, raza, peso, color);
    }

    public String hacerRuido() {
        String ruido = "MEEEOOOOOOOW";

        return ruido;
    }

    public boolean hacerCaso() {
        int alea;
        boolean casito = true;

        alea = (int) (Math.random() * 100);

        if (alea <= 5) {
            casito = true;
        } else {
            casito = false;
        }

        return casito;
    }

    public String ToserBolaPelo() {
        int alea;
        String vomito = "";
        boolean SeHizoLaCatastrofe = false;
        alea = (int) (Math.random() * 100);

        if (alea >= 30) {
            SeHizoLaCatastrofe = true;
            vomito = "Mami he gomitado";

        } else {
            SeHizoLaCatastrofe = false;
            vomito = "Aun no he gomitado";
        }
        return vomito;
    }

    @Override
    public String toString() {
        return "Gato: " + super.toString();
    }

}
