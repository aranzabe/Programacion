/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_herencia04currantes;

/**
 *
 * @author usuariob
 */
public class Becario extends Trabajador implements MetodosTrabajadoresTemporales {

    public Becario() {
        super();
    }

    public Becario(String nombre, String apellidos) {
        super(nombre, apellidos);
    }

    @Override
    public String toString() {
        return "Becario{" + super.toString() + ", tiempo=" + MetodosTrabajadoresTemporales.tiempo + '}';
    }

    @Override
    public double calculaSalario() {
        return 100;
    }
    
}
