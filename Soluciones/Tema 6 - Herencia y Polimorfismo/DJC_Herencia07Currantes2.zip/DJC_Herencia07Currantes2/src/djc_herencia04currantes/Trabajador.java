/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_herencia04currantes;

/**
 *
 * @author usuariob
 */
public abstract class Trabajador {
    protected String nombre;
    protected String apellidos;

    public Trabajador() {
        this.nombre = "";
        this.apellidos = "";
    }

    public Trabajador(String nombre, String apellidos) {
        this.nombre = nombre;
        this.apellidos = apellidos;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    @Override
    public String toString() {
        return "Trabajador{" + "nombre=" + nombre + ", apellidos=" + apellidos + '}';
    }
    
    public abstract double calculaSalario();
    
}
