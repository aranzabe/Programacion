/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_herencia04currantes;

/**
 *
 * @author usuariob
 */
public interface MetodosTrabajadoresTemporales {
    public static final int tiempo = 4;
}
