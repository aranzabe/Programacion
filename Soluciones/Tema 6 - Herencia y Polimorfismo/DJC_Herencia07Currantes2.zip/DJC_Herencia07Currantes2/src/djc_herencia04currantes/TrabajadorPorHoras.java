/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_herencia04currantes;

/**
 *
 * @author usuariob
 */
public class TrabajadorPorHoras extends Trabajador implements MetodosTrabajadoresTemporales {
    private int horas;
    private double sueldoHora;

    public TrabajadorPorHoras() {
        super();
        this.horas = 0;
        this.sueldoHora = 0;
    }

    public TrabajadorPorHoras(int horas, double sueldoHora, String nombre, String apellidos) {
        super(nombre, apellidos);
        this.horas = horas;
        this.sueldoHora = sueldoHora;
    }

    public int getHoras() {
        return horas;
    }

    public void setHoras(int horas) {
        this.horas = horas;
    }

    public double getSueldoHora() {
        return sueldoHora;
    }

    public void setSueldoHora(double sueldoHora) {
        this.sueldoHora = sueldoHora;
    }

    @Override
    public String toString() {
        return "TrabajadorPorHoras{" + super.toString() + "horas=" + horas + ", sueldoHora=" + sueldoHora + ", tiempo=" + MetodosTrabajadoresTemporales.tiempo +'}';
    }

    @Override
    public double calculaSalario() {
        return (double) this.horas * this.sueldoHora;
    }
    
    
}
