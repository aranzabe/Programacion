/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_herencia04currantes;

/**
 *
 * @author usuariob
 */
public class TrabajadorComision extends Trabajador {
    private double ventas;
    private double porcentaje;

    public TrabajadorComision() {
        this.ventas = 0;
        this.porcentaje = 0;
    }

    public TrabajadorComision(double ventas, double porcentaje, String nombre, String apellidos) {
        super(nombre, apellidos);
        this.ventas = ventas;
        this.porcentaje = porcentaje;
    }

    public double getVentas() {
        return ventas;
    }

    public void setVentas(double ventas) {
        this.ventas = ventas;
    }

    public double getPorcentaje() {
        return porcentaje;
    }

    public void setPorcentaje(double porcentaje) {
        this.porcentaje = porcentaje;
    }

    @Override
    public String toString() {
        return "TrabajadorComision{" + super.toString() + "ventas=" + ventas + ", porcentaje=" + porcentaje + '}';
    }

    @Override
    public double calculaSalario() {
        return this.ventas * this.porcentaje;
    }
    
}
