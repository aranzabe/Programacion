/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mundo;

import Items.*;
import Personajes.*;

/**
 *
 * @author laura
 */
public class Mapa {

    private Object mapa[][];
    public static int TRIBUTOSVIVOS = 0;

    public Mapa() {
        this.mapa = new Object[5][5];
    }

    public void addTributos(Jugador ju) {
        int i = 0;
        int j = 0;
        int f;
        int c;
        boolean conseguido = false;

        while (!conseguido) {
            i = (int) (Math.random() * this.mapa.length);
            j = (int) (Math.random() * this.mapa[0].length);

            if (this.mapa[i][j] == null) {
                this.mapa[i][j] = ju;
                conseguido = true;
                TRIBUTOSVIVOS++;
            }
        }

    }

    public boolean addItem(Item it) {
        int i = 0;
        int j = 0;
        int f;
        int c;
        boolean conseguido = false;

        while (!conseguido) {
            i = (int) (Math.random() * this.mapa.length);
            j = (int) (Math.random() * this.mapa[0].length);

            if (this.mapa[i][j] == null) {
                this.mapa[i][j] = it;
                conseguido = true;
            }
        }
        return conseguido;
    }

    public int cuantosTributos() {
        int cont = 0;

        for (int i = 0; i < this.mapa.length; i++) {
            for (int j = 0; j < this.mapa[0].length; j++) {
                if (this.mapa[i][j] instanceof Jugador) {
                    cont++;
                }
            }
        }
        return cont;
    }

    public int moverJugadores(Capitolio c) {
        int qhp = 0;
        int i = 0;
        int j = 0;
        int alea;
        int fAzar, cAzar;

        for (int k = 0; k < this.mapa.length; k++) {
            for (int l = 0; l < this.mapa[0].length; l++) {
                if (this.mapa[k][l] != null && this.mapa[k][l] instanceof Jugador) {
                    
                    Jugador tribActual = (Jugador) this.mapa[k][l];
                    
                    boolean salir = false;
                    do {
                        fAzar = (int) (Math.random() * 3);
                        if (fAzar == 2) {
                            fAzar = -1;
                        }
                        cAzar = (int) (Math.random() * 3);
                        if (cAzar == 2) {
                            cAzar = -1;
                        }
                        if (k + fAzar >= 0 && k + fAzar < this.mapa.length && l + cAzar >= 0 && l + cAzar < this.mapa[0].length) {
                            salir = true;
                        }
                    } while (!salir);
                    
                    if (this.mapa[k + fAzar][l + cAzar] instanceof Item){
                        if (this.mapa[k + fAzar][l + cAzar] instanceof Arma){
                            Arma a = (Arma) this.mapa[k + fAzar][l + cAzar];
                            tribActual.sumarFuerza(a.getNivFuerza());
                            this.mapa[k + fAzar][l + cAzar] = tribActual;
                            this.mapa[k][l] = null;
                        }
                        if (this.mapa[k + fAzar][l + cAzar] instanceof Medicina){
                            Medicina m = (Medicina) this.mapa[k + fAzar][l + cAzar];
                            tribActual.sumarVida(m.getNivelVida());
                            this.mapa[k + fAzar][l + cAzar] = tribActual;
                            this.mapa[k][l] = null;
                        }
                        if (this.mapa[k + fAzar][l + cAzar] instanceof Trampa){
                            c.addTributo(tribActual);
                            this.mapa[k][l] = null;
                            this.mapa[k + fAzar][l + cAzar] = null;
                        }
                    }
                    
                    if (this.mapa[k + fAzar][l + cAzar] instanceof Jugador){
                        Jugador jugador2 = (Jugador) this.mapa[k + fAzar][l + cAzar];
                        if (tribActual.getnFuerza() >= jugador2.getnFuerza()){
                            c.addTributo(jugador2);
                            this.mapa[k + fAzar][l + cAzar] = tribActual;
                            this.mapa[k][l] = null;
                        }
                        else {
                            c.addTributo(tribActual);
                            this.mapa[k][l] = null;
                        }
                    }
                    
                    
                }
            }
        }

//        //---------------LAS POSICIONES SON NULAS---------------------------//
//        while (i < this.mapa.length && j >= 0) {
//            if (this.mapa[i][j] instanceof Jugador && this.mapa[i + 1][j + 1] == null) {
//                this.mapa[i + 1][j + 1] = this.mapa[i][j];
//                this.mapa[i][j] = null;
//                qhp = 0;
//            } else {
//                if (this.mapa[i][j] instanceof Jugador && this.mapa[i - 1][j - 1] == null) {
//                    this.mapa[i - 1][j - 1] = this.mapa[i][j];
//                    this.mapa[i][j] = null;
//                    qhp = 0;
//                }
//            }
//
//            //---------------HAY JUGADORES EN LAS POSICIONES---------------------------//
//            //-------------------------DERECHA-------------------------------//
//            if (this.mapa[i][j] instanceof Jugador && this.mapa[i + 1][j + 1] instanceof Jugador) {
//                Jugador j1 = (Jugador) this.mapa[i][j];
//                Jugador j2 = (Jugador) this.mapa[i + 1][j + 1];
//
//                if (j1.getnFuerza() > j2.getnFuerza()) {
//                    c.addTributo(j2);
//                    this.mapa[i + 1][j + 1] = null;
//                } else {
//                    c.addTributo(j1);
//                    this.mapa[i][j] = null;
//                }
//
//                if (j1.getnFuerza() == j2.getnFuerza()) {
//                    if (j1.getnVida() > j2.getnVida()) {
//                        c.addTributo(j2);
//                        this.mapa[i + 1][j + 1] = null;
//                    } else {
//                        c.addTributo(j1);
//                        this.mapa[i][j] = null;
//                    }
//
//                    if (j1.getnVida() == j2.getnVida()) {
//                        alea = (int) (Math.random() * 2);
//                        if (alea == 1) {
//                            c.addTributo(j2);
//                            this.mapa[i + 1][j + 1] = null;
//                        } else {
//                            c.addTributo(j1);
//                            this.mapa[i][j] = null;
//                        }
//                    }
//                }
//                qhp = 1;
//                //-------------------------IZQUIERDA--------------------------------
//            } else {
//                if (this.mapa[i][j] instanceof Jugador && this.mapa[i - 1][j - 1] instanceof Jugador) {
//
//                    Jugador j1 = (Jugador) this.mapa[i][j];
//                    Jugador j2 = (Jugador) this.mapa[i - 1][j - 1];
//
//                    if (j1.getnFuerza() > j2.getnFuerza()) {
//                        c.addTributo(j2);
//                        this.mapa[i - 1][j - 1] = null;
//                    } else {
//                        c.addTributo(j1);
//                        this.mapa[i][j] = null;
//                    }
//
//                    if (j1.getnFuerza() == j2.getnFuerza()) {
//                        if (j1.getnVida() > j2.getnVida()) {
//                            c.addTributo(j2);
//                            this.mapa[i - 1][j - 1] = null;
//                        } else {
//                            c.addTributo(j1);
//                            this.mapa[i][j] = null;
//                        }
//
//                        if (j1.getnVida() == j2.getnVida()) {
//                            alea = (int) (Math.random() * 2);
//                            if (alea == 1) {
//                                c.addTributo(j2);
//                                this.mapa[i - 1][j - 1] = null;
//                            } else {
//                                c.addTributo(j1);
//                                this.mapa[i][j] = null;
//                            }
//                        }
//                    }
//                    qhp = 1;
//                }
//            }
//
//            //---------------HAY ITEMS EN LAS POSICIONES---------------------------//
//            //-------------------------DERECHA-------------------------------//
//            if (this.mapa[i][j] instanceof Jugador && this.mapa[i + 1][j + 1] instanceof Item) {
//                if (this.mapa[i + 1][j + 1] instanceof Arma) {
//                    Arma ar = (Arma) this.mapa[i + 1][j + 1];
//                    Jugador j1 = (Jugador) this.mapa[i][j];
//
//                    j1.sumarFuerza(ar.getNivFuerza());
//                    this.mapa[i + 1][j + 1] = this.mapa[i][j];
//                    this.mapa[i][j] = null;
//
//                    qhp = 2;
//                }
//
//                if (this.mapa[i + 1][j + 1] instanceof Medicina) {
//                    Medicina med = (Medicina) this.mapa[i + 1][j + 1];
//                    Jugador j1 = (Jugador) this.mapa[i][j];
//
//                    j1.sumarVida(med.getNivelVida());
//                    this.mapa[i + 1][j + 1] = this.mapa[i][j];
//                    this.mapa[i][j] = null;
//
//                    qhp = 2;
//                }
//
//                if (this.mapa[i + 1][j + 1] instanceof Trampa) {
//                    Trampa tr = (Trampa) this.mapa[i + 1][j + 1];
//                    Jugador j1 = (Jugador) this.mapa[i][j];
//
//                    c.addTributo(j1);
//                    this.mapa[i][j] = null;
//
//                    qhp = 2;
//                    //-------------------------IZQUIERDA-------------------------------//
//                } else {
//                    if (this.mapa[i - 1][j - 1] instanceof Arma) {
//                        Arma ar = (Arma) this.mapa[i - 1][j - 1];
//                        Jugador j1 = (Jugador) this.mapa[i][j];
//
//                        j1.sumarFuerza(ar.getNivFuerza());
//                        this.mapa[i - 1][j - 1] = this.mapa[i][j];
//                        this.mapa[i][j] = null;
//
//                        qhp = 2;
//                    }
//
//                    if (this.mapa[i - 1][j - 1] instanceof Medicina) {
//                        Medicina med = (Medicina) this.mapa[i - 1][j - 1];
//                        Jugador j1 = (Jugador) this.mapa[i][j];
//
//                        j1.sumarVida(med.getNivelVida());
//                        this.mapa[i - 1][j - 1] = this.mapa[i][j];
//                        this.mapa[i][j] = null;
//
//                        qhp = 2;
//                    }
//
//                    if (this.mapa[i - 1][j - 1] instanceof Trampa) {
//                        Trampa tr = (Trampa) this.mapa[i - 1][j - 1];
//                        Jugador j1 = (Jugador) this.mapa[i][j];
//
//                        c.addTributo(j1);
//                        this.mapa[i][j] = null;
//                        qhp = 2;
//                    }
//
//                }
//
//            }
//            i++;
//        }

        return qhp;
    }

    @Override
    public String toString() {
        String cad = "";

        cad = "Mapa: " + "\n";
        for (int i = 0; i < this.mapa.length; i++) {
            for (int j = 0; j < this.mapa[0].length; j++) {
                cad += this.mapa[i][j] + "\n";
                cad += "Posicion: " + i + "/" + j + "\n" + "\n";
            }
        }

        return cad;
    }

}
