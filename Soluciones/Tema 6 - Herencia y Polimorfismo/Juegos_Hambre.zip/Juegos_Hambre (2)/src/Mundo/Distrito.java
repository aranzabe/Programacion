/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mundo;

import Personajes.*;
import Items.*;

/**
 *
 * @author laura
 */
public class Distrito {

    private Jugador jug[];

    public Distrito() {
        this.jug = new Jugador[2];
    }

    public boolean addJugador(Jugador j){
        boolean conseguido = false;
        int i = 0;
        while(i < this.jug.length && !conseguido){
            if (this.jug[i] == null){
                this.jug[i] = j;
                conseguido=true;
            }
            i++;
        }
        return conseguido;
    }

    @Override
    public String toString() {
        String cad = "";

        for (int i = 0; i < this.jug.length; i++) {
            cad += "Jugador: " + this.jug[i] + "\n";

        }
        cad += "\n";
        return cad;
    }

}
