/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mundo;

import Items.*;
import Personajes.*;

/**
 *
 * @author laura
 */
public class Capitolio {

    private MuertosL tributo;
    private Item item[];

    public Capitolio() {
        this.tributo = null;
        this.item = new Item[100];
    }

    public Capitolio(MuertosL tributo, Item[] item) {
        this.tributo = null;
        this.item = new Item[100];
    }

    public int getMaxItems() {
        return this.item.length;
    }

    public void addItem(Item i) {
        int j = 0;
        boolean conseguido = false;

        while (j < this.item.length && !conseguido) {
            if (this.item[j] == null) {
                this.item[j] = i;
                conseguido = true;
            }
            j++;
        }
    }
    
     public void addTributo(Jugador j) {
       this.tributo.addDato(j);
    }

    public Item getPrimerItem() {
        Item it = null;
        int i = 0;
        boolean conseguido = false;

        while (i < this.item.length && !conseguido) {
            if (this.item[i] != null) {
                it = this.item[i];
                this.item[i] = null;
                conseguido = true;
            }
            i++;
        }
        return it;
    }

    

    @Override
    public String toString() {
        String cad = "";

        cad += "Items: " + "\n";
        for (int i = 0; i < this.item.length; i++) {
            cad += this.item[i] + "\n";
        }

        return cad;
    }

}
