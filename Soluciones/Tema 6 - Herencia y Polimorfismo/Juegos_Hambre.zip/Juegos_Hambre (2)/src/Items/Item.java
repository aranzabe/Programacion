/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Items;

/**
 *
 * @author laura
 */
public class Item {

    private String descripcion;

    public Item() {
        this.descripcion = "";
    }

    public Item(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    @Override
    public String toString() {
        String cad = "";

        cad = "Descripcion: " + this.descripcion;

        return cad;
    }

}
