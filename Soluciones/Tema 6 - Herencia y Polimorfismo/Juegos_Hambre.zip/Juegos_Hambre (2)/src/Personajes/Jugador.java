/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Personajes;

/**
 *
 * @author laura
 */
public class Jugador {

    private int nDistrito;
    private int nVida;
    private int nFuerza;

    public Jugador() {
        this.nDistrito = 1;
        this.nVida = 0;
        this.nFuerza = 0;
    }

    public Jugador(int nDistrito, int nVida, int nFuerza) {
        this.nDistrito = nDistrito;
        this.nVida = nVida;
        this.nFuerza = nFuerza;
    }

    public int getnDistrito() {
        return nDistrito;
    }

    public int getnVida() {
        return nVida;
    }

    public int getnFuerza() {
        return nFuerza;
    }

    public void setnVida(int nVida) {
        this.nVida = nVida;
    }

    @Override
    public String toString() {
        String cad = "";

        cad = "Tributo: " + "\n";
        cad += "Numero de Distrito: " + this.nDistrito + "\n";
        cad += "Nivel de vida: " + this.nVida + "\n";
        cad += "Nivel de fuerza: " + this.nFuerza;

        return cad;
    }

    public int sumarFuerza(int nivFuerza) {

        this.nFuerza += nivFuerza;

        return this.nFuerza;
    }

    public int sumarVida(int nivelVida) {
        this.nVida += nivelVida;

        return this.nVida;
    }

}
