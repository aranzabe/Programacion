/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Principal;

import Animalicos.*;
import Zoo.*;

/**
 *
 * @author danie
 */
public class Auxiliar {

    public static String elegirNombre() {
        int alea = (int) (Math.random() * 5);
        String nombre = "";
        switch (alea){
            case 0: nombre = "Rufo"; break;
            case 1: nombre = "Bola"; break;
            case 2: nombre = "Dumbo"; break;
            case 3: nombre = "Guybrush"; break;
            case 4: nombre = "Daxter";
        }
        return nombre;
    }
    
    public static String elegirRaza() {
        int alea = (int) (Math.random() * 3);
        String raza = "";
        switch (alea){
            case 0: raza = "de aguas"; break;
            case 1: raza = "egipcio"; break;
            case 2: raza = "indio";
        }
        return raza;
    }
    
    public static String elegirColor() {
        int alea = (int) (Math.random() * 5);
        String color = "";
        switch (alea){
            case 0: color = "Marrón"; break;
            case 1: color = "Gris"; break;
            case 2: color = "Verde fosforito"; break;
            case 3: color = "Azul cielo"; break;
            case 4: color = "Negro";
        }
        return color;
    }
    
    

}
