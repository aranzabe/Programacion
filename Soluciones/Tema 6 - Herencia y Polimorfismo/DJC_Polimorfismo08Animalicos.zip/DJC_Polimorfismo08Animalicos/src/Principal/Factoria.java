/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Principal;

import Animalicos.*;
import Zoo.*;
import java.util.Scanner;

/**
 *
 * @author danie
 */
public class Factoria {
    
    public static Animal factoriaAnimal(){
        Animal a = null;
        int aleaSpp = (int) (Math.random() * 3);
        float aleaPeso = (float) (Math.random() * 5000);
        String nombre = Auxiliar.elegirNombre();
        String raza = Auxiliar.elegirRaza();
        String color = Auxiliar.elegirColor();
        
        switch (aleaSpp){
            case 0: a = new Perro(nombre, raza, aleaPeso, color);break;
            case 1: a = new Gato(nombre, raza, aleaPeso, color);break;
            case 2: a = new Elefante(nombre, raza, aleaPeso, color);
        }
        return a;
    }
    
    public static Parque factoriaParque(){
        int dim;
        Parque p = null;
        Scanner sc = new Scanner(System.in);
        
        do{
            System.out.println("¿De qué tamaño quieres hacer el parque (mínimo 5)");
            dim = sc.nextInt();
            if (dim < 5){
                System.out.println("El parque tiene que ser más grande");
            }
        } while (dim < 5);
        p = new Parque(dim);
        
        for (int i = 0; i < dim; i++) {
            p.addAnimal(factoriaAnimal());
        }
        return p;
    }
    
}
