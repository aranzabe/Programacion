/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Principal;

import Zoo.*;
import Animalicos.*;

/**
 *
 * @author danie
 */
public class DJC_Polimorfismo08Animalicos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        Parque jurasico = Factoria.factoriaParque();
        int t = 0;

        while (t < 300) {
            if (t % 2 == 0) {
                jurasico.realizarAcciones();
            }
            if (t % 10 == 0) {
                Animal a = Factoria.factoriaAnimal();
                System.out.println(a + " quiere acceder al parque.");
                if (jurasico.addAnimal(a)) {
                    System.out.println("¡Ha llegado un nuevo animal!");
                } else {
                    System.out.println("Parque lleno");
                }
            }
            if (t % 15 == 0) {
                //jurasico.cambiarPosicion();
                //Extraer un animal al azar.
                Animal a = jurasico.extraerAnimal();
                if (a instanceof Gato){
                    System.out.println("Se ha extraido un gato: " + a);
                }
                if (a instanceof Perro){
                    System.out.println("Se ha extraido un perro: " + a);
                }
                if (a instanceof Elefante){
                    System.out.println("Se ha extraido un elefante: " + a);
                }
                //Luego lo insertamos al azar.
                jurasico.addAzar(a);
            }
            if (t % 20 == 0) {
                int alea = (int) (Math.random() * 2);
                if (alea == 0){
                    Animal a = jurasico.extraerAnimal();
                    System.out.println(a + " abandona el parque.");
                }
            }
            t++;
            Thread.sleep(1000);
        }
    }

}
