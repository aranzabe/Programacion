/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Animalicos;

/**
 *
 * @author danie
 */
public class Perro extends Animal implements Metodos {

    public Perro() {
    }

    public Perro(String nombre, String raza, float peso, String color) {
        super(nombre, raza, peso, color);
    }

    @Override
    public void comer(){
        this.peso++;
    }
    
    @Override
    public String dormir(){
        return "El perro sueña feliz que corre por el campo";
    }
    
    @Override
    public String hacerRuido() {
        String ruido = "";
        int alea = (int) (Math.random() * 4);

        switch (alea) {
            case 0:
                ruido = "Guau";
                break;
            case 1:
                ruido = "Auuu";
                break;
            case 2:
                ruido = "Woof";
                break;
            case 3:
                ruido = "Grrr";
        }
        return ruido;
    }

    @Override
    public boolean hacerCaso() {
        return (int) (Math.random() * 100) < 90;
    }

    public String sacarPaseo() {
        return "*el perrete está contento porque ha salido de paseo* :)";
    }

    @Override
    public String toString() {
        return "Perro{" + super.toString() + '}';
    }

}
