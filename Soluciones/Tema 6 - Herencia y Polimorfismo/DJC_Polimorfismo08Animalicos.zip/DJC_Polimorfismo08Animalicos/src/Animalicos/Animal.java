/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Animalicos;

/**
 *
 * @author danie
 */
public class Animal {
    protected String nombre;
    protected String raza;
    protected float peso;
    protected String color;

    public Animal() {
        this.nombre = "";
        this.raza = "";
        this.peso = 0;
        this.color = "";
    }

    public Animal(String nombre, String raza, float peso, String color) {
        this.nombre = nombre;
        this.raza = raza;
        this.peso = peso;
        this.color = color;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRaza() {
        return raza;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public String getColor() {
        return color;
    }
    
    public boolean vacunar(){
        return true;
    }
    
    public void comer(){
        
    }
    
    public String dormir(){
        return "";
    }
    
    public String hacerRuido(){
        return "";
    }
    
    public boolean hacerCaso(){
        return true;
    }

    @Override
    public String toString() {
        return "Mascota{" + "nombre=" + nombre + ", raza=" + raza + ", peso=" + peso + ", color=" + color + '}';
    }
}
