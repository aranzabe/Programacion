/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Zoo;

import Animalicos.Animal;
import Principal.Auxiliar;

/**
 *
 * @author danie
 */
public class Parque {

    private Animal sectores[];

    public Parque() {
        this.sectores = new Animal[10];
    }

    public Parque(int dimension) {
        this.sectores = new Animal[dimension];
    }

    public int getDimension() {
        return this.sectores.length;
    }

    public Animal getAnimal(int i) {
        return this.sectores[i];
    }

    public int getCuantos() {
        int cont = 0;

        for (int i = 0; i < this.getDimension(); i++) {
            if (this.getAnimal(i) != null) {
                cont++;
            }
        }
        return cont;
    }

    public boolean addAnimal(Animal a) {
        boolean conseguido = false;
        int i = 0;

        while (!conseguido && i < this.getDimension()) {
            if (this.sectores[i] == null) {
                this.sectores[i] = a;
                conseguido = true;
            }
            i++;
        }
        return conseguido;
    }

    public String realizarAcciones() {
        String cad = "";

        for (int i = 0; i < this.getDimension(); i++) {
            if (this.getAnimal(i) != null) {
                cad += elegirAccion(this.getAnimal(i));
            }
        }
        return cad;
    }

    private String elegirAccion(Animal a) {
        int alea = (int) (Math.random() * 3);
        String cad = a.getNombre() + ": ";

        switch (alea) {
            case 0:
                a.comer();
                cad += "ha comido";
                break;
            case 1:
                cad += a.dormir();
                break;
            case 2:
                cad += a.hacerRuido();
        }
        cad += "\n";
        return cad;
    }

    @Override
    public String toString() {
        String cad = "Parque:\n";

        for (int i = 0; i < this.getDimension(); i++) {
            if (this.getAnimal(i) != null) {
                cad += "  " + this.getAnimal(i).toString() + "\n";
            }
        }
        return cad;
    }

    public Animal extraerAnimal() {
        int pos;
        Animal a;
        do {
            pos = (int) (Math.random()*this.getDimension());
            a = this.sectores[pos];
        } while (a == null);
        this.sectores[pos] = null;
        return a;
    }

    public void addAzar(Animal a) {
        int pos;
        do {
            pos = (int) (Math.random()*this.getDimension());
        } while (this.sectores[pos] != null);
        this.sectores[pos] = a;
    }

}
