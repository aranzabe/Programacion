/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author faranzabe
 */
public class Localizacion {

    private int longitud;
    private int latitud;
    private String ciudad;

    public Localizacion(int longitud, int latitud, String ciudad) {
        this.longitud = longitud;
        this.latitud = latitud;
        this.ciudad = ciudad;
    }

    public int getLongitud() {
        return longitud;
    }

    public void setLongitud(int longitud) {
        this.longitud = longitud;
    }

    public int getLatitud() {
        return latitud;
    }

    public void setLatitud(int latitud) {
        this.latitud = latitud;
    }

    @Override
    public String toString() {
        return "Localizacion{" + "longitud=" + longitud + ", latitud=" + latitud + '}';
    }

}
