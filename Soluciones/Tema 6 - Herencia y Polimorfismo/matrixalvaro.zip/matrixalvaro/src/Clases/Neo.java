/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author alvar
 */
public class Neo extends Personaje implements Metodos  {
    private boolean cree;

    public Neo(Localizacion localizacion, int edad) {
        super("Neo", localizacion, edad);
        this.cree = false;
    }

    public boolean isCree() {
        return cree;
    }
    
    
    
    @Override
    public String pedir() {
        String devolver;
        devolver = "Clase Neo.";
        return devolver;
    }

    @Override
    public String mostrar() {
        String devolver;
        devolver = "Clase Neo.";
        return devolver;
    }

    @Override
    public String generar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    @Override
    public String toString() {
        return "Neo{" + "cree= " + cree + " nombre= " + nombre + ", localizacion= " + localizacion + ", edad= " + edad + '}';
    }
}
