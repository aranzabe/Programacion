/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author alvar
 */
public abstract class Personaje {
    protected String nombre;
    protected Localizacion localizacion;
    protected int edad;
//    public static int cuantos = 0;

    public Personaje(String nombre, Localizacion localizacion, int edad) {
        this.nombre = nombre;
        this.localizacion = localizacion;
        this.edad = edad;
//        cuantos++;
    }

    @Override
    public String toString() {
        return "Personajes{" + "nombre=" + nombre + ", localizacion=" + localizacion + ", edad=" + edad + '}';
    }
    
    public abstract String pedir();
    public abstract String mostrar();
    public abstract String generar();
}
