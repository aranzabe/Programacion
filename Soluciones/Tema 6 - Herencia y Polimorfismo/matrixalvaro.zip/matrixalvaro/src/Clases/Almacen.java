/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author alvar
 */
public class Almacen {

    private Generico al[];

    public Almacen() {
        this.al = new Generico[200];
    }

    public int cuantosPersonajes() {
        return this.al.length;
    }

    public boolean addPersonaje(Generico g) {
        boolean conseguido = false;
        int i = 0;
        while (!conseguido && i < this.al.length) {
            if (this.al[i] == null) {
                this.al[i] = g;
                conseguido = true;
            }
            i++;
        }
        return conseguido;
    }

    public Generico getPersonaje() {
        Generico g = null;
        boolean encontrado = false;
        int i = 0;
        while (i < this.al.length && !encontrado) {
            if (this.al[i] != null) {
                g = this.al[i];
                this.al[i] = null;
                encontrado = true;
            }
            i++;
        }
        return g;
    }

    @Override
    public String toString() {
        String devolver = "";
        for (int i = 0; i < this.al.length; i++) {
            if (this.al[i] != null) {
                devolver += this.al[i].toString() + "\n";
            }
        }
        return devolver;
    }

}
