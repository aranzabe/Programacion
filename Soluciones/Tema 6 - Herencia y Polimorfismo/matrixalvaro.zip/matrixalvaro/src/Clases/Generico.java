/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author alvar
 */
public class Generico extends Personaje implements Metodos {
    private int morir;
    public static int CUANTOS;

    public Generico(int morir, String nombre, Localizacion localizacion, int edad) {
        super(nombre, localizacion, edad);
        this.morir = morir;
        CUANTOS++;
    }

    public int getMorir() {
        return morir;
    }
    
    @Override
    public String pedir() {
        String devolver;
        devolver = "Clase Genericos.";
        return devolver;
    }

    @Override
    public String mostrar() {
        String devolver;
        devolver = "Clase Genericos.";
        return devolver;
    }

    @Override
    public String generar() {
        String devolver;
        devolver = "Clase Genericos.";
        return devolver;
    }
    
    @Override
    public String toString() {
        return "Generico{" + "morir= " + morir + " nombre= " + nombre + ", localizacion= " + localizacion + ", edad= " + edad + '}';
    }
}
