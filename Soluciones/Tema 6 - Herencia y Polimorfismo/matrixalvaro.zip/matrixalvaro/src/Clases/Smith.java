/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author alvar
 */
public class Smith extends Personaje implements Metodos  {
    private int infectar;

    public Smith(int infectar, Localizacion localizacion, int edad) {
        super("Smith", localizacion, edad);
        this.infectar = infectar;
    }

    public int getInfectar() {
        return infectar;
    }
    
    

    @Override
    public String pedir() {
        String devolver;
        devolver = "Clase Smith.";
        return devolver;
    }

    @Override
    public String mostrar() {
        String devolver;
        devolver = "Clase Smith.";
        return devolver;
    }

    @Override
    public String generar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String toString() {
        return "Smith{" + "infectar= " + infectar + " nombre= " + nombre + ", localizacion= " + localizacion + ", edad= " + edad + '}';
    }
}
