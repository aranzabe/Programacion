/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrixalvaro;

import Clases.Localizacion;
import java.util.Scanner;
import Clases.*;

/**
 *
 * @author alvar
 */
public class Matrixalvaro {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Mapa m = factoriaMapa();
        Neo n = factoriaNeo();
        Smith s = factoriaSmith();
        Almacen al = factoriaAlmacen();
        
        
        System.out.println(al.toString());
        System.out.println(Generico.CUANTOS);
        System.out.println(n);
        System.out.println(s);
    }

    private static Smith factoriaSmith() {
        int infectar = (int) (Math.random() * 100 + 1);
        Localizacion localizacion = generarLocalizacion();
        int edad = (int) (Math.random() * 35 + 18);
        Smith sm = new Smith(infectar, localizacion, edad);
        return sm;
    }

    private static Neo factoriaNeo() {
        Localizacion localizacion = generarLocalizacion();
        int edad = (int) (Math.random() * 35 + 18);
        Neo ne = new Neo(localizacion, edad);
        return ne;
    }
    
    private static Generico factoriaGenericos() {
        int morir = (int) (Math.random() * 100 + 1);
        String nombre = generarNombre();
        Localizacion localizacion = generarLocalizacion();
        int edad = (int) (Math.random() * 35 + 18);
        Generico ge = new Generico(morir, nombre, localizacion, edad);
        return ge;
    }
    
    private static Localizacion generarLocalizacion() {
        int alea = (int) (Math.random() * 4);
        Localizacion localizacion = null;
        String ciudad = "";
        int longit =(int) (Math.random() * 100);
        int lat =(int) (Math.random() * 100);
        switch (alea) {
            case 0:
                ciudad = "Fuente el Fresno";
                break;
            case 1:
                ciudad = "Malagón";
                break;
            case 2:
                ciudad = "Puertollano";
                break;
            case 3:
                ciudad = "Villarrubia";
                break;
        }
        localizacion = new Localizacion(longit, lat, ciudad);
        return localizacion;
    }

    private static String generarNombre() {
        int alea = (int) (Math.random() * 4);
        String nombre = "";
        switch (alea) {
            case 0:
                nombre = "Álvaro";
                break;
            case 1:
                nombre = "Luis";
                break;
            case 2:
                nombre = "Alonso";
                break;
            case 3:
                nombre = "Sergio";
                break;
        }
        return nombre;
    }

    private static Almacen factoriaAlmacen() {
        Almacen al = new Almacen();
        for (int i = 0; i < al.cuantosPersonajes(); i++) {
            Generico gn = factoriaGenericos();
            al.addPersonaje(gn);
        }
        return al;
    }

    private static Mapa factoriaMapa() {
        Scanner sc = new Scanner(System.in);
        int a, b;
        System.out.println("De que tamaño quieres el mapa?");
        a = sc.nextInt();
        b = sc.nextInt();
        Mapa m = new Mapa(a, b);
        return m;
    }
    
}
