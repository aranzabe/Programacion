/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrixalvaro;

import Clases.Generico;
import Clases.Smith;
import Clases.Neo;
import Clases.Personaje;

/**
 *
 * @author alvar
 */
public class Mapa {
    private Personaje tablero[][];

    public Mapa() {
        this.tablero = new Personaje[5][5];
    }

    public Mapa(int a, int b) {
        this.tablero = new Personaje[a][b];
    }

    public boolean addNeo(Neo n){
        int i = 0, j = 0;
        boolean insertado = false;
        while (i < this.tablero.length && !insertado) {
            while (j < this.tablero[0].length && !insertado) {
                if (this.tablero[i][j] == null) {
                    this.tablero[i][j] = n;
                    insertado = true;
                }
                j++;
            }
            i++;
        }
        return insertado;
    }
    
    public boolean addSmith(Smith s){
        int i = 0, j = 0;
        boolean insertado = false;
        while (i < this.tablero.length && !insertado) {
            while (j < this.tablero[0].length && !insertado) {
                if (this.tablero[i][j] == null) {
                    this.tablero[i][j] = s;
                    insertado = true;
                }
                j++;
            }
            i++;
        }
        return insertado;
    }
    
    public boolean addGenericos(Generico g){
        int i = 0, j = 0;
        boolean insertado = false;
        while (i < this.tablero.length && !insertado) {
            while (j < this.tablero[0].length && !insertado) {
                if (this.tablero[i][j] == null) {
                    this.tablero[i][j] = g;
                    insertado = true;
                }
                j++;
            }
            i++;
        }
        return insertado;
    }
    
    @Override
    public String toString() {
        String devolver = "";
        for (int i = 0; i < this.tablero.length; i++) {
            for (int j = 0; j < this.tablero[0].length; j++) {
                devolver += this.tablero[i][j];
            }
            devolver += "\n";
        }
        return devolver;
    }
    
    
    
}
