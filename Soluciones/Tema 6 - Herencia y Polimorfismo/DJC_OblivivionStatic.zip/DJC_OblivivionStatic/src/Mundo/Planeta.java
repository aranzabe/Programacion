/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mundo;

import Tecnologia.*;

/**
 *
 * @author usuariob
 */
public class Planeta {
    
    private String nombre;
    private Cuadrante[][] mapa;

    public Planeta() {
        this.nombre = "Tierra";
        this.mapa = new Cuadrante[3][3];
    }
    
    public Planeta(int f, int c) {
        this.nombre = "Tierra";
        this.mapa = new Cuadrante[f][c];
    }
    
    public Planeta(String nombre, int f, int c) {
        this.nombre = nombre;
        this.mapa = new Cuadrante[f][c];
    }
 
    public int getDimF(){
        return this.mapa.length;
    }
    
    public int getDimC(){
        return this.mapa[0].length;
    }
    
    public void setCuadrante(Cuadrante cuad, int f, int c){
        this.mapa[f][c] = cuad;
    }
    
    public Cuadrante getCuadrante(int f, int c){
        return this.mapa[f][c];
    }

    @Override
    public String toString() {
        String cad = nombre + ":\n";
        for (int i = 0; i < this.getDimF(); i++) {
            for (int j = 0; j < this.getDimC(); j++) {
                cad += this.getCuadrante(i, j).toString() + "   ";
            }
            cad += "\n";
        }
        return cad;
    }
}
