/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mundo;

import Gente.*;
import Tecnologia.*;
import CentroDeMando.*;

/**
 *
 * @author usuariob
 */
public class Cuadrante {

    private Mecanico jack;
    private Supervisora vika;
    private ListaDrones dronesAsignados;
    private ListaOrdenes ordenesSinResolver;

    public Cuadrante() {
        this.dronesAsignados = new ListaDrones();
        this.ordenesSinResolver = new ListaOrdenes();
    }

    public Cuadrante(Mecanico jack, Supervisora vika) {
        this.jack = jack;
        this.vika = vika;
        this.dronesAsignados = new ListaDrones();
        this.ordenesSinResolver = new ListaOrdenes();
    }

    public Dron getDron(int pos) {
        return this.dronesAsignados.getPos(pos);
    }

    public int getCuantosDrones() {
        return dronesAsignados.cuantosElementos();
    }

    public boolean addDron(Estacion tet) {
        boolean conseguido = false;

        if (this.getCuantosDrones() < 3) {
            this.dronesAsignados.addDatoFinal(tet.getDron());
            conseguido = true;
        }
        return conseguido;
    }

    @Override
    public String toString() {
        String cad = "Personal{ " + jack.toString() + ", " + vika.toString() + '}';
        cad += dronesAsignados.toString();
        cad += ordenesSinResolver.toString();
        return cad;
    }

    public boolean addDronEstatico(Dron dron) {
        boolean conseguido = false;

        if (this.getCuantosDrones() < 3) {
            this.dronesAsignados.addDatoFinal(dron);
            conseguido = true;
        }
        return conseguido;
    }
    
    
}
