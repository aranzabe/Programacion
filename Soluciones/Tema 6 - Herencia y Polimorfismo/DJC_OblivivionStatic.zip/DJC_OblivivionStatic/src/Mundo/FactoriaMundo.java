/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mundo;

import CentroDeMando.*;
import Gente.*;

/**
 *
 * @author danie
 */
public class FactoriaMundo {

    public static Cuadrante factoriaCuadrante(Estacion tet, Mecanico jack, Supervisora vika) {
        Cuadrante cuad = new Cuadrante(jack, vika);
        boolean insertado = false;

        //while (!cuad.addDron(tet)){}
        while (!insertado) {
            insertado = cuad.addDron(tet);
        }
        return cuad;
    }

    public static Planeta factoriaPlaneta(Estacion tet) {
        Planeta tierra = new Planeta();

        for (int i = 0; i < tierra.getDimF(); i++) {
            for (int j = 0; j < tierra.getDimC(); j++) {
                tierra.setCuadrante(factoriaCuadrante(tet, FactoriaGente.factoriaMecanico(i, j), FactoriaGente.factoriaSupervisora(i, j)), i, j);
            }
        }
        return tierra;
    }

    public static Planeta factoriaPlanetaTetEstatico() {
        Planeta tierra = new Planeta();

        for (int i = 0; i < tierra.getDimF(); i++) {
            for (int j = 0; j < tierra.getDimC(); j++) {
                tierra.setCuadrante(factoriaCuadranteEstatico(FactoriaGente.factoriaMecanico(i, j), FactoriaGente.factoriaSupervisora(i, j)), i, j);
            }
        }
        return tierra;
    }

    private static Cuadrante factoriaCuadranteEstatico(Mecanico factoriaMecanico, Supervisora factoriaSupervisora) {
        Cuadrante cuad = new Cuadrante(factoriaMecanico, factoriaSupervisora);
        boolean insertado = false;

        //while (!cuad.addDron(tet)){}
        while (!insertado) {
            insertado = cuad.addDronEstatico(EstacionStatic.getDron());
        }
        return cuad;
    }

}
