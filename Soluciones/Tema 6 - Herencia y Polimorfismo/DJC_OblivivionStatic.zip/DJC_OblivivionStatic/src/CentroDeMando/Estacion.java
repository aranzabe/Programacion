/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CentroDeMando;

import Tecnologia.*;

/**
 *
 * @author usuariob
 */
public class Estacion {
    
    private String nombre;
    private ListaDrones almacenDrones;
    private ListaOrdenes ordenes;

    public Estacion() {
        this.nombre = "Tet";
        this.almacenDrones = new ListaDrones();
        this.ordenes = new ListaOrdenes();
    }

    public Estacion(String nombre) {
        this.nombre = nombre;
        this.almacenDrones = new ListaDrones();
        this.ordenes = new ListaOrdenes();
    }
    
    public void addDron(Dron d){
        this.almacenDrones.addDatoFinal(d);
    }
    
    public void addOrdenReparacion(Reparacion r){
        this.ordenes.addDatoFinal(r);
    }
    
    public void addOrdenReconocimiento(Reconocimiento r){
        this.ordenes.addDatoFinal(r);
    }
    
    public Dron getDron(){
        Dron d = almacenDrones.getPrimero();
        almacenDrones.borrarPrimero();
        return d;
    }

    @Override
    public String toString() {
        String cad = "Estación " + nombre + ':';
        cad += almacenDrones.toString();
        cad += ordenes.toString();
        return cad;
    }
    
    
    
}
