/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CentroDeMando;

import java.time.LocalDate;

/**
 *
 * @author usuariob
 */
public abstract class Orden {
    
    protected LocalDate fecha;
    protected boolean completada;
    protected int[] cuadranteDestino;

    public Orden() {
        this.fecha = LocalDate.now();
        this.completada = false;
        this.cuadranteDestino = new int[2];
    }

    public Orden(int[] cuadranteDestino) {
        this.fecha = LocalDate.now();
        this.completada = false;
        this.cuadranteDestino = cuadranteDestino;
    }

    @Override
    public String toString() {
        String cad = fecha.toString();
        if (this.completada){
            cad += ", completada";
        } else {
            cad += ", pendiente";
        }
        cad += " (" + this.cuadranteDestino[0] + ',' + this.cuadranteDestino[1] + ')';
        return cad;
    }
    
    
    
}
