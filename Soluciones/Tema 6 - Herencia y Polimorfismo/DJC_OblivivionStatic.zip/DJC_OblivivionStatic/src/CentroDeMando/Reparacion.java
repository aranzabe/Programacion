/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CentroDeMando;

/**
 *
 * @author usuariob
 */
public class Reparacion extends Orden {
    
    private int numDron;
    private boolean estadoDron[];

    public Reparacion(int numDron, int[] cuadranteDestino) {
        super(cuadranteDestino);
        this.numDron = numDron;
        this.estadoDron[0] = false;
        this.estadoDron[1] = true;
    }

    @Override
    public String toString() {
        return "Reparacion{" + "numDron=" + numDron + '}';
    }
    
    
    
}
