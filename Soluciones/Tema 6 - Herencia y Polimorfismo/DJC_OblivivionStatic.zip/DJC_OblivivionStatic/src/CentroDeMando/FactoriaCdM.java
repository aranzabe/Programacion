/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CentroDeMando;

import Mundo.*;
import Tecnologia.*;

/**
 *
 * @author usuariob
 */
public class FactoriaCdM {
    
    public static Reparacion factoriaOrdenReparacion(Planeta planeta){
        int pos[] = {(int) (Math.random() * planeta.getDimF()), (int) (Math.random() * planeta.getDimC())};
        int numDron = (int) (Math.random() * Dron.CUANTOS);
        
        return new Reparacion(numDron, pos);
    }
    
    public static Estacion factoriaEstacion(){
        Estacion tet = new Estacion();
        
        for (int i = 0; i < 200; i++) {
            tet.addDron(FactoriaTecnologia.factoriaDron());
        }
        return tet;
    }

    public static void factoriaEstacionStatic() {
        for (int i = 0; i < 200; i++) {
            EstacionStatic.addDron(FactoriaTecnologia.factoriaDron());
        }
    }
    
}
