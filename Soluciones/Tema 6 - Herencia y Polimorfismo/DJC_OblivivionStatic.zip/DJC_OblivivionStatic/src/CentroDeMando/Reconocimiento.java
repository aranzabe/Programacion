/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CentroDeMando;

/**
 *
 * @author usuariob
 */
public class Reconocimiento extends Orden {

    private int area;
    private String hallazgo;

    public Reconocimiento(int area, int[] cuadranteDestino) {
        super(cuadranteDestino);
        this.area = area;
        this.hallazgo = "";
    }

    @Override
    public String toString() {
        return "Reconocimiento{" + "area=" + area + ", hallazgo=" + hallazgo + '}';
    }

}
