/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_herencia01;

/**
 *
 * @author danie
 */
public class Elefante extends Mascota {

    public Elefante() {
        super();
    }

    public Elefante(String nombre, String raza, float peso, String color) {
        super(nombre, raza, peso, color);
    }
    
    public void comer(){
        this.peso += 10;
    }
    
    public String dormir(){
        return "El elefante está soñando con cosas de elefantes";
    }
    
    public String hacerRuido(){
        String ruido = "Barrita ";
        int alea = (int) (Math.random() * 4);

        switch (alea) {
            case 0:
                ruido = "de cereales";
                break;
            case 1:
                ruido = "energética";
                break;
            case 2:
                ruido = "inanimada de carbono";
                break;
            case 3:
                ruido = "y punto";
        }
        return ruido;
    }
}
