/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_herencia01;

/**
 *
 * @author danie
 */
public class Gato extends Mascota {

    public Gato() {
    }

    public Gato(String nombre, String raza, float peso, String color) {
        super(nombre, raza, peso, color);
    }
    
    @Override
    public void comer(){
        this.peso += 2.5;
    }
    
    @Override
    public String dormir(){
        this.peso++;
        return "El gato sueña feliz que ha sometido a la raza humana";
    }
    
    @Override
    public String hacerRuido() {
        String ruido = "";
        int alea = (int) (Math.random() * 4);

        switch (alea) {
            case 0:
                ruido = "Miau";
                break;
            case 1:
                ruido = "Marramiau";
                break;
            case 2:
                ruido = "*indiferencia*";
                break;
            case 3:
                ruido = "Ffffffff";
        }
        return ruido;
    }

    @Override
    public boolean hacerCaso() {
        return (int) (Math.random() * 100) < 5;
    }

    public void toserBolaPelo() {

    }

    @Override
    public String toString() {
        return "Gato{" + super.toString() + '}';
    }
}
