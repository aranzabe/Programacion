/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Items;

/**
 *
 * @author laura
 */
public class Arma extends Item {

    private int nivFuerza;

    public Arma() {
        super();
        this.nivFuerza = nivFuerza;
    }

    public Arma(int nivFuerza, String descripcion) {
        super(descripcion);
        this.nivFuerza = nivFuerza;
    }
    
    

    public int getNivFuerza() {
        return nivFuerza;
    }

    @Override
    public String toString() {
        String cad = "";

        cad= "Arma: " +"\n";
        cad += "Nivel de fuerza: " + this.nivFuerza + "\n";
        cad += "Descripcion: " + super.toString() + "\n";
        
        return cad;
    }

}
