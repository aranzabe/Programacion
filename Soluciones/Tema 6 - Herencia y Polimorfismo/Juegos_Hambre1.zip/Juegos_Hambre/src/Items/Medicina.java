/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Items;

/**
 *
 * @author laura
 */
public class Medicina extends Item {

    private int nivelVida;

    public Medicina(int nivelVida, String descripcion) {
        super(descripcion);
        this.nivelVida = nivelVida;
    }

    public int getNivelVida() {
        return nivelVida;
    }

    @Override
    public String toString() {
        String cad = "";

        cad = "Medicina: " + "\n";
        cad += "Nivel de vida: " + this.nivelVida + "\n";
        cad += "Descripcion: " + super.toString() + "\n";

        return cad;
    }

}
