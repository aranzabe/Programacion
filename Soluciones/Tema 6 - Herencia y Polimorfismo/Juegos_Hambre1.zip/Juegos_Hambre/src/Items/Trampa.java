/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Items;

/**
 *
 * @author laura
 */
public class Trampa extends Item {

    public Trampa(String descripcion) {
        super(descripcion);
    }

    @Override
    public String toString() {
        String cad = "";

         cad = "Trampa: " + "\n";
        cad += "Descripcion: " + super.toString() + "\n";

        return cad;
    }

}
