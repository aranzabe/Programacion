/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package juegos_hambre;

import Items.*;
import Mundo.*;
import Personajes.*;
import static Mundo.Factorias_Mundo.*;

/**
 *
 * @author laura
 */
public class Juegos_Hambre {

    public static void main(String[] args) throws InterruptedException {
        Capitolio c = factoriaCapitolioItems();
        Mapa m = factoriaItemsMapa(c);
        int qhp;
        int t = 0;
        int i = 0;

        while (m.cuantosTributos() > 1) {
            if (t % 2 == 0) {
                qhp = m.moverJugadores(c);
                if (qhp == 0) {
                    System.out.println("Un jugador se ha movido de posicion");
                }
                if (qhp == 1) {
                    System.out.println("Un jugador ha encontrado un item");
                }
                if (qhp == 2) {
                    System.out.println("Un jugador ha muerto a causa de una Trampa");
                }
            }

            if (t % 5 == 0) {

                while (i <= 4) {
                    m.addItem(c.almacenarPrimerItem());
                    c.borrarPrimerItem();
                    i++;
                }
                System.out.println(m.toString());
            }
            t++;
            Thread.sleep(1000);
        }
    }

}
