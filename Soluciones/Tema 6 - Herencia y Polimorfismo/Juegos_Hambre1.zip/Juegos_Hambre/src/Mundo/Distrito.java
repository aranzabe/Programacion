/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mundo;

import Personajes.*;
import Items.*;

/**
 *
 * @author laura
 */
public class Distrito {

    private Jugador jug[];

    public Distrito() {
        this.jug = new Jugador[2];
    }

    public Distrito(Jugador[] jug) {
        this.jug = new Jugador[2];
    }

    public Jugador[] getJug() {
        return jug;
    }

    @Override
    public String toString() {
        String cad = "";

        for (int i = 0; i < this.jug.length; i++) {
            cad += "Jugador: " + this.jug[i] + "\n";

        }
        cad += "\n";
        return cad;
    }

}
