/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mundo;

import Items.*;
import Mundo.*;
import Personajes.*;

/**
 *
 * @author laura
 */
public class Factorias_Mundo {

    public static Capitolio factoriaCapitolioItems() {
        Capitolio c = new Capitolio();
        int alea;
        int i = 0;

        while (i < c.getMax()) {
            alea = (int) (Math.random() * 3);

            switch (alea) {
                case 0:
                    alea = (int) (Math.random() * 50 + 50);
                    Arma a = new Arma(alea, "");
                    c.addItem(a);
                    break;
                case 1:
                    alea = (int) (Math.random() * 50 + 50);
                    Medicina m = new Medicina(alea, "");
                    c.addItem(m);
                    break;
                case 2:
                    Trampa t = new Trampa("");
                    c.addItem(t);
            }
            i++;
        }
        return c;
    }

    public static Mapa factoriaITributosMapa() {
        Mapa m = new Mapa();
        int i = 1;

        while (i <= 8) {
            if (i <= 2) {
                Jugador j = new Jugador(1, 100, 50);
                m.addTributos(j);
            }
            if (i <= 4 && i > 2) {
                Jugador j = new Jugador(2, 100, 50);
                m.addTributos(j);
            }
            if (i <= 6 && i > 4) {
                Jugador j = new Jugador(3, 100, 50);
                m.addTributos(j);
            }
            if (i <= 8 && i > 6) {
                Jugador j = new Jugador(4, 100, 50);
                m.addTributos(j);
            }
            i++;

        }

        return m;
    }

    public static Mapa factoriaItemsMapa(Capitolio c) {
        Mapa m = factoriaITributosMapa();
   
        int i = 0;

        while (i <= 10) {
            m.addItem(c.almacenarPrimerItem());
            c.borrarPrimerItem();
            i++;
        }
        return m;
    }
}
