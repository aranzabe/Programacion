/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Personajes;

/**
 *
 * @author laura
 */
public class MuertosL {

    //******************************CLASE AUXILIAR****************************
    private class Nodo {

        private Jugador dato;
        private Nodo sig;

        public Nodo(Jugador dato) {
            this.dato = dato;
            this.sig = null;
        }
    }
    //***********************GIN DE CLASE AUXILIAR****************************
    private Nodo l;

    public MuertosL() {
        this.l = null;
    }

    public void addDato(Jugador i) {
        Nodo nuevo = new Nodo(i);
        if (this.l == null) {
            this.l = nuevo;
        } else {
            nuevo.sig = l;
            this.l= nuevo;
        }
    }

    @Override
    public String toString() {
        String cad = "";
        cad = "l--> ";
        Nodo aux = this.l;

        while (aux != null) {
            cad += aux.dato + "-->";
            aux = aux.sig;
        }
        cad += " null";
        return cad;
    }

}
