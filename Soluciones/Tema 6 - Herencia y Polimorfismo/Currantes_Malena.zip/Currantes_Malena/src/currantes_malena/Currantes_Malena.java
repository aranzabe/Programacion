/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package currantes_malena;

/**
 *
 * @author usuarioa
 */
public class Currantes_Malena {

    public static void main(String[] args) {
//        Trabajador t = new Trabajador("Manolo", "Garcia");
//        System.out.println(t);
//        Trabajador_Fijo tf = new Trabajador_Fijo ("Jorge", "Escorial");
//        System.out.println(tf);
//        Trabajador_PorHoras th = new Trabajador_PorHoras("Lucia", "Yseapago");
//        System.out.println(th);
//        Trabajador_Comision tc = new Trabajador_Comision("Leandro", "Gado");
//        System.out.println(tc);
        
    }
    
}
