/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package currantes_malena;

import Interface.Metodo_Obligatorio;

/**
 *
 * @author usuarioa
 */
public class Trabajador_Comision extends Trabajador implements Metodo_Obligatorio{
   //AComision: nombre, apellidos, ventasy porcentaje.
    private int numVentas;
    private int porcentaje;

    public Trabajador_Comision() {
    }

    public Trabajador_Comision(String nombre, String apellido) {
        super(nombre, apellido);
    }
    
    public Trabajador_Comision(int numVentas, String nombre, String apellido) {
        super(nombre, apellido);
        this.numVentas = numVentas;
    }

    public Trabajador_Comision(int numVentas, int porcentaje, String nombre, String apellido) {
        super(nombre, apellido);
        this.numVentas = numVentas;
        this.porcentaje = porcentaje;
    }

    public int getNumVentas() {
        return numVentas;
    }

    public int getPorcentaje() {
        return porcentaje;
    }

    public void setNumVentas(int numVentas) {
        this.numVentas = numVentas;
    }

    public void setPorcentaje(int porcentaje) {
        this.porcentaje = porcentaje;
    }

    @Override
    public String toString() {
        return "Trabajador_Comision{" + super.toString() + "numVentas=" + numVentas + ", porcentaje=" + porcentaje + '}';
    }

    @Override
    public int CalculaSalario() {
        return this.porcentaje * this.numVentas;
    }
    
    
}
