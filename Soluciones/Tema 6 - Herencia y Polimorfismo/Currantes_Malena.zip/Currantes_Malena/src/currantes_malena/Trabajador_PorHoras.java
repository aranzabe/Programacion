/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package currantes_malena;

import Interface.Metodo_Obligatorio;
import Interface.Metodo_Temporal;

/**
 *
 * @author usuarioa
 */
public class Trabajador_PorHoras extends Trabajador implements Metodo_Obligatorio, Metodo_Temporal{
    //PorHoras: nombre, apellidos, horas, sueldohora.
    private int horas;
    private int sueldohora;

    public Trabajador_PorHoras() {
    }

    public Trabajador_PorHoras(String nombre, String apellido) {
        super(nombre, apellido);
    }

    public Trabajador_PorHoras(int horas, String nombre, String apellido) {
        super(nombre, apellido);
        this.horas = horas;
    }

    public Trabajador_PorHoras(int horas, int sueldohora, String nombre, String apellido) {
        super(nombre, apellido);
        this.horas = horas;
        this.sueldohora = sueldohora;
    }

    public int getHoras() {
        return horas;
    }

    public int getSueldohora() {
        return sueldohora;
    }

    public void setHoras(int horas) {
        this.horas = horas;
    }

    public void setSueldohora(int sueldohora) {
        this.sueldohora = sueldohora;
    }

    @Override
    public String toString() {
        return "Trabajador_PorHoras{" + super.toString() + "horas=" + horas + ", sueldohora=" + sueldohora + '}';
    }

    @Override
    public int CalculaSalario() {
        return this.sueldohora * this.horas;
    }
    
    
}
