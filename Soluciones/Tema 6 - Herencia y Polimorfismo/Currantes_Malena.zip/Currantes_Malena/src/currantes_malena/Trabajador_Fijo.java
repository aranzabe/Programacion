/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package currantes_malena;

import Interface.Metodo_Obligatorio;

/**
 *
 * @author usuarioa
 */
public class Trabajador_Fijo extends Trabajador implements Metodo_Obligatorio{
    //Fijos: nombre, apellidos y sueldo.
    private int sueldo;

    public Trabajador_Fijo() {
    }

    public Trabajador_Fijo(String nombre, String apellido) {
        super(nombre, apellido);
    }
    
    public Trabajador_Fijo(int sueldo, String nombre, String apellido) {
        super(nombre, apellido);
        this.sueldo = sueldo;
    }

    public int getSueldo() {
        return sueldo;
    }

    public void setSueldo(int sueldo) {
        this.sueldo = sueldo;
    }

    @Override
    public String toString() {
        return "Trabajador_Fijo{" + super.toString() + "sueldo=" + sueldo + '}';
    }

    @Override
    public int CalculaSalario() {
        return this.sueldo;
    }

    
    
    
}
