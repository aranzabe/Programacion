/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package currantes_malena;

import Interface.Metodo_Temporal;

/**
 *
 * @author usuarioa
 */
public class Becario extends Trabajador_Abstract implements Metodo_Temporal{

    @Override
    public int CalculaSalario() {
        return 100;
    }
    
}
