/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Orden;

import java.time.LocalDate;
import Orden.Orden;

/**
 *
 * @author laura
 */
public class Reconocimiento extends Orden {

    private int area;
    private String descubrimiento;

    public Reconocimiento(int area, String descubrimiento, LocalDate fecha, boolean completado, int destinof, int destinoc) {
        super(fecha, completado, destinof, destinoc);
        this.area = area;
        this.descubrimiento = descubrimiento;
    }

  

    public int getArea() {
        return area;
    }

    public String getDescubrimiento() {
        return descubrimiento;
    }

    public void setArea(int area) {
        this.area = area;
    }

    public void setDescubrimiento(String descubrimiento) {
        this.descubrimiento = descubrimiento;
    }

    @Override
    public String toString() {
        String cad = "";

        cad = "Area: " + this.area + "\n";
        cad += "Descubrimiento: " + this.descubrimiento + "\n";

        return cad;
    }

}
