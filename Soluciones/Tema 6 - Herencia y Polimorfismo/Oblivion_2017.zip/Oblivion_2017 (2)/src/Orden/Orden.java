/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Orden;

import java.time.LocalDate;

/**
 *
 * @author laura
 */
public class Orden {

    private LocalDate fecha;
    private boolean completado;
    private int destinof;
    private int destinoc;

    public Orden() {
        this.fecha = LocalDate.now();
        this.completado = false;
        this.destinof = 0;
        this.destinoc = 0;
    }

    public Orden(LocalDate fecha, boolean completado, int destinof, int destinoc) {
        this.fecha = LocalDate.now();
        this.completado = completado;
        this.destinof = destinof;
        this.destinoc = destinoc;
    }

    public LocalDate getFecha() {
        return fecha.now();
    }

    public boolean isCompletado() {
        return completado;
    }

    @Override
    public String toString() {
        String cad = "";

        cad = "Fecha: " + this.fecha.now() + "\n";
        cad += "Estado: " + this.completado + "\n";
        cad += "DestinoF: " + this.destinof + "\n";
        cad += "DestinoC: " + this.destinoc + "\n";

        return cad;
    }

}
