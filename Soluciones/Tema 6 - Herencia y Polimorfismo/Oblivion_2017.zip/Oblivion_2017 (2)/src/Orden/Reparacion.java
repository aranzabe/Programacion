/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Orden;

import Orden.Orden;
import java.time.LocalDate;

/**
 *
 * @author laura
 */
public class Reparacion extends Orden {

    private int nDron;
    private boolean estadoAntes;
    private boolean estadoDesp;

    public Reparacion(int nDron, boolean estadoAntes, LocalDate fecha, boolean completado, int destinof, int destinoc) {
        super(fecha, completado, destinof, destinoc);
        this.nDron = nDron;
        this.estadoAntes = estadoAntes;
    }

    public int getnDron() {
        return nDron;
    }

    public boolean getEstadoAntes() {
        return estadoAntes;
    }

    public boolean getEstadoDesp() {
        return estadoDesp;
    }

    @Override
    public String toString() {
        String cad = "";

        cad = "Numero Dron: " + this.nDron + "\n";
        cad = "Estacion Antes: " + this.estadoAntes + "\n";
        cad = "Estacion Despues: " + this.estadoDesp + "\n";

        return cad;
    }

}
