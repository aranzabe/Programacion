/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Principal;

import Mundo.*;
import static Mundo.Factorias.*;
import Nave.*;

/**
 *
 * @author laura
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        
        int t = 0;
        Tet tet = factoriaDronesTet();
        Cuadrante c = new Cuadrante();
        Tierra ti = new Tierra();
        ti = factoriaCuadrantesPlaneta(tet);
        
        if (t % 4 == 0) {
            
        }
        if (t % 10 == 0) {
            
        }
        if (t % 20 == 0) {
            
        }
        t++;
        
        Thread.sleep(1000);
    }
    
}
