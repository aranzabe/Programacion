/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mundo;

import Mundo.Cuadrante;

/**
 *
 * @author laura
 */
public class Tierra {

    private Cuadrante cuadrante[][];

    public Tierra() {
        this.cuadrante = new Cuadrante[3][3];
    }

   

    

    public int getMaxFilas() {
        return this.cuadrante.length;
    }

    public int getMaxColumnas() {
        return this.cuadrante[0].length;
    }

    @Override
    public String toString() {
        String cad = "";

        cad = "Cuadrante: ";
        for (int i = 0; i < this.cuadrante.length; i++) {
            for (int j = 0; j < this.cuadrante[0].length; j++) {

                cad += this.cuadrante[i][j] + "\n";
                cad += "Fila: " + i + "\n";
                cad += "Columna: " + j + "\n";
            }
        }

        return cad;
    }

    public void addCuadrante(int i, int j, Cuadrante c) {
        this.cuadrante[i][j] = c;
    }

}
