/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mundo;

import java.util.LinkedList;
import Drones.Dron;
import Orden.Orden;
import Orden.Reparacion;
import java.util.ArrayList;

/**
 *
 * @author laura
 */
public class Cuadrante {

    //private Dron dron[];
    private ArrayList <Dron> dron;
    private String Vika;
    private String Jack;
    private LinkedList<Orden> or;

    public Cuadrante() {
        //this.dron = new Dron[3];
        this.dron = new ArrayList<Dron>();
        this.Vika = "";
        this.Jack = "";
        this.or = null;
    }

    public Cuadrante(String Vika, String Jack) {
        //this.dron = new Dron[3];
        this.dron = new ArrayList<Dron>();
        this.Vika = Vika;
        this.Jack = Jack;
        this.or = null;
    }

    public String getVika() {
        return Vika;
    }

    public String getJack() {
        return Jack;
    }

    public void addDron(Dron d) {
        this.dron.add(d);
//        boolean conseguido = false;
//        int i = 0;
//
//        while (!conseguido && i < this.dron.length) {
//            if (this.dron[i] == null) {
//                this.dron[i] = d;
//            }
//            i++;
//        }
    }

    void addOrden(Orden o) {
      this.or.add(o);
    }

    public int maxDron() {
        //return this.dron.length;
        return this.dron.size();
    }

    @Override
    public String toString() {
        String cad = "";

        cad = "Drones: " + "\n";
        for (int i = 0; i < this.dron.size(); i++) {
            //cad += this.dron[i] + "\n";
            cad += this.dron.get(i) + "\n";
        }
        cad += this.Jack + "\n";
        cad += this.Vika + "\n";
        cad += "Orden: " + this.or.toString() + "\n";

        return cad;
    }

}
