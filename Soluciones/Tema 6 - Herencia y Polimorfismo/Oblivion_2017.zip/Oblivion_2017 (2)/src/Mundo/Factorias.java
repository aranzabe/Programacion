/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mundo;

import Drones.*;
import Nave.*;
import Orden.*;
import java.time.LocalDate;

/**
 *
 * @author laura
 */
public class Factorias {

    public static Cuadrante FactoriaCuadranteOrdenes(Cuadrante c, Tierra t) {
        int alea = (int) (Math.random() * 2);

        switch (alea) {
            case 0:
                Reparacion rep = factoriaOrdenReparacion(t);
                c.addOrden(rep);
                break;
            case 1:
                Reconocimiento rec = factoriaOrdenReconocimiento(t);
                c.addOrden(rec);
        }

        return c;
    }

    public static Reparacion factoriaOrdenReparacion(Tierra t) {
        int nDron = (int) (Math.random() * Dron.CONT);
        int f = (int) (Math.random() * t.getMaxFilas());
        int c = (int) (Math.random() * t.getMaxColumnas());

        Reparacion r = new Reparacion(nDron, true, LocalDate.now(), false, f, c);

        return r;
    }

    public static Reconocimiento factoriaOrdenReconocimiento(Tierra t) {
        int area = (int) (Math.random() * 20 + 1);
        int alea = (int) (Math.random() * 3);
        String descubrimiento = "";
        int f = (int) (Math.random() * t.getMaxFilas());
        int c = (int) (Math.random() * t.getMaxColumnas());

        switch (alea) {
            case 0:
                descubrimiento = "animales";
                break;
            case 1:
                descubrimiento = "vegetales";
                break;
            case 2:
                descubrimiento = "radiacion";

        }
        Reconocimiento r = new Reconocimiento(area, descubrimiento, LocalDate.now(), false, f, c);
        return r;
    }

    public static Tet factoriaDronesTet() {
        Tet t = new Tet();

        for (int i = 0; i < 200; i++) {
            Dron d = new Dron();
            t.addDron(d);
        }
        return t;
    }

    public static Tierra factoriaCuadrantesPlaneta(Tet te) {
        Tierra t = new Tierra();

        for (int i = 0; i < t.getMaxFilas(); i++) {
            for (int j = 0; j < t.getMaxColumnas(); j++) {
                Cuadrante c = FactoriaCuadranteDrones("Vika" + i + j, "Jack" + i + j, te);
                t.addCuadrante(i, j, c);
            }

        }

        return t;
    }

    public static Cuadrante FactoriaCuadranteDrones(String v, String j, Tet te) {
        Cuadrante c = new Cuadrante(v, j);
        int alea = (int) (Math.random() * 3 + 1);

        for (int i = 0; i < alea; i++) {
            Dron d = te.getDrones().getPrimero();
            te.getDrones().borrarPrimero();
            c.addDron(d);
        }

        return c;
    }
}
