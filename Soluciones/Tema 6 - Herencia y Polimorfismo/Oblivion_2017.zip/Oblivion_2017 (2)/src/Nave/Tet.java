/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Nave;

import Drones.Dron;
import Orden.Orden;
import Drones.DronesLista;
import java.util.LinkedList;

/**
 *
 * @author laura
 */
public class Tet {
    
    private DronesLista drones;
    private LinkedList<Orden> orden;
    
    public Tet() {
        this.drones = null;
        this.orden = null;
    }
    
    public Tet(DronesLista drones, Orden orden) {
        this.drones = null;
        this.orden = null;
    }
    
    public DronesLista getDrones() {
        return drones;
    }
    
    public LinkedList<Orden> getOrden() {
        return orden;
    }
    
    public void addDron(Dron d) {
        this.drones.addDato(d);
    }
    
    @Override
    public String toString() {
        String cad = "";
        
        return cad;
    }
    
}
