/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Drones;

/**
 *
 * @author laura
 */
public class Dron {

    public static int CONT;
    boolean operativo;

    public Dron() {
        this.operativo = true;
        CONT++;
    }

    public Dron(boolean operativo) {
        this.operativo = operativo;
        CONT++;
    }

    public boolean isOperativo() {
        return operativo;
    }

    @Override
    public String toString() {
        String cad = "";

        cad = "NumeroID: " + CONT + "\n";
        cad += "¿Operativo?: " + this.operativo + "\n";

        return cad;
    }

}
