/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cuentas;

import Titulares.Titular;

/**
 *
 * @author usuariob
 */
public class Cuenta {

    protected String numCuenta;
    protected double saldo;
    protected Titular titulares[];
    
    public Cuenta(){
        
    }

    public Cuenta(String numCuenta) {
        this.saldo = 0;
        this.titulares = new Titular[3];
    }

    public Cuenta(String numCuenta, Titular t) {
        this.numCuenta = numCuenta;
        this.titulares = new Titular[3];
        this.titulares[0] = t;
        this.saldo = 0;
    }

    public String getNumCuenta() {
        return numCuenta;
    }

    public void setNumCuenta(String numCuenta) {
        this.numCuenta = numCuenta;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    @Override
    public String toString() {
        String cad;

        cad = "Cuenta:\n" + "   Número de cuenta: " + numCuenta + "\n   Saldo: " + saldo + "\n   Titulares:\n";
        for (int i = 0; i < this.titulares.length; i++) {
            if (this.titulares[i] != null) {
                cad += "     Titular " + (i + 1) + ":\n";
                cad += titulares[i].toString();
            }
        }
        cad += "\n";
        return cad;
    }

    //Métodos relativos a los titulares
    public boolean addTitular(Titular nuevoTitular) {
        boolean added = false;
        int i = 0;

        while (i < this.titulares.length && !added) {
            if (titulares[i] == null) {
                titulares[i] = nuevoTitular;
                added = true;
            }
            i++;
        }
        return added;
    }

    public boolean removeTitular(String DNI) {
        boolean eliminado = false;
        int i = 0;

        while (i < this.titulares.length && !eliminado) {
            if (this.titulares[i] != null) {
                if (this.titulares[i].getDNI().equals(DNI)) {
                    titulares[i] = null;
                    eliminado = true;
                }
            }
            i++;
        }
        return eliminado;
    }

    public int comprobarBorradoTitular(String DNI){
        int cod;
        
        if (this.cuantosTitulares() <= 1) {
            cod = 0;
        } else {
            if (this.estaTitular(DNI)) {
                cod = 1;
                this.removeTitular(DNI);
            } else {
                cod = 2;
            }
        }
        return cod;
    }
    
    public boolean modifyTitular(String DNI, Titular nuevoTitular) {
        boolean modificado = false;
        int i = 0;

        while (i < this.titulares.length && !modificado) {
            if (this.titulares[i] != null) {
                if (this.titulares[i].getDNI().equals(DNI)) {
                    titulares[i] = nuevoTitular;
                    modificado = true;
                }
            }
            i++;
        }
        return modificado;
    }

    public int cuantosTitulares(){
        int cont = 0;
        
        for (int i = 0; i < this.titulares.length; i++) {
            if (titulares[i] != null){
                cont++;
            }
        }
        return cont;
    }
    
    public boolean estaTitular(String DNI){
        boolean esta = false;
        int i = 0;
        
        while (!esta & i < this.titulares.length){
            if (this.titulares[i] != null){
                if (this.titulares[i].getDNI().equals(DNI)){
                    esta= true;
                }
            }
            i++;
        }
        return esta;
    }
    
    //Métodos relativos a operaciones
    public boolean ingresarDinero(double cantidad) {
        boolean ingresado = false;

        if (cantidad > 0) {
            this.saldo += cantidad;
            ingresado = true;
        }
        return ingresado;
    }

    public boolean extraerDinero(double cantidad) {
        boolean extraido = false;

        if (cantidad <= this.saldo) {
            this.saldo -= cantidad;
            extraido = true;
        }
        return extraido;
    }
}
