/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cuentas;

import Titulares.Titular;

/**
 *
 * @author danie
 */
public class CuentaAhorro extends Cuenta {

    private double cuotaMant;
    private double interesAnual;

    public CuentaAhorro(String numCuenta) {
        super(numCuenta);
        this.cuotaMant = 0;
        this.interesAnual = 0;
    }

    public CuentaAhorro(double cuotaMant, double interesAnual, String numCuenta, Titular t) {
        super(numCuenta, t);
        this.cuotaMant = cuotaMant;
        this.interesAnual = interesAnual;
    }

    public double getCuotaMant() {
        return cuotaMant;
    }

    public void setCuotaMant(double cuotaMant) {
        this.cuotaMant = cuotaMant;
    }

    public double getInteresAnual() {
        return interesAnual;
    }

    public void setInteresAnual(double interesAnual) {
        this.interesAnual = interesAnual;
    }
    
    public double aplicarInteres() {
        double ganancias = this.saldo * interesAnual;
        this.ingresarDinero(ganancias);
        return ganancias;
    }
    
    public void aplicarCuotaMant(){
        this.extraerDinero(this.cuotaMant);
    }

    @Override
    public String toString() {
        return super.toString() + "Cuenta de ahorro:\n" + "  Cuota de mantenimiento: " + cuotaMant + "\n   Interés Anual: " + interesAnual;
    }
    
    
}
