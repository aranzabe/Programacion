/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cuentas;

import Titulares.Titular;
import Transacciones.Transaccion;
import Transacciones.ListaTransacciones;

/**
 *
 * @author danie
 */
public class CuentaCorriente extends Cuenta {

    private double portentajeTransaccion;
    private int numTransacciones;
    private ListaTransacciones transacciones;

    public CuentaCorriente(String numCuenta) {
        super(numCuenta);
        this.numTransacciones = 0;
        this.transacciones = new ListaTransacciones();
    }

    public CuentaCorriente(double portentajeTransaccion, String numCuenta, Titular t) {
        super(numCuenta, t);
        this.portentajeTransaccion = portentajeTransaccion;
        this.numTransacciones = 0;
        this.transacciones = new ListaTransacciones();
    }

    public double getPortentajeTransaccion() {
        return portentajeTransaccion;
    }

    public int getNumTransacciones() {
        return this.transacciones.cuantosElementos();
    }

    public ListaTransacciones getTransacciones() {
        return transacciones;
    }

    @Override
    public String toString() {
        return super.toString() + "Cuenta corriente:\n" + " Porcentaje cobrado por transacción: " + portentajeTransaccion + "\n Número de transacciones: " + numTransacciones + "\n Historial de transacciones:\n" + transacciones.toString();
    }

    public double hacerTransaccion(Transaccion t, Cuenta c) {
        double coste = t.getImporte() + t.getImporte() * this.portentajeTransaccion;
        if (this.extraerDinero(coste)) {
            c.ingresarDinero(t.getImporte());
            this.transacciones.addDatoFinal(t);
        }
        return coste;
    }
}
