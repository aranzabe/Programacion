/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Titulares;

/**
 *
 * @author usuariob
 */
public class Titular {

    private String DNI;
    private String nombre;
    private String telefono;

    public Titular() {
        this.DNI = "";
        this.nombre = "";
        this.telefono = "";
    }

    public Titular(String DNI, String nombre, String telefono) {
        this.DNI = DNI;
        this.nombre = nombre;
        this.telefono = telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getDNI() {
        return DNI;
    }

    public String getNombre() {
        return nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    @Override
    public String toString() {
        return "      DNI: " + DNI + "\n      Nombre: " + nombre + "\n      Teléfono: " + telefono + "\n";
    }

}
