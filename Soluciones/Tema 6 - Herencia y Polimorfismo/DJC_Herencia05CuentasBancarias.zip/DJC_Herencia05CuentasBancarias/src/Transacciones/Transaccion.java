/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Transacciones;

/**
 *
 * @author danie
 */
public class Transaccion {
    private Fecha fecha;
    private String concepto;
    private double importe;

    public Transaccion() {
    }

    public Transaccion(Fecha fecha, String concepto, double importe) {
        this.fecha = fecha;
        this.concepto = concepto;
        this.importe = importe;
    }

    public Fecha getFecha() {
        return fecha;
    }

    public String getConcepto() {
        return concepto;
    }

    public double getImporte() {
        return importe;
    }

    @Override
    public String toString() {
        return "Transacción:\n Importe: " + this.importe + "\n Concepto: " + this.concepto + "\n Fecha: " + this.fecha.toString();
    }
    
    
}
