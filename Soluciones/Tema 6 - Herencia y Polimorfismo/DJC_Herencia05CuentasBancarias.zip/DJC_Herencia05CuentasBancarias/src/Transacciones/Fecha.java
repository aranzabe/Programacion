/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Transacciones;

import java.time.LocalDate;

/**
 *
 * @author danie
 */
public class Fecha {

    private LocalDate fecha;

    public Fecha() {
        this.fecha = LocalDate.now();
    }

    @Override
    public String toString() {
        return this.getDia() + "-" + this.getMes() + "-" + this.getAnio();
    }
    
    public int getDia(){
        return this.fecha.getDayOfMonth();
    }
    
    public int getMes(){
        return this.fecha.getMonthValue();
    }
    
    public int getAnio(){
        return this.fecha.getYear();
    }

}
