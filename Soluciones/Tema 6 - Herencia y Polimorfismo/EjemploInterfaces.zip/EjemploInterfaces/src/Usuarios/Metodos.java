/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Usuarios;

/**
 * Todos los atributos de esta clase son: static, publicos, finales
 * Todos los métodos son: publicos y abstractos.
 * @author faranzabe
 */
public interface Metodos {
    public static final int DESC=9;
    public abstract void metodoObligatorio();
    
    
    
}
