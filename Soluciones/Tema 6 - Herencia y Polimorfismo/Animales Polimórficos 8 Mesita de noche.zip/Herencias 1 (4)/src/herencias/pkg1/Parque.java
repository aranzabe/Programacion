/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herencias.pkg1;

import Animales.Animal;
import Animales.*;

/**
 *
 * @author laura
 */
public class Parque {

    private Animal animales[];

    public Parque() {
        this.animales = new Animal[20];
    }

    public Parque(int tam) {
        this.animales = new Animal[tam];
    }

    public Animal getAnimal(int pos){
        return this.animales[pos];
    }
    
    public boolean addAnimal(Animal a) {
        boolean conseguido = false;
        int i;

        while (!conseguido) {
            i = (int) (Math.random() * this.animales.length);

            if (this.animales[i] == null) {
                this.animales[i] = a;
                conseguido = true;
            }
        }
        return conseguido;
    }

    public Animal dropAnimal() {
        boolean conseguido = false;
        Animal a = null;
        while (!conseguido) {
            int i = (int) (Math.random() * this.animales.length);
            if (this.animales[i] != null) {
                a = this.animales[i];
                this.animales[i] = null;
                conseguido = true;
            }
        }
        return a;
    }

    public boolean moverAnimal(int i) {
        boolean conseguido = false;
        Animal a = this.animales[i];
        if (i + 1 < this.animales.length) {
            if (this.animales[i + 1] == null) {
                this.animales[i + 1] = a;
                this.animales[i] = null;
                conseguido = true;
            } else {
                if (i - 1 >= 0) {
                    if (this.animales[i - 1] == null) {
                        this.animales[i - 1] = a;
                        this.animales[i] = null;
                        conseguido = true;
                    }
                }
            }
        }
        return conseguido;
    }

    public int returnMax() {
        return this.animales.length;
    }

    @Override
    public String toString() {
        String cad = "";

        for (int i = 0; i < animales.length; i++) {
            cad += this.animales[i] + " " + "\n";
        }
        cad += " ";

        return cad;
    }

    public void realizarAcciones() {
        for (int i = 0; i < this.animales.length; i++) {
            if (this.animales[i] != null) {
                int alea = (int) (Math.random() * 3);
                //Opción A.
//                if (this.animales[i] instanceof Gato) {
//                    Gato g = (Gato) this.animales[i];
//                    switch (alea) {
//                        case 0: g.comer(); break;
//                        case 1: g.dormir(); break;
//                        case 2: g.hacerCaso();
//                    }
//                }
//                if (this.animales[i] instanceof Perro) {
//                    Perro g = (Perro) this.animales[i];
//                    switch (alea) {
//                        case 0: g.comer(); break;
//                        case 1: g.dormir(); break;
//                        case 2: g.hacerCaso();
//                    }
//                }
//                if (this.animales[i] instanceof Elefante) {
//                    Elefante g = (Elefante) this.animales[i];
//                    switch (alea) {
//                        case 0: g.comer(); break;
//                        case 1: g.dormir(); break;
//                        case 2: g.hacerCaso();
//                    }
//                }
                
                //Opción B.
                switch (alea) {
                        case 0: this.animales[i].comer(); break;
                        case 1: this.animales[i].dormir(); break;
                        case 2: this.animales[i].hacerCaso();
                    }
            }
        }
    }

}
