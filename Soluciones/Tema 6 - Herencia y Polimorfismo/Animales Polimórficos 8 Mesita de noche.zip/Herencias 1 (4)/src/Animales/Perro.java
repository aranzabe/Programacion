/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Animales;

/**
 *
 * @author laura
 */
public class Perro extends Animal  {


    public Perro(String nombre, String raza, int peso, String color) {
        super(nombre, raza, peso, color);
    }

    public String hacerRuido() {
        String ruido = "GROUUUUF";

        return ruido;
    }

    public boolean hacerCaso() {
        int alea;
        boolean casito = true;

        alea = (int) (Math.random() * 100);

        if (alea <= 90) {
            casito = true;
        } else {
            casito = false;
        }

        return casito;
    }

    public String sacarPaseo() {
        float horas;
        String paseo = "";
        boolean HoraDelPaseo = false;
        horas = (float) (Math.random() * 20);

        if (horas == 8.30 || horas == 15.00 || horas == 19.00) {
            HoraDelPaseo = true;
            paseo = "El perro es feliz y sale a pasear";

        } else {
            HoraDelPaseo = false;
            paseo = "El perro esta triste y tendra que aguantar sus necesidades";
        }
        return paseo;
    }

    @Override
    public String toString() {
        return super.toString();
    }

    @Override
    public boolean comer() {
        int alea;
        boolean TieneHambre = false;
        alea = (int) (Math.random() * 10);

        if (alea >= 5) {
            TieneHambre = true;
        }

        return TieneHambre;    }

    @Override
    public boolean dormir() {
       int alea;
        boolean TieneCheño = false;
        alea = (int) (Math.random() * 10);

        if (alea >= 5) {
            TieneCheño = true;
        }

        return TieneCheño;    }

}
