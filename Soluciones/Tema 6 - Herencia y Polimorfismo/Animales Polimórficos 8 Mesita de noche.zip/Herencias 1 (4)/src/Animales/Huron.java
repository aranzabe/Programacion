/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Animales;

/**
 *
 * @author faranzabe
 */
public class Huron extends Animal {

    @Override
    public boolean comer() {
        return true;
    }

    @Override
    public boolean dormir() {
        return true;
    }

    @Override
    public String hacerRuido() {
        return "Hurón haciendo caso";
    }
    
}
