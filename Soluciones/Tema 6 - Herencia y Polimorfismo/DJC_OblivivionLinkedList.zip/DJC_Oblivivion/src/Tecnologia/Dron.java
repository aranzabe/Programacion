/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tecnologia;

/**
 *
 * @author usuariob
 */
public class Dron {
    
    private int num;
    private boolean operativo;
    public static int CUANTOS=0;
    
    static{
        CUANTOS = 0;
    }

    public Dron() {
        this.num = CUANTOS;
        this.operativo = true;
        CUANTOS++;
    }

    public int getNum() {
        return num;
    }

    public boolean isOperativo() {
        return operativo;
    }

    public void setOperativo(boolean operativo) {
        this.operativo = operativo;
    }
    
    

    @Override
    public String toString() {
        String cad = "Dron" + num;
        if (this.operativo){
            cad += ", operativo";
        } else {
            cad += ", escarcharrao";
        }
        return cad;
    }
    
}
