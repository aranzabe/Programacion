/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gente;

/**
 *
 * @author danie
 */
public class FactoriaGente {
    
    public static Mecanico factoriaMecanico(int f, int c){
        String nombre = "Jack" + f + c;
        return new Mecanico(nombre);
    }
    
    public static Supervisora factoriaSupervisora(int f, int c){
        String nombre = "Vika" + f + c;
        return new Supervisora(nombre);
    }
    
}
