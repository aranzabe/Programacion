/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CentroDeMando;

import java.time.LocalDate;

/**
 *
 * @author usuariob
 */
public abstract class Orden {
    
    protected LocalDate fecha;
    protected boolean completada;
    protected int destinoF;
    protected int destinoC;
    public static int CURSADAS;

    static {
        CURSADAS = 0;
    }
    
    public Orden() {
        this.fecha = LocalDate.now();
        this.completada = false;
    }

    public Orden(int destinoF, int destinoC) {
        this.fecha = LocalDate.now();
        this.completada = false;
        this.destinoF = destinoF;
        this.destinoC = destinoC;
    }

    public void setCompletada(boolean completada) {
        this.completada = completada;
    }

    public boolean isCompletada() {
        return completada;
    }

    @Override
    public String toString() {
        String cad = fecha.toString();
        if (this.completada){
            cad += ", completada";
        } else {
            cad += ", pendiente";
        }
        cad += " (" + this.destinoF + ',' + this.destinoC + ')';
        return cad;
    }
    
    
    
}
