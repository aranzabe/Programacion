/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CentroDeMando;

import Tecnologia.*;

/**
 *
 * @author usuariob
 */
public class Reparacion extends Orden {
    
    private int numDron;
    private boolean estadoDron[];

    public Reparacion(int numDron, int destinoF, int destinoC) {
        super(destinoF, destinoC);
        this.numDron = numDron;
        this.estadoDron = new boolean[2];
        this.estadoDron[0] = false;
        this.estadoDron[1] = false;
    }

    public int getNumDron() {
        return numDron;
    }

    public boolean getEstadoAnterior(){
        return this.estadoDron[0];
    }
    
    public boolean getEstadoPosterior(){
        return this.estadoDron[1];
    }
    
    public boolean intentoDeReparacion(Dron d){
        int alea = (int) (Math.random() * 2);
        if (alea == 1){
            d.setOperativo(true);
            this.estadoDron[1] = true;
        }
        return this.estadoDron[1];
    }
    
    @Override
    public String toString() {
        return "Reparacion{" + "numDron=" + numDron + '}';
    }
    
    
    
}
