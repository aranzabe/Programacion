/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Principal;

import CentroDeMando.*;
import static CentroDeMando.Estacion.addOrdenReconocimiento;
import static CentroDeMando.Estacion.addOrdenReparacion;
import Gente.*;
import Mundo.*;
import static Mundo.Planeta.getCuadrante;
import static Mundo.Planeta.getDimC;
import static Mundo.Planeta.getDimF;
import Tecnologia.*;

/**
 *
 * @author usuariob
 */
public class DJC_Oblivivion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        int t = 0;
        FactoriaCdM.factoriaEstacion();
        System.out.println(Estacion.toStringS());
        FactoriaMundo.factoriaPlaneta();
        System.out.println(Planeta.toStringS());

        while (t < 300) {
            if (t % 4 == 0) {
                for (int i = 0; i < Planeta.getDimF(); i++) {
                    for (int j = 0; j < Planeta.getDimC(); j++) {
                        Cuadrante cuad = Planeta.getCuadrante(i, j);
                        for (int k = 0; k < cuad.getCuantosDrones(); k++) {
                            int alea = (int) (Math.random() * 5);
                            if (alea == 0) {
                                cuad.getDron(k).setOperativo(false);
                            }
                        }
                    }
                }
            }
            if (t % 10 == 0) {
                //Recorremos el planeta
                for (int i = 0; i < Planeta.getDimF(); i++) {
                    for (int j = 0; j < Planeta.getDimC(); j++) {
                        //En este cuadrante
                        Cuadrante cuad = Planeta.getCuadrante(i, j);
                        //Generamos un número aleatorio de órdenes de reconocimiento
                        int numOrdenes = (int) (Math.random() * 5) + 5;
                        for (int k = 0; k < numOrdenes; k++) {
                            //Las generamos
                            Reconocimiento rec = FactoriaCdM.factoriaOrdenReconocimiento(i, j);
                            //Las almacenamos en el Tet
                            Estacion.addOrdenReconocimiento(rec);
                            //Y las añadimos al cuadrante (sería más correcto hacer un método enviar, pero vendría a hacer esto)
                            cuad.addOrdenReconocimiento(rec);
                        }
                        //Ahora recorremos cada dron del cuadrante
                        for (int k = 0; k < cuad.getCuantosDrones(); k++) {
                            Dron d = cuad.getDron(k);
                            //Si está roto, generamos la orden de reparación
                            if (!d.isOperativo()) {
                                Reparacion rep = FactoriaCdM.factoriaOrdenReparacion(d.getNum());
                                //La almacenamos en el Tet
                                Estacion.addOrdenReparacion(rep);
                                //Y la enviamos al cuadrante
                                cuad.addOrdenReparacion(rep);
                            }
                        }
                    }
                }
            }
            if (t % 20 == 0) {
                for (int i = 0; i < Planeta.getDimF(); i++) {
                    for (int j = 0; j < Planeta.getDimC(); j++) {
                        //En este cuadrante
                        Cuadrante cuad = Planeta.getCuadrante(i, j);
                        //Recorro las órdenes que hay
                        for (int k = 0; k < cuad.getCuantasOrdenes(); k++) {
                            //Si no está cumplida...
                            if (!cuad.getOrdenesSinResolver().getPos(k).isCompletada()) {
                                //Si es una orden de reparación...
                                if (cuad.getOrdenesSinResolver().getPos(k) instanceof Reparacion) {
                                    Reparacion rep = (Reparacion) cuad.getOrdenesSinResolver().getPos(k);

                                    Reparacion.CURSADAS++;
                                    //Si la orden es de reconocimiento...
                                } else {
                                    Reconocimiento rec = (Reconocimiento) cuad.getOrdenesSinResolver().getPos(k);
                                    int alea = (int) (Math.random() * 3);
                                    String hallazgo = "";
                                    switch (alea) {
                                        case 0:
                                            hallazgo = "Vegetal";
                                            break;
                                        case 1:
                                            hallazgo = "Animal";
                                            break;
                                        case 2:
                                            hallazgo = "Radiación";
                                    }
                                    rec.setHallazgo(hallazgo);
                                    rec.setCompletada(true);
                                    Reconocimiento.CURSADAS++;
                                }
                            }
                        }
                    }
                }
            }
            t++;
            Thread.sleep(1000);
        }
    }

}
