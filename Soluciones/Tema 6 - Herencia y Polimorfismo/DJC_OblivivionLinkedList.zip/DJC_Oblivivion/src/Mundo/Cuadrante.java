/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mundo;

import Gente.*;
import Tecnologia.*;
import CentroDeMando.*;
import java.util.LinkedList;

/**
 *
 * @author usuariob
 */
public class Cuadrante {

    private Mecanico jack;
    private Supervisora vika;
    private LinkedList<Dron> dronesAsignados ;
    private ListaOrdenes ordenesSinResolver;

    public Cuadrante() {
        this.dronesAsignados = new LinkedList <Dron>();
        this.ordenesSinResolver = new ListaOrdenes();
    }

    public Cuadrante(Mecanico jack, Supervisora vika) {
        this.jack = jack;
        this.vika = vika;
        this.dronesAsignados = new LinkedList <Dron>();
        this.ordenesSinResolver = new ListaOrdenes();
    }

    public Dron getDron(int pos) {
        return this.dronesAsignados.get(pos);
    }

    public int getCuantosDrones() {
        return dronesAsignados.size();
    }

    public boolean addDron() {
        boolean conseguido = false;

        if (this.getCuantosDrones() < 3) {
            this.dronesAsignados.addLast(Estacion.getDron());
            conseguido = true;
        }
        return conseguido;
    }

    public void addOrdenReparacion(Reparacion r) {
        this.ordenesSinResolver.addDatoFinal(r);
    }

    public void addOrdenReconocimiento(Reconocimiento r) {
        this.ordenesSinResolver.addDatoFinal(r);
    }

    public int getCuantasOrdenes() {
        return this.ordenesSinResolver.cuantosElementos();
    }

    public LinkedList getDronesAsignados() {
        return dronesAsignados;
    }

    public ListaOrdenes getOrdenesSinResolver() {
        return ordenesSinResolver;
    }

    

    @Override
    public String toString() {
        String cad = "Personal{ " + jack.toString() + ", " + vika.toString() + '}';
        cad += dronesAsignados.toString();
        cad += ordenesSinResolver.toString();
        return cad;
    }

}
