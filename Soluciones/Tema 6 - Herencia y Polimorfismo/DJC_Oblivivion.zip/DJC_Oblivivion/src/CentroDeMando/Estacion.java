/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CentroDeMando;

import Tecnologia.*;
import Mundo.*;

/**
 *
 * @author usuariob
 */
public class Estacion {

    private static String nombre;
    private static ListaDrones almacenDrones;
    private static ListaOrdenes ordenes;

    static {
        nombre = "Tet";
        almacenDrones = new ListaDrones();
        ordenes = new ListaOrdenes();
    }

    public static void addDron(Dron d) {
        almacenDrones.addDatoFinal(d);
    }

    public static void addOrdenReparacion(Reparacion r) {
        ordenes.addDatoFinal(r);
    }

    public static void addOrdenReconocimiento(Reconocimiento r) {
        ordenes.addDatoFinal(r);
    }

    public static Dron getDron() {
        Dron d = almacenDrones.getPrimero();
        almacenDrones.borrarPrimero();
        return d;
    }

    public static String toStringS() {
        String cad = "Estación " + nombre + ':';
        cad += almacenDrones.toString();
        cad += ordenes.toString();
        return cad;
    }

    public static void recorrerPlaneta() {
        
    }

}
