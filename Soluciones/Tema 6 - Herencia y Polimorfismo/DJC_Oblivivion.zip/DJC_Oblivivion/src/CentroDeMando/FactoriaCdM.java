/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CentroDeMando;

import Mundo.*;
import Tecnologia.*;

/**
 *
 * @author usuariob
 */
public class FactoriaCdM {
    
    public static Reconocimiento factoriaOrdenReconocimiento(int f, int c){
        int area = (int) (Math.random() * 20) + 1;
        return new Reconocimiento(area, f, c);
    }
    
    public static Reparacion factoriaOrdenReparacion(int numDron){
        int pos[] = {(int) (Math.random() * Planeta.getDimF()), (int) (Math.random() * Planeta.getDimC())};
        
        return new Reparacion(numDron, pos[0], pos[1]);
    }
    
    public static void factoriaEstacion(){
//        Estacion tet = new Estacion();
        
        for (int i = 0; i < 200; i++) {
            Estacion.addDron(FactoriaTecnologia.factoriaDron());
        }
//        return tet;
    }
    
}
