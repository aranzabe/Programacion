/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mundo;

import Tecnologia.*;

/**
 *
 * @author usuariob
 */
public class Planeta {
    
    private static String nombre;
    private static Cuadrante[][] mapa;

    static {
        nombre = "Tierra";
        mapa = new Cuadrante[3][3];
    }
        
    public static int getDimF(){
        return mapa.length;
    }
    
    public static int getDimC(){
        return mapa[0].length;
    }
    
    public static void setCuadrante(Cuadrante cuad, int f, int c){
        mapa[f][c] = cuad;
    }
    
    public static Cuadrante getCuadrante(int f, int c){
        return mapa[f][c];
    }
    
    
    public static String toStringS() {
        String cad = nombre + ":\n";
        for (int i = 0; i < getDimF(); i++) {
            for (int j = 0; j < getDimC(); j++) {
                cad += getCuadrante(i, j).toString() + "   ";
            }
            cad += "\n";
        }
        return cad;
    }
}
