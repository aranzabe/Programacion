/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mundo;

import CentroDeMando.*;
import Gente.*;

/**
 *
 * @author danie
 */
public class FactoriaMundo {

    public static Cuadrante factoriaCuadrante(Mecanico jack, Supervisora vika) {
        Cuadrante cuad = new Cuadrante(jack, vika);
        boolean insertado = true;

        //while (!cuad.addDron(tet)){}
        while (insertado) {
            insertado = cuad.addDron();
        }
        return cuad;
    }

    public static void factoriaPlaneta() {
//        Planeta tierra = new Planeta();

        for (int i = 0; i < Planeta.getDimF(); i++) {
            for (int j = 0; j < Planeta.getDimC(); j++) {
                Planeta.setCuadrante(factoriaCuadrante(FactoriaGente.factoriaMecanico(i, j), FactoriaGente.factoriaSupervisora(i, j)), i, j);
            }
        }
//        return tierra;
    }

}
