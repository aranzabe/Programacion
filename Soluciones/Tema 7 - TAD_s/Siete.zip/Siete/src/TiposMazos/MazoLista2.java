/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TiposMazos;

import siete.Carta;

/**
 *
 * @author laura
 */
public class MazoLista2 {

    private class Nodo {

        private Carta dato;
        private Nodo sig;

        public Nodo(Carta dato) {
            this.dato = dato;
            this.sig = null;
        }
    }

    private Nodo principio;
    private Nodo fin;

    public boolean estaVacia() {
        boolean vacio = false;

        if (this.principio == null) {
            vacio = true;
        }

        return vacio;
    }

    public void insertarElemento(Carta e) {
        Nodo nuevo = new Nodo(e);

        if (this.principio == null) {
            this.principio = nuevo;
            this.fin = nuevo;
        } else {
            this.fin.sig = nuevo;
            this.fin = nuevo;
        }
    }

    public Carta obtenerPrimero() {
        Carta primero = null;

        if (this.principio != null) {
            primero = this.principio.dato;
        }
        return primero;
    }

    public void borrarPrimero() {

        if (this.principio != null) {
            this.principio = this.principio.sig;
        } else {
            if (this.principio == null) {
                this.fin = null;
            }
        }
    }

    @Override
    public String toString() {
        String cad = "";
        Nodo aux = this.principio;

        if (this.principio != null) {
            while (aux.sig != null) {
                cad += aux;
            }
        }

        return cad;
    }
}
