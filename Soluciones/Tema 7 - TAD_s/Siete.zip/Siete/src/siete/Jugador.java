/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package siete;

import java.util.LinkedList;

/**
 *
 * @author laura
 */
public class Jugador {

    private float puntos;
    private String tipo;
    private LinkedList<Carta> c;
    private Mazo cartas;

    public Jugador() {
        this.c = new LinkedList();
    }

    public Jugador(String tipo) {
        this.puntos = 0;
        this.tipo = tipo;
        this.c = new LinkedList();
        this.cartas = new Mazo();
    }

    public float getPuntos() {
        return puntos;
    }

    public String getTipo() {
        return tipo;
    }

    void darCarta(Carta car) {
        this.c.add(car);
        this.cartas.addCarta(car);
    }

    @Override
    public String toString() {
        String cad = "";

        cad = "Tipo de Jugador: " + this.tipo + "\n";
        cad += "Puntos: " + this.puntos + "\n";
        cad += "Cartas: " + this.c.toString() + "\n";

        return cad;
    }

    void sumarPuntos(float numero, String palo) {

        if (!palo.equals("Caballo") && !palo.equals("Sota") && !palo.equals("Rey")) {
            this.puntos += numero;
        } else {
            this.puntos = (float) (this.puntos + 0.5);
        }

    }

}
