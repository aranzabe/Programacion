/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package siete;

import java.util.Scanner;

/**
 *
 * @author laura
 */
public class SieteyMedia {

    public static void main(String[] args) {
        Carta c = Factorias.factoriaCarta();
        Mazo mazo = Factorias.factoriaMazo();
        Jugador j = new Jugador("Jugador");
        Jugador m = new Jugador("Maquina");
        boolean jSehapasao = false;
        boolean mSehapasao = false;
        boolean jSeplanta = false;
        boolean mSeplanta = false;
        Carta car;
        int respuesta = 0;
        float puntos;
        int alea;
        Scanner sc = new Scanner(System.in);

        System.out.println(mazo);
        while (!jSehapasao && !jSeplanta && !mSehapasao && !mSeplanta) {
            //-------------------------Reparto de Cartas-------------------------//
            //--------------------------------------------------------------------//
            //----------------------- Turno humano -------------------------------//
            if (!jSehapasao && !jSeplanta) {
                car = mazo.obtenerCarta();
                j.darCarta(car);
                j.sumarPuntos(car.getNumero(), car.getPalo());
                if (j.getPuntos() > 7.5) {
                    jSehapasao = true;
                } else {
                    System.out.println("Otra?");
                    System.out.println("¿Quieres pedir una carta?");
                    respuesta = sc.nextInt();
                    if (respuesta != 1) {
                        jSeplanta = true;
                    }
                    System.out.println(j);
                }
            }
            //----------------------- Turno máquina -------------------------------//
            if (!mSehapasao && !mSeplanta) {
                car = mazo.obtenerCarta();
                m.darCarta(car);
                m.sumarPuntos(car.getNumero(), car.getPalo());
                if (m.getPuntos() > 7.5) {
                    mSehapasao = true;
                } else {
                    alea = (int) (Math.random() * 2);

                    switch (alea) {
                        case 0:
                            respuesta = 1;
                            break;
                        case 1:
                            respuesta = 2;
                    }

                    if (respuesta != 1) {
                        mSeplanta = true;
                    }
                }
            }
        }
        if (jSehapasao && mSehapasao){
            System.out.println("Nadie gana");
        }
        else {
            if (jSehapasao && !mSehapasao){
                System.out.println("Gana la máquina");
            }
            else {
                if (mSehapasao && !jSehapasao){
                    System.out.println("Gana el humano");
                }
                else {
                    if (m.getPuntos() == j.getPuntos()){
                        System.out.println("Empate");
                    }
                    else {
                        if (m.getPuntos() > j.getPuntos()){
                            System.out.println("Máquina gana");
                        }
                        else {
                            System.out.println("Has ganao");
                        }
                    }
                }
            }
        }
    }

}
