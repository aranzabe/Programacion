/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tadpilainicial;

/**
 *
 * @author faranzabe
 */
public class PilaVector {

    private int elementos[];

    public PilaVector(int[] elementos) {
        this.elementos = new int[1];
    }

    public boolean estaVacia() {
        boolean vacia = false;

        if (this.elementos[0]== null) {
            vacia = true;
        }

        return vacia;

    }

    public boolean apilarElemento(int e) {
        boolean conseguido = false;
        int i = 0;

        while (i < this.elementos.length && !conseguido) {
            if (this.elementos[i] == null) {
                this.elementos[i] = e;
                conseguido = true;
            }
            i++;
        }
        return conseguido;
    }

    public int obtenerCima() {
        int cima = 0;
        int i = 0;

        while (i < this.elementos.length) {
            if (this.elementos[i] != null) {
                cima = this.elementos[i];
            }
            i++;
        }
        return cima;
    }

    public boolean desapilarCima() {
        boolean conseguido = false;
        int i = 0;

        if (this.elementos[i] != null) {
            this.elementos[this.elementos.length - 1] = null;
            conseguido=true;
        }
        i++;

        return conseguido;
    }

    @Override
    public String toString() {
        String cad = "";

        for (int i = 0; i < this.elementos.length; i++) {
            cad += this.elementos[i] + " ";
        }

        return cad;
    }

}
