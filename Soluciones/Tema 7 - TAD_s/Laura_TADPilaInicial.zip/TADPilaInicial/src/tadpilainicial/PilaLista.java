/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tadpilainicial;

/**
 *
 * @author faranzabe
 */
public class PilaLista {

    private class Nodo {

        private int dato;
        private Nodo sig;

        public Nodo(int dato) {
            this.dato = dato;
            this.sig = null;
        }

    }

    private Nodo cima;

    public boolean estaVacia() {
        boolean vacio = false;

        if (this.cima == null) {
            vacio = true;
        }

        return vacio;
    }

    public void apilarElemento(int e) {
        Nodo nuevo = new Nodo(e);
        Nodo aux;

        if (this.cima == null) {
            this.cima = nuevo;
        } else {
            aux = this.cima;
            while (aux.sig != null) {
                aux = aux.sig;
            }
            aux.sig = nuevo;
        }
    }

    public int obtenerCima() {
        Nodo aux;
        int ultimo = 0;

        if (this.cima.sig == null) {
            ultimo = this.cima.dato;
        } else {
            aux = this.cima;
            while (aux.sig != null) {
                aux = aux.sig;
            }
            ultimo = aux.dato;
        }
        return ultimo;
    }

    public void desapilarCima() {
        Nodo aux;

        if (this.cima.sig == null) {
            this.cima = null;
        } else {
            aux = this.cima;
            while (aux.sig != null) {
                aux = aux.sig;
            }
            aux = null;
        }
    }

    @Override
    public String toString() {
        String cad = "";
        cad = "cima--> ";
        Nodo aux = this.cima;

        while (aux != null) {
            cad += aux.dato + "-->";
            aux = aux.sig;
        }
        cad += " null";
        return cad;
    }
}
