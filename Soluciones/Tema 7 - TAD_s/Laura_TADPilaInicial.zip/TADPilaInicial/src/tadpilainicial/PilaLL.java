/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tadpilainicial;

import java.util.LinkedList;

/**
 *
 * @author faranzabe
 */
public class PilaLL {

    private LinkedList pila;

    public PilaLL() {
        this.pila = null;
    }

    public boolean estaVacia() {
        boolean conseguido = false;
        if (this.pila.isEmpty()) {
            conseguido = true;
        }
        return conseguido;
    }

    public void apilarElemento(int e) {
        this.pila.addLast(e);
    }

    public void obtenerCima() {
        this.pila.getFirst();
    }

    public void desapilarCima() {
        this.pila.removeLast();
    }

    @Override
    public String toString() {
        String cad = "";

        cad += this.pila.toString();

        return cad;
    }

}
