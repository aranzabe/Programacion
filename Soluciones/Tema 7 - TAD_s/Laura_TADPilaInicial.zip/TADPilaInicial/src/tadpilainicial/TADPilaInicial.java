/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tadpilainicial;

/**
 *
 * @author faranzabe
 */
public class TADPilaInicial {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //PilaVector p = new PilaVector();
//        PilaLista p = new PilaLista();
       PilaAL p = new PilaAL();
//        PilaLL p = new PilaLL();


        p.apilarElemento(4);
        p.apilarElemento(10);
        p.apilarElemento(18);
        while(!p.estaVacia()){
            System.out.println(p.obtenerCima());
            p.desapilarCima();
        }
        System.out.println(p.toString());
    }
    
}
