/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tadpilainicial;

/**
 *
 * @author faranzabe
 */
public class PilaLista {

    private class Nodo {

        private int dato;
        private Nodo sig;

        public Nodo(int dato) {
            this.dato = dato;
            this.sig = null;
        }

    }
    
    private Nodo cima;

    public PilaLista() {
        this.cima = null;
    }
    
    public boolean estaVacia() {
        return this.cima == null;
    }

    public void apilarElemento(int e) {
        if (this.cima == null){
            this.cima = new Nodo(e);
        } else {
            Nodo nuevo = new Nodo(e);
            nuevo.sig = this.cima;
            this.cima = nuevo;
        }
    }

    public int obtenerCima() {
        return this.cima.dato;
    }

    public boolean desapilarCima() {
        boolean conseguido = false;
        
        if (this.cima != null){
            this.cima = this.cima.sig;
            conseguido = true;
        }
        return conseguido;
    }
}
