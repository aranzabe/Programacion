/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tadpilainicial;

/**
 *
 * @author faranzabe
 */
public class PilaVector {

    private int elementos[];

    public PilaVector() {
        this.elementos = null;
    }

    public boolean estaVacia() {
        return this.elementos == null;
    }

    public void apilarElemento(int e) {
        if (this.elementos == null) {
            this.elementos = new int[1];
            this.elementos[1] = e;
        } else {
            int nuevo[] = new int[this.elementos.length + 1];
            for (int i = 0; i < this.elementos.length; i++) {
                nuevo[i] = this.elementos[i];
            }
            nuevo[nuevo.length - 1] = e;
            this.elementos = nuevo;
        }
    }

    public int obtenerCima() {
        return this.elementos[this.elementos.length - 1];
    }

    public boolean desapilarCima() {
        boolean conseguido = false;
        
        if (this.elementos != null) {
            int nuevo[] = new int[this.elementos.length - 1];
            for (int i = 0; i < nuevo.length; i++) {
                nuevo[i] = this.elementos[i];
            }
            this.elementos = nuevo;
            conseguido = true;
        }
        return conseguido;
    }
}
