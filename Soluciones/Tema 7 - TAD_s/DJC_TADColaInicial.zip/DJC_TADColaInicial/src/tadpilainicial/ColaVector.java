/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tadpilainicial;

/**
 *
 * @author faranzabe
 */
public class ColaVector {

    private int elementos[];

    public ColaVector() {
        this.elementos = null;
    }

    public boolean estaVacia() {
        return this.elementos == null;
    }

    public void insertarElemento(int e) {
        if (this.elementos == null) {
            this.elementos = new int[1];
            this.elementos[1] = e;
        } else {
            int nuevo[] = new int[this.elementos.length + 1];
            for (int i = 0; i < this.elementos.length; i++) {
                nuevo[i] = this.elementos[i];
            }
            nuevo[nuevo.length - 1] = e;
            this.elementos = nuevo;
        }
    }

    public int getPrimero() {
        return this.elementos[0];
    }

    public boolean extraerPrimero() {
        boolean conseguido = false;

        if (this.elementos != null) {
            if (this.elementos.length == 1) {
                this.elementos = null;
            } else {
                int nuevo[] = new int[this.elementos.length - 1];
                for (int i = 0; i < nuevo.length; i++) {
                    nuevo[i] = this.elementos[i + 1];
                }
                this.elementos = nuevo;
            }
            conseguido = true;
        }
        return conseguido;
    }
}
