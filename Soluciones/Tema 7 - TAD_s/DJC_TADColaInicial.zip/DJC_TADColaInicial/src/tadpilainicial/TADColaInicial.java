/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tadpilainicial;

/**
 *
 * @author faranzabe
 */
public class TADColaInicial {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //PilaVector p = new PilaVector();
//        PilaLista p = new PilaLista();
//        PilaAL p = new PilaAL();
        ColaLL p = new ColaLL();


        p.insertarElemento(4);
        p.insertarElemento(10);
        p.insertarElemento(18);
        while(!p.estaVacia()){
            System.out.println(p.getPrimero());
            p.extraerPrimero();
        }
    }
    
}
