/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tadpilainicial;

import java.util.LinkedList;

/**
 *
 * @author faranzabe
 */
public class ColaLL {
    
    private LinkedList pila;

    public ColaLL() {
        this.pila = new LinkedList();
    }
    
    public boolean estaVacia(){
        return this.pila.isEmpty();
    }
    
    public void insertarElemento(int e){
        this.pila.addLast(e);
    }
    
    public int getPrimero(){
        return (int) this.pila.getFirst();
    }
    
    public void extraerPrimero(){
        this.pila.removeFirst();
    }
}
