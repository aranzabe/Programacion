/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tadpilainicial;

/**
 *
 * @author faranzabe
 */
public class ColaLista {

    private class Nodo {

        private int dato;
        private Nodo sig;

        public Nodo(int dato) {
            this.dato = dato;
            this.sig = null;
        }

    }
    
    private Nodo primero;

    public ColaLista() {
        this.primero = null;
    }
    
    public boolean estaVacia() {
        return this.primero == null;
    }

    public void insertarElemento(int e) {
        Nodo aux = this.primero;
        
        if (this.primero == null){
            this.primero = new Nodo(e);
        } else {
            while (aux.sig != null){
                aux = aux.sig;
            }
            aux.sig = new Nodo(e);
        }
    }

    public int getPrimero() {
        return this.primero.dato;
    }

    public boolean extraerPrimero() {
        boolean conseguido = false;
        
        if (this.primero != null){
            this.primero = this.primero.sig;
            conseguido = true;
        }
        return conseguido;
    }
}
