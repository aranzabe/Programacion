/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tadpilainicial;

import java.util.ArrayList;

/**
 *
 * @author faranzabe
 */
public class ColaAL {
    
    private ArrayList pila;

    public ColaAL() {
        this.pila = new ArrayList();
    }
    
    public boolean estaVacia(){
        return this.pila.isEmpty();
    }
    
    public void insertarElemento(int e){
        this.pila.add(e);
    }
    
    public int getPrimero(){
        return (int) this.pila.get(0);
    }
    
    public void extraerPrimero(){
        this.pila.remove(0);
    }
    
}
