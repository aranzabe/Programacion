/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tadpilainicial;

/**
 *
 * @author faranzabe
 */
public class ColaLista2 {

    private class Nodo {

        private int dato;
        private Nodo sig;

        public Nodo(int dato) {
            this.dato = dato;
            this.sig = null;
        }

    }

    private Nodo primero;
    private Nodo ultimo;

    public ColaLista2() {
        this.primero = null;
        this.ultimo = null;
    }

    public boolean estaVacia() {
        return this.primero == null;
    }

    public void instertarElemento(int e) {
        Nodo nuevo = new Nodo(e);
        if (this.primero == null) {
            this.primero = nuevo;
            this.ultimo = nuevo;
        } else {
            this.ultimo.sig = nuevo;
            this.ultimo = nuevo;
        }
    }

    public int getPrimero() {
        return this.primero.dato;
    }

    public boolean extraerPrimero() {
        boolean conseguido = false;

        if (this.primero != null) {
            this.primero = this.primero.sig;
            if (this.primero == null) {
                this.ultimo = null;
            }
            conseguido = true;
        }
        return conseguido;
    }
}
