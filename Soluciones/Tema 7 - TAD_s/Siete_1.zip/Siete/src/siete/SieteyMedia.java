/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package siete;

import java.util.Scanner;

/**
 *
 * @author laura
 */
public class SieteyMedia {

    public static void main(String[] args) {
        Carta c = Factorias.factoriaCarta();
        Mazo mazo = Factorias.factoriaMazo();
        Jugador j = new Jugador(0, "Jugador", null);
        Jugador m = new Jugador(0, "Maquina", null);
        Carta car;
        int respuesta;
        float puntos;
        int alea;
        Scanner sc = new Scanner(System.in);

        System.out.println(mazo);

        //-------------------------Reparto de Cartas-------------------------//
        //--------------------------------------------------------------------//
        car = mazo.obtenerCarta();
        j.darCarta(car);
        j.sumarPuntos(car.getNumero(), car.getPalo());
        System.out.println(j);
        //-----------------------//
        car = mazo.obtenerCarta();
        m.darCarta(car);
        m.sumarPuntos(car.getNumero(), car.getPalo());
        System.out.println(m);

        //-----------------------------Turno Jugador--------------------------//
        //--------------------------------------------------------------------//
        //////////////1 es si, 2 es no
        System.out.println("¿Quieres pedir una carta?");
        respuesta = sc.nextInt();

        if (respuesta == 1) {
            car = mazo.obtenerCarta();
            j.darCarta(car);
            j.sumarPuntos(car.getNumero(), car.getPalo());
        } else {
            //-----------------------------Turno Maquina--------------------------//
            //--------------------------------------------------------------------//
            alea = (int) (Math.random() * 2);

            switch (alea) {
                case 0:
                    respuesta = 1;
                    break;
                case 1:
                    respuesta = 2;
            }

            if (respuesta == 1) {
                car = mazo.obtenerCarta();
                m.darCarta(car);
                m.sumarPuntos(car.getNumero(), car.getPalo());
            }
        }

    }

}
