/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package siete;

import java.util.LinkedList;

/**
 *
 * @author laura
 */
public class Jugador {

    private float puntos;
    private String tipo;
    private LinkedList<Carta> c;

    public Jugador() {
        this.puntos = puntos;
        this.tipo = tipo;
        this.c = new LinkedList();
    }

    public Jugador(int puntos, String tipo, LinkedList<Carta> c) {
        this.puntos = puntos;
        this.tipo = tipo;
        this.c = new LinkedList();
    }

    public float getPuntos() {
        return puntos;
    }

    public String getTipo() {
        return tipo;
    }

    void darCarta(Carta car) {
        this.c.add(car);
    }

    @Override
    public String toString() {
        String cad = "";

        cad = "Tipo de Jugador: " + this.tipo + "\n";
        cad += "Puntos: " + this.puntos + "\n";
        cad += "Cartas: " + this.c.toString() + "\n";

        return cad;
    }

    void sumarPuntos(float numero, String palo) {

        if (palo != "Caballo" && palo != "Sota" && palo != "Rey") {
            this.puntos += numero;
        } else {
            this.puntos = (float) (this.puntos + 0.5);
        }

    }

}
