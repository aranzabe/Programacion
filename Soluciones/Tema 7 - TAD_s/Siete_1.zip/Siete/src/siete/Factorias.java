/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package siete;

/**
 *
 * @author laura
 */
public class Factorias {

    public static Carta factoriaCarta() {
        String palo = "";
        int numero;
        int alea;
        Carta c = new Carta();

        numero = (int) (Math.random() * 4 + 1);

        switch (numero) {
            case 1:
                palo = "Copas";
                break;
            case 2:
                palo = "Bastos";
                break;
            case 3:
                palo = "Oros";
                break;
            case 4:
                palo = "Espadas";
        }

        numero = (int) (Math.random() * 12 + 1);
        if (numero != 8 && numero != 9 && numero < 10) {
            c = new Carta(palo, numero);
        } else {
            if (numero != 8 && numero != 9 && numero >= 10) {

                alea = (int) (Math.random() * 3 + 1);

                switch (alea) {
                    case 1:
                        palo = "Sota";
                        break;
                    case 2:
                        palo = "Caballo";
                        break;
                    case 3:
                        palo = "Rey";
                }

                c = new Carta(palo, numero);
            }

        }

        return c;
    }

    public static Mazo factoriaMazo() {
        Mazo m = new Mazo();

        for (int i = 0; i < 40; i++) {
            Carta c = factoriaCarta();
            m.addCarta(c);
        }

        return m;
    }
}
