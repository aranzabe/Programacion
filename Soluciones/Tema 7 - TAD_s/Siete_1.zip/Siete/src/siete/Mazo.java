/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package siete;

import TiposMazos.MazoAL;

/**
 *
 * @author laura
 */
public class Mazo {

    private MazoAL carta;

    public Mazo() {
        this.carta = new MazoAL();
    }

    public Mazo(MazoAL carta) {
        this.carta = carta;
    }

    void addCarta(Carta c) {
        this.carta.insertarElemento(c);
    }

    @Override
    public String toString() {
        String cad = "";

        cad = "Mazo: " + "\n";
        cad += this.carta.toString() + "\n";

        return cad;
    }

    public Carta obtenerCarta() {
        Carta c = new Carta();

        c = this.carta.obtenerPrimero();
        this.carta.borrarPrimero();

        return c;
    }

}
