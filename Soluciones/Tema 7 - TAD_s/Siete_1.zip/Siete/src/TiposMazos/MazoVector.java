/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TiposMazos;

import siete.Carta;

/**
 *
 * @author faranzabe
 */
public class MazoVector {

    private Carta cola[];

    public MazoVector() {
        this.cola = null;
    }

    public boolean estaVacia() {
        boolean vacia = false;

        if (this.cola == null) {
            vacia = true;
        }

        return vacia;

    }

    private Carta[] AumentarVector(Carta[] elementos) {
        Carta[] aux = new Carta[this.cola.length + 1];

        for (int i = 0; i < this.cola.length; i++) {
            aux[i] = this.cola[i];
        }

        return aux;
    }

    private Carta[] DisminuirVector(Carta[] elementos) {
        Carta[] aux = new Carta[this.cola.length - 1];
        int j=1;

        for (int i = 0; i < aux.length; i++) {
            aux[j] = this.cola[i];
            j++;
        }

        return aux;
    }

    public void insertarElemento(Carta e) {

        if (this.cola == null) {
            this.cola = new Carta[1];
            this.cola[0] = e;
        } else {
            this.cola = AumentarVector(this.cola);
            this.cola[this.cola.length - 1] = e;
        }

    }

    public Carta obtenerPrimero() {
        Carta cima = null;
        if (this.cola != null) {
            cima = this.cola[0];
        }
        return cima;
    }

    public boolean borrarPrimero() {
        boolean conseguido = false;

        if (this.cola != null) {
            conseguido = true;
            if (this.cola.length == 1) {
                this.cola = null;
            } else {
                this.cola=DisminuirVector(this.cola);            
            }
        }
        return conseguido;
    }

    @Override
    public String toString() {
        String cad = "";

        if (this.cola != null) {
            for (int i = 0; i < this.cola.length; i++) {
                cad += this.cola[i] + " ";
            }
        }

        return cad;
    }

}
