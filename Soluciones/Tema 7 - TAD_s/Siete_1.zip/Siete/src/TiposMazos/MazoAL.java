/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TiposMazos;

import java.util.ArrayList;
import siete.Carta;

/**
 *
 * @author faranzabe
 */
public class MazoAL {

    private ArrayList <Carta> cola;

    public MazoAL() {
        this.cola = new ArrayList();
    }

    /**
     * Nos dice si la pila de elementos esta vacia
     *
     * @return devuelve true si esta vacia, false si no lo esta.
     */
    public boolean estaVacia() {
        return this.cola.isEmpty();
    }

    public void insertarElemento(Carta e) {
        this.cola.add(e);
    }

    /**
     * Nos ofrece el ultimo elemento introducido del Arraylist
     *
     * @return Devolvera el ultimo elemento del arraylist si hay algo, sino
     * devolvera -1
     */
    public Carta obtenerPrimero() {
        Carta cima = null;

        if(!this.cola.isEmpty()){
            cima=this.cola.get(0);
        }

        return cima;
    }

    public void borrarPrimero() {

        if (!this.cola.isEmpty()) {
            this.cola.remove(0);
        }
    }

    @Override
    public String toString() {
        String cad = "";

        if (!this.cola.isEmpty()) {
            cad += this.cola.toString();
        }
        return cad;
    }

}
