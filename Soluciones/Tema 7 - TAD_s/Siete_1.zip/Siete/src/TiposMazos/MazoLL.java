/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TiposMazos;

import java.util.LinkedList;
import siete.Carta;

/**
 *
 * @author faranzabe
 */
public class MazoLL {

    private LinkedList cola;

    public MazoLL() {
        this.cola = new LinkedList();
    }

    public boolean estaVacia() {
        return this.cola.isEmpty();
    }

    public void insertarElemento(Carta e) {
        this.cola.addLast(e);
    }

    public void obtenerPrimero() {
        this.cola.getFirst();
    }

    public void borrarPrimero() {
        this.cola.removeFirst();
    }

    @Override
    public String toString() {
        String cad = "";

        if (!this.cola.isEmpty()) {
            cad += this.cola.toString();
        }
        return cad;
    }

}
