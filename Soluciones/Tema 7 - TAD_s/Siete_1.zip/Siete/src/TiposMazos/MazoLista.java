/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TiposMazos;

import siete.Carta;

/**
 *
 * @author faranzabe
 */
public class MazoLista {

    private class Nodo {

        private Carta dato;
        private Nodo sig;

        public Nodo(Carta dato) {
            this.dato = dato;
            this.sig = null;
        }

    }

    private Nodo cola;

    public boolean estaVacia() {
        boolean vacio = false;

        if (this.cola == null) {
            vacio = true;
        }

        return vacio;
    }

    public void insertarElemento(Carta e) {
        Nodo nuevo = new Nodo(e);
        Nodo aux;

        if (this.cola == null) {
            this.cola = nuevo;
        } else {
            aux = this.cola;
            while (aux.sig != null) {
                aux = aux.sig;
            }
            aux.sig = nuevo;
        }
    }

    public Carta obtenerPrimero() {
        Carta primero = null;

        if (this.cola != null) {
            primero = this.cola.dato;
        }
        return primero;
    }

    public void borrarPrimero() {

        if (this.cola.sig != null) {
            this.cola = this.cola.sig;
        }
    }

    @Override
    public String toString() {
        String cad = "";

        if (this.cola != null) {
            cad += this.cola.dato;
        }

        return cad;
    }
}
