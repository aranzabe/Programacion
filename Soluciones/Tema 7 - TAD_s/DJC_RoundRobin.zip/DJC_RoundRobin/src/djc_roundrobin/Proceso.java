/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_roundrobin;

/**
 *
 * @author danie
 */
public class Proceso {
    private int prioridad;
    private String identidad;
    private float quantum;
    private boolean listo;
    public static int CUANTOS = 0;

    public Proceso() {
        this.identidad = "";
        this.quantum = 0;
        this.listo = false;
        CUANTOS++;
    }

    public Proceso(String identidad, float quantum, int prio) {
        this.identidad = identidad;
        this.quantum = quantum;
        this.listo = false;
        CUANTOS++;
        this.prioridad = prio;
    }

    public boolean isListo() {
        return listo;
    }

    public void setListo(boolean listo) {
        this.listo = listo;
    }

    public float getQuantum() {
        return quantum;
    }

    public void setQuantum(float quantum) {
        this.quantum = quantum;
    }

    public int getPrioridad() {
        return prioridad;
    }
    
    

    @Override
    public String toString() {
        return this.identidad + '(' + this.quantum + " s)";
    }
    
    
}
