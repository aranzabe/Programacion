/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_roundrobin;

/**
 *
 * @author danie
 */
public class Factoria {

    public static Proceso factoriaProceso() {
        int p = (int) (Math.random() * 3) + 1;
        float quantum = (int) (Math.random() * 4) + 1;
        String id = "P" + Proceso.CUANTOS;

        return new Proceso(id, quantum, p);
    }

}
