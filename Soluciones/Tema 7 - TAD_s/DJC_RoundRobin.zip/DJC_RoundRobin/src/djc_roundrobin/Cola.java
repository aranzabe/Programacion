/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_roundrobin;

import java.util.LinkedList;

/**
 *
 * @author faranzabe
 */
public class Cola {

    private LinkedList cola;

    public Cola() {
        this.cola = new LinkedList();
    }

    public boolean estaVacia() {
        return this.cola.isEmpty();
    }

    public void insertarElemento(Proceso e) {
        this.cola.addLast(e);
    }

    public Proceso obtenerPrimero() {
        return (Proceso) this.cola.getFirst();
    }

    public void borrarPrimero() {
        this.cola.removeFirst();
    }

    @Override
    public String toString() {
        String cad = "";

        if (!this.cola.isEmpty()) {
            cad += this.cola.toString();
        }
        return cad;
    }

    public void insertarElementoPrioridad(Proceso pInsertar) {
        boolean insertado = false;
        if (this.cola.isEmpty()) {
            this.cola.add(pInsertar);
        } else {
            int i = 0;
            while (i < this.cola.size() && !insertado) {
                Proceso p = (Proceso) this.cola.get(i);
                if (pInsertar.getPrioridad() == p.getPrioridad()) {
                    this.cola.add(i, pInsertar);
                    insertado = true;
                }
                i++;
            }
        }
    }

}
