/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_roundrobin;

/**
 *
 * @author danie
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        Cola procesosPendientes = new Cola();
        Pila procesosTerminados = new Pila();
        float t = 0;

        while (true) {
            if (t % 2 == 0) {
                //procesosPendientes.insertarElemento(Factoria.factoriaProceso());
                procesosPendientes.insertarElementoPrioridad(Factoria.factoriaProceso());
            }
            if (!procesosPendientes.estaVacia()) {
                Proceso p = procesosPendientes.obtenerPrimero();
                procesosPendientes.borrarPrimero();
                p.setQuantum((float) (p.getQuantum() - 0.2));
                if (p.getQuantum() > 0) {
                    procesosPendientes.insertarElementoPrioridad(p);
                } else {
                    p.setListo(true);
                    procesosTerminados.PUSH(p);
                }
                System.out.println(p.toString());
            } else {
                System.out.println("No hay procesos en la CPU");
            }
            t = (float) (t + 0.2);
            Thread.sleep(200);
        }
    }

}
