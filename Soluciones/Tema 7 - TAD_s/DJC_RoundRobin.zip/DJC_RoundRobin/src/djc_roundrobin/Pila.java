/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_roundrobin;

import java.util.LinkedList;

/**
 *
 * @author faranzabe
 */
public class Pila {

    private LinkedList pila;

    public Pila() {
        this.pila = new LinkedList();
    }

    public boolean estaVacia() {
//        boolean conseguido = false;
//        if (this.pila.isEmpty()) {
//            conseguido = true;
//        }
        return this.pila.isEmpty();
    }

    public void apilarElemento(Proceso e) {
        this.pila.addLast(e);
        //this.pila.addFirst(e);
    }

    public Proceso obtenerCima() {
        return (Proceso) this.pila.getLast();
        //return this.pila.getFirst();
    }

    public void desapilarCima() {
        this.pila.removeLast();
//        this.pila.removeFirst();
    }

    @Override
    public String toString() {
        String cad = "";

        if (!this.pila.isEmpty()) {
            cad += this.pila.toString();
        }

        return cad;
    }

    public void PUSH(Proceso e) {
        this.pila.addLast(e);
        //this.pila.addFirst(e);
    }
    
    public Proceso POP() {
        Proceso e = (Proceso) this.pila.getLast();
        this.pila.removeLast();
        return e;
    }

   
}
