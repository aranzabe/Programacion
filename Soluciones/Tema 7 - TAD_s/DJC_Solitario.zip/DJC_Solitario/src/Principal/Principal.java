/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Principal;

import Cartas.*;
import Auxiliares.*;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author usuariob
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Baraja b = Factoria.factoriaBaraja();
        System.out.println(b.toString());
        PilaCartas mazoPrincipal = Auxiliar.barajearMazo(b);
        Baraja cartasSacadas = new Baraja();
        PilaCartas monton[] = new PilaCartas[4];

        for (int i = 0; i < monton.length; i++) {
            monton[i] = new PilaCartas();
        }
        int cont = 0;
        int montonElegido = 0;
        boolean jugadaCorrecta = false;
        boolean victoria = false;

        while (cont < 3 && !victoria) {
            while (!mazoPrincipal.estaVacia()) {
                System.out.println(mazoPrincipal.toString());
                for (int i = 0; i < monton.length; i++) {
                    System.out.print("Montón " + (i + 1) + ": ");
                    if (monton[i].estaVacia()) {
                        System.out.println("-");
                    } else {
                        System.out.println(monton[i].toString());
                    }
                }
                cartasSacadas.apilarElemento(mazoPrincipal.POP());
                Carta c = cartasSacadas.obtenerCima();
                do {
                    System.out.println("Has sacado el " + c.toString());
                    jugadaCorrecta = false;
                    System.out.println("¿En qué montón quieres colocar la carta?");
                    System.out.println("0 - Sacar otra carta");
                    System.out.println("1 - 4: Seleccionar montón");
                    try {
                        montonElegido = sc.nextInt();
                        if (montonElegido < 0 || montonElegido > 4) {
                            Excepcion404 e404 = new Excepcion404("404");
                            throw e404;
                        }
                        if (montonElegido != 0) {
                            if (monton[montonElegido - 1].estaVacia()) {
                                if (c.getValor() != 13) {
                                    throw new Excepcion101("101");
                                }
                            } else {
                                if (monton[montonElegido - 1].obtenerCima().getValor() != c.getValor() + 1
                                        || monton[montonElegido - 1].obtenerCima().getColor().equals(c.getColor())) {
                                    throw new Excepcion101("101");
                                }
                            }
                            monton[montonElegido - 1].PUSH(c);
                            cartasSacadas.POP();
                        }
                        jugadaCorrecta = true;
                    } catch (Excepcion404 ex) {
                        System.err.println("Error 404 - Montón not found");
                    } catch (Excepcion101 ex) {
                        System.err.println("Error 101 - Jugada incorrecta");
                    }
                } while (!jugadaCorrecta);
            }
            System.out.println("El mazo está vacío");
            mazoPrincipal = Auxiliar.barajearMazo(cartasSacadas);
            victoria = true;
            int i = 0;
            while (victoria && i < monton.length) {
                if (monton[i].estaVacia()) {
                    victoria = false;
                } else {
                    if (monton[i].obtenerCima().getValor() != 1) {
                        victoria = false;
                    } else {
                        i++;
                    }
                }
            }
            if (!victoria) {
                cont++;
                System.out.println("El mazo se barajea. Llevas " + cont + " de 3 intentos");
            }
        }
        if (!victoria) {
            System.out.println("Has perdido");
        } else {
            System.out.println("Has ganado");
        }
    }

}
