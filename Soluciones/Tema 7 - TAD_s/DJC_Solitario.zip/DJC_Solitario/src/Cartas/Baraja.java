/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cartas;

import java.util.LinkedList;

/**
 *
 * @author usuariob
 */
public class Baraja {

    private LinkedList<Carta> baraja;

    public Baraja() {
        this.baraja = new LinkedList();
    }

    public boolean estaVacia() {
        return this.baraja.isEmpty();
    }

    public void apilarElemento(Carta e) {
        this.baraja.addFirst(e);
    }

    public Carta extraerPosicion(int i) {
        Carta e = this.baraja.get(i);
        this.baraja.remove(i);
        return e;
    }
    
    public Carta POP(){
        Carta c = this.baraja.getFirst();
        this.baraja.removeFirst();
        return c;
    }

    public Carta obtenerCima(){
        return this.baraja.getFirst();
    }
    
    public Carta getPosicion(int i) {
        return this.baraja.get(i);
    }

    public int getCuantos() {
        return this.baraja.size();
    }

    @Override
    public String toString() {
        String cad = "";

        if (!this.estaVacia()) {
            for (int i = 0; i < this.getCuantos(); i++) {
                cad += this.getPosicion(i).toString() + "\n";
            }
        }
        return cad;
    }
}
