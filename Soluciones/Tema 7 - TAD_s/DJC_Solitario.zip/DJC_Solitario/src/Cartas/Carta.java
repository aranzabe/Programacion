/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cartas;

/**
 *
 * @author usuariob
 */
public class Carta {
    
    private int valor;
    private String palo;
    private String color;

    public Carta() {
        this.valor = 0;
        this.palo = "";
        this.color = "";
    }

    public Carta(int valor, String palo, String color) {
        this.valor = valor;
        this.palo = palo;
        this.color = color;
    }

    public int getValor() {
        return valor;
    }

    public String getColor(){
        return color;
    }
    
    @Override
    public String toString() {
        String cad = "";
        switch (this.valor){
            case 1: cad = "A"; break;
            case 11: cad = "J"; break;
            case 12: cad = "Q"; break;
            case 13: cad = "K"; break;
            default: cad = String.valueOf(this.valor);
        }
        switch (this.palo){
            case "Corazones": cad += "♥"; break;
            case "Diamantes": cad += "♦"; break;
            case "Tréboles": cad += "♣"; break;
            case "Picas": cad += "♠";
        }
        return cad;
    }
    
}
