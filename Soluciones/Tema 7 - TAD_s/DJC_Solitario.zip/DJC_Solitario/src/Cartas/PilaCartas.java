/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cartas;

import java.util.LinkedList;

/**
 *
 * @author faranzabe
 */
public class PilaCartas {
    
    private LinkedList<Carta> pila;

    public PilaCartas() {
        this.pila = new LinkedList();
    }
    
    public boolean estaVacia(){
        return this.pila.isEmpty();
    }
    
    public void PUSH(Carta e){
        this.pila.addFirst(e);
    }
    
    public Carta obtenerCima(){
        return this.pila.getFirst();
    }
    
    public void desapilarCima(){
        this.pila.removeFirst();
    }
    
    public Carta POP(){
        Carta c = this.pila.getFirst();
        this.pila.removeFirst();
        return c;
    }
    
    public int getCuantos(){
        return this.pila.size();
    }

    public Carta getPosicion(int i){
        return this.pila.get(i);
    }
    
    @Override
    public String toString() {
        String cad = "";
        
        for (int i = 0; i < this.getCuantos(); i++) {
            cad += " " + this.getPosicion(i).toString();
        }
        return cad;
    }
    
}
