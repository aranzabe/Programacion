/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Auxiliares;

/**
 * Cuando el montón no existe.
 * @author danie
 */
public class Excepcion404 extends Exception {

    public Excepcion404(String message) {
        super(message);
    }
    
}
