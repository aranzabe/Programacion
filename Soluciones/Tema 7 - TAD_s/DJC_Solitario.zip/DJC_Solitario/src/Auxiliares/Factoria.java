/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Auxiliares;

import Cartas.Carta;
import Cartas.Baraja;

/**
 *
 * @author usuariob
 */
public class Factoria {

    public static Carta factoriaCarta(int valor, String palo){
        String color = "";
        if (palo.equals("Diamantes") || palo.equals("Corazones")){
            color = "Rojo";
        } else {
            color = "Negro";
        }
        return new Carta(valor, palo, color);
    }
    
    public static Baraja factoriaBaraja(){
        Baraja b = new Baraja();
        String palo = "";
        for (int i = 0; i < 4; i++) {
            for (int j = 1; j < 14; j++) {
                switch (i){
                    case 0: palo = "Diamantes"; break;
                    case 1: palo = "Tréboles"; break;
                    case 2: palo = "Corazones"; break;
                    case 3: palo = "Picas";
                }
                b.apilarElemento(factoriaCarta(j, palo));
            }
        }
        return b;
    }
    
}
