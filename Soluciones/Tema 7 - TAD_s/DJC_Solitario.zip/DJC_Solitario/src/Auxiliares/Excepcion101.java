/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Auxiliares;

/**
 * Cuando la jugada no es correcta.
 * @author danie
 */
public class Excepcion101 extends Exception {

    public Excepcion101(String message) {
        super(message);
    }
    
}
