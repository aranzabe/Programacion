/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pilas;

import java.util.LinkedList;

/**
 *
 * @author faranzabe
 */
public class PilaLL {

    private LinkedList pila;

    public PilaLL() {
        this.pila = new LinkedList();
    }

    public boolean estaVacia() {
        return this.pila.isEmpty();
    }

    public void apilarElemento(char e) {
        this.pila.addFirst(e);
    }

    public char obtenerCima() {
        return (char) this.pila.getFirst();
    }

    public void desapilarCima() {
        this.pila.removeFirst();
    }

    @Override
    public String toString() {
        String cad = "";

        if (!this.pila.isEmpty()) {
            cad += this.pila.toString();
        }
        return cad;
    }

}
