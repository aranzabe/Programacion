/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pilas;

/**
 *
 * @author faranzabe
 */
public class PilaVector {

    private char elementos[];

    public PilaVector() {
        this.elementos = null;
    }

    public boolean estaVacia() {
        boolean vacia = false;

        if (this.elementos == null) {
            vacia = true;
        }

        return vacia;

    }

    public char[] AumentarVector(char[] elementos) {
        char[] aux = new char[this.elementos.length + 1];

        for (int i = 0; i < this.elementos.length; i++) {
            aux[i] = this.elementos[i];
        }

        return aux;
    }

    public char[] DisminuirVector(char[] elementos) {
        char[] aux = new char[this.elementos.length - 1];

        for (int i = 0; i < aux.length; i++) {
            aux[i] = this.elementos[i];
        }

        return aux;
    }

    public void apilarElemento(char e) {

        if (this.elementos == null) {
            this.elementos = new char[1];
            this.elementos[0] = e;
        } else {
            this.elementos = AumentarVector(this.elementos);
            this.elementos[this.elementos.length - 1] = e;
        }

    }

    public char obtenerCima() {
        char cima='n';
        if (this.elementos != null) {
            cima = this.elementos[this.elementos.length - 1];
        } 
        
        return cima;
    }

    public boolean desapilarCima() {
        boolean conseguido = false;

        if (this.elementos != null) {
            conseguido = true;
            if (this.elementos.length == 1) {
                this.elementos = null;
            } else {
                this.elementos = DisminuirVector(this.elementos);
            }
        }
        return conseguido;
    }

    @Override
    public String toString() {
        String cad = "";

        if (this.elementos != null) {
            for (int i = 0; i < this.elementos.length; i++) {
                cad += this.elementos[i] + " ";
            }
        }

        return cad;
    }

}
