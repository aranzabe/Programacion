/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pilas;

/**
 *
 * @author faranzabe
 */
public class PilaLista {

    private class Nodo {

        private int dato;
        private Nodo sig;

        public Nodo(char dato) {
            this.dato = dato;
            this.sig = null;
        }

    }

    private Nodo cima;

    public boolean estaVacia() {
        boolean vacio = false;

        if (this.cima == null) {
            vacio = true;
        }

        return vacio;
    }

    public void apilarElemento(char e) {
        Nodo nuevo = new Nodo(e);
        Nodo aux;

        if (this.cima == null) {
            this.cima = nuevo;
        } else {
            aux = this.cima;
            while (aux.sig != null) {
                aux = aux.sig;
            }
            aux.sig = nuevo;
        }
    }

    public char obtenerCima() {
        Nodo aux;
        char ultimo = 0;

        if (this.cima.sig == null) {
            ultimo = (char) this.cima.dato;
        } else {
            aux = this.cima;
            while (aux.sig != null) {
                aux = aux.sig;
            }
            ultimo = (char) aux.dato;
        }
        return ultimo;
    }

    public void desapilarCima() {
        if (this.cima != null) {
            this.cima = this.cima.sig;
        }
    }

    @Override
    public String toString() {
        String cad = "";

        if (this.cima != null) {
            cad += this.cima.dato;
        }

        return cad;
    }
}
