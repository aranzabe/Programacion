/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package palindromas;

import Colas.*;
import Pilas.*;
import java.util.Scanner;

/**
 *
 * @author laura
 */
public class Palindromas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String cadena;
        PilaLL pila = new PilaLL();
        ColaLL cola = new ColaLL();
        Scanner sc = new Scanner(System.in);
        boolean esPalindroma = true;

        System.out.println("Dime algo:");
        cadena = sc.nextLine();

        //Pasamos la cadena a minusculas y borramos espacios:
        cadena = cadena.toLowerCase();
        cadena = cadena.replace(" ", "");

        /*COMPROBANDO: */ System.out.println(cadena);

        //Apilamos la palabra con pilas:
        for (int i = 0; i < cadena.length(); i++) {
            pila.apilarElemento(cadena.charAt(i));
            //Metemos la palabra en una cola:
            cola.insertarElemento(cadena.charAt(i));
        }

        while (!pila.estaVacia() && !cola.estaVacia() && esPalindroma) {
            for (int i = 0; i < cadena.length(); i++) {
                if (pila.obtenerCima() == cola.obtenerPrimero()) {
                    pila.desapilarCima();
                    cola.borrarPrimero();
                } else {
                    esPalindroma = false;
                }

            }
        }

        //-------------------------------COMPROBACION FINAL-------------------//
        //--------------------------------------------------------------------//
        if (esPalindroma) {
            System.out.println("La palabra es palindroma");
        } else {
            System.out.println("La Palabra no es Palindroma");
        }
    }

}
