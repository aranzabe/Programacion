/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Colas;

/**
 *
 * @author faranzabe
 */
public class ColaLista <TIPO> {

    private class Nodo {

        private TIPO dato;
        private Nodo sig;

        public Nodo(TIPO dato) {
            this.dato = dato;
            this.sig = null;
        }

    }

    private Nodo cola;

    public boolean estaVacia() {
        boolean vacio = false;

        if (this.cola == null) {
            vacio = true;
        }

        return vacio;
    }

    public void insertarElemento(TIPO e) {
        Nodo nuevo = new Nodo(e);
        Nodo aux;

        if (this.cola == null) {
            this.cola = nuevo;
        } else {
            aux = this.cola;
            while (aux.sig != null) {
                aux = aux.sig;
            }
            aux.sig = nuevo;
        }
    }

    public TIPO obtenerPrimero() {
        Object primero = 0;

        if (this.cola != null) {
            primero = this.cola.dato;
        }
        return (TIPO) primero;
    }

    public void borrarPrimero() {

        if (this.cola.sig != null) {
            this.cola = this.cola.sig;
        }
    }

    @Override
    public String toString() {
        String cad = "";

        if (this.cola != null) {
            cad += this.cola.dato;
        }

        return cad;
    }
}
