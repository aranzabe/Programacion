/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tadpilainicial;

import java.util.ArrayList;

/**
 *
 * @author faranzabe
 */
public class PilaAL {

    private ArrayList pila;

    public PilaAL() {
        this.pila = new ArrayList();
    }

    /**
     * Nos dice si la pila de elementos esta vacia
     *
     * @return devuelve true si esta vacia, false si no lo esta.
     */
    public boolean estaVacia() {
//        boolean conseguido = false;
//
//        if (this.pila.isEmpty()) {
//            conseguido = true;
//        }
        return this.pila.isEmpty();
    }

    public void apilarElemento(int e) {
        this.pila.add(e);
    }

    /**
     * Nos ofrece el ultimo elemento introducido del Arraylist
     *
     * @return Devolvera el ultimo elemento del arraylist si hay algo, sino
     * devolvera -1
     */
    public int obtenerCima() {
        int cima = 0;

        if (this.pila.isEmpty()) {
            cima = -1;
        } else {
            cima = (int) this.pila.get(this.pila.size() - 1);
        }

        return cima;
    }

    public void desapilarCima() {
        this.pila.remove(this.pila.size() - 1);

    }

    @Override
    public String toString() {
        String cad = "";

        if (!this.pila.isEmpty()) {
            cad += this.pila.toString();
        }

        return cad;
    }

}
