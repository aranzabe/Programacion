/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tadpilainicial;

/**
 *
 * @author faranzabe
 */
public class PilaVector {

    private int elementos[];

    public PilaVector() {
        this.elementos = null;
    }

    public boolean estaVacia() {
        boolean vacia = false;

        if (this.elementos == null) {
            vacia = true;
        }

        return vacia;

    }

    public void apilarElemento(int e) {
        int i = 0;
        if (this.elementos == null) {
            this.elementos = new int[1];
            this.elementos[0] = e;
        } else {
            this.elementos = redimensionar(this.elementos);
            this.elementos[this.elementos.length - 1] = e;
        }
    }

    public int obtenerCima() {
        int cima = 0;

        if (this.elementos == null) {
            cima = -1;
        } else {
            cima = this.elementos[this.elementos.length - 1];
        }

        return cima;
    }

    public boolean desapilarCima() {
        boolean conseguido = false;

        if (this.elementos != null) {
            conseguido = true;
            if (this.elementos.length == 1) {
                this.elementos = null;
            } else {
                this.elementos = this.reducirVector(this.elementos);
            }
        }

        return conseguido;
    }

    @Override
    public String toString() {
        String cad = "";
        if (this.elementos != null) {
            for (int i = 0; i < this.elementos.length; i++) {
                cad += this.elementos[i] + " ";
            }
        }
        return cad;
    }

    private int[] redimensionar(int[] elementos) {
        int aux[] = new int[this.elementos.length + 1];
        for (int i = 0; i < this.elementos.length; i++) {
            aux[i] = this.elementos[i];
        }
        return aux;
    }

    private int[] reducirVector(int[] elementos) {
        int aux[] = new int[this.elementos.length - 1];
        for (int i = 0; i < aux.length; i++) {
            aux[i] = this.elementos[i];
        }
        return aux;
    }

}
