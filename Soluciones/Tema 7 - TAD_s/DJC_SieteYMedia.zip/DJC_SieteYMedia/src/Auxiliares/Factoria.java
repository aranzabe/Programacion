/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Auxiliares;

import Jugadores.Jugador;
import Cartas.Carta;
import Cartas.Baraja;

/**
 *
 * @author usuariob
 */
public class Factoria {

    public static Carta factoriaCarta(int valor, String palo){
        return new Carta(valor, palo);
    }
    
    public static Baraja factoriaBaraja(){
        Baraja b = new Baraja();
        String palo = "";
        int num = 0;
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 10; j++) {
                switch (i){
                    case 0: palo = "Oros"; break;
                    case 1: palo = "Copas"; break;
                    case 2: palo = "Espadas"; break;
                    case 3: palo = "Bastos";
                }
                switch (j){
                    case 7: num = 10; break;
                    case 8: num = 11; break;
                    case 9: num = 12; break;
                    default: num = j + 1;
                }
                b.apilarElemento(factoriaCarta(num, palo));
            }
        }
        return b;
    }
    
    public static Jugador factoriaJugador(){
        int alea = (int) (Math.random() * 6);
        String nombre = "";
        switch (alea){
            case 0: nombre = "Rigoberto"; break;
            case 1: nombre = "Anacleta"; break;
            case 2: nombre = "José María"; break;
            case 3: nombre = "Mariví"; break;
            case 4: nombre = "Godofredo"; break;
            case 5: nombre = "Pelagia";
        }
        return new Jugador(nombre);
    }
    
}
