/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Auxiliares;

import Cartas.*;

/**
 *
 * @author danie
 */
public class Auxiliar {
    public static PilaCartas barajearMazo(Baraja baraja){
        PilaCartas mazoCentral = new PilaCartas();
        
        while (!baraja.estaVacia()) {
            int alea = (int) (Math.random() * baraja.getCuantos());
            mazoCentral.apilarElemento(baraja.extraerPosicion(alea));
        }
        return mazoCentral;
    }
}
