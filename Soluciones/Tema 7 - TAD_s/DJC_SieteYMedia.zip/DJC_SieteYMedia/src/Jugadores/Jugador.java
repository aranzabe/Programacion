/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Jugadores;

import Cartas.Carta;
import Cartas.PilaCartas;

/**
 *
 * @author usuariob
 */
public class Jugador {
    
    private String nombre;
    private float puntos;
    private PilaCartas cartas;

    public Jugador() {
        this.nombre = "Yo";
        this.puntos = 0;
        this.cartas = new PilaCartas();
    }

    public Jugador(String nombre) {
        this.nombre = nombre;
        this.puntos = 0;
        this.cartas = new PilaCartas();
    }

    public float getPuntos() {
        return puntos;
    }

    public void setPuntos(float puntos) {
        this.puntos = puntos;
    }

    public String getNombre() {
        return nombre;
    }
    
    public void cogerCarta(Carta c){
        this.cartas.apilarElemento(c);
        if (c.getValor() < 8){
            this.puntos += c.getValor();
        } else {
            this.puntos += 0.5;
        }
    }

    public int pensarRespuesta(){
        int resp = -1;
        boolean coger = false;
        
        if (this.puntos <= 1.5){
            coger = true;
        } else if (this.puntos <= 3){
            coger = (int) (Math.random() * 5) < 4;
        } else if (this.puntos <= 5){
            coger = (int) (Math.random() * 2) == 0;
        } else if (this.puntos < 7){
            coger = (int) (Math.random() * 5) == 0;
        } else if (this.puntos == 7){
            coger = (int) (Math.random() * 10) == 0;
        }
        if (coger){
            resp = 1;
        } else {
            resp = 0;
        }
        return resp;
    }
    
    @Override
    public String toString() {
        return "Jugador{" + "nombre=" + nombre + ", puntos=" + puntos + '}';
    }
    
}
