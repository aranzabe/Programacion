/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_sieteymedia;

import Auxiliares.*;
import Jugadores.Jugador;
import Cartas.*;
import java.util.Scanner;

/**
 *
 * @author usuariob
 */
public class Principal {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean fin = false;
        boolean coger = false;
        int turno = 1;
        int respuesta = -1;
        Baraja b = Factoria.factoriaBaraja();
        System.out.println(b);
        PilaCartas mazoCentral = Auxiliar.barajearMazo(b);
        System.out.println(mazoCentral);
        Jugador humano = Factoria.factoriaJugador();
        Jugador maquina = Factoria.factoriaJugador();

        while (!fin) {
            switch (turno) {
                case 1:
                    boolean correcto = false;
                    do {
                        System.out.println("¿Quieres coger una carta? 0 - No, 1 - Sí");
                        try {
                            respuesta = sc.nextInt();
                            if (respuesta != 0 && respuesta != 1) {
                                throw new Excepcion("Opción incorrecta");
                            }
                            correcto = true;
                        } catch (Excepcion ex){
                            System.out.println("Opción incorrecta");
                        }
                    } while (!correcto);
                    switch (respuesta){
                        case 0: fin = true; break;
                        case 1:
                            Carta c = mazoCentral.obtenerCima();
                            mazoCentral.desapilarCima();
                            humano.cogerCarta(c);
                            System.out.println("Has sacado el " + c.toString());
                            System.out.println("Tienes " + humano.getPuntos());
                            if (humano.getPuntos() >= 7.5){
                                fin = true;
                            } else {
                                turno = 2;
                            }
                    }
                    break;
                case 2:
                    respuesta = maquina.pensarRespuesta();
                    switch (respuesta){
                        case 0: 
                            fin = true;
                            System.out.println("La máquina se ha plantado");
                            break;
                        case 1:
                            System.out.println("La máquina coge una carta");
                            Carta c = mazoCentral.obtenerCima();
                            mazoCentral.desapilarCima();
                            maquina.cogerCarta(c);
                            //System.out.println("La máquina ha sacado el " + c.toString());
                            //System.out.println("Tiene " + maquina.getPuntos());
                            if (maquina.getPuntos() >= 7.5){
                                fin = true;
                            } else {
                                turno = 1;
                            }
                    }
            }
        }
        float puntosH = humano.getPuntos();
        float puntosM = maquina.getPuntos();
        System.out.println("Tus puntos: " + puntosH);
        System.out.println("La máquina: " + puntosM);
        if ((puntosH > 7.5 && puntosM > 7.5) || (puntosH == puntosM)){
            System.out.println("La máquina y tú habéis empatado");
        } else if ((puntosM > 7.5 && puntosH < 7.5) || (puntosM < 7.5 && puntosH < 7.5 && puntosH > puntosM)){
            System.out.println("Enhorabuena, has ganado");
        } else if ((puntosH > 7.5 && puntosM < 7.5) || (puntosH < 7.5 && puntosM < 7.5 && puntosM > puntosH)){
            System.out.println("Ha ganado la máquina");
        }
        
    }

}
