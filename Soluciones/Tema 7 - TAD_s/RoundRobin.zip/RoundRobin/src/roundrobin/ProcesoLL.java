/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roundrobin;

import java.util.LinkedList;

/**
 *
 * @author faranzabe
 */
public class ProcesoLL {

    private LinkedList cola;

    public ProcesoLL() {
        this.cola = new LinkedList();
    }

    public boolean estaVacia() {
        return this.cola.isEmpty();
    }

    public void insertarElemento(Proceso e) {
        this.cola.addLast(e);
    }

    public Proceso obtenerPrimero() {
        return (Proceso) this.cola.getFirst();
    }

    public void borrarPrimero() {
        this.cola.removeFirst();
    }

  

    @Override
    public String toString() {
        String cad = "";

        if (!this.cola.isEmpty()) {
            cad += this.cola.toString();
        }
        return cad;
    }

}
