/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roundrobin;

/**
 *
 * @author laura
 */
public class RoundRobin {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        ProcesoLL CPU = new ProcesoLL();
        ProcesoLL listaProcesos = new ProcesoLL();
        Proceso proceso = new Proceso();

        int t = 0;

       
            //Cada dos segundos llega un nuevo proceso a la CPU que se queda en espera
            if (t % 2 == 0) {
                proceso = new Proceso();
                CPU.insertarElemento(proceso);
                System.out.println(CPU.toString());
            }

            //Pasan 0.2 segundos y la CPU expulsa el proceso para meterse en la cola de ejecucion
            Thread.sleep(2000);
            proceso = CPU.obtenerPrimero();//Obtenemos el primero de la CPU
            listaProcesos.insertarElemento(proceso);//Lo insertamos al final de la lista de Procesos
            CPU.borrarPrimero();//Al insertarlo de la lista de procesos lo borramos de la CPU

            //--------------------------------------------------------------------------------//
            //--------------------------------LISTA DE CPU DESPUES DE BORRAR------------------//
            //--------------------------------------------------------------------------------//
            System.out.println("Lista de CPU: ");
            System.out.println(CPU.toString());
            //--------------------------------------------------------------------------------//
            //-----------------------LISTA DE PROCESOS DESPUES DE INSERTAR--------------------//
            //--------------------------------------------------------------------------------//
            System.out.println("Lista de Procesos: ");
            System.out.println(listaProcesos.toString());

            //--------------------------Se va reduciendo el tiempo----------------------------//
            //Mientras la lista siga teniendo procesos, seguiran  ejecutandose
            while (listaProcesos != null) {
                //mientras el quantum del que entro primero siga siendo mayor que 0
                while (listaProcesos.obtenerPrimero().getQuantum() > 0) {
                    //lo vamos reduciendo
                    listaProcesos.obtenerPrimero().reducirQuantum();
                    //Si el quantum llega a 0
                    if (listaProcesos.obtenerPrimero().getQuantum() == 0) {
                        //sale de la lista
                        listaProcesos.borrarPrimero();
                    }
                }
            }
        }
    

}
