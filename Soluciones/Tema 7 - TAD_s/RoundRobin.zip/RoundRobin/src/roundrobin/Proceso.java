/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roundrobin;

/**
 *
 * @author laura
 */
public class Proceso {

    private String Pnumero;
    private int quantum;
    public static int NUMERO;
    public int prioridad;

    public Proceso() {
        this.Pnumero = "P" + NUMERO;
        this.quantum = (int) (Math.random() * 4 + 1);
        this.prioridad = (int) (Math.random() * 3);

        NUMERO++;
    }

    public Proceso(String Pnumero, int quantum, int prioridad) {
        this.Pnumero = "P" + NUMERO;
        this.quantum = (int) (Math.random() * 4 + 1);
        this.prioridad = (int) (Math.random() * 3 + 1);

        NUMERO++;
    }

    public int getQuantum() {
        return quantum;
    }

    public int getPrioridad() {
        return prioridad;
    }
    

    public int reducirQuantum() {
        this.quantum = this.quantum - 1;
        return this.quantum;
    }

    @Override
    public String toString() {
        String cad = "";
        cad = "Identidad: " + this.Pnumero + "\n";
        cad += "Quantum: " + this.quantum + "\n";

        return cad;
    }

}
