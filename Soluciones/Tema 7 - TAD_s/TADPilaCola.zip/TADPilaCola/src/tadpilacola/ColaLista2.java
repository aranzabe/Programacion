/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tadpilacola;

/**
 *
 * @author laura
 */
public class ColaLista2 <TIPO>{

    private class Nodo {

        private TIPO dato;
        private Nodo sig;

        public Nodo(TIPO dato) {
            this.dato = dato;
            this.sig = null;
        }
    }

    private Nodo principio;
    private Nodo fin;

    public boolean estaVacia() {
        boolean vacio = false;

        if (this.principio == null) {
            vacio = true;
        }

        return vacio;
    }

    public void insertarElemento(TIPO e) {
        Nodo nuevo = new Nodo(e);

        if (this.principio == null) {
            this.principio = nuevo;
            this.fin = nuevo;
        } else {
            this.fin.sig = nuevo;
            this.fin = nuevo;
        }

    }

    public TIPO obtenerPrimero() {
        Object primero = 0;

        if (this.principio != null) {
            primero = this.principio.dato;
        }
        return (TIPO) primero;
    }

    public void borrarPrimero() {

        if (this.principio != null) {
            this.principio = this.principio.sig;
            if (this.principio == null) {
                this.fin = null;
            }
        }
    }

    @Override
    public String toString() {
        String cad = "";
        Nodo aux = this.principio;

        if (this.principio != null) {
            while (aux != null) {
                cad += aux.dato + " ";
                aux = aux.sig;
            }
        }
        return cad;
    }

}
