/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tadpilacola;

/**
 *
 * @author laura
 */
public class TADPilaCola {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        ColaAL c = new ColaAL();
//        ColaVector c = new ColaVector();
        ColaLista2 c = new ColaLista2<Persona>();
        ColaLista2 ci = new ColaLista2<Integer>();
        
//        c.insertarElemento(18);
//        c.insertarElemento(12);
//        c.insertarElemento(2);
        c.insertarElemento(new Persona("Jaime"));
        c.insertarElemento(new Persona("Sergio"));
        c.insertarElemento(new Persona("Javier"));
        while(!c.estaVacia()){
            System.out.println(c.obtenerPrimero());
            c.borrarPrimero();
        }
    }
    
}
