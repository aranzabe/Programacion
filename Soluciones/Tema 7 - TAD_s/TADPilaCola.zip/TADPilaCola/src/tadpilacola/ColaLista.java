/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tadpilacola;

/**
 *
 * @author faranzabe
 */
public class ColaLista {

    private class Nodo {

        private int dato;
        private Nodo sig;

        public Nodo(int dato) {
            this.dato = dato;
            this.sig = null;
        }

    }

    private Nodo cola;

    public boolean estaVacia() {
        boolean vacio = false;

        if (this.cola == null) {
            vacio = true;
        }

        return vacio;
    }

    public void insertarElemento(int e) {
        Nodo nuevo = new Nodo(e);
        Nodo aux;

        if (this.cola == null) {
            this.cola = nuevo;
        } else {
            aux = this.cola;
            while (aux.sig != null) {
                aux = aux.sig;
            }
            aux.sig = nuevo;
        }
    }

    public int obtenerPrimero() {
        int primero = 0;

        if (this.cola != null) {
            primero = this.cola.dato;
        }
        return primero;
    }

    public void borrarPrimero() {

        if (this.cola.sig != null) {
            this.cola = this.cola.sig;
        }
    }

    @Override
    public String toString() {
        String cad = "";
        Nodo aux = this.cola;

        if (this.cola != null) {
            while (aux != null) {
                cad += aux.dato + " ";
                aux = aux.sig;
            }
        }
        return cad;
    }
}
