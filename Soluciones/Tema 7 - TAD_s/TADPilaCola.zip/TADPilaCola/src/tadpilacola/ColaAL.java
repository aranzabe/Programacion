/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tadpilacola;

import java.util.ArrayList;

/**
 *
 * @author faranzabe
 */
public class ColaAL {

    private ArrayList cola;

    public ColaAL() {
        this.cola = new ArrayList();
    }

    /**
     * Nos dice si la pila de elementos esta vacia
     *
     * @return devuelve true si esta vacia, false si no lo esta.
     */
    public boolean estaVacia() {
        return this.cola.isEmpty();
    }

    public void insertarElemento(int e) {
        this.cola.add(e);
    }

    /**
     * Nos ofrece el ultimo elemento introducido del Arraylist
     *
     * @return Devolvera el ultimo elemento del arraylist si hay algo, sino
     * devolvera -1
     */
    public int obtenerPrimero() {
        int cima = 0;

        if (this.cola.isEmpty()) {
            cima = -1;
        } else {
            cima = (int) this.cola.get(0);
        }

        return cima;
    }

    public void borrarPrimero() {

        if (!this.cola.isEmpty()) {
            this.cola.remove(0);
        }
    }

    @Override
    public String toString() {
        String cad = "";

        if (!this.cola.isEmpty()) {
            cad += this.cola.toString();
        }
        return cad;
    }

}
