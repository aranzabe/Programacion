/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemploexcepciones;

import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author faranzabe
 */
public class EjemploExcepciones {

    public static void metodo() {
        Persona p = null;
        try {
            System.out.println(p.toString());
            System.out.println("kndlfdsfkl");
        } catch (NullPointerException ex) {

        }
    }
    
    public static int pedirEntero(){
        Scanner sc = new Scanner(System.in);
        int n=0;
        boolean correcto = false;
        do {
            try {
                n = sc.nextInt();
                correcto = true;
            } catch (java.util.InputMismatchException ex) {
                System.out.println("Número incorrecto");
                sc.nextLine();
            } 
        } while (!correcto);
        return n;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)  {
        int n = 9;
        int v[] = new int[2];
        
        n = pedirEntero();
        if (n % 2 == 0){
            try {
                throw new MiExcepcion("Error número par");
            } catch (MiExcepcion ex) {
                System.err.println("Error número par!!!");
            }
        }
        System.out.println(n);        

        metodo();
        System.out.println("Sigo con normalidad");

//        n = n / 0;
//        System.out.println(n);
//        System.out.println(p.toString());
    }

   

}
