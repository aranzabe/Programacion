package serializacion;

import java.io.*;

public class Persona implements Serializable //Debemos incluir esta clausula para
//poder 'seriar' este objeto.
{

    //******************** Atributos *******************
    private String nombre;
    private String dirección;
    private int teléfono;

    //******************** Métodos *********************
    //-------------------------------------------------- 
    //----------------- Constructores ------------------
    public Persona() {
        nombre = "";
        dirección = "";
        teléfono = 0;
    }

    //-------------------- Get/Set ---------------------
    public Persona(String nom, String dir, int tel) {
        nombre = nom;
        dirección = dir;
        teléfono = tel;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDirección() {
        return dirección;
    }

    public void setDirección(String dirección) {
        this.dirección = dirección;
    }

    public int getTeléfono() {
        return teléfono;
    }

    public void setTeléfono(int teléfono) {
        this.teléfono = teléfono;
    }

    
    //----------------- Devolver información ------------------
    @Override
    public String toString() {
        return "Persona{" + "nombre=" + nombre + ", direcci\u00f3n=" + dirección + ", tel\u00e9fono=" + teléfono + '}';
    }

    public void mostrarPersona() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Dirección: " + dirección);
        System.out.println("Teléfono: " + teléfono);

    }
}
