/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BBDD;

import Auxiliar.Constantes;
import Personas.Persona;
import java.sql.SQLException;
import java.util.LinkedList;
import javax.swing.JOptionPane;

/**
 *
 * @author usuariob
 */
public class ConexionEstatica {

    //********************* Atributos *************************
    private static java.sql.Connection conexion;
    //Atributo a través del cual hacemos la conexión física.
    private static java.sql.Statement sentenciaSQL;
    //Atributo que nos permite ejecutar una sentencia SQL
    private static java.sql.ResultSet registros;
    //Atributo que recoge los cursores

    //----------------------------------------------------------
    private static void abrirConexion() {
        try {
            String controlador = "org.mariadb.jdbc.Driver"; // MariaDB la version libre de MySQL (requiere incluir la librería jar correspondiente).
            Class.forName(controlador);

            String URL_BD = "jdbc:mysql://" + Constantes.host + '/' + Constantes.bbdd;

            //Realizamos la conexión a una BD con un usuario y una clave.
            conexion = java.sql.DriverManager.getConnection(URL_BD, Constantes.usuario, Constantes.passwd);
            sentenciaSQL = conexion.createStatement();
            System.out.println("Conexion realizada con éxito");
        } catch (Exception e) {
            System.err.println("Exception: " + e.getMessage());
        }
    }

    //------------------------------------------------------
    private static void cerrarConexion() {
        try {
            conexion.close();
            System.out.println("Desconectado de la Base de Datos"); //Opcional para seguridad
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error de Desconexion", JOptionPane.ERROR_MESSAGE);
        }
    }

    //------------------------------------------------------
    public static LinkedList<Persona> obtenerDatos() {
        LinkedList<Persona> datos = new LinkedList();

        try {
            abrirConexion();
            String sentencia = "SELECT usuario.*, rol_asig.rol FROM usuario JOIN rol_asig ON usuario.dni = rol_asig.dni";
            registros = sentenciaSQL.executeQuery(sentencia);
            while (registros.next()) {
                datos.add(new Persona(registros.getString("dni"), registros.getString("correo"), registros.getString("telefono"), registros.getString("nombre"), registros.getInt("edad"), registros.getInt("rol")));
            }
        } catch (SQLException ex) {
            System.out.println("SELECT fallida");
        } finally {
            cerrarConexion();
        }
        return datos;
    }

    //------------------------------------------------------
    public static int insertarRegistro(Persona p) {
        int cod = 0;
        int rol;

        try {
            abrirConexion();
            String sentencia = "INSERT INTO usuario VALUES('" + p.getDni() + "','" + p.getCorreo() + "','" + p.getTelefono() + "','" + p.getNombre() + "'," + p.getEdad() + ')';
            sentenciaSQL.executeUpdate(sentencia);
            sentencia = "INSERT INTO rol_asig VALUES('" + p.getDni() + "'," + p.getRol() + ')';
            sentenciaSQL.executeUpdate(sentencia);
        } catch (SQLException ex) {
            System.out.println("INSERT fallido");
            cod = ex.getErrorCode();
        } finally {
            cerrarConexion();
        }

        return cod;
    }

    //------------------------------------------------------
    public static int borrarRegistro(String dni) {
        int cod = 0;

        try {
            abrirConexion();
            String sentencia = "DELETE FROM usuario WHERE dni LIKE '" + dni + "'";
            sentenciaSQL.executeUpdate(sentencia);
        } catch (SQLException ex) {
            System.out.println("DELETE fallido");
            cod = ex.getErrorCode();
        } finally {
            cerrarConexion();
        }

        return cod;
    }

    //------------------------------------------------------
    public static int modificarRegistro(Persona p) {
        int cod = 0;

        try {
            abrirConexion();
            String sentencia = "UPDATE usuario SET telefono = '" + p.getTelefono() + "', nombre = '" + p.getNombre() + "', edad = " + p.getEdad() + " WHERE dni LIKE '" + p.getDni() + "'";
            sentenciaSQL.executeUpdate(sentencia);
            sentencia = "UPDATE rol_asig SET rol = " + p.getRol() + " WHERE dni LIKE '" + p.getDni() + "'";
            sentenciaSQL.executeUpdate(sentencia);
        } catch (SQLException ex) {
            System.out.println("UPDATE fallido");
            cod = ex.getErrorCode();
        } finally {
            cerrarConexion();
        }

        return cod;
    }

}
