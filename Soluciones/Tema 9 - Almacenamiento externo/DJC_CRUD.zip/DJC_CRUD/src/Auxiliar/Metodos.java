/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Auxiliar;

import Personas.Persona;
import java.util.LinkedList;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author danie
 */
public class Metodos {
    
    /**
     * Este método añade un dato a la tabla swing
     * @param p la persona que queremos añadir
     */
    public static void addDatoTablaSwing(Persona p, JTable tabla){
        DefaultTableModel df = (DefaultTableModel) tabla.getModel();
        Object filas[] = new Object[6];
        filas[0] = p.getDni();
        filas[1] = p.getCorreo();
        filas[2] = p.getTelefono();
        filas[3] = p.getNombre();
        filas[4] = p.getEdad();
        filas[5] = p.getRol() == 0;
        df.addRow(filas);
        tabla.setModel(df);
    }
    
}
