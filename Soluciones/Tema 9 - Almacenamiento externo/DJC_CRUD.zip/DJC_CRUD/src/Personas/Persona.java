/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Personas;

/**
 *
 * @author usuariob
 */
public class Persona {
    
    private String dni;
    private String correo;
    private String telefono;
    private String nombre;
    private int edad;
    private int rol;

    public Persona() {
    }

    public Persona(String dni, String correo, String telefono, String nombre, int edad, int rol) {
        this.dni = dni;
        this.correo = correo;
        this.telefono = telefono;
        this.nombre = nombre;
        this.edad = edad;
        this.rol = rol;
    }

    public String getDni() {
        return dni;
    }

    public String getCorreo() {
        return correo;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public int getRol() {
        return rol;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setRol(int rol) {
        this.rol = rol;
    }
    
}
