/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplotokenizer;

import java.util.StringTokenizer;

/**
 *
 * @author faranzabe
 */
public class EjemploTokenizer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String strDatos="1A#Laura Moreno#Soltero#20#Alumna";
	StringTokenizer tokens=new StringTokenizer(strDatos, "#");
        
        int nDatos=tokens.countTokens();
        System.out.println("Cantidad de palabras: " + nDatos);
        int i=1;
        while(tokens.hasMoreTokens()){
            String str=tokens.nextToken();
            if (i==4){
                int edad = Integer.parseInt(str);
                System.out.println("Edad en entero: " + edad);
            }
            System.out.println(str);
            i++;
        }
    }
    
}
