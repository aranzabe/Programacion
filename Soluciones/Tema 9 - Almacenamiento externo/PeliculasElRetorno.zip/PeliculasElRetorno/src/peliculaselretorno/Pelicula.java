/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package peliculaselretorno;

import java.io.Serializable;

/**
 *
 * @author laura
 */
public class Pelicula implements Serializable{

    private String id;
    private String titulo;
    private String genero;
    private String director;
    private int year;

    public Pelicula() {
        this.id = id;
        this.titulo = titulo;
        this.genero = genero;
        this.director = director;
        this.year = year;
    }

    public Pelicula(String id, String titulo, String genero, String director, int year) {
        this.id = id;
        this.titulo = titulo;
        this.genero = genero;
        this.director = director;
        this.year = year;
    }

    public String getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getGenero() {
        return genero;
    }

    public String getDirector() {
        return director;
    }

    public int getYear() {
        return year;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public void setYear(int year) {
        this.year = year;
    }

    @Override
    public String toString() {
        String cad = "";

        cad = this.id + "," + this.titulo + "," + this.genero + "," + this.director + "," + this.year;

        return cad;
    }

}
