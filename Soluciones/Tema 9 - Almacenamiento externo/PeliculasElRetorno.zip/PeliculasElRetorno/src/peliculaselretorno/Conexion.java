/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package peliculaselretorno;

import Auxiliar.Constante;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author laura
 */
public class Conexion {

    //********************* Atributos *************************
    private java.sql.Connection Conex;
    //Atributo a través del cual hacemos la conexión física.
    private java.sql.Statement Sentencia_SQL;
    //Atributo que nos permite ejecutar una sentencia SQL
    private java.sql.ResultSet Conj_Registros;
    //(Cursor) En él están almacenados los datos.

    public Conexion() {
        //this.abrirConexion();
    }

    public void abrirConexion() {
        try {
            //Cargar Driver
            String controlador = "org.mariadb.jdbc.Driver";
            Class.forName(controlador);
            String URL_BD = "jdbc:mysql://localhost/" + Constante.bbdd;

            //Realizamos la conexión a una BD con un usuario y una clave.
            Conex = java.sql.DriverManager.getConnection(URL_BD, Constante.nombre, Constante.contrasenia);
            Sentencia_SQL = Conex.createStatement();
            System.out.println("Conexion realizada con éxito");
        } catch (Exception e) {
            System.err.println("Exception: " + e.getMessage());
        }
    }

    //********************** Métodos **************************
    //-----------------------------------------------------------------///
    //------------------------OBTENER DATOS TABLA BBDD---------------------///
    //--------------------------------------------------------------------///
    //----------------------------------------------------------
    public LinkedList obtenerDatosTablaLinked() {
        LinkedList lp = new LinkedList();
        try {
            String Sentencia = "SELECT * FROM " + Constante.nombreTabla;
            Conj_Registros = Sentencia_SQL.executeQuery(Sentencia);
            while (Conj_Registros.next()) {
                int n = Conj_Registros.getInt("year");
                Pelicula p = new Pelicula(Conj_Registros.getString("id"), Conj_Registros.getString("titulo"), Conj_Registros.getString("genero"), Conj_Registros.getString("director"), n);
                lp.add(p);
            }
        } catch (SQLException ex) {
        }
        return lp;
    }
    //-----------------------------------------------------------------///
    //------------------------INSERTAR DATOS TABLA BBDD---------------------///
    //--------------------------------------------------------------------/// 

    public int insertarDatos(String id, String titulo, String genero, String director, int year) {
        int codError = 0;
        
        try {
            String sentencia = "INSERT INTO " + Constante.nombreTabla + " VALUES ('" + id + "','" + titulo + "','" + genero + "','" + director + "','" + year + "')";
            Conj_Registros = Sentencia_SQL.executeQuery(sentencia);
        } catch (SQLException sq) {
            codError = sq.getErrorCode();
        }
        return codError;
    }

    //-----------------------------------------------------------------///
    //------------------------BORRAR DATOS TABLA BBDD---------------------///
    //--------------------------------------------------------------------/// 
    public int borrarDatos(String id) {
        int codError = 0;

        try {
            String sentencia = "DELETE FROM " + Constante.nombreTabla + " WHERE id= '" + id + "'";
            Conj_Registros = Sentencia_SQL.executeQuery(sentencia);
        } catch (SQLException sq) {
            codError = sq.getErrorCode();
        }
        return codError;
    }

    //-----------------------------------------------------------------///
    //------------------------OBTENER PRIMERO---------------------///
    //--------------------------------------------------------------------/// 
    public String obtenerPrimero(String campo) {
        campo = "";
        try {
            campo = Conj_Registros.getString(campo);
        } catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }

        return campo;

    }

    //-----------------------------------------------------------------///
    //------------------------CERRAR CONEXION---------------------///
    //--------------------------------------------------------------------/// 
    public void CerrarConexion() {
        try {
            Conex.close();
            System.out.println("Desconectado...");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error de Desconexion", JOptionPane.ERROR_MESSAGE);
        }
    }

    //-----------------------------------------------------------------///
    //------------------------MODIFICAR---------------------///
    //--------------------------------------------------------------------/// 
    public int modificarDato(String id, String titulo, String nuevo_titulo, String genero, String nuevo_genero, String director, String nuevo_director, int year, int new_year) {
        int cod = 0;
        String Sentencia = "UPDATE " + Constante.nombreTabla + " SET titulo = '" + nuevo_titulo + "',genero='" + nuevo_genero + "',director='" + nuevo_director + "',year='" + new_year + "' WHERE id like '" + id + "'";
        try {
            Sentencia_SQL.executeUpdate(Sentencia);
        } catch (SQLException ex) {
            cod = ex.getErrorCode();
        }

        return cod;
    }
}
