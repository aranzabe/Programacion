/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ventanas;

import Mensajes.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import Auxiliares.*;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author usuariob
 */
public class VentanaPrincipal extends javax.swing.JFrame {

    /**
     * Creates new form Ventana
     */
    public VentanaPrincipal() {
        initComponents();
        this.pilaMensajes = new LinkedList();
        File fTxt = new File(Auxiliar.TEXTFILENAME);
        File fObj = new File(Auxiliar.OBJECTFILENAME);
        ObjectOutputStream oos = null;
        DefaultTableModel df = (DefaultTableModel) this.tablaMsj.getModel();
        Object filas[] = new Object[4];
        if (fTxt.exists()) {
            try {
                //Recorro el archivo de texto
                Scanner sc = new Scanner(fTxt);
                //Cada línea corresponde a un objeto de clase Mensaje
                while (sc.hasNextLine()) {
                    //Así que creo objetos vacíos de clase Mensaje y de sus hijas
                    Mensaje msj = new Mensaje();
                    Cifrado msjC = new Cifrado();
                    NoCifrado msjN = new NoCifrado();
                    //La cadena de texto será la línea entera
                    String cad = sc.nextLine();
                    //Que descuartizaré con el tokenizer
                    StringTokenizer st = new StringTokenizer(cad, "#");
                    //Llevando la cuenta de cuál es el registro en el que estoy
                    int i = 1;
                    while (st.hasMoreTokens()) {
                        //Cada token será un campo
                        String campo = st.nextToken();
                        /*Según qué campo sea, hago un set a un atributo diferente.
                        A la par que establezco los atributos, voy añadiendo
                        cada campo a la tabla swing, para ahorrar en recorridos*/
                        switch (i) {
                            case 1: msj.setCodigo(campo); break;
                            case 2: msj.setOrigen(campo); break;
                            case 3: msj.setDestino(campo); break;
                            case 4:
                                /*Ojo con esto, que es lo que me dirá
                                si un mensaje está o no cifrado*/
                                if (campo.equals("c")) {
                                    msj.setCifrado(true);
                                }
                                break;
                            case 5:
                                //Es el último atributo genérico
                                msj.setPrioridad(Integer.parseInt(campo));
                                break;
                            case 6:
                                /*A partir del atributo número 6, son campos
                                especializados, así que tengo que distinguir
                                si el mensaje está o no está cifrado*/
                                if (msj.isCifrado()) {
                                    msjC = Cifrado.convertirEnCifrado(msj);
                                    msjC.setMsjCifrado(campo);
                                    //((Cifrado) msj).setMsjCifrado(campo);
                                } else {
                                    msjN = NoCifrado.convertirEnNoCifrado(msj);
                                    msjN.setMensaje(campo);
                                    //((NoCifrado) msj).setMensaje(campo);
                                }
                                break;
                            case 7:
                                if (msj.isCifrado()) {
                                    msjC.setClave(Integer.parseInt(campo));
                                    //((Cifrado) msj).setClave(Integer.parseInt(campo));
                                } else {
                                    if (campo.equals("s")) {
                                        msjN.setUrgente(true);
                                        //((NoCifrado) msj).setUrgente(true);
                                    } else {
                                        msjN.setUrgente(false);
                                        //((NoCifrado) msj).setUrgente(false);
                                    }
                                }
                        }
                        i++;
                    }
                    System.out.println(msj.toString());
                    /*Una vez el mensaje esté relleno como objeto,
                    lo añadimos a la pila de mensajes.
                    Añadimos uno u otro según esté o no cifrado*/
                    if (msj.isCifrado()){
                        this.pilaMensajes.addFirst(msjC);
                    } else {
                        this.pilaMensajes.addFirst(msjN);
                    }
                    /*Aquí termina la inserción de cada registro en la LL*/
                }
                //Y aquí termina la inserción de todos los registros en la pila.
                /*Ahora metemos el objeto de la pila en un archivo serializado.
                Si en lugar de esto hubiésemos metido en el archivo serializado
                los objetos uno a uno, el proceso habría que haberlo hecho justo
                antes de que terminase el bucle que recorre cada registro.*/
                oos = new ObjectOutputStream(new FileOutputStream(fObj));
                oos.writeObject(this.pilaMensajes);
                //Ahora extraemos los elementos de la pila a la tabla
                /*while (!this.pilaMensajes.isEmpty()){
                    Mensaje msj = this.pilaMensajes.pop();
                    filas[0] = msj.getCodigo();
                    filas[1] = msj.getOrigen();
                    filas[2] = msj.getDestino();
                    filas[3] = msj.isCifrado();
                    df.addRow(filas);
                }*/
                for (int i = 0; i < this.pilaMensajes.size(); i++) {
                    filas[0] = this.pilaMensajes.get(i).getCodigo();
                    filas[1] = this.pilaMensajes.get(i).getOrigen();
                    filas[2] = this.pilaMensajes.get(i).getDestino();
                    filas[3] = this.pilaMensajes.get(i).isCifrado();
                    df.addRow(filas);
                }
                this.tablaMsj.setModel(df);
            } catch (FileNotFoundException ex) {
                System.err.println("Archivo no encontrado");
            } catch (IOException ex) {
                System.err.println("Error del ObjectInputStream");
            }
        }
        //Sólo falta rellenar los textfield de fecha y total de mensajes
        this.tfFecha.setText(LocalDate.now().toString());
        this.tfTotalMsj.setText(String.valueOf(this.pilaMensajes.size()));
    }

    private Mensaje encontrarMensaje(String codigo){
        Mensaje msj = null;
        boolean encontrado = false;
        int i = 0;
        
        while (!encontrado && i < this.pilaMensajes.size()){
            if (this.pilaMensajes.get(i).getCodigo().equals(codigo)){
                msj = this.pilaMensajes.get(i);
                encontrado = true;
            } else {
                i++;
            }
        }
        
        return msj;
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbFecha = new javax.swing.JLabel();
        tfFecha = new javax.swing.JTextField();
        lbTotalMsj = new javax.swing.JLabel();
        tfTotalMsj = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaMsj = new javax.swing.JTable();
        btVer = new javax.swing.JButton();
        btBorrar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lbFecha.setText("Fecha actual");

        tfFecha.setEditable(false);

        lbTotalMsj.setText("Total de mensajes");

        tfTotalMsj.setEditable(false);

        tablaMsj.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Origen", "Destino", "Cifrado"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Boolean.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tablaMsj);

        btVer.setText("Ver en detalle");
        btVer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btVerActionPerformed(evt);
            }
        });

        btBorrar.setText("Borrar");
        btBorrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btBorrarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(72, 72, 72)
                        .addComponent(lbFecha)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(58, 58, 58)
                        .addComponent(lbTotalMsj)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfTotalMsj, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 470, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(37, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(93, 93, 93)
                .addComponent(btVer)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btBorrar, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(95, 95, 95))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbFecha)
                    .addComponent(tfFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbTotalMsj)
                    .addComponent(tfTotalMsj, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(50, 50, 50)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btVer)
                    .addComponent(btBorrar))
                .addContainerGap(42, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btVerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btVerActionPerformed
        try{
            VentanaDetalle v = new VentanaDetalle(encontrarMensaje((String) this.tablaMsj.getValueAt(this.tablaMsj.getSelectedRow(), 0)));
            v.setVisible(true);
        } catch (java.lang.ArrayIndexOutOfBoundsException ex){
            JOptionPane.showMessageDialog(rootPane, "Selecciona un mensaje que quieras ver en detalle", "Mensaje no seleccionado", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btVerActionPerformed

    private void btBorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btBorrarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btBorrarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaPrincipal().setVisible(true);
            }
        });
    }

    private LinkedList<Mensaje> pilaMensajes;

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btBorrar;
    private javax.swing.JButton btVer;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbFecha;
    private javax.swing.JLabel lbTotalMsj;
    private javax.swing.JTable tablaMsj;
    private javax.swing.JTextField tfFecha;
    private javax.swing.JTextField tfTotalMsj;
    // End of variables declaration//GEN-END:variables
}
