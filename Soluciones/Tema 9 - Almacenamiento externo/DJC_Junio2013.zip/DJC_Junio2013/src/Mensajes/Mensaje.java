/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mensajes;

import java.io.Serializable;

/**
 *
 * @author usuariob
 */
public class Mensaje implements Serializable {
    
    protected String codigo;
    protected String origen;
    protected String destino;
    protected boolean cifrado;
    protected int prioridad;

    public Mensaje() {
        this.codigo = "";
        this.origen = "";
        this.destino = "";
        this.cifrado = false;
        this.prioridad = 0;
    }

    public Mensaje(String codigo, String origen, String destino, boolean cifrado, int prioridad) {
        this.codigo = codigo;
        this.origen = origen;
        this.destino = destino;
        this.cifrado = cifrado;
        this.prioridad = prioridad;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getOrigen() {
        return origen;
    }

    public String getDestino() {
        return destino;
    }

    public int getPrioridad() {
        return prioridad;
    }

    public boolean isCifrado() {
        return cifrado;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public void setCifrado(boolean cifrado) {
        this.cifrado = cifrado;
    }

    public void setPrioridad(int prioridad) {
        this.prioridad = prioridad;
    }

    @Override
    public String toString() {
        return "Mensaje{" + "codigo=" + codigo + ", origen=" + origen + ", destino=" + destino + ", cifrado=" + cifrado + ", prioridad=" + prioridad + '}';
    }
}
