/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mensajes;

/**
 *
 * @author usuariob
 */
public class Cifrado extends Mensaje {
    
    private String msjCifrado;
    private int clave;

    public Cifrado() {
        super();
        this.msjCifrado = "";
        this.clave = 0;
    }

    public Cifrado(String codigo, String origen, String destino, boolean cifrado, int prioridad) {
        super(codigo, origen, destino, cifrado, prioridad);
    }

    public Cifrado(String msjCifrado, int clave, String codigo, String origen, String destino, boolean cifrado, int prioridad) {
        super(codigo, origen, destino, cifrado, prioridad);
        this.msjCifrado = msjCifrado;
        this.clave = clave;
    }

    public String getMsjCifrado() {
        return msjCifrado;
    }

    public void setMsjCifrado(String msjCifrado) {
        this.msjCifrado = msjCifrado;
    }

    public int getClave() {
        return clave;
    }

    public void setClave(int clave) {
        this.clave = clave;
    }
    
    public static Cifrado convertirEnCifrado(Mensaje msj){
        return new Cifrado(msj.getCodigo(), msj.getOrigen(), msj.getDestino(), msj.isCifrado(), msj.getPrioridad());
    }

    @Override
    public String toString() {
        return "Cifrado{" + super.toString() + "msjCifrado=" + msjCifrado + ", clave=" + clave + '}';
    }
    
}
