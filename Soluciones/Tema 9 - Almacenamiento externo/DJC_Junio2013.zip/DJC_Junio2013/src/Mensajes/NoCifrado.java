/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mensajes;

/**
 *
 * @author usuariob
 */
public class NoCifrado extends Mensaje {

    private String mensaje;
    private boolean urgente;

    public NoCifrado() {
        super();
        this.mensaje = "";
        this.urgente = false;
    }

    public NoCifrado(String codigo, String origen, String destino, boolean cifrado, int prioridad) {
        super(codigo, origen, destino, cifrado, prioridad);
    }
    
    public NoCifrado(String mensaje, boolean urgente, String codigo, String origen, String destino, boolean cifrado, int prioridad) {
        super(codigo, origen, destino, cifrado, prioridad);
        this.mensaje = mensaje;
        this.urgente = urgente;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public boolean isUrgente() {
        return urgente;
    }

    public void setUrgente(boolean urgente) {
        this.urgente = urgente;
    }

    @Override
    public String toString() {
        return "NoCifrado{" + super.toString() + "mensaje=" + mensaje + ", urgente=" + urgente + '}';
    }
    
    public static NoCifrado convertirEnNoCifrado(Mensaje msj){
        return new NoCifrado(msj.getCodigo(), msj.getOrigen(), msj.getDestino(), msj.isCifrado(), msj.getPrioridad());
    }

}
