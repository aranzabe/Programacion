/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Peliculas;

import java.io.Serializable;

/**
 *
 * @author usuariob
 */
public class Pelicula implements Serializable {
    
    private int id;
    private String titulo;
    private String genero;
    private String director;
    private int anio;
    public static int NEXTID = 1;
    
    
    public Pelicula() {
    }

    public Pelicula(String titulo, String genero, String director, int anio) {
        this.id = NEXTID;
        this.titulo = titulo;
        this.genero = genero;
        this.director = director;
        this.anio = anio;
    }
    
    public Pelicula(int id, String titulo, String genero, String director, int anio) {
        this.id = id;
        this.titulo = titulo;
        this.genero = genero;
        this.director = director;
        this.anio = anio;
        NEXTID++;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    @Override
    public String toString() {
        return "Pelicula{" + "id=" + id + ", titulo=" + titulo + ", genero=" + genero + ", director=" + director + ", anio=" + anio + '}';
    }
    
}
