/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BBDD;

import Auxiliar.Constantes;
import Peliculas.Pelicula;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author danijcoello
 */
public class ConexionEstatica {

    //********************* Atributos *************************
    private static java.sql.Connection conexion;
    //Atributo a través del cual hacemos la conexión física.
    private static java.sql.Statement sentenciaSQL;
    //Atributo que nos permite ejecutar una sentencia SQL
    private static java.sql.ResultSet registros;
    //Atributo que recoge los cursores

    //----------------------------------------------------------
    private static void abrirConexion() {
        try {
            String controlador = "org.mariadb.jdbc.Driver"; // MariaDB la version libre de MySQL (requiere incluir la librería jar correspondiente).
            Class.forName(controlador);

            String URL_BD = "jdbc:mysql://" + Constantes.host + '/' + Constantes.bbdd;

            //Realizamos la conexión a una BD con un usuario y una clave.
            conexion = java.sql.DriverManager.getConnection(URL_BD, Constantes.usuario, Constantes.passwd);
            sentenciaSQL = conexion.createStatement();
            System.out.println("Conexion realizada con éxito");
        } catch (Exception e) {
            System.err.println("Exception: " + e.getMessage());
        }
    }

    //------------------------------------------------------
    private static void cerrarConexion() {
        try {
            conexion.close();
            System.out.println("Desconectado de la Base de Datos"); //Opcional para seguridad
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error de Desconexion", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static LinkedList obtenerDatos() {
        LinkedList<Pelicula> datos = new LinkedList();
        Pelicula p = null;
        try {
            abrirConexion();
            String sentencia = "SELECT * FROM pelis";
            registros = sentenciaSQL.executeQuery(sentencia);
            while (registros.next()) {
                datos.add(new Pelicula(registros.getInt("id"), registros.getString("titulo"), registros.getString("genero"), registros.getString("director"), registros.getInt("anio")));
            }
            cerrarConexion();
        } catch (SQLException ex) {
        }
        return datos;
    }

    public static int insertarRegistro(Pelicula p) {
        int cod = 0;

        try {
            abrirConexion();
            sentenciaSQL.executeUpdate("INSERT INTO pelis VALUES(" + p.getId() + ",'" + p.getTitulo() + "','" + p.getGenero() + "','" + p.getDirector() + "'," + p.getAnio() + ')');
            cerrarConexion();
        } catch (SQLException ex) {
            cod = ex.getErrorCode();
        }
        return cod;
    }

    public static int borrarRegistro(int id) {
        int cod = 0;

        try {
            abrirConexion();
            sentenciaSQL.executeUpdate("DELETE FROM pelis WHERE id = " + id);
            cerrarConexion();
        } catch (SQLException ex) {
            cod = ex.getErrorCode();
        }

        return cod;
    }
    
    public static int modificarRegistro(Pelicula p){
        int cod = 0;
        
        try {
            abrirConexion();
            sentenciaSQL.executeUpdate("UPDATE pelis SET titulo = '" + p.getTitulo() + "', genero = '" + p.getGenero() + "', director = '" + p.getDirector() + "', anio = " + p.getAnio() + " WHERE id = " + p.getId());
            cerrarConexion();
        } catch (SQLException ex){
            cod = ex.getErrorCode();
        }
        
        return cod;
    }

}
