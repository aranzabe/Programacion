/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ficherostexto;

import java.io.*;
import java.util.Scanner;

/**
 *
 * @author faranzabe
 */
public class FicherosTexto {

    //******************************************************************
    //*************** ESCRITURA (SALIDA) EN EL FICHERO *****************
    //******************************************************************
    //******************************************************************
    /**
     * ESTE ES EL DE CLASE. Usamos la clase FileWriter para almacenar líneas de
     * texto en el fichero de texto.
     *
     * @param nombreFichero Nombre del fichero.
     */
    //******************************************************************
    //**************** Escribir en un fichero de texto: FORMA 1 ***************************
    public static void genera_fichero(String nombreFichero) {
        File fichero = null;//Un objeto de la clase FILE, representa el 
        //nombre de un fichero o de un directorio. 
        //Sus métodos servirán para interrogar al 
        //sistema sobre todas las características del mismo.
        FileWriter fs = null;
        //Un flujo de la clase 'FileWriter', permite escribir
        //caracteres en un fichero. 
        //Constructores posibles:
        //  - FileWriter(String nombre);
        //  - FileWriter(String nombre, boolean añadir);
        //      --> Si añadir == true => permite añadir elementos al fichero.
        //  - FileWriter(File fichero);
        String info;
        Scanner sc = new Scanner(System.in);
        char resp = 's';

        try {

            fichero = new File(nombreFichero);

            if (fichero.exists()) {
                System.out.print("El fichero existe ¿desea sobreescribirlo? (s/n) ");
                resp = sc.nextLine().charAt(0);
            }

            if (resp == 's') {
                fs = new FileWriter(nombreFichero);
                
                System.out.println("Escriba el texto que desea almacenar en el fichero:");
                info = sc.nextLine() + "\r\n";      //Recordamos que en Güindous el fin 
                //de línea es ENTER + SALTO DE LINEA
                //Se borra y se crea de nuevo.
                fs.write(info);
                //, 0, info.length());
            } else //Suponemos que si la respuesta es 'n', se añaden cadenas al fichero.
            {

                fs = new FileWriter(nombreFichero, true); //Añadimos al final (true).

                System.out.println("Escriba el texto que desea añadir en el fichero:");
                info = sc.nextLine() + "\r\n";        //Recordamos que en Güindous el fin 
                //de línea es ENTER + SALTO DE LINEA
                fs.write(info);
            }
            fs.close();
        } catch (IOException e) {
            System.out.println("Error: " + e.toString());
        }

    }

    //******************************************************************
    /**
     * Usamos la clase FileWriter y PrintWriter para almacenar líneas de texto
     * en el fichero de texto.
     *
     * @param nombreFichero Nombre del fichero.
     */
    //******************************************************************
    //**************** Escribir en un fichero de texto: FORMA 2 ***************************
    public static void genera_fichero2(String nombreFichero) {
        PrintWriter pw = new PrintWriter(System.out);
        String info = null;
        pw.println();
        File f = new File(nombreFichero);
        Scanner sc = new Scanner(System.in);

        try {
            //fichero = new FileWriter(nombreFichero);
            //fichero = new FileWriter(nombreFichero, true); //Si queremos añadir al final
            pw = new PrintWriter(new File(nombreFichero)); //Si usamos PrintWriter no necesitamos concatenar la cadena con \r\n.

            System.out.println("Escriba el texto que desea añadir en el fichero:");
            info = sc.nextLine();
            pw.println("Has introducido: " + info);

        } catch (Exception e) {
            System.out.println("Error: " + e.toString());
        }
    }

    //******************************************************************
    //*************** LECTURA (ENTRADA) DESDE EL FICHERO ***************
    //******************************************************************
    //******************************************************************
    /**
     * Usamos la clase FileInputStreamReader y BufferedReader para extraer
     * información del fichero de texto.
     *
     * @param nombreFichero Nombre del fichero.
     */
    //******************************************************************
    public static void muestra_fichero2(String nombreFichero) throws FileNotFoundException, IOException {//En este caso usamos las clases 'FileInputStren' y 'BufferedReader'
        //como flujos clásicos entre archivo y memoria principal.
        FileInputStream fd = new FileInputStream(nombreFichero);

        // Creo un BufferedReader para leer
        BufferedReader bf = new BufferedReader(new InputStreamReader(fd));
        String info;

        //Lectura de la primera linea exclusivamente.
        //info = bf.readLine();
        //System.out.println(info);//Mostramos lo leído
        //Lectura secuencial del fichero de texto hasta el final.
        info = bf.readLine();
        while (info != null) {
            //---- Tratamiento ---
            //.....
            System.out.println(info);
            info = bf.readLine();
        }

    }

    //******************************************************************
    /**
     * Usamos la clase FileReader y BufferedReader para extraer información del
     * fichero de texto.
     *
     * @param nombreFichero Nombre del fichero.
     */
    //******************************************************************
    public static void muestra_fichero(String nombreFichero) {
        File archivo = null;
        FileReader fr = null;
        BufferedReader br = null;

        try {
            // Apertura del fichero y creacion de BufferedReader para poder
            // hacer una lectura comoda (disponer del metodo readLine()).
            archivo = new File(nombreFichero);
            fr = new FileReader(archivo);
            br = new BufferedReader(fr);

            // Lectura del fichero
            String linea;
            while ((linea = br.readLine()) != null) {
                System.out.println(linea);
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.toString());
        } finally {
            // En el finally cerramos el fichero, para asegurarnos
            // que se cierra tanto si todo va bien como si salta 
            // una excepcion.
            try {
                if (null != fr) {
                    fr.close();
                }
            } catch (Exception e2) {
                System.out.println("Error: " + e2.toString());
            }
        }
    }

    //******************************************************************
    /**
     * ESTE ES EL DE CLASE. Usamos la clase Scanner para extraer información del
     * fichero de texto.
     *
     * @param nombreFichero Nombre del fichero.
     */
    //******************************************************************
    public static void muestra_fichero3(String nombreFichero) {
        File f = new File(nombreFichero);
        try {
            Scanner sc = new Scanner(f);

            while (sc.hasNextLine()) {
                String cad = sc.nextLine();
                System.out.println(cad);
            }
        } catch (FileNotFoundException ex) {
            System.out.println("Fichero no existe");
        }
    }

    //******************************************************************
    //************************* Método principal ***********************
    //******************************************************************
    public static void main(String[] args) throws IOException {
        String nombreFichero;
        Scanner sc = new Scanner(System.in);

        System.out.println("Nombre del fichero: ");
        nombreFichero = sc.nextLine();

        //nombreFichero="ejemplo.txt";
        genera_fichero(nombreFichero);
        //genera_fichero2(nombreFichero);
        //muestra_fichero(nombreFichero);
        //muestra_fichero2(nombreFichero);
        muestra_fichero3(nombreFichero);
    }

}
