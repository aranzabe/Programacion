package BBDD;

import Auxiliar.Constantes;
import java.sql.*;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class ConexionEstatica {

    //********************* Atributos *************************
    private static java.sql.Connection conexion;
    //Atributo a través del cual hacemos la conexión física.
    private static java.sql.Statement sentenciaSQL;
    //Atributo que nos permite ejecutar una sentencia SQL
    private static java.sql.ResultSet registros;

    //----------------------------------------------------------
    public static void abrirConexion() {
        try {
            //Cargar el driver/controlador
            //String controlador = "com.mysql.jdbc.Driver";
            //String controlador = "oracle.jdbc.driver.OracleDriver";
            //String controlador = "sun.jdbc.odbc.JdbcOdbcDriver"; 
            String controlador = "org.mariadb.jdbc.Driver"; // MariaDB la version libre de MySQL (requiere incluir la librería jar correspondiente).
            //Class.forName(controlador).newInstance();
            Class.forName(controlador);

            String URL_BD = "jdbc:mysql://localhost/" + Constantes.bbdd;
            //String URL_BD = "jdbc:mariadb://"+this.servidor+":"+this.puerto+"/"+this.bbdd+"";
            //String URL_BD = "jdbc:oracle:oci:@REPASO";
            //String URL_BD = "jdbc:oracle:oci:@REPASO";
            //String URL_BD = "jdbc:odbc:REPASO";

            //Realizamos la conexión a una BD con un usuario y una clave.
            conexion = java.sql.DriverManager.getConnection(URL_BD, Constantes.usuario, Constantes.passwd);
            sentenciaSQL = conexion.createStatement();
            System.out.println("Conexion realizada con éxito");
        } catch (Exception e) {
            System.err.println("Exception: " + e.getMessage());
        }
    }

    //------------------------------------------------------
    public static void cerrarConexion() {
        try {
            conexion.close();
            System.out.println("Desconectado de la Base de Datos"); // Opcional para seguridad
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error de Desconexion", JOptionPane.ERROR_MESSAGE);
        }
    }

    //---------------------------------------------------------
    public static LinkedList obtenerPelis() {
        LinkedList<String> ll = new LinkedList<String>();
        String p = null;
        try {
            abrirConexion();
            String Sentencia = "SELECT titulo FROM pelis";
            registros = sentenciaSQL.executeQuery(Sentencia);
            while (registros.next()) {
                ll.add(registros.getString("titulo"));
            }
            cerrarConexion();
        } catch (SQLException ex) {
        }
        return ll;
    }

    //----------------------------------------------------------
    public static int insertarDato(String peli) {
        int cod = 0;
        String Sentencia = "INSERT INTO pelis VALUES (NULL, '" + peli + "')";
        try {
            abrirConexion();
            sentenciaSQL.executeUpdate(Sentencia);
            cerrarConexion();
        } catch (SQLException sq) {
            cod = sq.getErrorCode();
        }
        return cod;
    }

    //----------------------------------------------------------
    public static int borrarDato(String peli) {
        int cod = 0;

        String Sentencia = "DELETE FROM pelis WHERE titulo LIKE '" + peli + "'";
        try {
            abrirConexion();
            sentenciaSQL.executeUpdate(Sentencia);
            cerrarConexion();
        } catch (SQLException ex) {
            cod = ex.getErrorCode();
        }

        return cod;
    }
}
