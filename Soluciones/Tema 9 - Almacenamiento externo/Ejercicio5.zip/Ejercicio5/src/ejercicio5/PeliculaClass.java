/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio5;

/**
 *
 * @author Malena
 */
public class PeliculaClass {
    private String ID;
    private String titulo;
    private String genero;
    private String director;
    private String anio;

    public PeliculaClass() {
        this.ID = "";
        this.titulo = "";
        this.genero = "";
        this.director = "";
        this.anio = "";
    }

    public PeliculaClass(String ID, String titulo, String genero, String director, String anio) {
        this.ID = ID;
        this.titulo = titulo;
        this.genero = genero;
        this.director = director;
        this.anio = anio;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getAnio() {
        return anio;
    }

    public void setAnio(String anio) {
        this.anio = anio;
    }

    @Override
    public String toString() {
        return "PeliculaClass{" + "ID=" + ID + ", titulo=" + titulo + ", genero=" + genero + ", director=" + director + ", anio=" + anio + '}';
    }
    
    
}
