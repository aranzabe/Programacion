/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Principal;

import Ventanas.Ventana1;

/**
 *
 * @author danie
 */
public class DJC_RegistroUsuarios {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Ventana1 v = new Ventana1();
        v.setVisible(true);
    }
    
}
