/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemploclase;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author faranzabe
 */
public class EjemploClase {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            FileWriter fw = null;
            String nombreFichero = "ejemplo.txt";
            File f = new File(nombreFichero);
            
            try {
                
                if (f.exists()){
                    System.out.println("Existe");
                    fw = new FileWriter(nombreFichero, true);
                }
                else {
                    fw = new FileWriter(nombreFichero);
                    System.out.println("No existe");
                }
                fw.write("Otra cosa..." + "\r\n");
                fw.close();
            } catch (IOException ex) {
            }
            
            Scanner sc = new Scanner(f);
            while(sc.hasNextLine()){
                String linea = sc.nextLine();
                System.out.println(linea);
            }
            
        } catch (FileNotFoundException ex) {
        } 
    }
    
}
