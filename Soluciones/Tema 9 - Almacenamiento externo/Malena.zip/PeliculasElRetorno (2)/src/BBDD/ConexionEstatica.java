package BBDD;

import Auxiliar.Constantes;
import java.sql.*;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import peliculaselretorno.Pelicula;

public class ConexionEstatica {

    //********************* Atributos *************************
    private static java.sql.Connection conexion;
    //Atributo a través del cual hacemos la conexión física.
    private static java.sql.Statement sentenciaSQL;
    //Atributo que nos permite ejecutar una sentencia SQL
    private static java.sql.ResultSet registros;

    //----------------------------------------------------------
    public static void abrirConexion() {
        try {
            String controlador = "org.mariadb.jdbc.Driver"; 
            Class.forName(controlador);

            String URL_BD = "jdbc:mysql://localhost/" + Constantes.bbdd;
            conexion = java.sql.DriverManager.getConnection(URL_BD, Constantes.usuario, Constantes.passwd);
            sentenciaSQL = conexion.createStatement();
            System.out.println("Conexion realizada con éxito");
        } catch (Exception e) {
            System.err.println("Exception: " + e.getMessage());
        }
    }

    //------------------------------------------------------
    public static void cerrarConexion() {
        try {
            conexion.close();
            System.out.println("Desconectado de la Base de Datos");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error de Desconexion", JOptionPane.ERROR_MESSAGE);
        }
    }

    //---------------------------------------------------------
    public static LinkedList obtenerPelisTablaLL(String nom_tabla) {
        LinkedList<Pelicula> ll = new LinkedList();
        Pelicula p = null;
        try {
            abrirConexion();
            String Sentencia = "SELECT * FROM " + nom_tabla + " ORDER BY id";
            registros = sentenciaSQL.executeQuery(Sentencia);
            while (registros.next()) {
                p = new Pelicula(registros.getInt("id"),registros.getString("titulo"),registros.getString("genero"),registros.getString("director"),registros.getInt("year"));
                ll.add(p);
            }
            cerrarConexion();
        } catch (SQLException ex) {
        }
        return ll;
    }

    //----------------------------------------------------------
    public static int insertarDato(String tablita,String titulo, String genero, String director, int year) {
        int cod = 0;
        String Sentencia = "INSERT INTO " + tablita + " VALUES (NULL," + "'" + titulo + "','" + genero + "','" + director + "'," + year + ")";
        try {
            abrirConexion();
            sentenciaSQL.executeUpdate(Sentencia);
            cerrarConexion();
        } catch (SQLException sq) {
            cod = sq.getErrorCode();
        }
        return cod;
    }

    //----------------------------------------------------------
    public static int borrarDato(int id) {
        int cod = 0;

        String Sentencia = "DELETE FROM pelicompleto WHERE id = '" + id + "'";
        try {
            abrirConexion();
            sentenciaSQL.executeUpdate(Sentencia);
            cerrarConexion();
        } catch (SQLException ex) {
            cod = ex.getErrorCode();
        }

        return cod;
    }
    
    public static int modificarRegistro(Pelicula pe){
        int cod = 0;
        try{
        abrirConexion();
        sentenciaSQL.executeUpdate("UPDATE pelicompleto SET titulo = '" + pe.getTitulo() + "', genero = '" + pe.getGenero() + "', director = '" + pe.getDirector() + "', anio = " + pe.getYear() + " WHERE id = " + pe.getId());
        cerrarConexion();
        }catch(SQLException ex){
            cod = ex.getErrorCode();
        }
        return cod;
    }
}
