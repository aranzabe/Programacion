/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio4;

import java.time.chrono.MinguoDate;
import java.util.Scanner;

/**
 *
 * @author faranzabe
 */
public class Ejercicio4 {
    
    public static Ordenador factoriaOrdenador(){
        Scanner sc = new Scanner(System.in);
        Ordenador o = new Ordenador();
        
        System.out.print("Código: ");
        o.setNumSerie(sc.nextLine());
        System.out.print("Procesador: ");
        o.setProcesador(sc.nextLine());
        System.out.print("Sistema operativo: ");
        o.setSO(sc.nextLine());
        System.out.print("HD: ");
        o.setHD(sc.nextInt());
        System.out.print("RAM: ");
        o.setRAM(sc.nextInt());
        
        return o;
    }
    
    public static Ordenador factoriaOrdenadorAleatorio(){
        Ordenador o = new Ordenador();
        
        int alea;
        alea = (int) (Math.random()*100) + 100;
        o.setNumSerie("DAW" + alea);
        alea = (int) (Math.random()*3);
        switch(alea){
            case 0: o.setProcesador("i5");break;
            case 1: o.setProcesador("i3");break;
            case 2: o.setProcesador("i7");
        }
        switch(alea){
            case 0: o.setSO("Linux");break;
            case 1: o.setSO("Windows");break;
            case 2: o.setSO("iOS");
        }
        switch(alea){
            case 0: o.setHD(256);break;
            case 1: o.setHD(512);break;
            case 2: o.setHD(1024);
        }
        switch(alea){
            case 0: o.setRAM(4);break;
            case 1: o.setRAM(8);break;
            case 2: o.setRAM(16);
        }
        return o;
    }
    
    public static Aula factoriaAula(){
        Aula a =  new Aula();
        for (int i = 0; i < a.getMaximo(); i++) {
            Ordenador o = factoriaOrdenadorAleatorio();
            a.addOrdenador(o);
        }
        return a;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Ejemplo factorías.
        Ordenador o = factoriaOrdenadorAleatorio();
        System.out.println(o);
        
        Aula a213 =  factoriaAula();
        System.out.println(a213.toString());
        
        
//        Ordenador miOrdenador = new Ordenador();
//        Ordenador portatil = new Ordenador(32,"i14",35);
//        System.out.println(miOrdenador.toString());
//        miOrdenador.setHD(512);
//        miOrdenador.setNumSerie("1A");
//        miOrdenador.setProcesador("i5 - 10104");
//        miOrdenador.setRAM(8);
//        miOrdenador.setSO("Linux - Ubuntu 20.04 LTS");
//        System.out.println(miOrdenador.toString());
//        //miOrdenador.setSO("Windows 10");
//        System.out.println(miOrdenador.toString());
//        System.out.println(miOrdenador.getSO());
//        System.out.println(portatil.toString());
//
//        portatil.setSO("Windows 10");
//        System.out.println(portatil.toString());
//        if (!portatil.getSO().isEmpty()) {
//            if (portatil.getSO().equals("Windows 10")) {
//                System.out.println("Tienes puesto güindon");
//            } else {
//                System.out.println("Pues tienes un SO de adultos.");
//            }
//        }
//        else {
//            System.out.println("NO tienes SO.");
//        }
//
//        if (miOrdenador.getRAM() < 8) {
//            System.out.println("Tienes poca RAM");
//        }
//        
//        portatil = miOrdenador;
//        System.out.println("Portatil: " + portatil.toString());
//        portatil.setSO("iOS");
//        System.out.println("Sobremesa: " + miOrdenador.toString());

        //PAra el ejercicio completo.
        //Que esto que voy a hacer aquí: NO SE HACE AQUÍ!!! ES SOLO PARA QUE ENTENDÁIS COMO SE MANIPULA UN VECTOR DE OBJETOS!!!!
//        Ordenador[] ords = new Ordenador[20];
//        ords[0] = new Ordenador();
//        System.out.println(ords[0].toString());
//        System.out.println(ords[1].toString());

//************************* Ampliación para aula *******************************
//        Aula a212 = new Aula("212");
//        Ordenador o = new Ordenador(32, "i14", 35);
//        o.setNumSerie("DAW108");
//        if (a212.addOrdenador(o)){
//            System.out.println("Inserción conseguida.");
//        }
//        else {
//            System.out.println("Aula completa.");
//        }
//        o = new Ordenador(128, "i36", 512);
//        o.setNumSerie("DAW102");
//        a212.addOrdenador(o);
//        System.out.println("Mi aula tiene: " + a212.getCuantos() + " ordenadores.");
//        System.out.println(a212.toString());
//        if (a212.removeOrdenador("DAW208")){
//            System.out.println("Ordenador borrado correctamente.");
//        }
//        else {
//            System.out.println("Fallo al borrar, no encontrado");
//        }
//        System.out.println(a212.toString());
        
//        o = new Ordenador(512,"i45",1000);
//        o.setNumSerie("DAW102");
//        if (a212.modifyOrdenador("DAW102", o)){
//            System.out.println("Modificado correctamente.");
//        }
//        else {
//            System.out.println("No encontrado.");
//        }
//        System.out.println(a212);
    }

}
