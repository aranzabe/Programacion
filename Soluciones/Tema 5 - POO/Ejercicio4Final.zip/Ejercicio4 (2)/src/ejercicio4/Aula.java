/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio4;

/**
 *
 * @author faranzabe
 */
public class Aula {

    private Ordenador[] ordenadores;
    private String codAula;

    public Aula() {
        this.codAula = "";
        this.ordenadores = new Ordenador[20];
    }

    public Aula(String codAula) {
        this.codAula = codAula;
        this.ordenadores = new Ordenador[20];
    }

    public Aula(String codAula, int max) {
        this.codAula = codAula;
        this.ordenadores = new Ordenador[max];
    }

    /**
     * Devolverá true si conseguimos añadir el ordenador a la clase.
     *
     * @param o
     * @return
     */
    public boolean addOrdenador(Ordenador o) {
        boolean colocado = false;
        int i = 0;
        while (i < this.ordenadores.length && !colocado) {
            if (this.ordenadores[i] == null) {
                this.ordenadores[i] = o;
                colocado = true;
            }
            i++;
        }
        return colocado;
    }

    public int getCuantos() {
        int cont = 0;
        for (int i = 0; i < this.ordenadores.length; i++) {
            if (this.ordenadores[i] != null) {
                cont++;
            }
        }
        return cont;
    }

    @Override
    public String toString() {
        String dev = "Aula: " + this.codAula + "\n[\n";
        for (int i = 0; i < this.ordenadores.length; i++) {
            if (this.ordenadores[i] != null) {
                dev += this.ordenadores[i].toString() + "\n";
            }

        }
        dev = dev + "]";
        return dev;
    }

    public boolean removeOrdenador(String numSerie) {
        boolean borrado = false;
        int i = 0;

        while (i < this.ordenadores.length && !borrado) {
            if (this.ordenadores[i] != null) {
                if (this.ordenadores[i].getNumSerie().equals(numSerie)) {
                    ordenadores[i] = null;
                    borrado = true;
                }
            }
            i++;
        }
        return borrado;
    }
    
//    public boolean removeOrdenador(Ordenador oborrar) {
//        boolean borrado = false;
//        int i = 0;
//
//        while (i < this.ordenadores.length && !borrado) {
//            if (this.ordenadores[i] != null) {
//                if (this.ordenadores[i].equals(oborrar)) {
//                    ordenadores[i] = null;
//                    borrado = true;
//                }
//            }
//            i++;
//        }
//        return borrado;
//    }

    public boolean modifyOrdenador(String numSerie, Ordenador o2) {
        boolean cambiado = false;
        int i = 0;

        while (i < this.ordenadores.length && !cambiado) {
            if (this.ordenadores[i] != null) {
                if (ordenadores[i].getNumSerie().equals(numSerie)) {
                    ordenadores[i] = o2;
                    cambiado = true;
                }
            }
            i++;
        }
        return cambiado;
    }

    public boolean modifyOrdenador(String numSerie, int HD, int RAM) {
        boolean cambiado = false;
        int i = 0;

        while (i < this.ordenadores.length && !cambiado) {
            if (this.ordenadores[i] != null) {
                if (ordenadores[i].getNumSerie().equals(numSerie)) {
                    ordenadores[i].setHD(HD);
                    ordenadores[i].setRAM(RAM);
                    cambiado = true;
                }
            }
            i++;
        }
        return cambiado;
    }
}
