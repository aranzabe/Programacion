/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_2018juegosdelhambre;

/**
 *
 * @author oem
 */
public class Mapa {

    private Casilla casillas[][];
    private static int jugadoresVivos;

    static {
        jugadoresVivos = 10;
    }

    public Mapa() {
        this.casillas = new Casilla[5][5];
    }

    public Mapa(int f, int c) {
        this.casillas = new Casilla[f][c];
    }

    public Casilla[][] getCasillas() {
        return casillas;
    }

    public int getDimF() {
        return this.casillas.length;
    }

    public int getDimC() {
        return this.casillas[0].length;
    }

    @Override
    public String toString() {
        String cad = "Mapa:\n";

        for (int i = 0; i < this.casillas.length; i++) {
            for (int j = 0; j < this.casillas[i].length; j++) {
                cad += this.casillas[i][j].toString() + "   ";
            }
            cad += "\n";
        }
        return cad;
    }

    public int[] getPosTributo(Tributo t) {
        int pos[] = new int[2];
        int i = 0;
        int j;
        boolean encontrado = false;

        while (!encontrado && i < this.getDimF()) {
            j = 0;
            while (!encontrado && j < this.getDimC()) {
                if (this.casillas[i][j].getTributo() != null && this.casillas[i][j].getTributo() == t) {
                    pos[0] = i;
                    pos[1] = j;
                    encontrado = true;
                }
                i++;
            }
            i++;
        }
        return pos;
    }

    public boolean sePuedeDesplazar(int f, int c) {
        return f >= 0 && f < this.getDimF() && c >= 0 && c < this.getDimC();
    }

    public void desplazamientoTributo(Tributo t) {
        boolean desplazado = false;
        int f = this.getPosTributo(t)[0];
        int c = this.getPosTributo(t)[1];

        while (!desplazado) {
            int alea = (int) (Math.random() * 8);
            switch (alea) {
                case 0: //desplazamiento arriba izq
                    if (sePuedeDesplazar(f - 1, c - 1)) {
                        this.casillas[f - 1][c - 1].setTributo(t);
                        desplazado = true;
                    }
                    break;
                case 1: //desplazamiento arriba
                    if (sePuedeDesplazar(f - 1, c)) {
                        this.casillas[f - 1][c].setTributo(t);
                        desplazado = true;
                    }
                    break;
                case 2: //desplazamiento arriba dcha
                    if (sePuedeDesplazar(f - 1, c + 1)) {
                        this.casillas[f - 1][c + 1].setTributo(t);
                        desplazado = true;
                    }
                    break;
                case 3: //desplazamiento dcha
                    if (sePuedeDesplazar(f, c + 1)) {
                        this.casillas[f][c + 1].setTributo(t);
                        desplazado = true;
                    }
                    break;
                case 4: //desplazamiento abajo dcha
                    if (sePuedeDesplazar(f + 1, c + 1)) {
                        this.casillas[f + 1][c + 1].setTributo(t);
                        desplazado = true;
                    }
                    break;
                case 5: //desplazamiento abajo
                    if (sePuedeDesplazar(f + 1, c)) {
                        this.casillas[f - 1][c].setTributo(t);
                        desplazado = true;
                    }
                    break;
                case 6: //desplazamiento abajo izq
                    if (sePuedeDesplazar(f + 1, c - 1)) {
                        this.casillas[f + 1][c - 1].setTributo(t);
                        desplazado = true;
                    }
                    break;
                case 7: //desplazamiento izq
                    if (sePuedeDesplazar(f, c - 1)) {
                        this.casillas[f][c - 1].setTributo(t);
                        desplazado = true;
                    }
            }
            this.casillas[f][c].setTributo(null);
        }
    }

}
