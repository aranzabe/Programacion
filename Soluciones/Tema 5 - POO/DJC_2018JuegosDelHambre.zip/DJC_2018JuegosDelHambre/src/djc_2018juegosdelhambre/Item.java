/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_2018juegosdelhambre;

/**
 *
 * @author oem
 */
public class Item {

    private String tipo;
    private String descripcion;
    private int lvlFuerza;
    private int lvlVida;

    public Item() {
        this.tipo = "";
        this.descripcion = "";
        this.lvlFuerza = 0;
        this.lvlVida = 0;
    }

    public Item(String tipo, String descripcion, int lvlFuerza, int lvlVida) {
        this.tipo = tipo;
        this.descripcion = descripcion;
        this.lvlFuerza = lvlFuerza;
        this.lvlVida = lvlVida;
    }

    public String getTipo() {
        return tipo;
    }

    public int getLvlFuerza() {
        return lvlFuerza;
    }

    public int getLvlVida() {
        return lvlVida;
    }

    @Override
    public String toString() {
        String cad = "";

        cad += this.tipo;
        switch (tipo) {
            case "Arma":
                cad += "(" + lvlFuerza + ")";
                break;
            case "Medicina":
                cad += "(" + lvlVida + ")";
        }
        return cad;
    }

}
