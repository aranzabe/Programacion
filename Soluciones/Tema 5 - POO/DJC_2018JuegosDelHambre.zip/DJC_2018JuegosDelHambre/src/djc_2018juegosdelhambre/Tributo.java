/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_2018juegosdelhambre;

/**
 *
 * @author oem
 */
public class Tributo {
    private Distrito distrito;
    private int lvlVida;
    private int lvlFuerza;
    
    public Tributo(){
        this.lvlVida = 0;
        this.lvlFuerza = 0;
    }
    
    public Tributo(Distrito distrito, int lvlVida, int lvlFuerza){
        this.distrito = distrito;
        this.lvlVida = lvlVida;
        this.lvlFuerza = lvlFuerza;
    }

    public void setLvlVida(int lvlVida) {
        this.lvlVida = lvlVida;
    }

    public void setLvlFuerza(int lvlFuerza) {
        this.lvlFuerza = lvlFuerza;
    }

    public Distrito getDistrito() {
        return distrito;
    }

    public int getLvlVida() {
        return lvlVida;
    }

    public int getLvlFuerza() {
        return lvlFuerza;
    }

    @Override
    public String toString() {
        String cad = "";
        
        cad += "Tributo (D" + this.distrito.getNumDistrito() + ", " + this.lvlVida + "HP, " + this.lvlFuerza + "DMG)";
        return cad;
    }
    
    public void matarTributo(){
        this.lvlVida = 0;
    }
    
    public void cogerItem(Item item){
        switch (item.getTipo()){
            case "Arma": this.lvlFuerza += item.getLvlFuerza(); break;
            case "Medicina": this.lvlVida += item.getLvlVida(); break;
            case "Trampa": matarTributo();
        }
    }
    
}
