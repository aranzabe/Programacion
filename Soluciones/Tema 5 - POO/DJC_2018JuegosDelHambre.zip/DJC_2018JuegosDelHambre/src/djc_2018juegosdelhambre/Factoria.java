/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_2018juegosdelhambre;

/**
 *
 * @author oem
 */
public class Factoria {

    public static Item factoriaItem() {
        int aleaTipo = (int) (Math.random() * 3);
        int aleaLvl = (int) (Math.random() * 51) + 50;
        String tipo = "";
        String descr = "";
        int lvlF = 0, lvlV = 0;

        switch (aleaTipo) {
            case 0:
                tipo = "Arma";
                lvlF = aleaLvl;
                break;
            case 1:
                tipo = "Medicina";
                lvlV = aleaLvl;
                break;
            case 2:
                tipo = "Trampa";
        }

        return new Item(tipo, descr, lvlF, lvlV);
    }

    public static Capitolio factoriaCapitolio() {
        Capitolio cap = new Capitolio();

        for (int i = 0; i < cap.getTamAlmacenItems(); i++) {
            cap.addItem(factoriaItem());
        }
        return cap;
    }

    public static Tributo factoriaTributo(Distrito dis) {
        Tributo trib;
        int aleaV = (int) (Math.random() * 100) + 201;
        int aleaF = (int) (Math.random() * 100) + 201;

        trib = new Tributo(dis, aleaF, aleaV);
        return trib;
    }

    public static Distrito factoriaDistrito(int numDistrito) {
        Distrito d = new Distrito(numDistrito);

        d.addTributo(factoriaTributo(d));
        d.addTributo(factoriaTributo(d));
        return d;
    }

    public static Mapa factoriaMapa(Capitolio cap) {
        Mapa m = new Mapa();
        int itemsColocados = 0;

        for (int j = 0; j < m.getDimF(); j++) {
            for (int k = 0; k < m.getDimC(); k++) {
                m.getCasillas()[j][k] = new Casilla();
            }
        }

        while (itemsColocados < 10) {
            int aleaPosF = (int) (Math.random() * m.getDimF());
            int aleaPosC = (int) (Math.random() * m.getDimC());
            Casilla cas = m.getCasillas()[aleaPosF][aleaPosC];
            if (cas.getItem() == null) {
                cap.enviarItem(cas);
                itemsColocados++;
            }
        }
        return m;
    }

    public static Mapa factoriaMapa(int f, int c, Capitolio cap) {
        Mapa m = new Mapa(f, c);
        int itemsColocados = 0;

        for (int j = 0; j < m.getDimF(); j++) {
            for (int k = 0; k < m.getDimC(); k++) {
                m.getCasillas()[j][k] = new Casilla();
            }
        }

        while (itemsColocados < 10) {
            int aleaPosF = (int) (Math.random() * m.getDimF());
            int aleaPosC = (int) (Math.random() * m.getDimC());
            Casilla cas = m.getCasillas()[aleaPosF][aleaPosC];
            if (cas.getItem() == null) {
                cap.enviarItem(cas);
                itemsColocados++;
            }
        }
        return m;
    }

}
