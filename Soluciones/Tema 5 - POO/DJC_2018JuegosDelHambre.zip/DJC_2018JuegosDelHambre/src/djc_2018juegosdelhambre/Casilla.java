/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_2018juegosdelhambre;

/**
 *
 * @author oem
 */
public class Casilla {

    private Item item;
    private Tributo tributo;

    public Casilla() {
        this.item = null;
        this.tributo = null;
    }

    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    public Tributo getTributo() {
        return tributo;
    }

    public void setTributo(Tributo tributo) {
        this.tributo = tributo;
    }

    public boolean addItem(Item item) {
        boolean conseguido = false;

        if (this.item == null && this.tributo == null) {
            this.item = item;
            conseguido = true;
        }
        return conseguido;
    }

    public boolean addTributo(Tributo t) {
        boolean conseguido = false;

        if (this.tributo == null && this.item == null) {
            this.tributo = t;
            conseguido = true;
        }
        return conseguido;
    }

    @Override
    public String toString() {
        String cad = "";

        if (this.item != null) {
            cad += this.item.toString();
        }
        if (this.tributo != null) {
            cad += this.tributo.toString();
        }
        if (this.item == null && this.tributo == null){
            cad += "Vacía";
        }
        return cad;
    }
}
