/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_2018juegosdelhambre;

/**
 *
 * @author oem
 */
public class Capitolio {

    private Item almacenItems[];
    private Tributo cadaveres[];

    public Capitolio() {
        this.almacenItems = new Item[100];
        this.cadaveres = null;
    }

    public Item[] getAlmacenItems() {
        return almacenItems;
    }

    public Tributo[] getCadaveres() {
        return cadaveres;
    }

    public int getTamAlmacenItems() {
        return this.almacenItems.length;
    }

    public int getTamCadaveres() {
        return this.cadaveres.length;
    }

    @Override
    public String toString() {
        String cad = "Estado del capitolio:\n";

        cad += "Items:\n";
        for (int i = 0; i < this.getTamAlmacenItems(); i++) {
            if (this.almacenItems[i] != null) {
                cad += this.almacenItems[i].toString();
            }
        }
        if (this.cadaveres != null) {
            cad += "Tributos fallecidos:\n";
            for (int i = 0; i < this.cadaveres.length; i++) {
                cad += this.cadaveres[i].toString();
            }
        }
        return cad;
    }

    public boolean addItem(Item item) {
        boolean conseguido = false;
        int i = 0;

        while (i < this.almacenItems.length && !conseguido) {
            if (this.almacenItems[i] == null) {
                this.almacenItems[i] = item;
                conseguido = true;
            }
            i++;
        }
        return conseguido;
    }

    /**
     * Este método inicia el vector de cadáveres y mete un cadáver dentro
     *
     * @param cadaver el cuerpo del primer tributo fallecido
     */
    public void inaugurarCementerio(Tributo cadaver) {
        this.cadaveres = new Tributo[1];
        this.cadaveres[0] = cadaver;
        cadaver = null;
    }

    public boolean enviarItem(Casilla cas) {
        boolean conseguido = false;
        int i = 0;

        while (i < this.almacenItems.length && !conseguido) {
            if (this.almacenItems[i] != null) {
                cas.addItem(this.almacenItems[i]);
                this.almacenItems[i] = null;
                conseguido = true;
            }
            i++;
        }
        return conseguido;
    }

}
