/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_2018juegosdelhambre;

/**
 *
 * @author oem
 */
public class DJC_2018JuegosDelHambre {

    public static void colocarTributosMapa(Distrito d, Mapa m){
        int i = 0;
        
        while (i < d.getJugadores().length) {
            int aleaPosF = (int) (Math.random() * m.getDimF());
            int aleaPosC = (int) (Math.random() * m.getDimC());
            Casilla cas = m.getCasillas()[aleaPosF][aleaPosC];
            if (cas.getTributo() == null && cas.getItem() == null){
                cas.addTributo(d.getJugadores()[i]);
                i++;
            }
        }
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        int t = 0;
        boolean fin = false;
        
        //INICIALIZACIÓN
        Capitolio cap = Factoria.factoriaCapitolio();
        Distrito dis1 = Factoria.factoriaDistrito(1);
        Distrito dis2 = Factoria.factoriaDistrito(2);
        Distrito dis3 = Factoria.factoriaDistrito(3);
        Distrito dis4 = Factoria.factoriaDistrito(4);
        Distrito dis5 = Factoria.factoriaDistrito(5);
        Mapa m = Factoria.factoriaMapa(cap);
        colocarTributosMapa(dis1, m);
        colocarTributosMapa(dis2, m);
        colocarTributosMapa(dis3, m);
        colocarTributosMapa(dis4, m);
        colocarTributosMapa(dis5, m);
        System.out.println(m);
        
        //INICIALIZACIÓN
            //Se rellena el almacén de items del capitolio con 100 items
                //Se generan al azar dos cosas:
                    //El tipo de item
                    //Su nivel (entre 50 y 100)
            //Se sacan 10 items del capitolio y se colocan al azar en el mapa
            //Se colocan los tributos al azar sólo en casillas vacías
        
//        while (!fin){
//            if(t % 2 == 0){
//                
//            }
//            
//            if (t % 5 == 0){
//                
//            }
//            
//            t++;
//            Thread.sleep(1000);
//        }
    }
    
}
