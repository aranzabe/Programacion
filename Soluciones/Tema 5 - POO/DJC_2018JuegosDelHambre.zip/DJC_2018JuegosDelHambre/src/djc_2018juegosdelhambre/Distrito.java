/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_2018juegosdelhambre;

/**
 *
 * @author oem
 */
public class Distrito {
    private Tributo jugadores[];
    private int numDistrito;
    
    public Distrito(){
        this.jugadores = new Tributo[2];
        this.numDistrito = 0;
    }
    
    public Distrito(int numDistrito){
        this.numDistrito = numDistrito;
        this.jugadores = new Tributo[2];
    }

    public int getNumDistrito() {
        return this.numDistrito;
    }

    public Tributo[] getJugadores() {
        return jugadores;
    }
    
    public boolean addTributo(Tributo trib){
        boolean conseguido = false;
        int i = 0;
        
        while (i < this.jugadores.length && !conseguido){
            if (this.jugadores[i] == null){
                this.jugadores[i] = trib;
                conseguido = true;
            }
            i++;
        }
        return conseguido;
    }

    @Override
    public String toString() {
        String cad = "";
        
        cad += "Distrito " + numDistrito + "\n";
        cad += "Estado de los tributos:\n";
        for (int i = 0; i < this.jugadores.length; i++) {
            if (this.jugadores[i] == null){
                cad += "ELIMINADO\n";
            } else {
                cad += this.jugadores[i].toString() + "\n";
            }
        }
        return cad;
    }
    
    
    
}
