/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objetosmosca.pkg2;

/**
 *
 * @author 34671
 */
public class Tablero {

    private Mosca tablero[];

    public Tablero(int[] Tablero) {
        this.tablero = new Mosca[10];
    }

    public Tablero(int tam) {
        this.tablero = new Mosca[tam];
    }

    /**
     * Esta funcion sirve para generar un tablero nuevo.
     */
    public void generarTablero() {

        for (int i = 0; i < this.tablero.length; i++) {
            this.tablero[i] = null;
        }
    }

    /**
     * Esta funcion sirve para posicionar la mosca en alguna casilla del Tablero
     * de manera aleatoria
     */
    public void ponerMosca(Mosca m) {
        int posmosca;
        boolean colocada = false;

        while (!colocada) {
            posmosca = (int) (Math.random() * this.tablero.length);
            if (this.tablero[posmosca] == null) {
                this.tablero[posmosca] = m;
                colocada = true;
            }
        }
    }

    /**
     * Esta funcion te dira si en la posicion que ha elegido el usuario, hay una
     * mosca
     *
     * @param pos
     * @return 1: Si no la cazas, pero has estado cerca/ 2: Si no la cazas y no
     * has estado cerca/ 3: Si la cazas
     */
    public int pegarManotazo(int pos) {
        int cazada = 2;

        if (this.tablero[pos] != null) {
            this.tablero[pos].quitarUnaVida();
            //this.tablero[pos].setHP(this.tablero[pos].getHP() - 1);
            if (this.tablero[pos].getHP() == 0){
                cazada = 3;
            }
            else {
                cazada = 4;
            }
        } else {
            int i = pos + 1;
            if (i < this.tablero.length) {
                if (this.tablero[i] != null) {
                    cazada = 1;
                }
            }
            i = pos - 1;
            if (i >= 0) {
                if (this.tablero[i] != null) {
                    cazada = 1;
                }
            }
        }

        return cazada;
    }

    public void revolotear(Mosca m) {
        this.generarTablero();
        this.ponerMosca(m);
    }
    
    public void revolotear(){
        Mosca mos = null;
        for (int i = 0; i < this.tablero.length; i++) {
            if (this.tablero[i]!=null){
                mos = this.tablero[i];
                this.tablero[i] = null;
            }
        }
        this.ponerMosca(mos);
    }

    @Override
    public String toString() {
        String div = "";

        for (int i = 0; i < this.tablero.length; i++) {
            div = div + this.tablero[i] + " ";

        }
        div = div + "\n";

        return div;
    }
}
