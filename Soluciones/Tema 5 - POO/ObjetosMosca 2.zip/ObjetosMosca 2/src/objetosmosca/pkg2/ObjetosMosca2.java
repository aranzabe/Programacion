/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objetosmosca.pkg2;

import java.util.Scanner;

/**
 *
 * @author 34671
 */
public class ObjetosMosca2 {

    public static Mosca factoriaMoscaAleatoria() {
        int alea;
        int vidas;
        String tipo = null;
        alea = (int) (Math.random() * 3);
        switch (alea) {
            case 0:
                tipo = "Tse Tse";
                break;
            case 1:
                tipo = "Verde";
                break;
            case 2:
                tipo = "Fruta";
                break;
        }
        vidas = (int) (Math.random() * 4) + 1;
        Mosca m = new Mosca(tipo, vidas);
        return m;
    }

    public static Mosca factoriaMoscaTeclado() {
        Scanner sc = new Scanner(System.in);
        int vidas;
        String tipo;

        System.out.println("Cuantas vidas quieres asignar a la mosca?");
        vidas = sc.nextInt();
        System.out.println("De que tipo quieres que sea la mosca?");
        tipo = sc.nextLine();
        Mosca m = new Mosca(tipo, vidas);

        return m;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Tablero t = new Tablero(5);
        int qhp = 0;
        boolean cazada = false;
        int manotazo;
        int intentos = 0;
        Mosca m = factoriaMoscaAleatoria();

        System.out.println("Colocando la mosca: " + m.toString());

        t.generarTablero();
        t.ponerMosca(m);

        while (!cazada && intentos < 150) {
            System.out.println(t.toString());

            System.out.println("Donde vas a pegar el manotazo?");
            manotazo = sc.nextInt();
            intentos++;
            qhp = t.pegarManotazo(manotazo);
            if (qhp == 1) {
                System.out.println("La mosca revolotea y se va de su posicion");
                //t.revolotear(m);
                t.revolotear();
            }
            if (qhp == 2) {
                System.out.println("No te has acercado");
            }
            if (qhp == 3) {
                System.out.println("Le has dado!!!! Y la has matado.");
                cazada = true;
            }
            if (qhp == 4) {
                System.out.println("Le has dado pero le quedan vidas");
                //t.revolotear(m);
                t.revolotear();
            }
        }

        if (cazada) {
            System.out.println("Enhorabuena, has ganado");
        } else {
            System.out.println("No has ganado");
        }
        System.out.println(t.toString());

    }
}
