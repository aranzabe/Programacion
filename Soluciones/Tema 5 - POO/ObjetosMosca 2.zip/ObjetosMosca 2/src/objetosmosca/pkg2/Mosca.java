/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objetosmosca.pkg2;

/**
 *
 * @author 34671
 */
public class Mosca {

    private String tipos;
    private int HP;

    
    public Mosca() {
        this.tipos = "";
        this.HP = 3;
    }
    
    public Mosca(String tipo, int vidas) {
        this.tipos = tipo;
        this.HP = vidas;
    }

    
    public void setTipos(String tipos) {
        this.tipos = tipos;
    }

    public String getTipos() {
        return tipos;
    }

    public int getHP() {
        return HP;
    }

    public void setHP(int HP) {
        this.HP = HP;
    }
    
    
    
    public void quitarUnaVida(){
        this.HP--;
    }

    @Override
    public String toString() {
        return "Mosca{" + "tipos=" + tipos + ", HP=" + HP + '}';
    }
    

    
    
    
}
