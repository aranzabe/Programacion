/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objetosmosca.pkg2;

import java.util.Scanner;

/**
 *
 * @author 34671
 */
public class ObjetosMosca2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        TableroLogico t = new TableroLogico(5);
        int qhp = 0;
        int vidas;
        boolean cazada = false;
        int manotazo;
        int intentos = 0;
        String tipo;
        Scanner sc = new Scanner(System.in);

        t.generarTablero();
        t.ponerMosca();
        System.out.println(t.toString());
        System.out.println("Cuantas vidas quieres asignar a la mosca?");
        vidas = sc.nextInt();
        System.out.println("De que tipo quieres que sea la mosca?");
        tipo = sc.nextLine();
        Mosca m = new Mosca("tipo", vidas);

        while (!cazada || intentos < 15 && vidas > 0) {
            System.out.println("Donde vas a pegar el manotazo?");
            manotazo = sc.nextInt();
            qhp = t.pegarManotazo(manotazo);
            if (qhp == 1) {
                System.out.println("La mosca revolotea y se va de su posicion");
                cazada = false;
                t.revolotear();
                intentos++;
            }
            if (qhp == 2) {
                System.out.println("No te has acercado");
                cazada = false;
                intentos++;
            }
            if (qhp == 3) {
                vidas--;
                System.out.println("Le has dado!!!! su vida disminuye, le quedan : " + vidas);
                cazada = true;

            }
        }

        if (cazada) {
            System.out.println("Enhorabuena, has ganado");
        } else {
            System.out.println("No has ganado");
            System.out.println(t.toString());
        }
    }
}
