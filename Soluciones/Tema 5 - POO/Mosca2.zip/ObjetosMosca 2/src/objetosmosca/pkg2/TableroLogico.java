/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objetosmosca.pkg2;

/**
 *
 * @author 34671
 */
public class TableroLogico {

    private int Tablero[];

    public TableroLogico(int[] Tablero) {
        this.Tablero = new int[10];
    }

    public TableroLogico(int tam) {
        this.Tablero = new int[tam];
    }

    /**
     * Esta funcion sirve para generar un tablero nuevo.
     */
    public void generarTablero() {

        for (int i = 0; i < this.Tablero.length; i++) {

            this.Tablero[i] = 0;

        }
    }

    /**
     * Esta funcion sirve para posicionar la mosca en alguna casilla del Tablero
     * de manera aleatoria
     */
    public void ponerMosca() {
        int posmosca;
        boolean colocada = false;

        while (!colocada) {
            posmosca = (int) (Math.random() * this.Tablero.length);
            if (this.Tablero[posmosca] == 0) {
                this.Tablero[posmosca] = 1;
                colocada = true;
            }
        }
    }

    /**
     * Esta funcion te dira si en la posicion que ha elegido el usuario, hay una
     * mosca
     *
     * @param pos
     * @return 1: Si no la cazas, pero has estado cerca/ 2: Si no la cazas y no
     * has estado cerca/ 3: Si la cazas
     */
    public int pegarManotazo(int pos) {
        int cazada = 2;

        if (this.Tablero[pos] == 1) {
            cazada = 3;
        } else {
            int i = pos + 1;
            if (i < this.Tablero.length) {
                if (this.Tablero[i] == 1) {
                    cazada = 1;
                }
            }
            i = pos - 1;
            if (i >= 0) {
                if (this.Tablero[i] == 1) {
                    cazada = 1;
                }
            }
        }

        return cazada;
    }

    public void revolotear() {
        this.generarTablero();
        this.ponerMosca();
    }

    @Override
    public String toString() {
        String div = "";

        for (int i = 0; i < this.Tablero.length; i++) {
            div = div + this.Tablero[i] + " ";

        }
        div = div + "\n";

        return div;
    }
}
