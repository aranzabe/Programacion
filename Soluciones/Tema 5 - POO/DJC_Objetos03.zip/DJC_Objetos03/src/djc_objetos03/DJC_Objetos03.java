/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_objetos03;

import java.util.Scanner;

/**
 *
 * @author usuariob
 */
public class DJC_Objetos03 {

    /**
     * Este módulo pide la velocidad de crucero por teclado, controlando que sea
     * mayor que 0
     */
    public static int pedirVelocidad() {
        int v;
        Scanner sc = new Scanner(System.in);

        do {
            System.out.println("Dame una velocidad de crucero. Tiene que ser "
                    + "mayor que 0 y múltiplo de 5");
            v = sc.nextInt();
            if (v < 5 && v % 5 != 0) {
                System.out.println("Velocidad incorrecta");
            }
        } while (v < 5 && v % 5 != 0);
        return v;
    }

    /**
     * Este módulo pide la velocidad de crucero por teclado, controlando que sea
     * mayor que 0
     */
    public static int pedirTiempo() {
        int t;
        Scanner sc = new Scanner(System.in);

        do {
            System.out.println("Dame un tiempo para mantener "
                    + "la velocidad de crucero");
            t = sc.nextInt();
            if (t < 0) {
                System.out.println("Valor demasiado pequeño");
            }
        } while (t < 0);
        return t;
    }

    /*------------------------------------------------------------------------*/
 /*-----------------------------ALGORITMO PRINCIPAL---------------------------*/
 /*---------------------------------------------------------------------------*/
    public static void main(String[] args) throws InterruptedException {
        Coche miCoche = new Coche("Peugeot", "206", "blanco", "0000BMG");
        int vCrucero, tCrucero;
        int vActual, tActual;
        boolean marchaCambiada = false;

        vCrucero = pedirVelocidad();
        tCrucero = pedirTiempo();
        miCoche.arrancarMotor();
        System.out.println("Motor arrancado");
        //Este bucle acelera el coche
        while (miCoche.getVelocidadActual() < vCrucero) {
            vActual = miCoche.getVelocidadActual();
            switch (miCoche.getMarchaActual()) {
                case 0:
                    miCoche.subirMarcha();
                    marchaCambiada = true;
                    break;
                case 1:
                    if (vActual < 30) {
                        miCoche.acelera();
                        marchaCambiada = false;
                    } else {
                        miCoche.subirMarcha();
                        marchaCambiada = true;
                    }
                    break;
                case 2:
                    if (vActual < 50) {
                        miCoche.acelera();
                        marchaCambiada = false;
                    } else {
                        miCoche.subirMarcha();
                        marchaCambiada = true;
                    }
                    break;
                case 3:
                    if (vActual < 70) {
                        miCoche.acelera();
                        marchaCambiada = false;
                    } else {
                        miCoche.subirMarcha();
                        marchaCambiada = true;
                    }
                    break;
                case 4:
                    if (vActual < 100) {
                        miCoche.acelera();
                        marchaCambiada = false;
                    } else {
                        miCoche.subirMarcha();
                        marchaCambiada = true;
                    }
                    break;
                case 5:
                    miCoche.acelera();
                    marchaCambiada = false;
            }
            System.out.println("Velocidad del coche: " + miCoche.getVelocidadActual());
            if (marchaCambiada) {
                System.out.println("El coche ha tenido que subir de "
                        + (miCoche.getMarchaActual() - 1) + "ª a "
                        + miCoche.getMarchaActual() + "ª");
            }
        }
        //Este bucle mantiene la simulación en la velocidad de crucero
        System.out.println("Se ha llegado a la velocidad de crucero");
        for (tActual = 0; tActual <= tCrucero; tActual++) {
            System.out.println(tActual + " segundos en la velocidad de crucero");
            Thread.sleep(1000);
        }
        //Este bucle desacelera el coche
        while (miCoche.getVelocidadActual() > 0) {
            vActual = miCoche.getVelocidadActual();
            switch (miCoche.getMarchaActual()) {
                case 1:
                    if (vActual > 0) {
                        miCoche.frena();
                        marchaCambiada = false;
                    } else {
                        miCoche.bajarMarcha();
                        marchaCambiada = true;
                    }
                    break;
                case 2:
                    if (vActual > 30) {
                        miCoche.frena();
                        marchaCambiada = false;
                    } else {
                        miCoche.bajarMarcha();
                        marchaCambiada = true;
                    }
                    break;
                case 3:
                    if (vActual > 50) {
                        miCoche.frena();
                        marchaCambiada = false;
                    } else {
                        miCoche.bajarMarcha();
                        marchaCambiada = true;
                    }
                    break;
                case 4:
                    if (vActual > 70) {
                        miCoche.frena();
                        marchaCambiada = false;
                    } else {
                        miCoche.bajarMarcha();
                        marchaCambiada = true;
                    }
                    break;
                case 5:
                    if (vActual > 100) {
                        miCoche.frena();
                        marchaCambiada = false;
                    } else {
                        miCoche.bajarMarcha();
                        marchaCambiada = true;
                    }
            }
            System.out.println("Velocidad del coche: " + miCoche.getVelocidadActual());
            if (marchaCambiada) {
                System.out.println("El coche ha tenido que bajar de "
                        + (miCoche.getMarchaActual() + 1) + "ª a "
                        + miCoche.getMarchaActual() + "ª");
            }
        }
        miCoche.pararMotor();
        System.out.println("Motor parado");
    }

}
