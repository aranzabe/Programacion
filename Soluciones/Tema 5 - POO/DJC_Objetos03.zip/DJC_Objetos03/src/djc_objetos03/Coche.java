/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_objetos03;

/**
 *
 * @author usuariob
 */
public class Coche {

    private String marca;
    private String modelo;
    private String color;
    private String matricula;
    private boolean motorEncendido;
    private int marchaActual;
    private int velocidadActual;

    public Coche() {
        this.marca = "";
        this.modelo = "";
        this.color = "";
        this.matricula = "";
    }

    public Coche(String marca, String modelo, String color, String matricula) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.matricula = matricula;
    }

    @Override
    public String toString() {
        return "Coche{" + "marca=" + marca + ", modelo=" + modelo + ", color=" + color + ", matricula=" + matricula + ", motorEncendido=" + motorEncendido + ", marchaActual=" + marchaActual + ", velocidadActual=" + velocidadActual + '}';
    }

    public boolean isMotorEncendido() {
        return motorEncendido;
    }

//    public void setMotorEncendido(boolean motorEncendido) {
//        this.motorEncendido = motorEncendido;
//    }
    public void arrancarMotor() {
        this.motorEncendido = true;
    }

    public void pararMotor() {
        this.motorEncendido = false;
    }
    
    public int getMarchaActual() {
        return marchaActual;
    }

    public boolean subirMarcha() {
        boolean conseguido = false;
        if (this.marchaActual < 6) {
            this.marchaActual++;
            conseguido = true;
        }
        return conseguido;
    }

    public boolean bajarMarcha() {
        boolean conseguido = false;
        if (this.marchaActual > 0) {
            this.marchaActual--;
            conseguido = true;
        }
        return conseguido;
    }

    public int getVelocidadActual() {
        return velocidadActual;
    }

    public void acelera() {
        this.velocidadActual += 5;
    }

    public void frena() {
        this.velocidadActual -= 5;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public String getColor() {
        return color;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

}
