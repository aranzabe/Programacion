/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_objetos02;

import java.util.Scanner;

/**
 *
 * @author danie
 */
public class Racional {

    private int numerador, denominador;
    Scanner sc = new Scanner(System.in);

    public Racional() {
        this.numerador = 0;
        this.denominador = 0;
    }

    public void leer() {
        this.numerador = sc.nextInt();
        this.denominador = sc.nextInt();
    }

    public void simplificar() {
        int i;
        int elMenor;

        if (this.denominador < this.numerador) {
            elMenor = this.denominador;
        } else {
            elMenor = this.numerador;
        }
        i = elMenor;
        
        do {
            if (this.numerador % i == 0 && this.denominador % i == 0) {
                this.numerador = this.numerador / i;
                this.denominador = this.denominador / i;
            }
            i--;
        } while (i >= 1);
    }

    @Override
    public String toString() {
        return "" + numerador + '/' + denominador;
    }

    public int getNumerador() {
        return numerador;
    }

    public void setNumerador(int numerador) {
        this.numerador = numerador;
    }

    public int getDenominador() {
        return denominador;
    }

    public void setDenominador(int denominador) {
        this.denominador = denominador;
    }
}
