/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_objetos02;

import java.util.Scanner;

/**
 *
 * @author danie
 */
public class DJC_Objetos02 {

    /**
     * Este módulo pide por teclado (con control de errores) un código para
     * decidir qué operación se va a hacer
     */
    public static int pedirOperacion(){
        int cod;
        Scanner sc = new Scanner(System.in);
        
        do{
            System.out.println("¿Qué operación quieres hacer?");
            System.out.println("1 - Suma");
            System.out.println("2 - Multiplicación");
            cod = sc.nextInt();
            if (cod != 1 && cod != 2){
                System.out.println("Código incorrecto");
            }
        } while (cod != 1 && cod != 2);
        return cod;
    }
    /**
     * Este módulo suma dos fracciones y devuelve el resultado simplificado
     */
    public static Racional sumarFracciones(Racional a, Racional b) {
        Racional c = new Racional();

        if (a.getDenominador() == b.getDenominador()) {
            c.setNumerador(a.getNumerador() + b.getNumerador());
            c.setDenominador(a.getDenominador());
        } else {
            c.setDenominador(a.getDenominador() * b.getDenominador());
            c.setNumerador((a.getNumerador() * b.getDenominador()) + (b.getNumerador() * a.getDenominador()));
        }
        return c;
    }

    /**
     * Este módulo multiplica dos fracciones y devuelve el resultado
     * simplificado
     */
    public static Racional multiplicarFracciones(Racional a, Racional b) {
        Racional c = new Racional();

        c.setNumerador(a.getNumerador() * b.getNumerador());
        c.setDenominador(a.getDenominador() * b.getDenominador());
        return c;
    }

    /*------------------------------------------------------------------------*/
 /*-----------------------------ALGORITMO PRINCIPAL---------------------------*/
 /*---------------------------------------------------------------------------*/
    public static void main(String[] args) {
        Racional a = new Racional();
        Racional b = new Racional();
        Racional c = new Racional();
        int operacion;

        System.out.println("Dame el numerador y el denominador de la primera fracción:");
        a.leer();
        System.out.println("Dame el numerador y el denominador de la segunda fracción:");
        b.leer();
        operacion = pedirOperacion();
        switch (operacion) {
            case 1:
                c = sumarFracciones(a, b);
                System.out.print("El resultado de la suma es: ");
                break;
            case 2:
                c = multiplicarFracciones(a, b);
                System.out.print("El resultado de la multiplicación es: ");
        }
        System.out.println(c.toString());
        c.simplificar();
        System.out.println("El resultado de simplificado es: " + c.toString());
    }

}
