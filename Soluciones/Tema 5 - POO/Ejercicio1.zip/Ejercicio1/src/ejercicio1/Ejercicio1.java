/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1;

/**
 *
 * @author faranzabe
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Reloj r1 = new Reloj(14,19,0);
        Reloj rNY = new Reloj(8,19,0);
        r1.ticTac();
        System.out.println(r1.toString());
        r1.ticTac();
        System.out.println(r1.toString());
        r1.ticTac();
        System.out.println(r1.toString());
        r1.ticTac();
        System.out.println(r1.toString());
        r1.cambiarPila();
        r1.ticTac();
        System.out.println(r1.toString());
        r1.ticTac();
        System.out.println(r1.toString());
        System.out.println(rNY.toString());
    }
    
}
