/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1;

/**
 *
 * @author faranzabe
 */
public class Reloj {

    private int h;
    private int m;
    private int s;
    private String tipo;
    private int pila;

    public Reloj() {
        this.h = 0;
        this.m = 0;
        this.s = 0;
        this.tipo = "A";
        this.pila = 100;
    }

    public Reloj(int h, int m, int s) {
        this.h = h;
        this.m = m;
        this.s = s;
        this.pila = 2;
    }

    public int getH() {
        return h;
    }

    public int getM() {
        return m;
    }

    public int getS() {
        return s;
    }

    public void setH(int h) {
        this.h = h;
    }

    public void setM(int m) {
        this.m = m;
    }

    public void setS(int s) {
        this.s = s;
    }

    public void cambiarPila() {
        this.pila = 100;
    }

    public void ticTac() {
        if (this.pila > 0) {
            this.s++;
            if (this.s == 60) {
                this.s = 0;
                this.m++;
            }
            if (this.m == 60) {
                this.m = 0;
                this.h++;
            }
            if (this.h == 24) {
                this.h = 0;
            }
            this.pila--;
        }
    }

    @Override
    public String toString() {
        return "Reloj{" + h + ":" + m + ":" + s + '}';
    }

}
