/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio4;

import java.time.chrono.MinguoDate;

/**
 *
 * @author faranzabe
 */
public class Ejercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        Ordenador miOrdenador = new Ordenador();
//        Ordenador portatil = new Ordenador(32,"i14",35);
//        System.out.println(miOrdenador.toString());
//        miOrdenador.setHD(512);
//        miOrdenador.setNumSerie("1A");
//        miOrdenador.setProcesador("i5 - 10104");
//        miOrdenador.setRAM(8);
//        miOrdenador.setSO("Linux - Ubuntu 20.04 LTS");
//        System.out.println(miOrdenador.toString());
//        //miOrdenador.setSO("Windows 10");
//        System.out.println(miOrdenador.toString());
//        System.out.println(miOrdenador.getSO());
//        System.out.println(portatil.toString());
//
//        portatil.setSO("Windows 10");
//        System.out.println(portatil.toString());
//        if (!portatil.getSO().isEmpty()) {
//            if (portatil.getSO().equals("Windows 10")) {
//                System.out.println("Tienes puesto güindon");
//            } else {
//                System.out.println("Pues tienes un SO de adultos.");
//            }
//        }
//        else {
//            System.out.println("NO tienes SO.");
//        }
//
//        if (miOrdenador.getRAM() < 8) {
//            System.out.println("Tienes poca RAM");
//        }
//        
//        portatil = miOrdenador;
//        System.out.println("Portatil: " + portatil.toString());
//        portatil.setSO("iOS");
//        System.out.println("Sobremesa: " + miOrdenador.toString());

        //PAra el ejercicio completo.
        //Que esto que voy a hacer aquí: NO SE HACE AQUÍ!!! ES SOLO PARA QUE ENTENDÁIS COMO SE MANIPULA UN VECTOR DE OBJETOS!!!!
//        Ordenador[] ords = new Ordenador[20];
//        ords[0] = new Ordenador();
//        System.out.println(ords[0].toString());
//        System.out.println(ords[1].toString());
        Aula a212 = new Aula("212");
        Ordenador o = new Ordenador(32, "i14", 35);
        if (a212.addOrdenador(o)){
            System.out.println("Inserción conseguida.");
        }
        else {
            System.out.println("Aula completa.");
        }
        o = new Ordenador(128, "i36", 512);
        a212.addOrdenador(o);
        System.out.println("Mi aula tiene: " + a212.getCuantos() + " ordenadores.");
        System.out.println(a212.toString());
        if (a212.removeOrdenador("108")){
            System.out.println("Ordenador borrado correctamente.");
        }
        else {
            System.out.println("Fallo al borrar, no encontrado");
        }
    }

}
