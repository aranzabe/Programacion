/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio4;

/**
 * 
 * @author faranzabe
 */
public class Ordenador {
    private int RAM;
    private String procesador;
    private String SO;
    private String numSerie;
    private int HD;

    public Ordenador() {
        this.procesador = "";
        this.SO = "";
        this.numSerie = "";
    }

    public Ordenador(int RAM, String procesador, int HD) {
        this.RAM = RAM;
        this.procesador = procesador;
        this.HD = HD;
        this.SO = "";
        this.numSerie = "";
    }

    public Ordenador(int RAM, String procesador, String SO, String numSerie, int HD) {
        this.RAM = RAM;
        this.procesador = procesador;
        this.SO = SO;
        this.numSerie = numSerie;
        this.HD = HD;
    }
    
    

    public int getRAM() {
        return RAM;
    }

    public void setRAM(int RAM) {
        this.RAM = RAM;
    }

    public String getProcesador() {
        return procesador;
    }

    public void setProcesador(String procesador) {
        this.procesador = procesador;
    }

    public String getSO() {
        return SO;
    }

    public void setSO(String SO) {
        this.SO = SO;
    }

    public String getNumSerie() {
        return numSerie;
    }

    public void setNumSerie(String numSerie) {
        this.numSerie = numSerie;
    }

    public int getHD() {
        return HD;
    }

    public void setHD(int HD) {
        this.HD = HD;
    }

    
    @Override
    public String toString() {
        return "Ordenador{" + "RAM=" + RAM + ", procesador=" + procesador + ", SO=" + SO + ", numSerie=" + numSerie + ", HD=" + HD + '}';
    }

    
    
}
