/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Juego;

import Principal.Jugador;

/**
 *
 * @author faranzabe
 */
public class Tablero {

    private Casilla tab[][];

    public Tablero() {
        tab = new Casilla[3][4];
    }

    public Tablero(int f, int c) {
        tab = new Casilla[f][c];
    }

    public int getFilas() {
        return this.tab.length;
    }

    public int getCols() {
        return this.tab[0].length;
    }

    public boolean addCasilla(int f, int c, Casilla cas) {
        boolean conseguido = false;

        if (f >= 0 && f < this.tab.length && c >= 0 && c < this.tab[0].length) {
            if (this.tab[f][c] == null) {
                this.tab[f][c] = cas;
                conseguido = true;
            }
        }

        return conseguido;
    }

    @Override
    public String toString() {
        String cad = "";
        for (int i = 0; i < this.tab.length; i++) {
            for (int j = 0; j < this.tab[0].length; j++) {
                cad += this.tab[i][j] + "  ";
            }
            cad += "\n";
        }
        return cad;
    }

    public boolean quedanCasillasRepartir() {
        boolean quedan = false;
        for (int i = 0; i < this.tab.length; i++) {
            for (int j = 0; j < this.tab[0].length; j++) {
                if (this.tab[i][j].getPropietario().isEmpty()) {// if (this.tab[i][j].getPropietario().equals(""))
                    quedan = true;
                }
            }
        }
        return quedan;
    }

    public boolean estaOcupada(int f, int c) {
        boolean loEsta = true;
        if (this.tab[f][c].getPropietario().isEmpty()) {
            loEsta = false;
        }
        return loEsta;
//        return !this.tab[f][c].getPropietario().isEmpty();
    }

    public void ocuparCasilla(int f, int c, String propietario) {
        this.tab[f][c].setPropietario(propietario);
    }

    public void sumarPuntos(Jugador jugador, int valor) {
        for (int i = 0; i < this.tab.length; i++) {
            for (int j = 0; j < this.tab[0].length; j++) {
                if (this.tab[i][j].getNum() == valor && this.tab[i][j].getPropietario().equals(jugador.getNombre())) {
                    switch (this.tab[i][j].getRecurso()) {
                        case "Trigo":
                            jugador.sumarTrigo();
                            break;
                        case "Madera":
                            jugador.sumarMadera();
                            break;
                        case "Carbon":
                            jugador.sumarCarbon();
                    }
                }
            }
        }
    }

    public Casilla getCasilla(int i, int j) {
        return this.tab[i][j];
    }
}
