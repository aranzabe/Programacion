/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Juego;

/**
 *
 * @author faranzabe
 */
public class FactoriaJuego {
    public static Casilla factoriaCasilla() {
        Casilla c = new Casilla();
        int alea = (int) (Math.random() * 3);
        String recurso = "";
        switch (alea) {
            case 0:
                recurso = "Trigo";
                break;
            case 1:
                recurso = "Madera";
                break;
            case 2:
                recurso = "Carbón";
        }
        alea = (int) (Math.random() * 6) + 1;
        c.setRecurso(recurso);
        c.setNum(alea);
        return c;
    }

    public static Tablero factoriaTablero() {
        Tablero t = new Tablero();
        for (int i = 0; i < t.getFilas(); i++) {
            for (int j = 0; j < t.getCols(); j++) {
                t.addCasilla(i, j, factoriaCasilla());
            }
        }
        return t;
    }

    public static Tablero factoriaTablero(int filas, int cols) {
        Tablero t = new Tablero(filas, cols);
        for (int i = 0; i < t.getFilas(); i++) {
            for (int j = 0; j < t.getCols(); j++) {
                t.addCasilla(i, j, factoriaCasilla());
            }
        }
        return t;
    }

}
