/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Juego;

/**
 *
 * @author faranzabe
 */
public class Casilla {

    private String recurso;
    private String propietario;
    private int num;

    public Casilla() {
        this.propietario = "";
        this.recurso = "";
        this.num = 0;
    }

    public Casilla(String recurso, int num) {
        this.recurso = recurso;
        this.num = num;
        this.propietario = "";
    }

    public String getRecurso() {
        return recurso;
    }

    public void setRecurso(String recurso) {
        this.recurso = recurso;
    }

    public String getPropietario() {
        return propietario;
    }

    public void setPropietario(String propietario) {
        this.propietario = propietario;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    @Override
    public String toString() {
        return "Casilla{" + "recurso=" + recurso + ", propietario=" + propietario + ", num=" + num + '}';
    }



}
