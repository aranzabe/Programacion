/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Principal;

import Juego.*;
import java.util.Scanner;

/**
 *
 * @author faranzabe
 */
public class CatanClase {

    public static void sumarPuntos(Tablero t, Jugador jugador, int valor) {
        Casilla cas = null;
        for (int i = 0; i < t.getFilas(); i++) {
            for (int j = 0; j < t.getCols(); j++) {
                cas = t.getCasilla(i, j);
                if (cas.getNum() == valor && cas.getPropietario().equals(jugador.getNombre())) {
                    switch (cas.getRecurso()) {
                        case "Trigo":
                            jugador.setTrigo(jugador.getTrigo() + 1);
                            break;
                        case "Madera":
                            jugador.sumarMadera();
                            break;
                        case "Carbon":
                            jugador.sumarCarbon();
                    }
                }
            }
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        Dado d = new Dado();
        Scanner sc = new Scanner(System.in);
        //Fase 1: Inicialización.
        Tablero t = FactoriaJuego.factoriaTablero();
        System.out.println(t.toString());
        Jugador m = FactoriaJugador.factoriaJugador("Máquina");
        Jugador h = FactoriaJugador.factoriaJugador("Humano");
        System.out.println(m);
        System.out.println(h);

        //Fase 2: Reparto de las casillas.
        int f, c;
        boolean conseguido;
        while (t.quedanCasillasRepartir()) {
            //Elige la máquina.
            conseguido = false;
            do {
                f = (int) (Math.random() * t.getFilas());
                c = (int) (Math.random() * t.getCols());
                if (!t.estaOcupada(f, c)) {
                    t.ocuparCasilla(f, c, "Maquina");
                    conseguido = true;
                }
            } while (!conseguido);
            System.out.println(t.toString());

            //Elige el humano.
            conseguido = false;
            do {
                System.out.print("Fila elegida: ");
                f = sc.nextInt();
                System.out.print("Columna elegida: ");
                c = sc.nextInt();
                if (!t.estaOcupada(f, c)) {
                    t.ocuparCasilla(f, c, "Humano");
                    conseguido = true;
                } else {
                    System.out.println("Elige otra, está ocupada.");
                }
            } while (!conseguido);
            System.out.println(t.toString());

        }

        //Fase 3: El juego.
        do {
            System.out.println("Se lanza el dado...");
            d.lanzarDado();
            System.out.println("Ha salido un " + d.getValor());
            t.sumarPuntos(h, d.getValor());
            t.sumarPuntos(m, d.getValor());
            System.out.println(t);
            Thread.sleep(1000);
        //} while (!h.comprobarVictoria() || !m.comprobarVictoria());
        }while((h.getTrigo() >= 20 && h.getMadera() >= 20 && h.getCarbon() >= 20) ||
               (m.getTrigo() >= 20 && m.getMadera() >= 20 && m.getCarbon() >= 20));
    }

}
