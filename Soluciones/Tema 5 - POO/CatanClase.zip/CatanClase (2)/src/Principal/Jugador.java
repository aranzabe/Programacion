/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Principal;

/**
 *
 * @author faranzabe
 */
public class Jugador {
    private String nombre;
    private int madera;
    private int carbon;
    private int trigo;

    public Jugador() {
        this.nombre = "";
    }

    public Jugador(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getMadera() {
        return madera;
    }

    public void setMadera(int madera) {
        this.madera = madera;
    }

    public int getCarbon() {
        return carbon;
    }

    public void setCarbon(int carbon) {
        this.carbon = carbon;
    }

    public int getTrigo() {
        return trigo;
    }

    public void setTrigo(int trigo) {
        this.trigo = trigo;
    }

    @Override
    public String toString() {
        return "Jugador{" + "nombre=" + nombre + ", madera=" + madera + ", carbon=" + carbon + ", trigo=" + trigo + '}';
    }
    
    public void sumarMadera(){
        this.madera++;
    }
    
    public void sumarTrigo(){
        this.trigo++;
    }
    
    public void sumarCarbon(){
        this.carbon++;
    }
    
    
    
    public boolean comprobarVictoria(){
        boolean win = false;
        
        if (this.trigo >= 20 && this.madera >= 20 && this.carbon >= 20){
            win = true;
        }
        return win;
    }
}
