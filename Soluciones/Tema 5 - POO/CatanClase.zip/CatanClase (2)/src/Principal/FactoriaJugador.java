/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Principal;

import java.util.Scanner;

/**
 *
 * @author faranzabe
 */
public class FactoriaJugador {
    
    
    public static Jugador factoriaJugadorAleatoria() {
        Jugador j = new Jugador();
        int alea = (int) (Math.random() * 2);
        if (alea == 0) {
            j.setNombre("Humano");
        } else {
            j.setNombre("Máquina");
        }
        return j;
    }

    public static Jugador factoriaJugador() {
        Scanner sc = new Scanner(System.in);
        Jugador j = new Jugador();
        System.out.println("Nombre del jugador: ");
        j.setNombre(sc.nextLine());
        return j;
    }

    public static Jugador factoriaJugador(String nombre) {
        Jugador j = new Jugador();
        j.setNombre(nombre);
        return j;
    }

}
