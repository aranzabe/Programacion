/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_2017oblivion;

/**
 *
 * @author danie
 */
public class Factoria {
    public static Planeta factoriaPlaneta(int f, int c){
        Planeta p;
        Cuadrante cuad[][] = new Cuadrante[f][c];
        
        for (int i = 0; i < f; i++) {
            for (int j = 0; j < c; j++) {
                cuad[i][j] = new Cuadrante("Jack" + i + "" + j, "Vika" + i + "" + j);
            }
        }
        p = new Planeta(cuad);
        return p;
    }
    
    public static Planeta factoriaPlaneta2(int f, int c, Estacion t){
        Planeta p = new Planeta(f,c);
        
        for (int i = 0; i < f; i++) {
            for (int j = 0; j < c; j++) {
                Cuadrante cuad = new Cuadrante("Jack" + i + "" + j, "Vika" + i + "" + j);
                int alea = (int) (Math.random()* 3)+1;
                for (int k = 0; k < alea; k++) {
                    cuad.addDrones(t.getDron());
                }
                p.addCuadrante(i,j,cuad);
            }
        }
        return p;
    }
    
    public static Dron factoriaDron(){
        Dron d = new Dron();
        return d;
    }
    
    public static Cuadrante factoriaCuadrante(String nombreTecnico, String nombreSupervisora){
        Cuadrante c = new Cuadrante(nombreTecnico,nombreSupervisora);
        return c;
    }
    
    /**
     * 
     * @param nombreTecnico
     * @param nombreSupervisora
     * @param p
     * @return 
     */
    public static Cuadrante factoriaCuadrante(String nombreTecnico, String nombreSupervisora, Planeta p){
        Cuadrante c = new Cuadrante("Jack18","Vicka18");
        return c;
    }
    
    public static Estacion factoriaEstacion(){
        Estacion tet = new Estacion();
        for (int i = 0; i < tet.getTamEstacion(); i++) {
            tet.addDron(factoriaDron());
        }
        return tet;
    }
}
