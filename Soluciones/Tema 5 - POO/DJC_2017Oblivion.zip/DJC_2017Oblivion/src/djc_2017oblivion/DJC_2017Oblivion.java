/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_2017oblivion;

/**
 *
 * @author danie
 */
public class DJC_2017Oblivion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Estacion tet = Factoria.factoriaEstacion();
        System.out.println(tet);
        Planeta p = Factoria.factoriaPlaneta2(3, 3, tet);
        System.out.println(p);
        System.out.println(tet);
        
        
        
        //Se rellena el almacén de drones del Tet
        //Se rellenan los cuadrantes del planeta de drones, sacándolos del Tet
//        for (int t = 0; t < 180; t++) {
//            if (t % 4 == 0){
//                //Se recorre cada cuadrante y se estropean drones (20%)
//            }
//            if (t % 10 == 0){
//                //Se recorren todos los cuadrantes buscando drones estropeados
//                    //Se envían órdenes de reparación
//                    //Se envían órdenes de reconocimiento (5-10)
//            }
//            if (t % 20 == 0){
//                //Cada sector resuelve las órdenes sin atender
//                    //Reparación:
//                        //Accede al dron fallido
//                            //50% lo repara --> dron.setEstaOperativo(true)
//                            //50% no lo repara --> se envía un dron del Tet (si hay)
//                    //Observación:
//                        //hallazgo = aleaHallazgo();
//                            //Math.random() * 3 --> switch
//                //orden.setEstaCompletada(true);
//            }
//        }
        //Mostrar información de todo:
            //Sectores
            //Órdenes
            //Estado de drones
    }
    
}
