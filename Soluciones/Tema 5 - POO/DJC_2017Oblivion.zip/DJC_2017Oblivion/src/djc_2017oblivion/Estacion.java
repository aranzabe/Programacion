/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_2017oblivion;

/**
 *
 * @author danie
 */
public class Estacion {

    private String nombre;
    private Dron almacenDrones[];
    private Reparacion ordenes[];

    public Estacion() {
        this.nombre = "Tet";
        this.almacenDrones = new Dron[50];
    }

    public int getTamEstacion() {
        return this.almacenDrones.length;
    }

    public boolean addDron(Dron a) {
        int i = 0;
        boolean insertado = false;
        while (i < this.almacenDrones.length && !insertado) {
            if (this.almacenDrones[i] == null) {
                this.almacenDrones[i] = a;
                insertado = true;
            }
            i++;
        }
        return insertado;
    }

    @Override
    public String toString() {
        String cad = "Estacion: " + nombre + "\n";
        for (int i = 0; i < this.almacenDrones.length; i++) {
            if (this.almacenDrones[i] != null) {
                cad += this.almacenDrones[i].toString() + "\n";
            }
        }
        return cad;
    }

    public Dron getDron() {
        boolean encontrado = false;
        Dron d = null;
        int i = 0;
        while (i < this.almacenDrones.length && !encontrado) {
            if (this.almacenDrones[i] != null) {
                encontrado = true;
                d = this.almacenDrones[i];
                this.almacenDrones[i] = null;
            }
            i++;
        }
        return d;
    }

}
