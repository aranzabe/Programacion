/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_2017oblivion;

/**
 *
 * @author danie
 */
public class Reparacion {
    private String fecha;
    private boolean estaCumplida;
    private int destino[];
    
    private int numDron;
    private boolean estados[]; //2 posiciones 0 -> antes; 1 -> después.
}
