/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_2017oblivion;

/**
 *
 * @author danie
 */
public class Planeta {
    private String nombre;
    private Cuadrante cuadrantes[][];
    
    public Planeta(){
        this.nombre = "La Tierra";
    }
    
    public Planeta(Cuadrante cuadrantes[][]){
        this.nombre = "La Tierra";
        this.cuadrantes = cuadrantes;
    }

    public Planeta(int f, int c) {
        this.nombre = "La Tierra";
        this.cuadrantes = new Cuadrante[f][c];
    }

    public String getNombre() {
        return nombre;
    }

    public Cuadrante[][] getCuadrantes() {
        return cuadrantes;
    }
    
    public int[] getDimension(){
        int dim[] = new int[2];
        
        dim[0] = this.cuadrantes.length;
        dim[1] = this.cuadrantes[0].length;
        return dim;
    }

    @Override
    public String toString() {
        String cad = "Planeta " + this.nombre + ":\n";
        
        for (int i = 0; i < this.cuadrantes.length; i++) {
            for (int j = 0; j < this.cuadrantes[i].length; j++) {
                cad += "----------------------------\n";
                cad += "Cuadrante (" + i + "," + j + ")\n"
                        + this.cuadrantes[i][j].toString() + "";
                cad += "----------------------------\n";
            }
            cad += "\n";
        }
        return cad;
    }

    public void addCuadrante(int i, int j, Cuadrante cuadrante) {
        this.cuadrantes[i][j] = cuadrante;
    }
    
    
    
}
