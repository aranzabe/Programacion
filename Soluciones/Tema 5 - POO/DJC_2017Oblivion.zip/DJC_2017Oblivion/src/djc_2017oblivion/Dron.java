/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_2017oblivion;

/**
 *
 * @author danie
 */
public class Dron {
    private static int cod;
    private int numDron;
    private boolean estaOperativo;
    
    static {
        cod = 0;
    }
    
    public Dron(){
        this.numDron = cod;
        cod++;
        this.estaOperativo = true;
    }
    
    public Dron(int numDron){
        this.numDron = numDron;
        this.estaOperativo = true;
    }

    @Override
    public String toString() {
        return "Dron{" + "numDron=" + numDron + ", estaOperativo=" + estaOperativo + '}';
    }
    
}
