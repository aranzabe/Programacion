/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_2017oblivion;

/**
 *
 * @author faranzabe
 */
public class Reconocimiento {
    private String fecha;
    private boolean estaCumplida;
    private int destino[];
    
    private int area;
    private String encontrado;
}
