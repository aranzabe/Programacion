/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_2017oblivion;

/**
 *
 * @author danie
 */
public class Cuadrante {

    private Dron drones[];
    private Reparacion ordenes[];
    private Reconocimiento reconocimiento[];
    private String jack;
    private String vika;

    public Cuadrante() {
        this.drones = new Dron[3];
        this.ordenes = new Reparacion[1];
        this.jack = "Jack";
        this.vika = "Vika";
    }

    public Cuadrante(String jack, String vika) {
        this.drones = new Dron[3];
        this.ordenes = new Reparacion[1];
        this.jack = jack;
        this.vika = vika;
    }

    @Override
    public String toString() {
        String cad = "";
        cad = "Drones: " + "\n";
        for (int i = 0; i < this.drones.length; i++) {
            if (this.drones[i] != null) {
                cad += this.drones[i].toString() + "\n";
            }
        }
        cad += "Supervisores: " + this.jack + " y " + this.vika + "\n";

        return cad;
    }

    public Dron[] getDrones() {
        return drones;
    }

    public Reparacion[] getOrdenes() {
        return ordenes;
    }

    public boolean addDrones(Dron d) {
        boolean insertado = false;
        int i = 0;

        while (i < this.drones.length && !insertado) {
            if (this.drones[i] == null) {
                this.drones[i] = d;
                insertado = true;
            }
            i++;
        }
        return insertado;
    }

}
