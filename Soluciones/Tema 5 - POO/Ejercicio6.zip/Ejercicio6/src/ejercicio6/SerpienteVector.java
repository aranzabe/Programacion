/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio6;

/**
 *
 * @author laura
 */
public class SerpienteVector {

    private char[] anillas;
    private int tam;
    private int edad;

    public SerpienteVector() {
        this.tam = 1;
        this.anillas = new char[this.tam];
        this.anillas[0] = this.generarAnilla();
        this.edad = 0;
    }

    public int getAños() {
        return this.edad;
    }

    public void crecer() {
        this.tam++;
        char[] anillasNuevo = new char[tam];
        for (int i = 0; i < this.anillas.length; i++) {
            anillasNuevo[i] = this.anillas[i];
        }
        anillasNuevo[anillasNuevo.length - 1] = this.generarAnilla();
        this.anillas = anillasNuevo;
        this.aumentarAños();
    }

    public boolean mudar() {
        boolean conseguido = true;
        if (this.anillas.length > 0) {
            for (int i = 0; i < this.anillas.length; i++) {
                this.anillas[i] = generarAnilla();
            }
            this.aumentarAños();
        } else {
            conseguido = false;
        }
        return conseguido;
    }

    public boolean decrecer() {
        boolean conseguido = true;
        if (this.anillas.length > 0) {
            this.tam--;
            char[] anillasNuevo = new char[tam];
            for (int i = 0; i < anillasNuevo.length; i++) {
                anillasNuevo[i] = this.anillas[i];
            }
            this.aumentarAños();
            this.anillas = anillasNuevo;
        } else {
            conseguido = false;
        }
        return conseguido;
    }

    public void aumentarAños() {
        this.edad++;
    }

    @Override
    public String toString() {
        String cad = "";

        cad += "La serpiente tiene " + this.edad + " años y " + this.tam + " anillas:\n";
        for (int i = 0; i < this.anillas.length; i++) {
            cad += this.anillas[i];
        }
        return cad;
    }

    private char generarAnilla() {
        int random;
        char anilla = '0';

        random = (int) (Math.random() * 3);
        switch (random) {
            case 0:
                anilla = 'r';
                break;
            case 1:
                anilla = 'v';
                break;
            case 2:
                anilla = 'a';
        }
        return anilla;
    }

    public void matarSerpiente() {
        this.tam = 0;
    }

    public boolean isEstaViva() {
        return this.tam > 0;
    }

}
