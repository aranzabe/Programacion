/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio6;

/**
 *
 * @author laura
 */
public class Ejercicio6 {

    public static boolean ataqueMangosta() {
        int alea = (int) (Math.random()*100);
        return alea <= 10;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SerpienteVector s = new SerpienteVector();
        boolean muere = false;
        int alea;

        
        //----------------------------------------------------1ºFASE
        while (s.isEstaViva()) {
            if (s.getAños() < 10) {
                alea = (int) (Math.random() * 100);
                if (alea <= 80) {
                    s.crecer();
                    System.out.println("La serpiente crece, se añade una anilla, la situacion es esta: .");
                } else {
                    s.mudar();
                    System.out.println("La serpiente ha mudado.");
                }
            }
            //----------------------------------------------------2ºFASE       
            if (s.getAños() >= 10) {
                alea = (int) (Math.random() * 100);
                if (alea <= 90) {
                    s.decrecer();
                    System.out.println("La serpiente crece, se añade una anilla, la situacion es esta: .");
                } else {
                    s.mudar();
                    System.out.println("La serpiente ha mudado.");
                }
            }
            System.out.println(s);
            muere = ataqueMangosta();
            if (muere){
                s.matarSerpiente();
            }
        }

        if (muere) {
            System.out.println("La serpiente ha muerto por una mangosta");
        } else {
            System.out.println("La serpiente ha muerto por que se ha quedado sin anillas");
        }

    }

}
