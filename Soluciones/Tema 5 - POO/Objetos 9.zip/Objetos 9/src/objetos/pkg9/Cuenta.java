/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objetos.pkg9;

/**
 *
 * @author laura
 */
public class Cuenta {

    private float Saldo;
    private String nCuenta;
    private Titular titulares[];

    public Cuenta() {
        this.Saldo = 0;
        this.titulares = new Titular[3];
    }

    //Ponemos t por que le vamos a pasar un titular, es un vector, da igual el nombre que le pongamos al titular
    public Cuenta(float Saldo, Titular t) {
        this.Saldo = 0;
        this.titulares = new Titular[3];
        //Asignamos en la posicion 0 el titular t
        this.titulares[0] = t;
    }

    public Cuenta(String nCuenta, Titular t) {
        this.nCuenta = nCuenta;
        this.titulares = new Titular[3];
        this.titulares[0] = t;
    }

    public float getSaldo() {
        return Saldo;
    }

    public String getnCuenta() {
        return nCuenta;
    }

    public Titular[] getTitulares() {
        return titulares;
    }

    //--------------------------------------AÑADIR TITULAR
    public boolean addTitular(Titular t) {
        boolean añadido = false;
        int i = 0;

        while (i < this.titulares.length && !añadido) {
            if (titulares[i] == null) {
                titulares[i] = t;
                añadido = true;
            }
            i++;
        }
        return añadido;
    }

    public int getCuantosTitulares() {
        int cont = 0;
        for (int j = 0; j < this.titulares.length; j++) {
            if (this.titulares[j] != null) {
                cont++;
            }
        }
        return cont;
    }

//--------------------------------------BORRAR TITULAR
    /**
     * Este método sirve para borrar a un titular de la cuenta, pasando el DNI
     * del titular.
     *
     * @param DNI
     * @return Este método devolverá: 3 si solo queda un titular, 2 si no lo
     * encuentra y 1 si lo borra.
     */
    public int deleteTitular(String DNI) {
        boolean borrado = false;
        int quehapasado = 0;
        int i = 0;
        int cont = 0;

        cont = this.getCuantosTitulares();
        if (cont == 1) {
            quehapasado = 3;
        } else {
            while (i < this.titulares.length && !borrado) {
                if (this.titulares[i] != null) {
                    //if (this.titulares[i].getDNI().equals(DNI)) {
                    if (this.titulares[i].equals(DNI)) {
                        this.titulares[i] = null;
                        borrado = true;
                        quehapasado = 1;
                    }
                    i++;
                }
            }
            if (!borrado) {
                quehapasado = 2;
            }
        }
        return quehapasado;
    }

    @Override
    public String toString() {
        //Esto es un modulo que va a devolver lo que tu quieres mostrar al exterior, la estructura, por eso declaramos la variable dev, es la que iremos concatenando con lo que pasemos.
        // "\n" --> Esto causara un salto de linea
        String dev = "";
        dev = dev + "Cuenta: " + this.nCuenta + "\n";
        dev = dev + "Saldo: " + this.Saldo + "\n";
        dev = dev + "Titulares: \n";

        for (int i = 0; i < this.titulares.length; i++) {
            if (this.titulares[i] != null) {
                dev = dev + titulares[i].toString() + "/";
            }
        }

        return dev;
    }

    
    public void ingresarDinero(int dinero) {
        this.Saldo += dinero;
    }
    
    public boolean retirarDinero(int dinero){
        boolean conseguido=false;
    }

}
