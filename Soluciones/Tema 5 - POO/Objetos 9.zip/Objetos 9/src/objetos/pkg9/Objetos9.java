/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objetos.pkg9;

import java.util.Scanner;

/**
 *
 * @author laura
 */
public class Objetos9 {

    //---------------------------------------FACTORIA DE TITULAR--------------------------------------------------------------------------------
    //---------Pedimos los datos por teclado, a esto lo llamamos Factoria, ya no es public static void, vamos a manejar y devolver nuestro propio objeto Titular
    //asi que es public static Titular
    public static Titular factoriaTitularTeclado() {
        String DNI;
        String nombre;
        String telefono;
        Scanner sc = new Scanner(System.in);

        System.out.print("Dame el DNI: ");
        //De esta manera pediremos los datos para nuestra clase, podriamos hacerlo de otro modo, pero no he declarado el set para modificar en la clase.
        DNI = sc.nextLine();
        System.out.print("Dame el nombre: ");
        nombre = sc.nextLine();
        System.out.print("Dame el Telefono: ");
        telefono = sc.nextLine();

        //llamaremos a nuestro constructor que hemos hecho para guardar los datos depositados arriba
        Titular t = new Titular(DNI, nombre, telefono);

        return t;
    }

    public static Titular factoriaTitularAleatorio() {

        int alea;
        String nombre = "";
        String DNI;
        String telefono;

        alea = (int) (Math.random() * 5);

        switch (alea) {
            case 0:
                nombre = "Peter";
                break;
            case 1:
                nombre = "Belinda";
                break;
            case 2:
                nombre = "Soponcio";
                break;
            case 3:
                nombre = "Lorenzo";
                break;
            case 4:
                nombre = "Maria";
                break;
            case 5:
                nombre = "Nela";
        }

        alea = (int) (Math.random() * 60000);
        // valueOf(area) sirve para pasar alea a cadena, por eso entre parentesis esta (alea)
        DNI = String.valueOf(alea);
        telefono = String.valueOf(alea);

        Titular t = new Titular(DNI, nombre, telefono);

        return t;
    }

    //---------------------------------------FACTORIA DE CUENTA--------------------------------------------------------------------------------
    public static Cuenta FactoriaCuentaTeclado() {

        String nCuenta;
        Scanner sc = new Scanner(System.in);

        System.out.println("Dame el numero de cuenta");
        nCuenta = sc.nextLine();
        //Para asignarle  al numero de cuenta un titular, tendras primero que llamar a ese titular....
        Titular t = factoriaTitularAleatorio();
        Cuenta c = new Cuenta(nCuenta, t);

        return c;
    }

    public static Cuenta FactoriaCuentaAleatoria() {

        String nCuenta;
        int alea;

        alea = (int) (Math.random() * 1000000000);
        //Acuerdate de transformar el int en un string...
        nCuenta = String.valueOf(alea);
        //Acuerdate de llamar al titular creado....
        Titular t = factoriaTitularAleatorio();
        Cuenta c = new Cuenta(nCuenta, t);

        return c;
    }

    //---------------------------------------ALGORITMO PRINCIPAL--------------------------------------------------------------------------------
    public static void main(String[] args) {
        Titular t;
        Cuenta c;
        int qhp, opc = 0;
        String cadDNI;
        Scanner sc = new Scanner(System.in);

//--------------------------------USUARIO------------------------------------
        //t = factoriaTitularTeclado();
        // t = factoriaTitularAleatorio();
        // System.out.println(t.toString());
//-------------------------------CUENTA --------------------------------
        //c=FactoriaCuentaTeclado();
        c = FactoriaCuentaAleatoria();
        System.out.println("Estado inicial de la cuenta.");
        System.out.println(c.toString());
        System.out.println("--------------------------------");

        do {
            System.out.println("1.- Mostrar información de la cuenta.");
            System.out.println("2.- Añadir un titular nuevo.");
            System.out.println("3.- Borrar por DNI.");
            System.out.println("4.- Modificar el DNI del cliente.");
            System.out.println("5.- Consultar saldo.");
            System.out.println("6.- Ingresar dinero.");
            System.out.println("7.- Retirar dinero.");
            System.out.println("8.- Salir.");
            opc = sc.nextInt();
            switch (opc) {
                case 1:
                    System.out.println(c.toString());
                    break;
                case 2:
                    //t = factoriaTitularAleatorio();
                    if (c.getCuantosTitulares() == 3) {
                        System.out.println("No se admiten más titulares.");
                    } else {
                        t = factoriaTitularTeclado();
                        if (c.addTitular(t)) {
                            System.out.println("Se ha añadido correctamente");
                        } else {
                            System.out.println("No se ha podido añadir");
                        }
                    }
                    break;
                case 3:
                    System.out.println("Dame el DNI del titular a borrar: ");
                    cadDNI = sc.nextLine();
                    qhp = c.deleteTitular(cadDNI);
                    if (qhp == 1) {
                        System.out.println("Se ha borrado");
                    }
                    if (qhp == 2) {
                        System.out.println("No se ha podido borrar este usuario por que no existe");
                    }
                    if (qhp == 3) {
                        System.out.println("Solo existe un titular en esta cuenta, no lo puedo borrar");
                    }
                    break;
            }//Fin del switch.
        } while (opc != 8);

        /*
//---------------------------AÑADIR TITULAR----------------------------
        t = factoriaTitularAleatorio();
        if (c.addTitular(t)) {
            System.out.println("Se ha añadido correctamente");
        } else {
            System.out.println("No se ha podido añadir");
        }
        System.out.println("Estado después de añadir a " + t.toString());
        System.out.println(c.toString());
        System.out.println("--------------------------------");
//----------------------------------BORRAR TITULAR----------------------------   
        qhp = c.deleteTitular(t.getDNI());

        if (qhp == 1) {
            System.out.println("Se ha borrado");
        }
        if (qhp == 2) {
            System.out.println("No se ha podido borrar este usuario por que no existe");
        }
        if (qhp == 3) {
            System.out.println("Solo existe esta cuenta, no la puedo borrar");
        }
        System.out.println(c.toString());
        
        System.out.println("A quien quieres borrar: ");
        cadDNI = sc.nextLine();
        qhp = c.deleteTitular(t.getDNI());
        if (qhp == 1) {
            System.out.println("Se ha borrado");
        }
        if (qhp == 2) {
            System.out.println("No se ha podido borrar este usuario por que no existe");
        }
        if (qhp == 3) {
            System.out.println("Solo existe un titular en esta cuenta, no lo puedo borrar");
        }
        System.out.println(c.toString());
         */
    }

}
