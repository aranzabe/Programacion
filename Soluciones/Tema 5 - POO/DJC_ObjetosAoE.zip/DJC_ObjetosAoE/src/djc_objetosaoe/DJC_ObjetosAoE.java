/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_objetosaoe;

/**
 *
 * @author danie
 */
public class DJC_ObjetosAoE {

    /**
     * Este método usa diferentes probabilidades para asignar diferentes valores
     * a un código
     *
     * @return 0: si no se añade ningún aldeano, 1: si se añade un aldeano
     * español, 2: si se añade un aldeano bizantino
     */
    public static int asignacionAldeano() {
        int cod = 0;
        int alea = (int) (Math.random() * 100);
        if (alea < 40) {
            cod = 1;
        } else if (alea < 60) {
            cod = 2;
        }
        return cod;
    }

    /**
     * Este método resta un recurso de la mina y lo suma al almacén
     * correspondiente
     *
     * @param m la mina en cuestión
     * @param civ la civilización a la que pertenece cada minero
     */
    public static int extraerRecursos(Mina m, Civilizacion civ) {
        int recursosExtraidos = 0;
        for (int i = 0; i < m.getTamMina(); i++) {
            if (m.getMineros()[i] != null) {
                if (m.getMineros()[i].getCiv().getNombre().equals(civ.getNombre())) {
                    if (m.hayMinerales()) {
                        m.setItems(m.getItems() - 1);
                        switch (m.getTipo()) {
                            case "ORO":
                                civ.setAlmacenOro(civ.getAlmacenOro() + 1);
                                break;
                            case "PIEDRA":
                                civ.setAlmacenPiedra(civ.getAlmacenPiedra() + 1);
                        }
                        recursosExtraidos++;
                    }
                }
            }
        }
        return recursosExtraidos;
    }

    public static boolean wololo(Mina m, Civilizacion esp, Civilizacion biz) {
        boolean conseguido = false;

        while (!conseguido && m.cuantosMineros(esp) > 0) {
            int alea = (int) (Math.random() * m.getTamMina());
            if (m.getMineros()[alea] != null && m.getMineros()[alea].getCiv().equals(esp)){
                m.getMineros()[alea].setCiv(biz);
                conseguido = true;
            }
        }
        return conseguido;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        int t;
        int codAld;
        Civilizacion esp = Factoria.factoriaCivilizacion(1);
        Civilizacion biz = Factoria.factoriaCivilizacion(2);
        Aldeano ald;
        Mina mina = new Mina();
        System.out.println(esp);
        System.out.println(biz);

        for (t = 0; t < 60; t++) {
            //Los aldeanos se unen a la mina
            if (t % 2 == 0) {
                codAld = asignacionAldeano();
                switch (codAld) {
                    case 1:
                        ald = Factoria.factoriaAldeano(200, esp);
                        esp.crecePoblacion(ald);
                        mina.creceMina(ald);
                        System.out.println("Se ha añadido un aldeano del Imperio Español a la mina");
                        break;
                    case 2:
                        ald = Factoria.factoriaAldeano(250, biz);
                        biz.crecePoblacion(ald);
                        mina.creceMina(ald);
                        System.out.println("Se ha añadido un aldeano del Imperio Bizantino a la mina");
                }
            }
            
            //Los aldeanos pican recursos
            System.out.println("El Imperio Español ha extraído " + extraerRecursos(mina, esp) + " items de " + mina.getTipo());
            System.out.println("El Imperio Bizantino ha extraído " + extraerRecursos(mina, biz) + " items de " + mina.getTipo());
            
            //Ataque del cura bizantino
            if (t % 5 == 0) {
                if (wololo(mina, esp, biz)){
                    System.out.println("Un cura bizantino ha convertido a uno de los mineros españoles");
                }
            }
            System.out.println("Estado de la partida:");
            System.out.println(esp);
            System.out.println(biz);
            Thread.sleep(1000);
        }
        System.out.println("Fin de la simulación.");
    }
}
