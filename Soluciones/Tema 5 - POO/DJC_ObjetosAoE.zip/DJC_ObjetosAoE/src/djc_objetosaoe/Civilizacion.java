/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_objetosaoe;

/**
 *
 * @author danie
 */
public class Civilizacion {

    private String nombre;
    private String monarca;
    private int almacenOro;
    private int almacenPiedra;
    private Aldeano poblacion[];

    public Civilizacion() {
        this.nombre = "";
        this.monarca = "";
        this.almacenOro = 0;
        this.almacenPiedra = 0;
        this.poblacion = null;
    }

    public Civilizacion(String nombre, String monarca) {
        this.nombre = nombre;
        this.monarca = monarca;
        this.almacenOro = 0;
        this.almacenPiedra = 0;
        this.poblacion = new Aldeano[1];
    }

    public int getAlmacenOro() {
        return almacenOro;
    }

    public void setAlmacenOro(int almacenOro) {
        this.almacenOro = almacenOro;
    }

    public int getAlmacenPiedra() {
        return almacenPiedra;
    }

    public void setAlmacenPiedra(int almacenPiedra) {
        this.almacenPiedra = almacenPiedra;
    }

    public String getNombre() {
        return nombre;
    }
    
    public int getTamCiv(){
        return this.poblacion.length;
    }

    @Override
    public String toString() {
        String cad = "";

        cad += this.nombre + ", gobernado con mano de hierro por " + this.monarca + ":\n"
                + "   Almacén de oro: " + this.almacenOro
                + "\n   Almacén de piedra: " + this.almacenPiedra + "\n   "
                + "Aldeanos: " + this.cuantosAldeanos();
        return cad;
    }

    public Aldeano[] getPoblacion() {
        return poblacion;
    }

    /**
     * Este método redimensiona el vector de población y añade un aldeano en la
     * última posición
     *
     * @param ald
     */
    public void crecePoblacion(Aldeano ald) {
        Aldeano nuevoVector[] = new Aldeano[this.poblacion.length + 1];
        for (int i = 0; i < this.poblacion.length; i++) {
            nuevoVector[i] = this.poblacion[i];
        }
        nuevoVector[this.poblacion.length] = ald;
        this.poblacion = nuevoVector;
    }

    /**
     * Este método cuenta el número de aldeanos que hay en la civilización
     * @return el número de posiciones del vector diferentes de null
     */
    public int cuantosAldeanos() {
        int cont = 0;

        for (int i = 0; i < this.poblacion.length; i++) {
            if (this.poblacion[i] != null) {
                cont++;
            }
        }
        return cont;
    }
}
