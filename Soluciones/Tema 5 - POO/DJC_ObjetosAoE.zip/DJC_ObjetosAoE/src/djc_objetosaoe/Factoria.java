/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_objetosaoe;

/**
 *
 * @author danie
 */
public class Factoria {
    
    public static Civilizacion factoriaCivilizacion(int cod){
        String nombre = "", monarca = "";
        Civilizacion civ;
        
        switch (cod){
            case 1:
                nombre = "Imperio Español";
                monarca = "Isabel I";
                break;
            case 2:
                nombre = "Imperio Bizantino";
                monarca = "Constantino II";
        }
        civ = new Civilizacion(nombre,monarca);
        return civ;
    }
    
    public static Aldeano factoriaAldeano(int salud, Civilizacion civ){
        Aldeano ald = new Aldeano(salud, civ);
        return ald;
    }
    
}
