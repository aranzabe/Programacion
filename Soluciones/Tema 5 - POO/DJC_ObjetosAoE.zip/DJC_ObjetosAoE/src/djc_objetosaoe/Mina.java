/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_objetosaoe;

/**
 *
 * @author danie
 */
public class Mina {

    private String tipo;
    private int items;
    private Aldeano mineros[];

    public Mina() {
        this.tipo = "ORO";
        this.items = 500;
        this.mineros = new Aldeano[1];
    }

    public Mina(String tipo, int items) {
        this.tipo = tipo;
        this.items = items;
        this.mineros = new Aldeano[1];
    }

    public String getTipo() {
        return tipo;
    }

    public int getItems() {
        return items;
    }

    public Aldeano[] getMineros() {
        return mineros;
    }
    
    public int getTamMina(){
        return this.mineros.length;
    }

    public void setItems(int items) {
        this.items = items;
    }

    public void creceMina(Aldeano ald) {
        Aldeano nuevoVector[] = new Aldeano[this.mineros.length + 1];
        for (int i = 0; i < this.mineros.length; i++) {
            nuevoVector[i] = this.mineros[i];
        }
        nuevoVector[this.mineros.length] = ald;
        this.mineros = nuevoVector;
    }

    public int cuantosMineros(Civilizacion civ) {
        int cont = 0;

        for (int i = 0; i < this.mineros.length; i++) {
            if (this.mineros[i] != null) {
                if (civ.getNombre().equals(this.mineros[i].getCiv().getNombre())) {
                    cont++;
                }
            }
        }
        return cont;
    }
    
    public boolean hayMinerales(){
        return this.items > 0;
    }
}
