/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_objetosaoe;

/**
 *
 * @author danie
 */
public class Aldeano {
    private int salud;
    private Civilizacion civ;

    public Aldeano() {
        this.salud = 0;
        this.civ = null;
    }
    
    public Aldeano(int salud, Civilizacion civ){
        this.salud = salud;
        this.civ = civ;
    }

    public int getSalud() {
        return salud;
    }

    public void setSalud(int salud) {
        this.salud = salud;
    }

    public Civilizacion getCiv() {
        return civ;
    }

    public void setCiv(Civilizacion civ) {
        this.civ = civ;
    }

    @Override
    public String toString() {
        return "Aldeano{" + "salud=" + salud + ", civ=" + civ + '}';
    }
    
    
}
