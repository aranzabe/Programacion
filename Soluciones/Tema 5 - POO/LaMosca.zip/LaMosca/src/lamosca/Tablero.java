/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lamosca;

/**
 *
 * @author faranzabe
 */
public class Tablero {

    private int tablero[];

    public Tablero() {
        this.tablero = new int[10];
    }

    public Tablero(int tam) {
        this.tablero = new int[tam];
    }

    public void iniciarTablero() {
        for (int i = 0; i < this.tablero.length; i++) {
            this.tablero[i] = 0;
        }
    }

    public boolean colocarMosca() {
        boolean conseguido = false;
        int pos;
        while (!conseguido) {
            pos = (int) (Math.random() * this.tablero.length);
            if (this.tablero[pos] == 0) {
                this.tablero[pos] = 1;
                conseguido = true;
            }
        }
        return conseguido;
    }

    @Override
    public String toString() {
        String dev = "";

        for (int i = 0; i < this.tablero.length; i++) {
            dev += this.tablero[i] + " ";
        }
        dev += "\n";

        return dev;
    }

    /**
     * Esta función comprueba si en la posición existe una mosca. Caso de no ser así comprueba las adyacentes.
     * @param pos
     * @return 0 (si la cazas); 1 (si no la cazas pero la has asustado); 2 (ni la cazas, ni la asustas)
     */
    public int darManotazo(int pos) {
        int cod = 2; //Ni se entera.
        
        if (this.tablero[pos] == 1) {
            cod = 0; //Te la has cargao.
        } else {
            if (pos - 1 >= 0) {
                if (this.tablero[pos - 1] == 1) {
                    cod = 1; //Casi le das.
                }
            }
            if (pos + 1 < this.tablero.length) {
                if (this.tablero[pos + 1] == 1) {
                    cod = 1; //Casi le das.
                }
            }
        }
        return cod;
    }

    public void revoloteaMosca() {
        this.iniciarTablero();
        this.colocarMosca();
    }

}
