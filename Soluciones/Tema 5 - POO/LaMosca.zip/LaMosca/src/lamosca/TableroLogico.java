/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lamosca;

/**
 *
 * @author faranzabe
 */
public class TableroLogico {

    private boolean tablero[];

    public TableroLogico() {
        this.tablero = new boolean[10];
    }

    public TableroLogico(int tam) {
        this.tablero = new boolean[tam];
    }

    public void iniciarTablero() {
        for (int i = 0; i < this.tablero.length; i++) {
            this.tablero[i] = false;
        }
    }

    public boolean colocarMosca() {
        boolean conseguido = false;
        int pos;
        while (!conseguido) {
            pos = (int) (Math.random() * this.tablero.length);
            if (this.tablero[pos] == false) {
                this.tablero[pos] = true;
                conseguido = true;
            }
        }
        return conseguido;
    }

    @Override
    public String toString() {
        String dev = "";

        for (int i = 0; i < this.tablero.length; i++) {
            dev += this.tablero[i] + " ";
        }
        dev += "\n";

        return dev;
    }

    /**
     * Esta función comprueba si en la posición existe una mosca. Caso de no ser así comprueba las adyacentes.
     * @param pos
     * @return 0 (si la cazas); 1 (si no la cazas pero la has asustado); 2 (ni la cazas, ni la asustas)
     */
    public int darManotazo(int pos) {
        int cod = 2; //Ni se entera.
        
        if (this.tablero[pos] == true) {
            cod = 0; //Te la has cargao.
        } else {
            if (pos - 1 >= 0) {
                if (this.tablero[pos - 1] == true) {
                    cod = 1; //Casi le das.
                }
            }
            if (pos + 1 < this.tablero.length) {
                if (this.tablero[pos + 1] == true) {
                    cod = 1; //Casi le das.
                }
            }
        }
        return cod;
    }

    public void revoloteaMosca() {
        this.iniciarTablero();
        this.colocarMosca();
    }

}
