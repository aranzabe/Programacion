/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lamosca;

import java.util.Scanner;

/**
 *
 * @author faranzabe
 */
public class LaMosca {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        TableroLogico t = new TableroLogico(5);
        boolean cazada = false;
        int pos, qhp, intentos = 0;
        Scanner sc = new Scanner(System.in);

        t.iniciarTablero();
        t.colocarMosca();
        System.out.println(t.toString());

        while (!cazada && intentos < 5) {
            System.out.print("Dame la posición del golpeo: ");
            pos = sc.nextInt();
            intentos++;
            qhp = t.darManotazo(pos);
            switch (qhp) {
                case 0:
                    cazada = true;
                    break;
                case 1:
                    System.out.println("Casi le das. Se ha movido.");
//                    t.iniciarTablero();
//                    t.colocarMosca();
                    t.revoloteaMosca();
                    break;
                case 2:
                    System.out.println("Ni se ha enterado.");
            }
        }
        if (cazada){
            System.out.println("Enhorabuena. La has cazado.");
        }
        else {
            System.out.println("No la has cazado");
        }
        System.out.println(t.toString());
        /*
        iniciarTablero();
        colocarMosca();
        toString();
         */
    }

}
