/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio9;

/**
 *
 * @author faranzabe
 */
public class Titular {
    private String DNI;
    private String nombre;
    private String tfno;

    public Titular() {
        this.DNI = "";
        this.nombre = "";
        this.tfno = "";
    }

    public Titular(String DNI, String nombre, String tfno) {
        this.DNI = DNI;
        this.nombre = nombre;
        this.tfno = tfno;
    }

    public String getDNI() {
        return DNI;
    }

    public String getNombre() {
        return nombre;
    }

    public String getTfno() {
        return tfno;
    }

    public void setTfno(String tfno) {
        this.tfno = tfno;
    }

    @Override
    public String toString() {
        return "Titular{" + "DNI=" + DNI + ", nombre=" + nombre + ", tfno=" + tfno + '}';
    }
    
    
    
    
    
}
