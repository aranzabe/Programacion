/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio9;

/**
 *
 * @author faranzabe
 */
public class Cuenta {

    private float saldo;
    private String numCuenta;
    private Titular titulares[];

    public Cuenta(String numCuenta) {
        this.saldo = 0;
        this.titulares = new Titular[3];
    }

    public Cuenta(String numCuenta, Titular t) {
        this.saldo = 0;
        this.titulares = new Titular[3];
        this.titulares[0] = t;
        this.numCuenta = numCuenta;
    }

    @Override
    public String toString() {
        String dev="";
        dev = dev + "Cuenta: " + this.numCuenta + "\n";
        dev = dev + "Saldo: " + this.saldo + "\n";
        dev += "Titulares: \n";
        for (int i = 0; i < this.titulares.length; i++) {
            if (this.titulares[i]!=null){
                dev = dev + titulares[i].toString() + "\n";
            }
        }
        return dev;
    }

    public boolean addTitular(Titular nuevo) {
        boolean insertado = false;
        
    }
    
    

}
