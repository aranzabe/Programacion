/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio9;

import java.util.Scanner;

/**
 *
 * @author faranzabe
 */
public class Main {

    public static Titular factoriaTitularTeclado() {
        Scanner sc = new Scanner(System.in);
        System.out.print("DNI: ");
        String DNI = sc.nextLine();
        System.out.print("Nombre: ");
        String nombre = sc.nextLine();
        System.out.print("Teléfono: ");
        String tfno = sc.nextLine();
        Titular t = new Titular(DNI, nombre, tfno);
        return t;
    }

    public static Titular factoriaTitular() {
        int alea;
        String nombre = "", DNI, tfno;
        alea = (int) (Math.random() * 4);
        switch (alea) {
            case 0:
                nombre = "Ruben";
                break;
            case 1:
                nombre = "Jaime";
                break;
            case 2:
                nombre = "Eduardo";
                break;
            case 3:
                nombre = "Malena";
                break;
        }
        alea = (int) (Math.random() * 10000);
        DNI = String.valueOf(alea);
        alea = (int) (Math.random() * 1000000) + 1000000;
        tfno = String.valueOf(alea);
        Titular t = new Titular(DNI, nombre, tfno);
        return t;
    }

    public static Cuenta factoriaCuenta() {
        String numCuenta;
        int alea = (int) (Math.random() * 10000000) + 10000000;
        numCuenta = String.valueOf(alea);
        Titular t = factoriaTitular();
        Cuenta c = new Cuenta(numCuenta, t);
        return c;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Titular t = new Titular("1A","Javier","123456789");
//        Titular t = factoriaTitularTeclado();
//        Titular t = factoriaTitular();
//        System.out.println(t.toString());
        Cuenta cu = factoriaCuenta();
        System.out.println(cu.toString());
        Titular nuevo = factoriaTitular();
        if (cu.addTitular(nuevo)){
            System.out.println("Titular añadido");
        }
        else  {
            System.out.println("No se ha podido añadir");
        }
        //Modificar un titular. Pedir el DNI del que quiero cambiar y los nuevos datos.
        //Borrar un titular. No se puede quedar sin titulares. Si es el último no se puede borrar.
        //Ingresas pasta y retirar dinero.
        /*
        1.- Mostrar información de la cuenta.
        2.- Añadir un titular nuevo.
        3.- Borrar por DNI.
        4.- Modificar el DNI del cliente.
        5.- Consultar saldo.
        6.- Ingresar dinero.
        7.- Retirar dinero.
        8.- Salir.
        */
    }

}
