/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ej3poo;

import java.util.Scanner;

/**
 *
 * @author Portatil Alvaro
 */
public class Ej3poo {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) throws InterruptedException {
        int velocidad = 0;
        String encender = "";
        coche polo = new coche();
        Scanner sc = new Scanner(System.in);
        System.out.println(polo);
        System.out.println("El coche está apagado, ¿quieres encenderlo? S/N");
        encender = sc.nextLine();
        if (encender.equals("S") || encender.equals("s")) {
            polo.setMotor("Encendido");
            System.out.println("Coche encendido,a que velocidad quieres poner el coche 1-120");
            do {
                velocidad = sc.nextInt();
            } while (!((velocidad > 0) && (velocidad <= 120)));
            polo.setVelocidadActual(velocidad);
            polo.subirMarcha(velocidad);
            System.out.println("Cuanto tiempo en segundos quieres ir a "+velocidad+"Km/h");
            int tiempo = sc.nextInt();
            tiempo=tiempo*1000;
            Thread.sleep(tiempo);
            System.out.println(polo);
            polo.bajarMarcha(velocidad);
            polo.setMotor("Apagado");
            System.out.println(polo);
        }else{
            System.out.println(encender);
        }

    }

}
