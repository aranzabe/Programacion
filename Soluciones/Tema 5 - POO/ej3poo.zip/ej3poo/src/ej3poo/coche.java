/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ej3poo;

/**
 *
 * @author Portatil Alvaro
 */
class coche {

    private String motor;
    private int marchaActual;
    private int velocidadActual;
    private int subirMarcha;
    private int bajarMarcha;

    public coche() {
        this.motor = "apagado";
        this.marchaActual = 0;
        this.velocidadActual = 0;
    }

    @Override
    public String toString() {
        return "coche{" + "motor=" + motor + ", marchaActual=" + marchaActual + ", velocidadActual=" + velocidadActual + '}';
    }

    public void subirMarcha(int velocidadActual) {
        System.out.println("Acelerando...");
        if ((this.velocidadActual > 0)) {
            this.marchaActual++;
            System.out.print("Voy en la marcha " + this.marchaActual);
            if (this.velocidadActual >= 30) {
                System.out.println(" y voy a 30 por hora");
            } else {
                System.out.println(" y voy a " + this.velocidadActual + " por hora");
            }
        }
        if ((this.velocidadActual > 30)) {
            this.marchaActual++;
            System.out.print("Voy en la marcha " + this.marchaActual);
            if (this.velocidadActual >= 50) {
                System.out.println(" y voy a 50 por hora");
            } else {
                System.out.println(" y voy a " + this.velocidadActual + " por hora");
            }
        }
        if ((this.velocidadActual > 50)) {
            this.marchaActual++;
            System.out.print("Voy en la marcha " + this.marchaActual);
            if (this.velocidadActual >= 70) {
                System.out.println(" y voy a 70 por hora");
            } else {
                System.out.println(" y voy a " + this.velocidadActual + " por hora");
            }
        }
        if ((this.velocidadActual > 70)) {
            this.marchaActual++;
            System.out.print("Voy en la marcha " + this.marchaActual);
            if (this.velocidadActual >= 100) {
                System.out.println(" y voy a 100 por hora");
            } else {
                System.out.println(" y voy a " + this.velocidadActual + " por hora");
            }
        }
        if ((this.velocidadActual > 100)) {
            this.marchaActual++;
            System.out.println("Voy en la marcha " + this.marchaActual + " y voy a " + this.velocidadActual + " por hora");
        }
    }

    public void bajarMarcha(int velocidadActual) {
        System.out.println("Desacelerando...");
        if ((this.velocidadActual > 100)) {
            System.out.println("Voy en la marcha " + this.marchaActual + " y voy a " + this.velocidadActual + " por hora");
            this.marchaActual--;
        }
        if ((this.velocidadActual > 70)) {
            System.out.print("Voy en la marcha " + this.marchaActual);
            this.marchaActual--;
            if (this.velocidadActual >= 100) {
                System.out.println(" y voy a 100 por hora");
                this.velocidadActual = 100;
            } else {
                System.out.println(" y voy a " + this.velocidadActual + " por hora");
            }
        }
        if ((this.velocidadActual > 50)) {
            System.out.print("Voy en la marcha " + this.marchaActual);
            this.marchaActual--;
            if (this.velocidadActual >= 70) {
                System.out.println(" y voy a 70 por hora");
                this.velocidadActual = 70;
            } else {
                System.out.println(" y voy a " + this.velocidadActual + " por hora");
            }
        }
        if ((this.velocidadActual > 30)) {
            System.out.print("Voy en la marcha " + this.marchaActual);
            this.marchaActual--;
            if (this.velocidadActual >= 50) {
                System.out.println(" y voy a 50 por hora");
                this.velocidadActual = 50;
            } else {
                System.out.println(" y voy a " + this.velocidadActual + " por hora");
            }
        }
        if ((this.velocidadActual > 0)) {
            System.out.print("Voy en la marcha " + this.marchaActual);
            this.marchaActual--;
            if (this.velocidadActual >= 30) {
                System.out.println(" y voy a 30 por hora");
                 this.velocidadActual = 30;
            } else {
                System.out.println(" y voy a " + this.velocidadActual + " por hora");
            }
        }
        if ((this.velocidadActual >= 0)) {
            System.out.println("Estoy en punto muerto y el coche está parado ");
            this.velocidadActual = 0;
        }
    }

    public coche(String motor, int marchaActual, int velocidadActual, int subirMarcha, int bajarMarcha) {
        this.motor = motor;
        this.marchaActual = marchaActual;
        this.velocidadActual = velocidadActual;
        this.subirMarcha = subirMarcha;
        this.bajarMarcha = bajarMarcha;
    }

    public String getMotor() {
        return motor;
    }

    public void setMotor(String motor) {
        this.motor = motor;
    }

    public int getMarchaActual() {
        return marchaActual;
    }

    public void setMarchaActual(int marchaActual) {
        this.marchaActual = marchaActual;
    }

    public int getVelocidadActual() {
        return velocidadActual;
    }

    public void setVelocidadActual(int velocidadActual) {
        this.velocidadActual = velocidadActual;
    }

    public int getSubirMarcha() {
        return subirMarcha;
    }

    public void setSubirMarcha(int subirMarcha) {
        this.subirMarcha = subirMarcha;
    }

    public int getBajarMarcha() {
        return bajarMarcha;
    }

    public void setBajarMarcha(int bajarMarcha) {
        this.bajarMarcha = bajarMarcha;
    }

}
