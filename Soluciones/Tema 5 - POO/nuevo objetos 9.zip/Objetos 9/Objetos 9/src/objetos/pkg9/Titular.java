/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objetos.pkg9;

/**
 *
 * @author laura
 */
public class Titular {
    private String DNI;
    private String nombre;
    private String telefono;
    private String ap1;


  //----------------UN CONSTRUCTOR POR DEFECTO SIEMPRE VIENE BIEN, CON LOS STRINGS "" Y NO EN NULL
    public Titular() {
        this.DNI = "";
        this.nombre = "";
        this.telefono = "";

    }

 //--------------UN CONSTRUCTOR QUE NOS PERMITA CONECTAR LOS DATOS QUE QUEREMOS CON EL EXTERIOR
    public Titular(String DNI, String nombre, String telefono) {  
        this.DNI = DNI;
        this.nombre = nombre;
        this.telefono = telefono;
    }

//---¿QUE VAMOS A VER?---------------PUES QUERREMOS VER EL DNI, NOMBRE Y TELEFONO---USAMOS GET
    public String getDNI() {
        return DNI;
    }

    public String getNombre() {
        return nombre;
    }

    public String getTelefono() {
        return telefono;
    }
//----------------¿QUE VAMOS A MANIPULAR?------------PUES SOLO EL TELEFONO, LA PERSONA NO CAMBIARA DE DNI..... PERO SI EL TELEFONO.....---USAMOS SET
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
//------------------------------------UN TO STRING PARA PODER VER EN EL EXTERIOR CON UN SOUT LOS DATOS
    @Override
    public String toString() {
        return "Titular{" + "DNI=" + DNI + ", nombre=" + nombre + ", telefono=" + telefono + '}';
    }
    
    
    public boolean equals(String DNI){
        return this.DNI.equals(DNI);
    }
    
    
    
    
}

