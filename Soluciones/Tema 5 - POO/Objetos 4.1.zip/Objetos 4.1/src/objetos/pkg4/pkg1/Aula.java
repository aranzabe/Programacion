/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objetos.pkg4.pkg1;

/**
 *
 * @author laura
 */
public class Aula {

    private String codigoAula;
    private Ordenador[] Ordenadores;

    public Aula(String codigoAula) {
        this.codigoAula = "";
        this.Ordenadores = new Ordenador[20];
    }

    public Aula(String codigoAula, Ordenador[] Ordenadores) {
        this.codigoAula = codigoAula;
        this.Ordenadores = new Ordenador[20];
    }

    public void setCodigoAula(String codigoAula) {
        this.codigoAula = codigoAula;
    }

    public String getCodigoAula() {
        return codigoAula;
    }

    public Ordenador[] getOrdenadores() {
        return Ordenadores;
    }

    public boolean addOrdenador(Ordenador or1) {

        boolean encontrado = false;
        int i = 0;

        while (i < this.Ordenadores.length && !encontrado) {

            if (this.Ordenadores[i] == null) {
                this.Ordenadores[i] = or1;
                encontrado = true;
            }
            i++;
        }

        return encontrado;
    }

    public boolean deleteOrdenador(Ordenador or1) {

        boolean encontrado = true;
        int i = 0;

        while (i < this.Ordenadores.length && encontrado) {

            if (this.Ordenadores[i] == or1) {
                this.Ordenadores[i] = null;
                encontrado = false;
            }
            i++;
        }

        return encontrado;
    }

    public int cuantosOrdenadores() {
        int cont = 0;

        for (int i = 0; i < this.Ordenadores.length; i++) {

            if (this.Ordenadores[i] != null) {
                cont++;
            }
        }
        return cont;
    }

    public boolean modifyOrdenador(Ordenador or1, Ordenador or2) {

        boolean encontrado = true;
        int i = 0;

        while (i < this.Ordenadores.length && encontrado) {

            if (this.Ordenadores[i] == or1) {
                this.Ordenadores[i] = or2;
                encontrado = false;
            }
            i++;
        }

        return encontrado;
    }

}
