/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objetos.pkg4.pkg1;

/**
 *
 * @author laura
 */
public class Objetos41 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*     Ordenador or1= new Ordenador(8, "Windows", 4, "ASUS");
        Ordenador or2= new Ordenador(32, "Linux", 4, "AMD");
        
        
        System.out.println(or1.toString());
        or1.setRAM(12);
        System.out.println(or1.toString());
        System.out.println(or2.toString());
        
       if (or1.getRAM()>12){
           System.out.println("or1 Es buen ordenador");
       }else{
           System.out.println("or1 Es mal ordenador");
       }
        if (or2.getRAM()>12){
           System.out.println("or2 Es buen ordenador");
       }else{
           System.out.println("or2 Es mal ordenador");
       }*/

        Ordenador or1 = new Ordenador(8, "Windows10", 2, "ASUS");
         Ordenador or2 = new Ordenador(16, "Ubuntu16", 4, "Gigabyte");
        Aula a212 = new Aula("212");

        a212.addOrdenador(or1);
        System.out.println("Esta clase tiene: " + a212.cuantosOrdenadores() + " ordenadores");
        a212.deleteOrdenador(or1);
        System.out.println("Esta clase tiene: " + a212.cuantosOrdenadores() + " ordenadores");
        a212.modifyOrdenador(or1, or2);
        

    }

}
