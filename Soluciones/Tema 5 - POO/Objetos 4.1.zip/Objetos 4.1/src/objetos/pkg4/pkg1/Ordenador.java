/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objetos.pkg4.pkg1;

/**
 *
 * @author laura
 */
public class Ordenador {
    private int RAM;
    private String SO;
    private int ventiladores;
    private String placa;

    public Ordenador() {
        this.RAM = 0;
        this.SO = "";
        this.ventiladores = 0;
        this.placa = "";
    }

    public Ordenador(int RAM, String SO, int ventiladores, String placa) {
        this.RAM = RAM;
        this.SO = SO;
        this.ventiladores = ventiladores;
        this.placa = placa;
    }
    
    

    public void setRAM(int RAM) {
        this.RAM = RAM;
    }

    public void setSO(String SO) {
        this.SO = SO;
    }

    public void setVentiladores(int ventiladores) {
        this.ventiladores = ventiladores;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public int getRAM() {
        return RAM;
    }

    public String getSO() {
        return SO;
    }

    public int getVentiladores() {
        return ventiladores;
    }

    public String getPlaca() {
        return placa;
    }

    @Override
    public String toString() {
        return "Ordenador{" + "RAM=" + RAM + ", SO=" + SO + ", ventiladores=" + ventiladores + ", placa=" + placa + '}';
    }
}
