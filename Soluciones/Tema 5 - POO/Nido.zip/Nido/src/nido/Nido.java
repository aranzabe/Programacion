/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nido;

/**
 *
 * @author faranzabe
 */
public class Nido {
    private Serpiente nido[];

    public Nido() {
        nido = new Serpiente[20];
    }
    
    public Nido(int tam){
        nido = new Serpiente[tam];
    }
    
    public boolean addSerpiente(Serpiente s){
        boolean conseguido = false;
        int i=0;
        while(i < this.nido.length && !conseguido){
            if (this.nido[i] == null){
                this.nido[i] = s;
                conseguido = true;
            }
            i++;
        }
        
        return conseguido;
    }

    @Override
    public String toString() {
        String cad="";
        for (int i = 0; i < this.nido.length; i++) {
          if (this.nido[i] != null){
              cad += this.nido[i].toString() + "\n";
          }
          else {
              cad+="vacío \n";
          }
        }
        return cad;
    }
    
    
}
