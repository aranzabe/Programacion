/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nido;

/**
 *
 * @author laura
 */
public class Serpiente {

    private String color;
    private int años;
    private boolean estaViva;

    public Serpiente() {
        this.color = this.colorAleatorio();
        this.años = 0;
        this.estaViva = true;
    }

    public String getColor() {
        return color;
    }

    public int getAños() {
        return años;
    }

    public int getAnillas() {
        return this.color.length();
    }

    public void crecer() {
        this.color = this.color + this.colorAleatorio();
        this.aumentarAños();

    }

    public boolean mudar() {
        String otroCuerpo = "";
        boolean conseguido = true;
        
        if (!this.color.isEmpty()) {
            for (int i = 0; i < this.color.length(); i++) {
                otroCuerpo += this.colorAleatorio();
            }
            this.color = otroCuerpo;
            this.aumentarAños();
        } else {
            conseguido = false;
        }
        return conseguido;
    }

    public boolean decrecer() {
        boolean conseguido = true;
        if (!this.color.isEmpty()) {
            this.color = this.color.substring(0, this.color.length() - 1);
            this.aumentarAños();
            if (this.color.isEmpty()){
                this.estaViva = false;
            }
        } else {
            conseguido = false;
        }
        return conseguido;
    }

    public void aumentarAños() {
        this.años++;
    }

    @Override
    public String toString() {
        return  this.color + " (" + años + ")";
    }

    private String colorAleatorio() {
        String color = "";
        int alea = (int) (Math.random() * 3);
        switch (alea) {
            case 0:
                color = "r";
                break;
            case 1:
                color = "a";
                break;
            case 2:
                color = "v";
        }
        return color;
    }

    public void matarSerpiente() {
        this.estaViva = false;
    }

    public boolean isEstaViva() {
        return estaViva;
    }
    
    

}
