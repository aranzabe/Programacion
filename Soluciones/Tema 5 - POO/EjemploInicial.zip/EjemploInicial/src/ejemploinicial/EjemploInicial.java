/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemploinicial;

/**
 *
 * @author faranzabe
 */
public class EjemploInicial {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Mesa mesaClase = new Mesa();
        Mesa mesaCasa = new Mesa(3,"verde","trabajo");
        Mesa mesaNoche = new Mesa(1, "marrón","dormir");
        Mesa mesas[] = new Mesa[4];
        
        
        System.out.println(mesaClase.toString());
        System.out.println(mesaCasa.toString());
        mesaClase.setColor("amarillo");
        mesaClase.setTipo("comer");
        mesaClase.setPatas(4);
        System.out.println(mesaClase);
        System.out.println("La mesa de casa es: " + mesaCasa.getColor());
        System.out.println(mesaNoche.toString());
        
        mesas[0] = new Mesa();
        mesas[0].setColor("rojo");
        System.out.println(mesas[0].toString());
    }
    
}
