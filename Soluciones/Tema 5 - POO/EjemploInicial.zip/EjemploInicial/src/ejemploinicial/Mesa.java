/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemploinicial;

/**
 *
 * @author faranzabe
 */
public class Mesa {
    private int patas;
    private String color;
    private String tipo;

    public Mesa() {
        this.patas = 0;
        this.color = "";
        this.tipo = "";
    }

    public Mesa(int patas, String color, String tipo) {
        this.patas = patas;
        this.color = color;
        this.tipo = tipo;
    }

    public int getPatas() {
        return patas;
    }

    public void setPatas(int patas) {
        this.patas = patas;
    }

    public String getColor() {
        return this.color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Mesa{" + "patas=" + patas + ", color=" + color + ", tipo=" + tipo + '}';
    }
    
    
    
    
}
