/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ageofempires;

/**
 *
 * @author faranzabe
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {

        Civilizacion biz = new Civilizacion("Sergio", "Bizantinos", 250);
        Civilizacion esp = new Civilizacion("Pepe", "Españoles", 200);
        Mina mina = new Mina("Oro", 500);

        biz.mostrarInfo();
        esp.mostrarInfo();
        int tiempo = 0;

        while (tiempo <= 5) {

            //Cada dos segundos
            if (tiempo % 2 == 0) {
                int alea = (int) (Math.random() * 100);
                if (alea <= 40) {
                    Aldeano alAux = esp.obtenerAldeano();
                    mina.addAldeano(alAux);
                }
                if (alea > 40 && alea <= 60) {
                    Aldeano alAux = biz.obtenerAldeano();
                    mina.addAldeano(alAux);
                }
            }

            //Cada segundo
            mina.extraerItems(biz);
            mina.extraerItems(esp);

            Thread.sleep(1000);
            tiempo++;
        }
        System.out.println(esp);
        System.out.println("------------------------------------------------------------------");
        System.out.println(biz);
    }

}
