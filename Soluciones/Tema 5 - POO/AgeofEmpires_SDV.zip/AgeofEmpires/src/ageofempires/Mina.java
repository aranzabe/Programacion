/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ageofempires;

/**
 *
 * @author faranzabe
 */
public class Mina {

    private String recurso;
    private int items;
    private Aldeano alds[];

    public Mina() {
        this.recurso = "";
    }

    public Mina(String recurso, int items) {
        this.recurso = recurso;
        this.items = items;
        this.alds = new Aldeano[1];
    }

    public void mostrarAldeanos() {
        for (int i = 0; i < alds.length; i++) {
            System.out.println(alds[i]);
        }
    }

    public boolean addAldeano(Aldeano alAux) {
        boolean conseguido = false;
        int i = 0;

        while (i < this.alds.length && !conseguido) {
            if (this.alds[i] == null) {
                this.alds[i] = alAux;
                conseguido = true;
            }
            i++;
        }

        if (i == this.alds.length) {
            redimensionarAlds();
            this.alds[i] = alAux;
            conseguido = true;
        }
        return conseguido;
    }

    private void redimensionarAlds() {
        Aldeano aux[] = new Aldeano[this.alds.length + 1];

        for (int i = 0; i < this.alds.length; i++) {
            aux[i] = this.alds[i];
        }
        this.alds = aux;
    }

    public void extraerItems(Civilizacion c) {
        int i = 0;

        if (this.recurso.equals("Piedra")) {
            if (c.getNombre().equals("Español")) {
                while (this.items > 0 && i < this.alds.length) {
                    this.items--;
                    c.setAlmPiedra(c.getAlmPiedra() + 1);
                    i++;
                }
            }

        }

        if (this.recurso.equals("Oro")) {
            if (c.getNombre().equals("Español")) {
                while (this.items > 0 && i < this.alds.length) {
                    this.items--;
                    c.setAlmOro(c.getAlmOro() + 1);
                    i++;
                }
            }
        }

    }

    @Override
    public String toString() {
        return "Mina{" + "Recurso=" + recurso + ", Items=" + items + '}';
    }

}
