/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ageofempires;

/**
 *
 * @author faranzabe
 */
public class Aldeano {

    private int vida;
    private int ct;
    private Civilizacion civ;

    public Aldeano() {
    }

    public Aldeano(Civilizacion civ, int vida) {
        this.civ = civ;
        this.vida = vida;
        this.ct = (int) (Math.random() * 3) + 1;
    }

    public int getCt() {
        return ct;
    }

    public Civilizacion getCiv() {
        return civ;
    }

    public void setCiv(Civilizacion civ) {
        this.civ = civ;
    }
    /*
    public int trabajaAldeanoPorFavor(String recurso){
        this.civ.setAlmOro(this.civ.getAlmOro() + this.ct);
        return this.ct;
    }*/

    @Override
    public String toString() {
        return "Aldeano tiene: {" + "HP=" + vida + ", CT=" + ct + ", CIV=" + civ + '}';
    }

}
