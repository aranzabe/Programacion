/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ageofempires;

/**
 *
 * @author faranzabe
 */
public class Civilizacion {
    private String nombre;
    private String rey;
    private int almOro;
    private int almPiedra;
    private Aldeano alds[];
    private int vidaDefecto;

    public Civilizacion() {
        this.nombre="";
        this.rey="";
    }

    public Civilizacion(String nombre, String rey, int vidaDefecto) {
        this.vidaDefecto = vidaDefecto;
        this.nombre = nombre;
        this.rey = rey;
        alds = new Aldeano[50];
        for (int i = 0; i < alds.length; i++) {
            alds[i] = new Aldeano(this, this.vidaDefecto);
        }
    }

    public int getAlmOro() {
        return almOro;
    }

    public void setAlmOro(int almOro) {
        this.almOro = almOro;
    }

    public int getAlmPiedra() {
        return almPiedra;
    }

    public void setAlmPiedra(int almPiedra) {
        this.almPiedra = almPiedra;
    }

    public String getNombre() {
        return nombre;
    }

    public String getRey() {
        return rey;
    }

    @Override
    public String toString() {
        return "Civilización{" + "Nombre=" + nombre + ", Rey=" + rey + ", AlmOro=" + almOro + ", AlmPiedra=" + almPiedra + '}';
    }
    
    public void mostrarInfo(){
        System.out.println("Civilización: " + this.nombre);
        System.out.println("Rey: " + this.rey);
        System.out.println("Oro total: " + this.almOro);
        System.out.println("Piedra total: " + this.almPiedra);
        System.out.println("Aldeanos trabajando:");
        for (int i = 0; i < alds.length; i++) {
            System.out.println(alds[i]);
        }
    }

    /**
     * Recorre mi lista de aldeanos. Devolverá null si ya ni quedan más aldeanos en la civilización.
     * @return 
     */
    public Aldeano obtenerAldeano() {
        Aldeano alDevolver = null;
        int i=0;
        while(i<this.alds.length && alDevolver==null){
            if (this.alds[i]!=null){
                alDevolver = this.alds[i];
                this.alds[i]=null;
            }
            i++;
        }
        return alDevolver;
    }
}
