/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_objetos06serpiente;

/**
 *
 * @author usuariob
 */
public class Nido {

    private Serpiente[] serpiente;

    public Nido() {
        this.serpiente = new Serpiente[20];
    }
    
    public Nido(int t) {
        this.serpiente = new Serpiente[t];
    }
    
    public int getTamNido(){
        return this.serpiente.length;
    }

    public Serpiente getSerpiente(int pos) {
        return serpiente[pos];
    }

    /**
     * Este método posiciona una serpiente en una posición aleatoria
     *
     * @return true si ha conseguido colocarla, false si no lo ha hecho
     */
    public boolean naceSerpiente(Serpiente s) {
        int alea;
        boolean conseguido = false;

        while (!conseguido && !this.estaLleno()) {
            alea = (int) (Math.random() * this.serpiente.length);
            if (this.serpiente[alea] == null) {
                this.serpiente[alea] = s;
                conseguido = true;
            }
        }
        return conseguido;
    }

    /**
     * Este método posiciona una serpiente en una posición aleatoria
     *
     * @return true si ha conseguido colocarla, false si no lo ha hecho
     */
    public boolean naceSerpiente() {
        int alea;
        boolean conseguido = false;
        Serpiente s = new Serpiente();

        while (!conseguido && !this.estaLleno()) {
            alea = (int) (Math.random() * this.serpiente.length);
            if (this.serpiente[alea] == null) {
                this.serpiente[alea] = s;
                conseguido = true;
            }
        }
        return conseguido;
    }
    /**
     * Este método hace que todas las serpientes cumplan un año
     */
    public void aniversarioNido() {
        for (int i = 0; i < serpiente.length; i++) {
            if (this.serpiente[i] != null) {
                this.serpiente[i].aniversarioSerpiente();
                if (!this.serpiente[i].sigueViva()){
                    this.serpiente[i] = null;
                }
            }
        }
    }

    /**
     * Este método libera el espacio de una serpiente que ha muerto
     */
    public void muerteSerpiente() {
        for (int i = 0; i < serpiente.length; i++) {
            if (this.serpiente[i] != null && !this.serpiente[i].sigueViva()) {
                this.serpiente[i] = null;
            }
        }
    }

    /**
     * Este método comprueba si el nido está lleno
     *
     * @return true si está lleno, false si no lo está
     */
    private boolean estaLleno() {
        int cont = 0;
        boolean loEsta = false;

        for (int i = 0; i < this.serpiente.length; i++) {
            if (this.serpiente[i] != null) {
                cont++;
            }
        }
        if (cont == this.serpiente.length) {
            loEsta = true;
        }
        return loEsta;
    }

    @Override
    public String toString() {
        String cad = "El nido:\n";

        for (int i = 0; i < this.serpiente.length; i++) {
            cad += "Hueco " + i + " - ";
            if (this.serpiente[i] == null) {
                cad += "Vacío";
            } else {
                cad += serpiente[i].toString();
            }
            cad += "\n";
        }
        return cad;
    }

    public int getCuantasQuedan() {
        int cont = 0;

        for (int i = 0; i < this.serpiente.length; i++) {
            if (this.serpiente[i] != null) {
                cont++;
            }
        }
        return cont;
    }

    public void muerteSerpiente(int i) {
        this.serpiente[i] = null;
    }

}
