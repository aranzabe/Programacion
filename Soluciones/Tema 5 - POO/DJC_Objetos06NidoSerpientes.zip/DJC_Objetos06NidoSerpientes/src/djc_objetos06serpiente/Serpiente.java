/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_objetos06serpiente;

/**
 *
 * @author danie
 */
public class Serpiente {

    private char[] anillas;
    private int tam;
    private int edad;

    public Serpiente() {
        this.tam = 1;
        this.anillas = new char[this.tam];
        this.anillas[0] = generarAnilla();
        this.edad = 0;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public char[] getAnillas() {
        return anillas;
    }

    public int getTam() {
        return tam;
    }

    public int getEdad() {
        return edad;
    }

    @Override
    public String toString() {
        String cad = "";

        for (int i = 0; i < this.anillas.length; i++) {
            cad += this.anillas[i];
        }
        cad += "( " + this.edad + " años y " + this.tam + " anillas)";
        return cad;
    }

    /**
     * Este método genera un número aleatorio que corresponde a un color: 0 para
     * rojo, 1 para verde, 2 para amarillo
     *
     * @return el color de la anilla: 'r' --> rojo, 'v' --> verde, 'a' -->
     * amarillo
     */
    public char generarAnilla() {
        int random;
        char anilla = '0';

        random = (int) (Math.random() * 3);
        switch (random) {
            case 0:
                anilla = 'r';
                break;
            case 1:
                anilla = 'v';
                break;
            case 2:
                anilla = 'a';
        }
        return anilla;
    }

    /**
     * Este método hace crecer la serpiente una anilla, respetando los valores
     * de las anillas ya creadas, y poniendo una anilla aleatoria al final
     */
    public void creceSerpiente() {
        this.tam++;
        char[] anillasNuevo = new char[tam];
        for (int i = 0; i < this.anillas.length; i++) {
            anillasNuevo[i] = this.anillas[i];
        }
        anillasNuevo[anillasNuevo.length - 1] = generarAnilla();
        this.anillas = anillasNuevo;
    }

    /**
     * Este método da valores nuevos al vector, respetando su tamaño
     */
    public void mudaPiel() {
        for (int i = 0; i < this.anillas.length; i++) {
            this.anillas[i] = generarAnilla();
        }
    }

    /**
     * Este método quita la última anilla a la serpiente
     */
    public boolean decreceSerpiente() {
        boolean conseguido = false;

        this.tam--;
        if (this.sigueViva()) {
            char[] anillasNuevo = new char[tam];
            for (int i = 0; i < anillasNuevo.length; i++) {
                anillasNuevo[i] = this.anillas[i];
            }
            this.anillas = anillasNuevo;
            conseguido = true;
        }
        return conseguido;
    }

    /**
     * Este método suma 1 a la edad de la serpiente
     */
    public void cumpleSerpiente() {
        this.edad++;
    }

    /**
     * Este método llama a diferentes métodos según diferentes porcentajes de
     * probabilidad
     *
     * @return cod = 1
     */
    public int aniversarioSerpiente() {
        int cod = 0;
        int prob = (int) (Math.random() * 100);

        this.edad++;
        if (this.edad < 10) {
            if (prob < 80) {
                creceSerpiente();
                cod = 1;
            } else {
                mudaPiel();
                cod = 2;
            }
        } else {
            if (prob < 90) {
                if (decreceSerpiente()) {
                    cod = 3;
                } else {
                    cod = 4;
                }
            } else {
                mudaPiel();
                cod = 2;
            }
        }
        return cod;
    }

    /**
     * Este método comprueba si la serpiente sigue viva
     *
     * @return true tiene más de 0 anillas, false si tiene 0
     */
    public boolean sigueViva() {
        return this.tam > 0;
    }

    public void matarSerpiente() {
        this.tam = 0;
    }
}
