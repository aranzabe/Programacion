/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_objetos06serpiente;

/**
 *
 * @author danie
 */
public class DJC_Objetos06Serpiente {

    public static int ataqueMangosta(Nido n) {
        int probAtaque = (int) (Math.random() * 100);
        int numSerpientes, victimas = 0;
        int posSerpientes;

        if (probAtaque < 20) {
            numSerpientes = (int) (Math.random() * 5);
            if (numSerpientes > n.getCuantasQuedan()) {
                numSerpientes = n.getCuantasQuedan();
            }
            while (victimas != numSerpientes) {
                posSerpientes = (int) (Math.random() * n.getTamNido());

                if (n.getSerpiente(posSerpientes) != null && n.getSerpiente(posSerpientes).sigueViva()) {
                    n.getSerpiente(posSerpientes).matarSerpiente();
                    victimas++;
                }
            }
        }

        return victimas;
    }

    public static int ataqueMangosta2(Nido n) {
        int probAtaque = (int) (Math.random() * 100);
        int numSerpientes = 0;

        if (probAtaque < 20) {
            numSerpientes = (int) (Math.random() * 5);
            if (numSerpientes > n.getCuantasQuedan()) {
                numSerpientes = n.getCuantasQuedan();
            }

        }

        return numSerpientes;
    }

    public static Serpiente factoriaSerpiente() {
//        Serpiente s = new Serpiente();
//        return s;
        return new Serpiente();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        Nido n = new Nido();
        int nacimientos;
        int t;
        int victimas, numSerpientes;

        for (t = 0; t < 300; t++) {
            //n.muerteSerpiente();
            if (t % 5 == 0) {
                nacimientos = (int) (Math.random() * 3) + 1;
                while (nacimientos != 0 && n.naceSerpiente(factoriaSerpiente())) {
                    nacimientos--;
                }
            }

            if (t % 10 == 0) {
                //Opción A - El ataque en sí está en el método.
//                victimas = ataqueMangosta(n);
//                if (victimas != 0) {
//                    System.out.println("Una mangosta ha atacado el nido y se ha comido a " + victimas + " serpientes");
//                }
                //Opción B - En la que sacamos el ataque al programa principal.
                victimas = 0;
                numSerpientes = ataqueMangosta2(n);
                while (victimas != numSerpientes) {
                    int posSerpientes = (int) (Math.random() * n.getTamNido());
                    if (n.getSerpiente(posSerpientes) != null && n.getSerpiente(posSerpientes).sigueViva()) {
                        n.getSerpiente(posSerpientes).matarSerpiente();
                        victimas++;
                    }
                }
            }
            System.out.println(n);
            Thread.sleep(1000);
            //Opción A - Derivamos la vida de la serpiente a un método auxiliar.
            //n.aniversarioNido();
            
            //Opción B - Recorrer las serpientes y que pase la vida de cada una aquí.
            for (int i = 0; i < n.getTamNido(); i++) {
                Serpiente s = n.getSerpiente(i);
                if (s != null) {
                    s.cumpleSerpiente();
                    int prob = (int) (Math.random() * 100);
                    if (s.getEdad() < 10) {
                        if (prob < 80) {
                            s.creceSerpiente();
                        } else {
                            s.mudaPiel();
                        }
                    } else {
                        if (prob < 90) {
                            s.decreceSerpiente();
                        } else {
                            s.mudaPiel();
                        }
                    }
                    if (!s.sigueViva()){
                        n.muerteSerpiente(i);
                    }
                }
            }
        }
        System.out.println("Fin de la simulación.");
    }

}
