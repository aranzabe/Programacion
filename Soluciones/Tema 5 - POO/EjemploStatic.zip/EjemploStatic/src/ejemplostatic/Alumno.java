/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplostatic;

/**
 *
 * @author faranzabe
 */
public class Alumno {
    private String cod;
    private String nombre;
    private int edad;
    public static int SE;
    private static int codNum;
    
    
    static {
        SE = 2;
        codNum = 1;
    }

    public Alumno() {
        this.cod = "DAW1" + codNum;
        codNum++;
    }

    public Alumno(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
        this.cod = "DAW1" + codNum;
        codNum++;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    
    public int calcularSeguro(){
        int calculo = SE + edad * SE;
        return calculo;
    }

    public String getCod() {
        return cod;
    }

    @Override
    public String toString() {
        return "Alumno{" + "cod=" + cod + ", nombre=" + nombre + ", edad=" + edad + '}';
    }

    public static int getCodigoActual() {
        return codNum;
    }
    
    
    
}
