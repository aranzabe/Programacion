/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplostatic;

/**
 *
 * @author faranzabe
 */
public class EjemploStatic {

    public static int loquesea(){
        return 0;
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Tasa de seguro común: " + Alumno.SE);
        Alumno.SE = 9;
        Alumno p = new Alumno("Malena", 18);
        Alumno p2 = new Alumno("Pablo", 72);
        System.out.println(p);
        System.out.println(p2);
        System.out.println(p.getNombre());
        System.out.println(p.calcularSeguro());
        System.out.println(p2.calcularSeguro());
        
        System.out.println(Alumno.getCodigoActual());
        
        String cad;
        
    }

}
