/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_vectores12;

/**
 *
 * @author danijcoello
 */
public class DJC_Vectores12 {

    /**
     * Este procedimiento inicia un vector con valores entre -10 y 10
     */
    public static void iniciarVector(int v[]){
        for (int i = 0; i < v.length; i++) {
            v[i] = (int) (Math.random() * 21) - 10;
        }
    }
    
    
    /**
     * Este procedimiento muestra un vector
     */ 
    public static void mostrarVector(int v[]){
        for (int i = 0; i < v.length; i++) {
            System.out.print(v[i] + " ");
        }
        System.out.println("");
    }
    
    
    /**
     * Esta función devuelve la suma de dos vectores
     */
    public static int[] sumaVectores(int v1[], int v2[]){
        int sum[] = new int[v1.length];
        
        for (int i = 0; i < v1.length; i++) {
            sum[i] = v1[i] + v2[i];
        }
        return sum;
    }
    
    /**
     * Esta función devuelve la suma de dos vectores
     */
    public static void sumaVectoresProc(int v1[], int v2[], int sum[]){
        
        for (int i = 0; i < v1.length; i++) {
            sum[i] = v1[i] + v2[i];
        }
    }
    
    /*-----------------------------------------------------------------------*/
    /*--------------------------ALGORITMO PRINCIPAL--------------------------*/
    /*-----------------------------------------------------------------------*/
    public static void main(String[] args) {
        int vector1[] = new int[3];
        int vector2[] = new int[3];
        int suma[] = new int[3];
        
        System.out.println("Este programa suma dos vectores ");
        
        iniciarVector(vector1);
        System.out.println("Vector 1: ");
        mostrarVector(vector1);
        iniciarVector(vector2);
        System.out.println("Vector 2: ");
        mostrarVector(vector2);
        suma = sumaVectores(vector1, vector2);
        //sumaVectoresProc(vector1, vector2, suma);
        System.out.println("La suma de los vectores es: ");
        mostrarVector(suma);
    }
    
}
