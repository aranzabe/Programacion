/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package argmvectores3;

import java.util.Scanner;

/**
 *
 * @author usuarioa
 */
public class ARGMvectores3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
            Scanner sc=new Scanner(System.in);
            float vector[]= new float[10];
            float n,media = 0;
            for(int i=0; i<vector.length;i++){
                System.out.println("Dime numero real: ");
                n= sc.nextFloat();
                vector[i]=n;
            }
            for(int i=0; i<vector.length;i++){
                System.out.print(vector[i]+" ");
                
                media=(media+vector[i])/vector.length;
            }
            System.out.println(" ");
            System.out.println("La media es "+media);
            
            
            
    }
    
}
