/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_vectores16;

import java.util.Scanner;

/**
 *
 * @author danijcoello
 */
public class DJC_Vectores16 {

    /**
     * Esta función pide un nùmero, controlando que sea mayor que 0
     */
    public static int pedirFuerza() {
        Scanner sc = new Scanner(System.in);
        int fuerza;

        do {
            System.out.print("¿Con cuánta fuerza quieres tirar la piedra? ");
            fuerza = sc.nextInt();
            if (fuerza <= 0) {
                System.out.println("Tira la piedra más fuerte");
            }
        } while (fuerza <= 0);
        return fuerza;
    }

    /**
     * Esta función pide la posición, controlando que esté entre los valores
     * permitidos
     */
    public static int pedirPosicion() {
        int pos;
        Scanner sc = new Scanner(System.in);
        do {
            System.out.print("¿A qué posición quieres tirar la piedra (del 0 al 14)? ");
            pos = sc.nextInt();
            if (pos < 0 || pos > 14) {
                System.out.println("Esa posición no existe");
            }
        } while (pos < 0 || pos > 14);

        return pos;
    }

    /**
     * Esta función devuelve un vector iniciado teniendo en cuenta la fuerza y
     * la posición a la que se tira la piedra, creando una onda alrededor de la
     * posición con posiciones progresivamente menores
     */
    public static int[] tiraPiedra(int pos, int fuerza) {
        int v[] = new int[15];
        int j;
        int k;

        for (int i = 0; i < v.length; i++) {
            if (i == pos) {
                v[i] = fuerza;
                j = i + 1;
                k = i - 1;
                while (j < v.length && v[j - 1] != 0) {
                    v[j] = v[j - 1] - 1;
                    j++;
                }
                while (k >= 0 && v[k + 1] != 0) {
                    v[k] = v[k + 1] - 1;
                    k--;
                }
            }
        }
        return v;
    }

    /**
     * Este procedimiento muestra un vector
     */
    public static void mostrarVector(int v[]) {
        for (int i = 0; i < v.length; i++) {
            System.out.print(v[i] + " ");
        }
        System.out.println("");
    }

    /**
     * Este módulo calma el río, restando 1 a cada posición mayor que 0
     */
    public static void calmarRio(int v[]) {
        for (int i = 0; i < v.length; i++) {
            if (v[i] > 0) {
                v[i]--;
            }
        }
    }

    /**
     * Este módulo booleano comprueba si el río está calmado, es decir, si todas
     * las posiciones del vector valen 0
     */
    public static boolean estaCalmado(int v[]) {
        boolean loEsta = true;
        int i = 0;

        while (i < v.length && loEsta == true) {
            if (v[i] != 0) {
                loEsta = false;
            }
            i++;
        }
        return loEsta;
    }

    /*-------------------------------------------------------------------------*/
 /*---------------------------ALGORITMO PRINCIPAL---------------------------*/
 /*-------------------------------------------------------------------------*/
    public static void main(String[] args) {
        int rio[];
        int pos, fuerza;
        Scanner sc = new Scanner(System.in);

        System.out.println("Tienes un río delante y una piedra en la mano");
        fuerza = pedirFuerza();
        pos = pedirPosicion();

        rio = tiraPiedra(pos, fuerza);
        do {
            mostrarVector(rio);
            calmarRio(rio);
        } while (!estaCalmado(rio));

    }

}
