/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_vectores08;

/**
 *
 * @author usuariob
 */
public class DJC_Vectores08 {

    public static void iniciarVector(int v[]){
        int n = 0;
        
        for (int i = 0; i < v.length; i++) {
            v[i] = n + 1;
            n++;
        }
    }
    
    
    public static void invertirVector(int v[], int inv[]){
        int j = v.length - 1;
        
        for (int i = 0; i < v.length; i++) {
            inv[i] = v[j];
            j--;
        }
    }
    
    
    public static void mostrarVector(int v[]){
        for (int i = 0; i < v.length; i++) {
            System.out.print(v[i] + " ");
        }
        System.out.println("");
    }
    
    
    public static void main(String[] args) {
        int vector[] = new int[5];
        int vectorInv[] = new int[5];
        
        iniciarVector(vector);
        mostrarVector(vector);
        invertirVector(vector, vectorInv);
        mostrarVector(vectorInv);
    }
    
}
