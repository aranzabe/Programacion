/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package argmv16;

import java.util.Scanner;

/**
 *
 * @author raul
 */
public class ARGMv16 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int pos, inte;
        int rio[] = new int[10];

        pos = pedirPosicion();
        inte = pedirFuerza();

        iniciarVector(rio, pos, inte);
        do {
            mostrarVector(rio);
            calmarRio(rio);
        }while(!estaCalmado(rio));

    }

    
    
    
    public static void iniciarVector(int[] r, int p, int intens) {
        int posAux;
        int intensAux;

        posAux = p;
        intensAux = intens;
        while (posAux >= 0 && intensAux > 0) {
            r[posAux] = intensAux;
            intensAux--;
            posAux--;
        }

        intensAux = intens;
        posAux = p;
        while (posAux < r.length && intensAux > 0) {
            r[posAux] = intensAux;
            intensAux--;
            posAux++;
        }

    }

    static int pedirFuerza() {
        int pos;
        Scanner sc = new Scanner(System.in);
        do {
            System.out.print("Dime una fuerza del 0 al 9: ");
            pos = sc.nextInt();
        } while (pos > 10);
        return pos;
    }

    static int pedirPosicion() {
        int pos;
        Scanner sc = new Scanner(System.in);
        do {
            System.out.print("Dime una posicion del 0 al 9: ");
            pos = sc.nextInt();
        } while (pos > 10);
        return pos;
    }

    private static void mostrarVector(int[] rio) {
        int i;

        for (i = 0; i < rio.length; i++) {
            System.out.print(rio[i] + " ");

        }
        System.out.println("");
    }

    static void calmarRio(int[] rio) {
        
    }

    static boolean estaCalmado(int[] rio) {
        boolean loEsta;
        
        return loEsta;
    }
}
