/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javamodularvectores.pkg1;

/**
 *
 * @author Laura
 */
public class JavaModularVectores1 {

    public static void iniciarVector(int vector[]) {
        for (int cont = 0; cont < vector.length; cont++) {
            vector[cont] = -1;
        }
    }
    
    public static void mostrarVector(int v[]){
        for (int i = 0; i < v.length; i++) {
            System.out.print(v[i] + " ");
        }
        System.out.println("");
    }

    public static void main(String[] args) {

        int vector[] = new int[10];

        iniciarVector(vector);
        mostrarVector(vector);
    }

}
