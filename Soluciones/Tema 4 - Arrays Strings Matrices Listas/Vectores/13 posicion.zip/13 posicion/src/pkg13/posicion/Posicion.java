/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg13.posicion;

import java.util.Scanner;

/**
 *
 * @author alvar
 */
public class Posicion {

    static void rellenarVector(int[] v, int n) {
        v[0] = n;
        for (int i = 1; i < v.length; i++) {
            v[i] = v[i - 1] + 1;
        }
    }
    
    static void rellenarVector2(int[] v2, int n) {
        v2[0] = n;
        for (int i = 1; i < v2.length; i++) {
            v2[i] = v2[i - 1] + i;
        }
    }
    
    static void mostrarVector(int[] v) {
        for (int i = 0; i < v.length; i++) {
            System.out.print(v[i] + " ");
        }
        System.out.println("");
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        int v[] = new int[7],v2[] = new int[7], n;
        
        System.out.println("Dame un número");
        n = sc.nextInt();
        rellenarVector(v,n);
        mostrarVector(v);
        rellenarVector2(v2,n);
        mostrarVector(v2);
    }
    
}
