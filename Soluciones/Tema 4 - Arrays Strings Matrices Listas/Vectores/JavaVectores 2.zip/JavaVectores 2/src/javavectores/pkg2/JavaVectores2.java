/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javavectores.pkg2;

/**
 *
 * @author Laura
 */
public class JavaVectores2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        int par[] = new int[10];
        int impar[] = new int[10];
        int numero = 0;

        //Opción A)
        for (int cont = 0; cont < par.length; cont++) {
            par[cont] = numero;
            numero = numero + 2;            
        }
        
        numero = 1;
        for (int cont = 0; cont < impar.length; cont++) {
            impar[cont] = numero;
            numero = numero + 2;            
        }

//Opción B)
//        for (int cont = 0; cont < par.length; cont++) {
//            par[cont] = numero;
//            numero++;
//            impar[cont] = numero;
//            numero++;
//        }
        
        for (int i = 0; i < par.length; i++) {
            System.out.print(par[i] + " ");
        }
        System.out.println("");
        
        for (int i = 0; i < impar.length; i++) {
            System.out.print(impar[i] + " ");
        }
        System.out.println("");
    }

}
