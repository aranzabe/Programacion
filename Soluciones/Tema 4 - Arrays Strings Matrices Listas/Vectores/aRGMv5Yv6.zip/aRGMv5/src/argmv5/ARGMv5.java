/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package argmv5;

/**
 *
 * @author usuarioa
 */
public class ARGMv5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int vec []=new int[10];
        int pos []=new int[1];
        int negativo;
        iniciarVector(vec);
        MostrarVector(vec);
        negativo=cuantos(pos,vec);
        System.out.print("Positivos: " + pos[0] + " y negativos: " + negativo);
    }

    public static void iniciarVector(int[] vec) {
        int i;
        for(i=0;i<vec.length;i++){
            vec[i]=(int) (Math.random()*200)-100;
        }
    }

    public static void MostrarVector(int[] vec) {
            int i;
            for(i=0;i<vec.length;i++){
                System.out.print(vec[i] + " ");
            }    
            System.out.println(" ");
    }

    static int cuantos(int[] posit, int[] v) {
        int i,negativo = 0;
        int positivo = 0;

        for(i=0;i<v.length;i++){
            if(v[i]>=0)positivo++;
            if(v[i]<0)negativo++;
        }    
        
        posit[0]=positivo;
        return negativo;
    }
    
}
