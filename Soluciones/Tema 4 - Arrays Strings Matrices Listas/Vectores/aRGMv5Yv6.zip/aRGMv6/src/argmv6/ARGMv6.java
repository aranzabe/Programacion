/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package argmv6;

import java.util.Scanner;

/**
 *
 * @author usuarioa
 */
public class ARGMv6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int v[]=new int[100];
        Scanner sc=new Scanner(System.in);
        int n,comp=0;
        iniciarVector(v);
        mostrarVector(v);
        
        System.out.print("Dime un numero: ");
        n=sc.nextInt();
        
        comp=comprobarNumero(v,n);
        System.out.println("Esta " + comp +" veces en el vector");
    }
   
    
        public static void iniciarVector(int[] vec) {
        int i;
        for(i=0;i<vec.length;i++){
            vec[i]=(int) (Math.random()*100+1);
        }
    }

    public static void mostrarVector(int[] vec) {
            int i;
            for(i=0;i<vec.length;i++){
                System.out.print(vec[i] + " ");
            }    
            System.out.println(" ");
    }

    static int comprobarNumero(int[] vec, int num) {
        int i;
        int cont=0;
        for(i=0;i<vec.length;i++){
            if(vec[i]==num) cont++;
        }
        return cont;
    }
}

