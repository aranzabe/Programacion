/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemploinicial;

/**
 *
 * @author faranzabe
 */
public class EjemploInicial {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int vector[] = new int[4];
        
        for (int i = 0; i < vector.length; i++) {
            vector[i] = i;
        }
        
        vector = new int[3];
        for (int i = 0; i < vector.length; i++) {
            System.out.print(vector + " ");
        }
        System.out.println("");
        
        
        
    }
    
}
