/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_vectores13b;

import java.util.Scanner;

/**
 *
 * @author danijcoello
 */
public class DJC_Vectores13b {

    /**
     * Esta función inicia un vector cuyos valores son iguales al valor en la
     * posición anterior más el valor de la propia posición
     */
    public static int[] iniciarVector(int n, int longit) {
        int v[] = new int[longit];

        v[0] = n;
        for (int i = 1; i < v.length; i++) {
            v[i] = v[i - 1] + i;
        }
        return v;
    }

    /**
     * Este procedimiento muestra un vector
     */
    public static void mostrarVector(int v[]) {
        for (int i = 0; i < v.length; i++) {
            System.out.print(v[i] + " ");
        }
        System.out.println("");
    }

 /*-----------------------------------------------------------------------*/
 /*--------------------------ALGORITMO PRINCIPAL--------------------------*/
 /*-----------------------------------------------------------------------*/
    public static void main(String[] args) {
        int num;
        int longitud;
        int sucesion[];
        Scanner sc = new Scanner(System.in);

        System.out.println("Este programa genera un vector a cada valor el valor de la posición en que se encuentra");
        System.out.print("¿De qué longitud quieres el vector? ");
        longitud = sc.nextInt();
        System.out.print("Dame un número para ponerlo en la primera posición: ");
        num = sc.nextInt();

        sucesion = iniciarVector(num, longitud);
        mostrarVector(sucesion);
    }
}
