/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg14.mosca;

import java.util.Scanner;

/**
 *
 * @author alvar
 */
public class Mosca {

    static void colocarMosca(int[] tablero) {
        int ale = (int) (Math.random() * tablero.length);
        tablero[ale] = 1;
    }

    //-------------------------------------------------------------------------------------------------------------------------//
    static void rellenarTablero(int[] tablero) {
        for (int i = 0; i < tablero.length; i++) {
            tablero[i] = 0;
        }
    }

    //-------------------------------------------------------------------------------------------------------------------------//
    static boolean comprobar(int pos, int[] tablero) {
        boolean ok = true;
        if (pos < 0 || pos > tablero.length - 1) {
            ok = false;
        }
        return ok;
    }

    //-------------------------------------------------------------------------------------------------------------------------//
    /**
     * caso 2 => Ni te acercas. caso 0 => Si me la cargo. caso 1 => Casi.
     *
     * @param pos
     * @param tablero
     * @return
     */
    static int comprobarGolpe(int pos, int[] tablero) {
        int caso = 2;

        if (tablero[pos] == 1) {
            caso = 0;
        } else {
            if (pos == 0) {
                if (tablero[pos + 1] == 1) {
                    caso = 1;
                }
            } else if (pos == tablero.length - 1) {
                if (tablero[pos - 1] == 1) {
                    caso = 1;
                }
            } else if (tablero[pos - 1] == 1 || tablero[pos + 1] == 1) {
                caso = 1;
            }
        }

        return caso;
    }

    //-------------------------------------------------------------------------------------------------------------------------//
    static void mostrarTablero(int[] v) {
        for (int i = 0; i < v.length; i++) {
            System.out.print(v[i] + " ");
        }
        System.out.println("");
    }

    //-------------------------------------------------------------------------------------------------------------------------//
    //-------------------------------------------------------------------------------------------------------------------------//
    //-------------------------------------------------------------------------------------------------------------------------//
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int tablero[] = new int[7], pos, quepasa = -1;

        rellenarTablero(tablero);
        colocarMosca(tablero);
        while (quepasa != 0) {
            do {

                mostrarTablero(tablero);

                System.out.println("Dime donde crees que está la mosca, de la casilla 0 a la " + (tablero.length - 1) + ".");
                pos = sc.nextInt();
                comprobar(pos, tablero);
                if (!comprobar(pos, tablero)) {
                    System.out.println("Posición incorrecta");
                }
            } while (!comprobar(pos, tablero));
            quepasa = comprobarGolpe(pos, tablero);
            switch (quepasa) {
                case 0:
                    System.out.println("Mataste a la mosca.");
                    break;
                case 1:
                    System.out.println("Estuviste cerca, la mosca se ha movido.");
                    rellenarTablero(tablero);
                    colocarMosca(tablero);
                    break;
                case 2:
                    System.out.println("La mosca no se ha enterado.");
                    break;
                default:
                    System.out.println("Ha ocurrido un error");
            }
        }
    }
}
