/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javamodulovectores.pkg7;

import java.awt.BorderLayout;
import java.util.Scanner;

/**
 *
 * @author Laura
 */
public class JavaModuloVectores7 {

    
     /*---------------------------InicializarVector------------------------------*/
    
    public static void InicializarVector(int vector[]) {
        for (int cont = 0; cont < vector.length; cont++) {
            vector[cont] = (int) (Math.random() * 100);
        }
    }

    /*---------------------------mostrarVector------------------------------*/
    
    public static void mostrarVector(int vector[]) {
        for (int cont = 0; cont < vector.length; cont++) {
            System.out.print(vector[cont] + " ");
        }
        System.out.println("");
    }

     /*---------------------------N repetido------------------------------*/
    
    public static int elRepetidoN(int vector[], int n) {
        int repetido = 0;

        for (int cont = 0; cont < vector.length; cont++) {
            if (vector[cont] == n) {
                repetido++;

            }
        }
        return repetido;
    }
/*---------------------------laposiciondeN------------------------------------*/
    public static int laposiciondeN(int vector[], int n) {
        int cont = 0;
        boolean pos = false;

        while (cont < vector.length && pos == false) {
            if (vector[cont] == n) {
                pos = true;
            }
            cont++;
        }
        if (pos == false) {
            cont = -1;
        }
        return cont;
    }
/*---------------------------ALGORITMO PRINCIPAL------------------------------------*/
    
    public static void main(String[] args) {
        int vector[] = new int[10];
        int n;
        int repetido;
        int pos;
        Scanner sc = new Scanner(System.in);

        InicializarVector(vector);
        mostrarVector(vector);

        System.out.println("Dame un numero");
        n = sc.nextInt();

        repetido = elRepetidoN(vector, n);
        pos = laposiciondeN(vector, n);

        System.out.println("el numero se ha repetido :" + repetido);
        System.out.println("La posicion del primer numero es: " + pos);

    }

}
