/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javamodularvectores.pkg6;

import java.util.Scanner;

/**
 *
 * @author laura
 */
public class JavaModularVectores6 {

    public static void InicializarVector(int vector[]) {
        for (int cont = 0; cont < vector.length; cont++) {
            vector[cont] = (int) (Math.random() * 10);
        }
    }

    public static void mostrarVector(int vector[]) {
        for (int cont = 0; cont < vector.length; cont++) {
            System.out.print(vector[cont] + " ");
        }
        System.out.println("");
    }

    public static int elRepetidoN(int vector[], int n) {
        int repetido = 0;

        for (int cont = 0; cont < vector.length; cont++) {
            if (vector[cont] == n) {
                repetido++;
            }
        }
        return repetido;
    }

    /**
     * Este módulo es el ejercicio 7.
     * @param vector
     * @param n
     * @return 
     */
    public static int posicionN(int vector[], int n) {
        int cont;
        boolean encontrado = false;

        cont = 0;                      //encontrado == false
        while (cont < vector.length && !encontrado) {
            if (vector[cont] == n) {
                encontrado = true;
            } else {
                cont++;
            }
        } 
        if (!encontrado){  //if (encontrado == false)
            cont = -1;
        }
        return cont;
    }

    public static void main(String[] args) {
        int vector[] = new int[10];
        int n;
        int repetido;
        Scanner sc = new Scanner(System.in);

        InicializarVector(vector);
        mostrarVector(vector);

        System.out.println("Dame un numero");
        n = sc.nextInt();
        repetido = elRepetidoN(vector, n);

        System.out.println("el numero se ha repetido :" + repetido);
        System.out.println("La primera posición en la que aparece es: " + posicionN(vector, n));

    }

}
