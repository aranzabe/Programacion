/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loteria;

/**
 *
 * @author Portatil Alvaro
 */
public class Loteria {

    /**
     * @param args the command line arguments
     */
    public static int numGen(int Array[]) {
        int random = (int) (1 + Math.random() * 49);
        for (int i = 0; i < Array.length; i++) {
            if (Array[i] == random) {
                return numGen(Array);
            }
        }
        return random;
    }

    public static void main(String args[]) {

        int Array[] = new int[6];
        String resultado = "";

        for (int index = 0; index < 6; index++) {
            Array[index] = numGen(Array);
        }

        for (int index = 0; index < 6; index++) {
            resultado += Array[index] + " ";
        }

        System.out.println(resultado);
    }

}
