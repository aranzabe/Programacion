/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javamodulovectores.pkg8;

/**
 *
 * @author Laura
 */
public class JavaModuloVectores8 {

    public static void Invertir(int vector[], int vectorinvertido[]) {
        int cont2 = vector.length - 1;

        for (int cont = 0; cont < vector.length; cont++) {
            vectorinvertido[cont2] = vector[cont];
            cont2--;
        }
    }
    
    public static int[] Invertir2(int [] ve) {
        int vectorinvertido[] = new int[ve.length];
        int cont2 = ve.length - 1;

        for (int cont = 0; cont < ve.length; cont++) {
            vectorinvertido[cont2] = ve[cont];
            cont2--;
        }
        return vectorinvertido;
    }
    

    
    public static void mostrarVector(int vector[]) {
        for (int cont = 0; cont < vector.length; cont++) {
            System.out.print(vector[cont] + " ");
        }
        System.out.println("");
    }

    
    
    public static void main(String[] args) {
        int vector[] = {1, 2, 3, 4, 5};
        int [] vectorinvertido = new int[5];
        

        mostrarVector(vector);
        Invertir(vector, vectorinvertido);
        //vectorinvertido = Invertir2(vector);
        mostrarVector(vectorinvertido);

    }

}
