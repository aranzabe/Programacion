/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_vectores18buscaminas;

import java.util.Scanner;

/**
 *
 * @author danijcoello
 */
public class DJC_Vectores18Buscaminas {

    /**
     * Esta función pide un valor por teclado y lo devuelve pasando por un
     * control de errores
     */
    public static int pedirTamaño() {
        int tam;
        Scanner sc = new Scanner(System.in);

        do {
            System.out.print("¿De qué tamaño quieres el tablero? ");
            tam = sc.nextInt();
            if (tam < 2) {
                System.out.println("El tablero no puede ser tan pequeño");
            }
        } while (tam < 2);
        return tam;
    }

    /**
     * Esta función pide un valor por teclado y lo devuelve pasando por un
     * control de errores
     */
    public static int pedirMinas(int tam) {
        int minas;
        Scanner sc = new Scanner(System.in);

        do {
            System.out.print("¿Cuántas minas quieres en el tablero? ");
            minas = sc.nextInt();
            if (minas >= tam) {
                System.out.println("No puedes poner tantas minas");
            } else if (minas <= 0) {
                System.out.println("Pero pon alguna mina...");
            }
        } while (minas >= tam || minas <= 0);
        return minas;
    }

    /**
     * Esta función inicia un vector con el mismo valor en todas las posiciones
     */
    public static int[] iniciarTablero(int tam, int n) {
        int v[] = new int[tam];

        for (int i = 0; i < v.length; i++) {
            v[i] = n;
        }
        return v;
    }

    /**
     * Este procedimiento pone las minas en el tablero
     */
    public static void ponerMinas(int v[], int min) {
        int ale;

        while (min > 0) {
            ale = (int) (Math.random() * v.length);
            if (v[ale] != -1) {
                v[ale] = -1;
                min--;
            }
        }
    }

    /**
     * Este procedimiento pone las pistas en el tablero
     */
    public static void ponerPistas(int v[]) {
        for (int i = 0; i < v.length; i++) {
            if (i == 0) {
                if (v[i + 1] == -1 && v[i] != -1) {
                    v[i]++;
                }
            } else if (i == v.length - 1) {
                if (v[i - 1] == -1 && v[i] != -1) {
                    v[i]++;
                }
            } else {
                if (v[i - 1] == -1 && v[i] != -1) {
                    v[i]++;
                }
                if (v[i + 1] == -1 && v[i] != -1) {
                    v[i]++;
                }
            }
        }
    }

    /**
     * Este procedimiento muestra el tablero oculto, poniendo las minas como '*'
     */
    public static void mostrarTableroOculto(int v[]) {
        for (int i = 0; i < v.length; i++) {
            if (v[i] == -1) {
                System.out.print("* ");
            } else {
                System.out.print(v[i] + " ");
            }
        }
        System.out.println("");
    }

    /**
     * Este procedimiento muestra el tablero del jugador
     */
    public static void mostrarTableroJugador(int v[]) {
        for (int i = 0; i < v.length; i++) {
            if (v[i] == -2) {
                System.out.print("- ");
            } else {
                System.out.print(v[i] + " ");
            }
        }
        System.out.println("");
    }

    /**
     * Esta función pide una casilla por teclado, incluyendo control de errores
     */
    public static int pedirCasilla(int v[]) {
        Scanner sc = new Scanner(System.in);
        int casilla;
        boolean correcto = true;

        do {
            System.out.print("¿En qué casilla quieres pisar? ");
            casilla = sc.nextInt();
            if (casilla < 0 || casilla >= v.length) {
                correcto = false;
                System.out.println("Esa casilla no está en el tablero");
            }
            if (v[casilla] != -2) {
                correcto = false;
                System.out.println("Ya habías pisado esta casilla");
            }
        } while (!correcto);
        return casilla;
    }

    /**
     * Este procedimiento es el correspondiente a cuando el jugador selecciona
     * una casilla en el buscaminas
     */
    public static boolean pisarCasilla(int tabJ[], int tabO[], int casilla) {
        boolean perdido = false;

        tabJ[casilla] = tabO[casilla];
        if (tabJ[casilla] == -1) {
            perdido = true;
        }
        return perdido;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int tabOculto[];
        int tabJug[];
        int tamaño, minas;
        int casilla, casillasDestapadas;
        boolean perdido;

        System.out.println("El buscaminas bidimensional");
        /*----------Se prepara el tablero----------*/
        tamaño = pedirTamaño();
        minas = pedirMinas(tamaño);
        tabOculto = iniciarTablero(tamaño, 0);
        ponerMinas(tabOculto, minas);
        ponerPistas(tabOculto);
        mostrarTableroOculto(tabOculto);
        casillasDestapadas = tamaño - minas;
        /*----------Empieza el juego----------*/
        tabJug = iniciarTablero(tamaño, -2);
        do {
            mostrarTableroJugador(tabJug);
            casilla = pedirCasilla(tabJug);
            perdido = pisarCasilla(tabJug, tabOculto, casilla);
            if (!perdido) {
                casillasDestapadas--;
            }
        } while (!perdido && casillasDestapadas > 0);
        
        System.out.println("El tablero oculto era el siguiente: ");
        mostrarTableroOculto(tabOculto);
        if (perdido) {
            System.out.println("Has perdido :(");
        } else {
            System.out.println("Has ganado :D");
        }
    }

}
