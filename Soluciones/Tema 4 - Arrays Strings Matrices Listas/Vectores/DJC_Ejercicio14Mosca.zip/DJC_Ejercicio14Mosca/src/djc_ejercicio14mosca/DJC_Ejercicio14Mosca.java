/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_ejercicio14mosca;

import java.util.Scanner;

/**
 *
 * @author danie
 */
public class DJC_Ejercicio14Mosca {

    /**
     * Esta función inicia un vector de 10 colocando un valor diferente (-1) al
     * resto (0) en una posición aleatoria, que devuelve como valor
     */
    public static int moscaRevolotea(int v[]) {
        int posMosca = (int) (Math.random() * 10);
        for (int i = 0; i < v.length; i++) {
            if (i == posMosca) {
                v[i] = -1;
            } else {
                v[i] = 0;
            }
        }
        return posMosca;
    }

    /**
     * Este procedimiento muestra un vector
     */
    public static void mostrarVector(int v[]) {
        for (int i = 0; i < v.length; i++) {
            System.out.print(v[i] + " ");
        }
        System.out.println("");
    }

    /**
     * Esta función pide una entrada de teclado al usuario, asegurándose de que
     * el usuario no introduce un valor incorrecto
     */
    public static int pegaZapatillazo() {
        int zapatilla;
        Scanner sc = new Scanner(System.in);

        do {
            System.out.print("Dime en qué posición quieres darle con la zapatilla (del 0 al 9): ");
            zapatilla = sc.nextInt();
            if (zapatilla < 0 || zapatilla > 9) {
                System.out.println("La mosca no puede estar tan lejos. Prueba otra vez");
            }
        } while (zapatilla < 0 || zapatilla > 9);
        return zapatilla;
    }

    /**
     * Esta función compara la posición de la mosca con la posición en la que
     * golpea el jugador, devolviendo el resultado como booleano y reiniciando
     * la posición de la mosca si se golpea en las posiciones contiguas
     */
    public static int estaEspachurrada(int mosca, int zapatilla, int v[]) {
        int caso = 0;
        if (zapatilla != mosca) {
            if (zapatilla == mosca + 1 || zapatilla == mosca - 1) {
                caso = 1;
            }
        } else {
            caso = 2;
        }
        return caso;
    }

    

    /*-------------------------------------------------------------------------------------------*/
 /*------------------------------------ALGORITMO PRINCIPAL------------------------------------*/
 /*-------------------------------------------------------------------------------------------*/
    public static void main(String[] args) {
        int intentos = 5;
        int mosca[] = new int[10];
        int posMosca, posZapatilla;
        int win;

        System.out.println("El juego de la mosca");
        System.out.println("Hay una mosca revoloteando por un vector de 10 posiciones y tienes que intentar cazarla en menos de cinco intentos");
        System.out.println("Si fallas pero la mosca está en una casilla adyacente, cambiará de posición");

        posMosca = moscaRevolotea(mosca);
        do {
            System.out.println("Tienes " + intentos + " intentos");
            //mostrarVector(mosca);
            posZapatilla = pegaZapatillazo();

            win = estaEspachurrada(posMosca, posZapatilla, mosca);
            switch (win) {
                case 0:
                    System.out.println("Ni te has acercado");
                    break;
                case 1:
                    posMosca = moscaRevolotea(mosca);
                    System.out.println("La has espantado y ha revoloteado por el vector");
                    break;                
                case 2:
                    System.out.println("Te la has cargado.");
            }
            intentos--;
        } while (intentos > 0 && win != 2);
        if (win == 2) {
            System.out.println("Has espachurrado a la mosca, ¡asesino!");
        } else {
            System.out.println("La mosca ha sido más lista que tú. Has perdido");
        }
    }

}
