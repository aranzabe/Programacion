/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javamodulovectores.pkg12;

/**
 *
 * @author Laura
 */
public class JavaModuloVectores12 {

    /*----------------------ALEATORIO---------------------------------*/
    public static void Aleatorio(int v1[], int v2[]) {

        for (int cont = 0; cont < v1.length; cont++) {
            v1[cont] = (int) (Math.random() * 3);
            v2[cont] = (int) (Math.random() * 3);
        }
    }

    /*-------------------------MOSTRAR VECTOR------------------------------*/
    public static void mostrarVector(int vector[]) {
        for (int cont = 0; cont < vector.length; cont++) {
            System.out.print(vector[cont] + " ");
        }
        System.out.println("");
    }

    /*-------------------------SUMA-----------------------------------------*/
    public static void Suma(int v1[], int v2[], int suma[]) {

        for (int cont = 0; cont < v1.length; cont++) {
            suma[cont] = v1[cont] + v2[cont];
        }
    }

    /*------------------------ALGORITMO PRINCIPAL-------------------------*/
    public static void main(String[] args) {
        int vector1[] = new int[3];
        int vector2[] = new int[3];
        int suma[] = new int[3];

        Aleatorio(vector1, vector2);
        mostrarVector(vector1);
        mostrarVector(vector2);
        Suma(vector1, vector2, suma);
        mostrarVector(suma);

    }

}
