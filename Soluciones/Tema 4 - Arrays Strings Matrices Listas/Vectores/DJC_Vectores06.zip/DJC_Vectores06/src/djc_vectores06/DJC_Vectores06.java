/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_vectores06;

import java.util.Scanner;

/**
 *
 * @author usuariob
 */
public class DJC_Vectores06 {

    public static void iniciarVector(int v[]) {
        for (int i = 0; i < v.length; i++) {
            v[i] = (int) (Math.random() * 100) + 1;
        }
    }
    
    
    public static void mostrarVector(int v[]){
        for (int i = 0; i < v.length; i++) {
            System.out.print(v[i] + " ");
        }
        System.out.println("");
    }
    
    
    public static int cuantasVeces(int n, int v[]){
        int cont = 0;
        
        for (int i = 0; i < v.length; i++) {
            if (n == v[i]) {
                cont++;
            }
        }
        return cont;
    }
    
            
    public static void main(String[] args) {
        int ale[] = new int[20];
        int num;
        Scanner sc = new Scanner(System.in);
        
        iniciarVector(ale);
        //mostrarVector(ale);
        System.out.print("Dame un número entre 1 y 100: ");
        num = sc.nextInt();
        System.out.println(num + " está repetido " + cuantasVeces(num, ale) + " veces");
    }
    
}
