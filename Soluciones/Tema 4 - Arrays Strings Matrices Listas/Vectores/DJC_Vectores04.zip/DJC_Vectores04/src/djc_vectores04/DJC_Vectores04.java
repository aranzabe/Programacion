/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_vectores04;

/**
 *
 * @author danie
 */
public class DJC_Vectores04 {
    
    public static void mostrarVector(int v[]) {
        for (int i = 0; i < v.length; i++) {
            System.out.print(v[i] + " ");
        }
        System.out.println("");
    }

    
    public static void iniciarAleatorio(int a[]) {
        for (int i = 0; i < a.length; i++) {
            a[i] = (int) (Math.random() * 10) + 1;
        }
    }

    
    public static int elMayor(int a[], int posMayor[]) {
        int numMayor = 0;

        for (int i = 0; i < a.length; i++) {
            if (a[i] >= numMayor) {
                numMayor = a[i];
                posMayor[0] = i;
            }
        }
        return numMayor;
    }
    
    
    public static int elMenor(int a[], int posMayor[]) {
        int numMayor = 0;

        for (int i = 0; i < a.length; i++) {
            if (a[i] <= numMayor) {
                numMayor = a[i];
                posMayor[0] = i;
            }
        }
        return numMayor;
    }

    /*----------------------------------------Algoritmo principal----------------------------------------*/
    public static void main(String[] args) {
        int ale[] = new int[10];
        int numMayor, posMayor[] = new int[1];

        System.out.println("Este programa crea un vector de números aleatorios y devuelve el mayor valor");
        iniciarAleatorio(ale);
        mostrarVector(ale);
        numMayor = elMayor(ale, posMayor);
        System.out.println("El valor máximo ha sido " + numMayor + ", que ocupa la posición " + posMayor[0]);

    }

}
