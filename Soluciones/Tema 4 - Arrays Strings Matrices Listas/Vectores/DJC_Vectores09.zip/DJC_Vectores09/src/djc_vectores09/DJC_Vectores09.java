/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_vectores09;

import java.util.Scanner;

/**
 *
 * @author usuariob
 */
public class DJC_Vectores09 {

    /**
     * Esta función cuenta las cifras de un número
     */
    public static int cuantasCifras(int n){
        int cifras = 0;
        
        while (n != 0){
            n = n / 10;
            cifras++;
        }
        return cifras;
    }
    
    /**
     * Esta función convierte un número en un vector compuesto por cada uno de sus dígitos
     */
    public static int[] convierteEnVector(int n, int cifras){
        int v[] = new int[cifras];
        
        for (int i = 0; i < v.length; i++) {
            v[i] = n % 10;
            n = n / 10;
        }
        return v;
    }
    
    /**
     * Esta función devuelve un vector invertido
     */
    public static int[] invertirVector(int v[]){
        int inv[] = new int[v.length];
        int j = v.length - 1;
        
        for (int i = 0; i < v.length; i++) {
            inv[i] = v[j];
            j--;
        }
        return inv;
    }
    
    /**
     * Esta función devuelve verdadero si todas las posiciones de un vector coinciden en valor
     */
    public static boolean esCapicua(int v[], int inv[]){
        boolean loEs = true;
        int i = 0;
        
        while (i < v.length && loEs) {
            if (v[i] == inv[i]){
                loEs = true;
            } else {
                loEs = false;
            }
            i++;
        }
        return loEs;
    }
    /*---------------------------------------------------------------------------*/
    /*----------------------------ALGORITMO PRINCIPAL----------------------------*/
    /*---------------------------------------------------------------------------*/
    public static void main(String[] args) {
        int num, cif;
        int numero[], invertido[];
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Este programa te dice si un número es capicúa");
        System.out.print("Dame un número: ");
        num = sc.nextInt();
        cif = cuantasCifras(num);
                
        numero = convierteEnVector(num, cif);
        invertido = invertirVector(numero);
        
        if (esCapicua(numero, invertido)){
            System.out.println(num + " es capicúa");
        } else {
            System.out.println(num + " no es capicúa");
        }
    }
    
}
