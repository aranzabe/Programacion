/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_vectores05;

/**
 *
 * @author usuariob
 */
public class DJC_Vectores05 {

    public static void iniciarVector(int v[]) {
        for (int i = 0; i < v.length; i++) {
            v[i] = (int) (Math.random() * 201) - 100;
        }
    }
    
    public static void mostrarVector(int v[]){
        for (int i = 0; i < v.length; i++) {
            System.out.print(v[i] + " ");
        }
    }
    
    public static int cuantosPositivos(int v[]){
        int positivos = 0;
        for (int i = 0; i < v.length; i++) {
            if(v[i] >= 0){
                positivos++;
            }
        }
        return positivos;
    }
    
    public static int cuantosNegativos(int v[]){
        int negativos = 0;
        for (int i = 0; i < v.length; i++) {
            if(v[i] < 0){
                negativos++;
            }
        }
        return negativos;
    }

    /*--------------------------------Algoritmo principal------------------------------*/
    public static void main(String[] args) {
        int num[] = new int[10];
        
        System.out.println("Este programa pone 10 valores aleatorios y te devuelve el número de valores positivos y negativos");
        
        iniciarVector(num);
        mostrarVector(num);
        System.out.println("");
        System.out.println("Hay " + cuantosPositivos(num) + " positivos y " + cuantosNegativos(num) + " negativos");
    }

}
