/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javamodularvectores.pkg2;

/**
 *
 * @author Laura
 */
public class JavaModularVectores2 {

    public static void mostrarVector(int v[]){
        for (int i = 0; i < v.length; i++) {
            System.out.print(v[i] + " ");
        }
        System.out.println("");
    }

    
    public static void iniciarPar(int v[]) {
        int n = 0;

        for (int cont = 0; cont < v.length; cont++) {
            v[cont] = n + 2;
            n = n + 2;
        }
    }
    
    public static void iniciarImpar(int v[]) {
        int n = 1;

        for (int cont = 0; cont < v.length; cont++) {
            v[cont] = n + 2;
            n = n + 2;
        }
    }
    
    /**
     * Inicia en base a n.
     * @param v
     * @param n 
     */
    public static void iniciar(int v[], int n){
        for (int cont = 0; cont < v.length; cont++) {
            v[cont] = n + 2;
            n = n + 2;
        }
    }

    
    public static void main(String[] args) {
        int pares[] = new int[10];
        int impares[] = new int[10];
        

//        iniciarPar(pares);
//        mostrarVector(pares);
//        iniciarImpar(impares);
//        mostrarVector(impares);

        iniciar(pares, 0);
        mostrarVector(pares);
        iniciar(impares, 1);
        mostrarVector(impares);
    }

}
