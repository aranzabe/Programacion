/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javavectores.pkg1;

/**
 *
 * @author Laura
 */
public class JavaVectores1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[] vector = new int[4];

        for (int cont = 0; cont < vector.length; cont++) {
            vector[cont] = -1;
            System.out.print(vector[cont] + "  ");
        }
        System.out.println("");

    }

}
