/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javamodularvectores.pkg3;

import java.util.Scanner;

/**
 *
 * @author Laura
 */
public class JavaModularVectores3 {

    public static void mostrarVector(float v[]) {
        for (int i = 0; i < v.length; i++) {
            System.out.print(v[i] + " ");
        }
        System.out.println("");
    }

    public static void pedirVector(float v[]) {
        Scanner sc = new Scanner(System.in);

        for (int cont = 0; cont < v.length; cont++) {
            System.out.println("Dame notas");
            v[cont] = sc.nextFloat();
        }
    }

    public static float notaMedia(float n[]) {
        int suma = 0;
        float media;

        for (int cont = 0; cont < n.length; cont++) {
            suma = (int) (n[cont] + suma);
        }
        media = (float) suma / n.length;

        return media;
    }

    public static void main(String[] args) {
        float n[] = new float[10];
        float media;

        pedirVector(n);
        mostrarVector(n);

        media = notaMedia(n);
        System.out.println("la media es: " + media);
    }

}
