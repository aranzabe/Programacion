/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_vectores10;

/**
 *
 * @author usuariob
 */
public class DJC_Vectores10 {

    /**
     * Este módulo inicia un vector con valores no repetidos entre 1 y 49
     */
    public static void iniciarVector(int v[]) {
        int i = 0;
        int j;
        boolean repetido = false;

        while (i < v.length) {
            v[i] = (int) (Math.random() * 49) + 1;

            j = 0;
            repetido = false;
            while (j < i && !repetido) {
                if (v[i] == v[j]) {
                    repetido = true;
                }
                j++;
            }
            if (!repetido) {
                i++;
            }
        }
    }

    /**
     * Este módulo muestra los valores de un vector
     */
    public static void mostrarVector(int v[]) {
        for (int i = 0; i < v.length; i++) {
            System.out.print(v[i] + " ");
        }
        System.out.println("");
    }

    /*----------------------------------------------------------------------*/
 /*------------------------ALGORITMO PRINCIPAL---------------------------*/
 /*----------------------------------------------------------------------*/
    public static void main(String[] args) {
        int primitiva[] = new int[6];

        System.out.println("Este programa da los números de la primitiva");
        iniciarVector(primitiva);
        mostrarVector(primitiva);
    }

}
