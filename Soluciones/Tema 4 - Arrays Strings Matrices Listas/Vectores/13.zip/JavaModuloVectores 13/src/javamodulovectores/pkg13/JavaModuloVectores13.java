/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javamodulovectores.pkg13;

import java.util.Scanner;

/**
 *
 * @author Laura
 */
public class JavaModuloVectores13 {

    /*--------------------------PEDIR NUMERO-----------------------------------*/
    public static void Pedirnumero(int vector[]) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Dame un numero");
        vector[0] = sc.nextInt();
    }

    /*---------------------------------SUMA-----------------------------------*/
    public static void Suma(int vector[]) {

        int cont = 1;
        int cont2 = 0;

        while (cont < vector.length) {
            vector[cont] = vector[cont2] + cont;
            cont++;
            cont2++;
 /*en el ejercicio anterior era +1, por que sumabamos 1 al siguiente
 , en este sumamos el indice, o como lo llamo yo, cont.*/
        }
    }
    /*-------------------------MOSTRAR VECTOR---------------------------------*/
    public static void mostrarVector(int vector[]) {
        for (int cont = 0; cont < vector.length; cont++) {
            System.out.print(vector[cont] + " ");
        }
        System.out.println("");
    }

    /*-------------------------ALGORITMO PRINCIPAL----------------------------*/
    public static void main(String[] args) {
        int vector[] = new int[7];

        Pedirnumero(vector);
        Suma(vector);
        mostrarVector(vector);

    }

}
