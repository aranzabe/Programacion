/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javavectores.pkg3;

import java.util.Scanner;

/**
 *
 * @author Laura
 */
public class JavaVectores3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        int vector[] = new int[10];
        int suma = 0;
        int media;
        int n;
        Scanner sc = new Scanner(System.in);

        for (int cont = 0; cont < vector.length; cont++) {
            System.out.println("Dame un numero");
            n = sc.nextInt();
            vector[cont] = n;
            suma = suma + vector[cont];
        }

        media = suma / vector.length;
        System.out.println("La media es: " + media);

    }

}
