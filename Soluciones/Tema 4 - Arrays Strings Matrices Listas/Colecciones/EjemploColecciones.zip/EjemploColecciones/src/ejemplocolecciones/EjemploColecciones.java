/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplocolecciones;

import java.util.ArrayList;
import java.util.LinkedList;

/**
 *
 * @author faranzabe
 */
public class EjemploColecciones {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList al = new ArrayList();
        LinkedList <Persona> ll = new LinkedList<Persona>();
                
        al.add(12);
        al.add('a');
        Persona p = new Persona("Laura");
        al.add(p);
        
        for (int i = 0; i < al.size(); i++) {
            System.out.println(al.get(i));
        }
        
        ll.addLast("DAW1");
        ll.addFirst(p);
        ll.addFirst(3287);
        for (int i = 0; i < ll.size(); i++) {
            System.out.println(ll.get(i));
        }
    }
    
}
