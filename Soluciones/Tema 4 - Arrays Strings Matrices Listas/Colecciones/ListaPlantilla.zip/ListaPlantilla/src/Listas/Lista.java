/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Listas;

/**
 *
 * @author faranzabe
 */
public class Lista <LAURA> {
    
    //*************************
    private class Nodo {
        private LAURA dato;
        private Nodo sig;

        public Nodo(LAURA dato) {
            this.dato = dato;
            this.sig = null;
        }
    }
    //*************************
    
    private Nodo l;

    public Lista() {
        this.l = null;
    }
    
    public void addInicio(LAURA ele){
        Nodo nuevo = new Nodo(ele);
        if (this.l == null){
            this.l = nuevo;
        }
        else {
            nuevo.sig = this.l;
            this.l = nuevo;
        }
    }
    
    @Override
    public String toString(){
        String cad = "";
        Nodo aux = this.l;
        while(aux != null){
            cad += aux.dato + " --> ";
            aux = aux.sig;
        }
        cad+="null";
        return cad;
    }
    
    
    
    
}
