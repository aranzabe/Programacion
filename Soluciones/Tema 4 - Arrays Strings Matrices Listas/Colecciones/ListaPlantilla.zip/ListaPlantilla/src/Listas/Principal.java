/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Listas;

/**
 *
 * @author faranzabe
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Lista lp = new Lista<Persona>();
        Lista li = new Lista<Integer>();
        Lista ls = new Lista<String>();
        
        lp.addInicio(new Persona("Carlos"));
        lp.addInicio(new Persona("Malena"));
        lp.addInicio(new Persona("Pablo"));
        System.out.println(lp);
        
        li.addInicio(12);
        li.addInicio(6);
        li.addInicio(62);
        System.out.println(li);
        
        ls.addInicio("Lo que sea");
        ls.addInicio("otra cosa");
        ls.addInicio("no sé qué poner");
        System.out.println(ls);
    }
    
}
