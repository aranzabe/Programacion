/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_matrices01;

/**
 *
 * @author usuariob
 */
public class DJC_Matrices01 {

    /**
     * Este procedimiento genera una matriz con valores al azar
     */
    public static void generarMatriz(int m[][]) {
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                m[i][j] = (int) (Math.random() * 100) + 1;
            }
        }
    }

    /**
     * Este procedimiento muestra una matriz
     */
    public static void mostrarMatriz(int m[][]){
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                System.out.print(m[i][j] + "  ");
            }
            System.out.println("");
        }
    }
    
    /**
     * Esta devuelve la suma de dos matrices
     */
    public static int[][] sumarMatrices(int m1[][], int m2[][]){
        int suma[][] = new int[m1.length][m1[0].length];
        
        for (int i = 0; i < m1.length; i++) {
            for (int j = 0; j < m1[0].length; j++) {
                suma[i][j] = m1[i][j] + m2[i][j];
            }
        }
        return suma;
    }
    
    /*-------------------------------------------------------------------------------------------------*/
 /*---------------------------------------ALGORITMO PRINCIPAL---------------------------------------*/
 /*-------------------------------------------------------------------------------------------------*/
    public static void main(String[] args) {
        int matriz1[][] = new int[3][4];
        int matriz2[][] = new int[3][4];
        int matrizSuma[][] = new int[3][4];

        generarMatriz(matriz1);
        System.out.println("Matriz 1:");
        mostrarMatriz(matriz1);
        generarMatriz(matriz2);
        System.out.println("Matriz 2:");
        mostrarMatriz(matriz2);
        matrizSuma = sumarMatrices(matriz1, matriz2);
        System.out.println("Suma:");
        mostrarMatriz(matrizSuma);
    }

}
