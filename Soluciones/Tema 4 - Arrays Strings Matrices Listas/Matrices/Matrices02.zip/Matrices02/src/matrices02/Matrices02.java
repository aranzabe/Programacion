/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrices02;

import java.util.Scanner;

/**
 *
 * @author danie
 */
public class Matrices02 {

    /**
     * Este procedimiento genera una matriz con valores al azar
     */
    public static void generarMatriz(int m[][]) {
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                m[i][j] = (int) (Math.random() * 50) + 1;
            }
        }
    }

    public static int[][] generarMatriz(int f, int c) {
        int m[][] = new int[f][c];
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                m[i][j] = (int) (Math.random() * 50) + 1;
            }
        }
        return m;
    }

    /**
     * Este procedimiento muestra una matriz
     */
    public static void mostrarMatriz(int m[][]) {
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                System.out.print(m[i][j] + "  ");
            }
            System.out.println("");
        }
    }

    /**
     * Este módulo pide un número por teclado
     */
    public static int pedirNumero() {
        int num;
        Scanner sc = new Scanner(System.in);

        do {
            System.out.print("Dame un número emtre 1 y 50: ");
            num = sc.nextInt();
            if (num < 1 || num > 50) {
                System.out.println("Número incorrecto");
            }
        } while (num < 1 || num > 50);
        return num;
    }

    /**
     * Este módulo devuelve como vector de dos posiciones el valor de la primera
     * ocurrencia de un número dentro de una matriz
     */
    public static int[] encontrarPrimeraOcurrencia(int m[][], int num) {
        int pos[] = new int[2]; //0-->fila  1-->col
        boolean encontrado = false;
        int i = 0, j = 0;

        while (i < m.length && !encontrado) {
            j = 0;
            while (j < m[0].length && !encontrado) {
                if (m[i][j] == num) {
                    pos[0] = i;
                    pos[1] = j;
                    encontrado = true;
                } else {
                    j++;
                }
            }
            i++;
        }
        if (!encontrado) {
            for (int k = 0; k < pos.length; k++) {
                pos[k] = -1;
            }
        }
        return pos;
    }

    /*------------------------------------------------------------------------*/
 /*----------------------------ALGORITMO PRINCIPAL----------------------------*/
 /*---------------------------------------------------------------------------*/
    public static void main(String[] args) {
        int matriz[][] = new int[3][5];
        int num;
        int pos[];

        generarMatriz(matriz);
        System.out.println("La matriz:");
        mostrarMatriz(matriz);
        num = pedirNumero();
        pos = encontrarPrimeraOcurrencia(matriz, num);
        if (pos[0] == -1) {
            System.out.println(num + " no está dentro de la matriz");
        } else {
            System.out.println("La primera ocurrencia de " + num + " está en la"
                    + "posición " + pos[0] + "," + pos[1]);
        }

    }
}
