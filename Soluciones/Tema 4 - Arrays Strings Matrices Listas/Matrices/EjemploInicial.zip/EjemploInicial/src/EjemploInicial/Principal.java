/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EjemploInicial;

/**
 *
 * @author faranzabe
 */
public class Principal {
    
    public static void mostrarMatriz(int m[][]){
        for (int i = 0; i < m.length; i++) { //Recorremos las filas. m.length --> 2
            for (int j = 0; j < m[0].length; j++) { //m[1].length --> 3
                System.out.print(m[i][j] + "  ");
            }
            System.out.println("");
        }
    }
    
    public static void generarMatriz(int m[][]){
        for (int i = 0; i < m.length; i++) { //Recorremos las filas. m.length --> 2
            for (int j = 0; j < m[0].length; j++) { //m[1].length --> 3
                m[i][j] = (int) (Math.random() * 100);
            }
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int mat[][] = new int[2][3];
        
        generarMatriz(mat);
        mostrarMatriz(mat);
    }
    
}
