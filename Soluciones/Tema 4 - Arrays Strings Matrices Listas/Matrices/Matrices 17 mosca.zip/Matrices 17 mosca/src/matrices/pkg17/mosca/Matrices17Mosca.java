/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrices.pkg17.mosca;

import java.util.Scanner;

/**
 *
 * @author alvar
 */
public class Matrices17Mosca {

    static void colocarMosca(char[][] t) {
        int v[] = new int[2];
        v[0] = (int) (Math.random() * t.length);
        v[1] = (int) (Math.random() * t[0].length);
        t[v[0]][v[1]] = '*';
    }

    static void iniciarTablero(char[][] t) {
        for (int i = 0; i < t.length; i++) {
            for (int j = 0; j < t[i].length; j++) {
                t[i][j] = '-';
            }
        }
    }

    static void mostrarMatriz(char[][] m) {
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[i].length; j++) {
                System.out.print(m[i][j] + "  ");
            }
            System.out.println("");
        }
    }

    private static int darManotazo(char[][] tablero, int f, int c) {
        int qhp = 0;
        if (tablero[f][c] == '*') {
            qhp = 2;
        } else {
            if (f - 1 >= 0 && c - 1 >= 0) {
                if (tablero[f - 1][c - 1] == '*') {
                    qhp = 1;
                }
            }
            if (f - 1 >= 0) {
                if (tablero[f - 1][c] == '*') {
                    qhp = 1;
                }
            }
            if (f - 1 >= 0 && c + 1 < tablero[0].length) {
                if (tablero[f - 1][c + 1] == '*') {
                    qhp = 1;
                }
            }
            if (c + 1 < tablero[0].length) {
                if (tablero[f][c + 1] == '*') {
                    qhp = 1;
                }
            }
            if (f + 1 < tablero.length && c + 1 < tablero[0].length) {
                if (tablero[f + 1][c + 1] == '*') {
                    qhp = 1;
                }
            }
            if (f + 1 < tablero.length) {
                if (tablero[f + 1][c] == '*') {
                    qhp = 1;
                }
            }
            if (f + 1 < tablero.length && c - 1 >= 0) {
                if (tablero[f + 1][c - 1] == '*') {
                    qhp = 1;
                }
            }
            if (c - 1 >= 0) {
                if (tablero[f][c - 1] == '*') {
                    qhp = 1;
                }
            }
        }
        return qhp;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int f, c;
        int d1, d2;
        int qhp;

        System.out.println("como de grande quieres el tablero?");
        d1 = sc.nextInt();
        d2 = sc.nextInt();
        char tablero[][] = new char[d1][d2];
        iniciarTablero(tablero);
        colocarMosca(tablero);
        do {
            mostrarMatriz(tablero);
            System.out.print("Dame la fila del manotazo: ");
            f = sc.nextInt();
            System.out.print("Dame la columna del manotazo: ");
            c = sc.nextInt();

            qhp = darManotazo(tablero, f, c);
            if (qhp == 0) {
                System.out.println("Ni te has acercado");
            }
            if (qhp == 1) {
                System.out.println("La mosca ha revoloteado. Casi le das.");
                iniciarTablero(tablero);
                colocarMosca(tablero);
            }
            if (qhp == 2) {
                System.out.println("Mosca cazada");
            }
        } while (qhp != 2);

    }

}
