/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrices.pkg2;

import java.util.Scanner;

/**
 *
 * @author laura
 */
public class Matrices2 {

//-------------------------------------GENERAR MATRIZ--------------------------
    public static void generarMatriz(int m[][]) {

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                m[i][j] = (int) (Math.random() * 10);
            }

        }

    }
//-------------------------------------MOSTRAR MATRIZ--------------------------

    public static void mostrarMatriz(int m[][]) {

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                System.out.print(m[i][j] + " ");
            }
            System.out.println("");

        }

    }
//-------------------------------------PEDIR NUMERO----------------------------

    public static int pedirNumero() {
        int n;
        Scanner sc = new Scanner(System.in);

        System.out.println("Dame un numero: ");
        n = sc.nextInt();

        return n;
    }
//-------------------------------------ENCONTRAR NUMERO INTENTO1---------------

    public static void encontrarNumero(int m[][], int n, int posiciongrafica[][], int posfila[], int poscolumna[]) {


            for (int i = 0; i < m.length; i++) {
                for (int j = 0; j < m[0].length; j++) {

                    if (n == m[i][j]) {
                        posiciongrafica[i][j] = m[i][j];
                        posfila[0] = i;
                        poscolumna[0] = j;
                    } else {
                         posiciongrafica[i][j] = 0;
                    }
                }

            }

    }

//-------------------------------------ENCONTRAR NUMERO INTENTO 2---------------
    /*public static void encontrarNumero(int m[][], int n, int posiciongrafica[][], int posfila[], int poscolumna[]) {
        
        int i = 0;
        int j = 0;
        boolean encontrado=false; 

        do {
            if (n == m[i][j]) {
                posiciongrafica[i][j] = m[i][j];
                posfila[0] = i;
                poscolumna[0] = j;
                encontrado=true;
            } else {
                i++;
                j++;
                encontrado=false;
            }
        } while (n != m[i][j] && i < m.length && j < m[0].length && !encontrado);

    }*/
    //-------------------------------------ALGORITMO PRINCIPAL------------------
    public static void main(String[] args) {
        int m[][] = new int[2][3];
        int n;
        int posiciongrafica[][] = new int[2][3];
        int posfila[] = new int[1];
        int poscolumna[] = new int[1];

        generarMatriz(m);
        mostrarMatriz(m);
        n = pedirNumero();
        encontrarNumero(m, n, posiciongrafica, posfila, poscolumna);
        mostrarMatriz(posiciongrafica);

        System.out.println("La posicion donde se encuentra el primer numero en la fila es: " + posfila[0] + " y en "
                + "la columna: " + poscolumna[0]);

    }

}
