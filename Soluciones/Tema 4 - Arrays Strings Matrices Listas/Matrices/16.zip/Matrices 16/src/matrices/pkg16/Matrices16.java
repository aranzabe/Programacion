/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrices.pkg16;

import java.util.Scanner;

/**
 *
 * @author laura
 */
public class Matrices16 {

    //----------------------------GENERAR TABLERO-----------------------------
    public static void generarTablero(char tablero[][]) {

        int suma;

        for (int i = 0; i < tablero.length; i++) {
            for (int j = 0; j < tablero[0].length; j++) {

                suma = i + j;

                if (suma % 2 == 0) {
                    tablero[i][j] = 'B';
                } else {
                    tablero[i][j] = 'N';
                }

            }

        }
    }

    //----------------------------MOSTRAR TABLERO-----------------------------
    public static void mostrarTablero(char tablero[][]) {

        for (int i = 0; i < tablero.length; i++) {
            for (int j = 0; j < tablero[0].length; j++) {

                System.out.print(tablero[i][j] + " ");

            }
            System.out.println("");

        }
    }

    //---------------------------PEDIR PIEZA------------------------------------
    public static int pedirPieza(char tablero[][]) {

        int pieza;
        Scanner sc = new Scanner(System.in);

        do {
            System.out.println("Dime la pieza que quieres mover, 1: torre, 2:alfil, 3:dama, 4:caballo");
            pieza = sc.nextInt();

            if (pieza != 1 && pieza != 2 && pieza != 3 && pieza != 4) {
                System.out.println("no has introducido lo correcto");
            }
        } while (pieza != 1 && pieza != 2 && pieza != 3 && pieza != 4);

        return pieza;
    }
//-----------------------------PEDIR POSICION FILA------------------------------

    public static int pedirPosicionFila(char tablero[][]) {

        int pos;
        Scanner sc = new Scanner(System.in);

        do {
            System.out.println("A que fila  quieres mover la pieza?");
            pos = sc.nextInt();

            if (pos > tablero.length && pos < tablero.length) {
                System.out.println("Fuera de rango del tablero");
            }
        } while (pos > tablero.length && pos < tablero.length);

        return pos;
    }

    //-----------------------------PEDIR POSICION COLUMNA-----------------------
    public static int pedirPosicionColumna(char tablero[][]) {

        int pos;
        Scanner sc = new Scanner(System.in);

        do {
            System.out.println("Y a que columna quieres mover la pieza?");
            pos = sc.nextInt();

            if (pos > tablero[0].length && pos < tablero[0].length) {
                System.out.println("Fuera de rango del tablero");
            }
        } while (pos > tablero[0].length && pos < tablero[0].length);

        return pos;
    }
//-----------------------------MOVER TORRE-----------------------------------

    public static void moverTorre(int posfila, int poscolumna, char tablero[][]) {

        for (int j = 0; j < tablero[0].length; j++) {

            tablero[posfila][j] = '*';
        }

        for (int i = 0; i < tablero.length; i++) {

            tablero[i][poscolumna] = '*';
        }

        tablero[posfila][poscolumna] = 'T';

    }
  
    //-----------------------------MOVER ALFIL-----------------------------------

    public static void moverAlfil(int posfila, int poscolumna, char tablero[][]) {

        for (int j = 0; j < tablero[0].length; j++) {

            tablero[posfila][j] = '*';
        }

        for (int i = 0; i < tablero.length; i++) {

            tablero[i][poscolumna] = '*';
        }

        tablero[posfila][poscolumna] = 'T';

    }
//-----------------------------ALGORITMO PRINCIPAL--------------------------------

    public static void main(String[] args) {

        char tablero[][] = new char[8][8];
        int posfila;
        int poscolumna;
        int pieza;

        generarTablero(tablero);
        mostrarTablero(tablero);
        pieza = pedirPieza(tablero);
        posfila = pedirPosicionFila(tablero);
        poscolumna = pedirPosicionColumna(tablero);
        // 1: torre, 2:alfil, 3:dama, 4:caballo
        if (pieza == 1) {
            moverTorre(posfila, poscolumna, tablero);
            mostrarTablero(tablero);
        }
        
         if (pieza == 2) {
            moverAlfil(posfila, poscolumna, tablero);
            mostrarTablero(tablero);
        }

        
    }

}
