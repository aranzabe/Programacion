/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrices.pkg14;

/**
 *
 * @author laura
 */
public class Matrices14 {

    //------------------------------GENERAR MATRIZ-----------------------------
    public static void generarMatriz(int m[][]) {

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {

                m[i][j] = (int) (Math.random() * 5);

            }

        }
    }
    //------------------------------MOSTRAR MATRIZ-----------------------------

    public static void mostrarMatriz(int m[][]) {

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {

                System.out.print(m[i][j] + " ");

            }

            System.out.println("");
        }

    }
    //------------------------------COMPROBAR SIMETRIA-----------------------------

    public static boolean comprobarSimetria(int m[][]) {

        boolean esSimetrica = true;

        for (int i = 0; i < m.length && esSimetrica; i++) {
            for (int j = 0; j < m[0].length; j++) {
                if (m[i][j] != m[j][i]) {
                    esSimetrica = false;
                }
            }

        }

        return esSimetrica;
    }
    //------------------------------ALGORITMO PRINCIPAL-----------------------------

    public static void main(String[] args) {
        int m[][] = new int[3][3];
        boolean esSimetrica;

        generarMatriz(m);
        mostrarMatriz(m);
        esSimetrica = comprobarSimetria(m);

        if (esSimetrica) {
            System.out.println("Es simetrica");

        } else {
            System.out.println("No es simetrica");
        }
    }

}
