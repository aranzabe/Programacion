/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrices.pkg15;

import java.util.Scanner;

/**
 *
 * @author laura
 */
public class Matrices15 {

    //------------------------------GENERAR MATRIZ-----------------------------
    public static void generarMatriz(int m[][]) {

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {

                m[i][j] = (int) (Math.random() * 5);

            }
        }
    }
    //------------------------------MOSTRAR MATRIZ-----------------------------

    public static void mostrarMatriz(int m[][]) {

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {

                System.out.print(m[i][j] + " ");

            }

            System.out.println("");
        }
    }

    
    //------------------------------INTERCAMBIAR FILAS--------------------------
    public static void intercambiarFilas(int m[][], int f1, int f2) {

        int aux;

        for (int c = 0; c < m[0].length; c++) {
            aux = m[f1][c];
            m[f1][c] = m[f2][c];
            m[f2][c] = aux;
        }
    }
    
    //------------------------------INTERCAMBIAR FILAS--------------------------
    public static void intercambiarCols(int m[][], int c1, int c2) {
        int aux;

        for (int f = 0; f < m.length; f++) {
            aux = m[f][c1];
            m[f][c1] = m[f][c2];
            m[f][c2] = aux;
        }
    }

    //------------------------------ALGORITMO PRINCIPAL-------------------------
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int m[][] = new int[4][5];
        //en 0 y 1 se deposita las filas a intercambiar, en el  y 3 las columnas
        int pos1, pos2;

        generarMatriz(m);
        mostrarMatriz(m);
        System.out.println("Dime la fila que quieres intercambiar");
        pos1 = sc.nextInt();
        System.out.println("¿Por cual la quieres intercambiar?");
        pos2 = sc.nextInt();
        //intercambiarFilas(m, pos1, pos2);
        intercambiarCols(m, pos1, pos2);
        mostrarMatriz(m);
    }

}
