/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_matrices20buscaminas;

import java.util.Scanner;

/**
 *
 * @author danie
 */
public class DJC_Matrices20Buscaminas {

    /**
     * Este módulo pide las dimensiones del tablero por teclado
     */
    public static int[] pedirDimensiones() {
        int dim[] = new int[2];
        Scanner sc = new Scanner(System.in);

        for (int i = 0; i < dim.length; i++) {
            do {
                System.out.println("Dame un valor para la " + (i + 1)
                        + "ª dimensión del tablero");
                dim[i] = sc.nextInt();
                if (dim[i] < 2) {
                    System.out.println("Tienes que darme un número mayor");
                }
            } while (dim[i] < 2);
        }
        return dim;
    }

    /**
     * Este módulo inicia el tablero oculto con todas sus casillas a 0
     */
    public static int[][] iniciarTableroO(int dim[]) {
        int m[][] = new int[dim[0]][dim[1]];

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                m[i][j] = 0;
            }
        }
        return m;
    }

    /**
     * Este módulo pide el número de minas por teclado
     */
    public static int pedirMinas(int max) {
        int n;
        Scanner sc = new Scanner(System.in);

        do {
            System.out.println("¿Cuántas minas quieres poner en el tablero?");
            n = sc.nextInt();
            if (n < 1) {
                System.out.println("Tienes que poner más minas");
            }
            if (n >= max) {
                System.out.println("No puedes poner tantas minas");
            }
        } while (n < 1 || n >= max);
        return n;
    }

    /**
     * Este módulo pone las minas en posiciones al azar
     */
    public static void ponerMinas(int minas, int m[][]) {
        int aleF, aleC;

        while (minas > 0) {
            aleF = (int) (Math.random() * m.length);
            aleC = (int) (Math.random() * m[0].length);
            if (m[aleF][aleC] != -1) {
                m[aleF][aleC] = -1;
                minas--;
            }
        }
    }

    /**
     * Este módulo pone pistas numéricas sobre el tablero
     */
    public static void ponerPistas(int m[][]) {
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                if (m[i][j] != -1) {
                    if (i - 1 >= 0 && j - 1 >= 0) {
                        if (m[i - 1][j - 1] == -1) {
                            m[i][j]++;
                        }
                    }
                    if (i - 1 >= 0) {
                        if (m[i - 1][j] == -1) {
                            m[i][j]++;
                        }
                    }
                    if (i - 1 >= 0 && j + 1 < m[0].length) {
                        if (m[i - 1][j + 1] == -1) {
                            m[i][j]++;
                        }
                    }
                    if (j + 1 < m[0].length) {
                        if (m[i][j + 1] == -1) {
                            m[i][j]++;
                        }
                    }
                    if (i + 1 < m.length && j + 1 < m[0].length) {
                        if (m[i + 1][j + 1] == -1) {
                            m[i][j]++;
                        }
                    }
                    if (i + 1 < m.length) {
                        if (m[i + 1][j] == -1) {
                            m[i][j]++;
                        }
                    }
                    if (i + 1 < m.length && j - 1 >= 0) {
                        if (m[i + 1][j - 1] == -1) {
                            m[i][j]++;
                        }
                    }
                    if (j - 1 >= 0) {
                        if (m[i][j - 1] == -1) {
                            m[i][j]++;
                        }
                    }
                }
            }
        }
    }

    /**
     * Este módulo inicia el tablero del jugador con cada casilla a -2
     */
    public static int[][] iniciarTableroJ(int dim[]) {
        int m[][] = new int[dim[0]][dim[1]];

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                m[i][j] = -2;
            }
        }
        return m;
    }

    /**
     * Este módulo muestra el tablero
     */
    public static void mostrarTablero(int m[][]) {
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                switch (m[i][j]) {
                    case -2:
                        System.out.print("-  ");
                        break;
                    case -1:
                        System.out.print("*  ");
                        break;
                    default:
                        System.out.print(m[i][j] + "  ");
                }
            }
            System.out.println("");
        }
    }

    /**
     * Este módulo pide una casilla al jugador
     */
    public static int pedirCasilla(int dim[], int tipo) {
        int casilla;
        Scanner sc = new Scanner(System.in);

        switch (tipo) {
            case 1:
                System.out.print("Elige una fila: ");
                break;
            case 2:
                System.out.print("Elige una columna: ");
                break;
        }
        casilla = sc.nextInt();
        return casilla;
    }

    /**
     * Este módulo transfiere una casilla del tablero oculto al tablero del
     * jugador
     */
    public static boolean comprobarCasilla(int f, int c, int tabO[][], int tabJ[][]) {
        boolean explotado = false;

        tabJ[f][c] = tabO[f][c];
        if (tabJ[f][c] == -1) {
            explotado = true;
        }
        return explotado;
    }

    /*------------------------------------------------------------------------*/
 /*---------------------------ALGORITMO PRINCIPAL-----------------------------*/
 /*---------------------------------------------------------------------------*/
    public static void main(String[] args) {
        int dim[];
        int tableroOculto[][], tableroJugador[][];
        int minas, casillasRestantes;
        int f, c;
        boolean explotado;

        dim = pedirDimensiones();
        tableroOculto = iniciarTableroO(dim);
        minas = pedirMinas(dim[0] * dim[1]);
        casillasRestantes = (dim[0] * dim[1]) - minas;
        ponerMinas(minas, tableroOculto);
        ponerPistas(tableroOculto);
        tableroJugador = iniciarTableroJ(dim);
        do {
            //mostrarTablero(tableroOculto);
            System.out.println("Tu tablero:");
            mostrarTablero(tableroJugador);
            f = pedirCasilla(dim, 1);
            c = pedirCasilla(dim, 2);
            explotado = comprobarCasilla(f, c, tableroOculto, tableroJugador);
            if (!explotado) {
                casillasRestantes--;
            }
        } while (casillasRestantes > 0 && !explotado);
        
        if (casillasRestantes == 0) {
            System.out.println("Enhorabuena, has ganado");
        } else {
            System.out.println("Has pisado una mina :(");
            System.out.println("El tablero era el siguiente:");
            mostrarTablero(tableroOculto);
        }
    }

}
