/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrices16;

import java.util.Scanner;

/**
 *
 * @author Sergio
 */
public class Matrices16 {

    static void iniciarTablero(char m[][]) {
        int suma;
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[i].length; j++) {
                suma = i + j;
                if (suma % 2 == 0) {
                    m[i][j] = 'b';
                } else {
                    m[i][j] = 'n';
                }
            }
        }
    }

    static void mostrarTablero(char m[][]) {
        //Inicio
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[i].length; j++) {
                System.out.print(m[i][j] + " | ");
            }
            System.out.println(" ");
        }
    }

    static void colocarAlfil(char tablero[][], int lugar[]) {
        int i = lugar[0], j = lugar[1];
        while (i >= 0 && j >= 0) {
            tablero[i][j] = '*';
            i--;
            j--;
        }
        i = lugar[0];
        j = lugar[1];
        while (i < tablero.length && j >= 0) {
            tablero[i][j] = '*';
            i++;
            j--;
        }
        i = lugar[0];
        j = lugar[1];
        while (i >= 0 && j < tablero.length) {
            tablero[i][j] = '*';
            i--;
            j++;

        }
        i = lugar[0];
        j = lugar[1];
        while (i < tablero.length && j < tablero.length) {
            tablero[i][j] = '*';
            i++;
            j++;
        }
        tablero[lugar[0]][lugar[1]] = 'a';
    }

    static void colocarTorre(char tablero[][], int lugar[]) {
        int i = lugar[0], j = lugar[1];
        while (i >= 0) {
            tablero[i][j] = '*';
            i--;
        }
        i = lugar[0];
        j = lugar[1];
        while (j >= 0) {
            tablero[i][j] = '*';
            j--;
        }
        i = lugar[0];
        j = lugar[1];
        while (j < tablero.length) {
            tablero[i][j] = '*';
            j++;

        }
        i = lugar[0];
        j = lugar[1];
        while (i < tablero.length) {
            tablero[i][j] = '*';
            i++;
        }
        tablero[lugar[0]][lugar[1]] = 't';
    }

    static void colocarDama(char tablero[][], int lugar[]) {
        int i = lugar[0], j = lugar[1];
        colocarAlfil(tablero, lugar);
        colocarTorre(tablero, lugar);
        tablero[lugar[0]][lugar[1]] = 'd';
    }

    static void colocarCaballo(char tablero[][], int lugar[]) {
        int i = lugar[0], j = lugar[1];
        if (i - 1 >= 0 && j - 2 >= 0) {
            i--;
            j = j - 2;
            tablero[i][j] = '*';

        }
        i = lugar[0];
        j = lugar[1];
        if (i - 2 >= 0 && j - 1 >= 0) {
            i = i - 2;
            j--;
            tablero[i][j] = '*';
        }
        i = lugar[0];
        j = lugar[1];
        if (i - 2 >= 0 && j + 1 < tablero.length) {
            i = i - 2;
            j++;
            tablero[i][j] = '*';

        }
        i = lugar[0];
        j = lugar[1];
        if (i + 1 < tablero.length && j - 2 >= 0) {
            i++;
            j = j - 2;
            tablero[i][j] = '*';
        }
        i = lugar[0];
        j = lugar[1];
        if (i - 1 >= 0 && j + 2 < tablero.length) {
            i--;
            j = j + 2;
            tablero[i][j] = '*';
        }
        i = lugar[0];
        j = lugar[1];
        if (i + 2 < tablero.length && j - 1 >= 0) {
            i = i + 2;
            j--;
            tablero[i][j] = '*';
        }
        i = lugar[0];
        j = lugar[1];
        if (i + 1 < tablero.length && j + 2 < tablero.length) {
            i++;
            j = j + 2;
            tablero[i][j] = '*';
        }
        i = lugar[0];
        j = lugar[1];
        if (i + 2 < tablero.length && j + 1 < tablero.length) {
            i = i + 2;
            j++;
            tablero[i][j] = '*';
        }
        tablero[lugar[0]][lugar[1]] = 'c';
    }

    public static void main(String[] args) {
        char tablero[][] = new char[8][8];
        int lugar[] = new int[2];
        Scanner sc = new Scanner(System.in);

        System.out.println("1. Alfil | 2. Torre | 3. Dama | 4. Caballo | 5. Salir");
        iniciarTablero(tablero);
        mostrarTablero(tablero);
        System.out.println("¿En qué posición quieres colocar el alfil? (Ej: 1,3)");
        lugar[0] = sc.nextInt();
        lugar[1] = sc.nextInt();
        colocarAlfil(tablero, lugar);
        mostrarTablero(tablero);
        System.out.println("----------------------------------");
        iniciarTablero(tablero);
        mostrarTablero(tablero);
        System.out.println("¿En qué posición quieres colocar la torre? (Ej: 1,3)");
        lugar[0] = sc.nextInt();
        lugar[1] = sc.nextInt();
        colocarTorre(tablero, lugar);
        mostrarTablero(tablero);
        System.out.println("----------------------------------");
        iniciarTablero(tablero);
        mostrarTablero(tablero);
        System.out.println("¿En qué posición quieres colocar la dama? (Ej: 1,3)");
        lugar[0] = sc.nextInt();
        lugar[1] = sc.nextInt();
        colocarDama(tablero, lugar);
        mostrarTablero(tablero);
        System.out.println("----------------------------------");
        iniciarTablero(tablero);
        mostrarTablero(tablero);
        System.out.println("¿En qué posición quieres colocar el caballo? (Ej: 1,3)");
        lugar[0] = sc.nextInt();
        lugar[1] = sc.nextInt();
        colocarCaballo(tablero, lugar);
        mostrarTablero(tablero);
    }

}
