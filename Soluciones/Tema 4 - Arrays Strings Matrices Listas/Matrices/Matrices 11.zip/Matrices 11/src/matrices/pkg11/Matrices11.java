/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrices.pkg11;

/**
 *
 * @author laura
 */
public class Matrices11 {

    //--------------------------GENERAR MATRIZ------------------------------
    public static void generarMatriz(int m[][]) {

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {

                m[i][j] = (int) (Math.random() * 10);

            }

        }
    }

    //--------------------------MOSTRAR MATRIZ------------------------------
    public static void mostrarMatriz(int m[][]) {

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {

                System.out.print(m[i][j] + " ");

            }
            System.out.println("");

        }
    }

    //--------------------------SUMAR DIAGONALES------------------------------
    public static void sumarDiagonales(int m[][], int suma[]) {
        int i = 0;
        int j = 0;

        while (i < m.length) {
            suma[0] = suma[0] + m[i][i];
            i++;
        }

        i = 0;
        j = m[0].length - 1;

        while (j >= 0) {

            suma[1] = suma[1] + m[i][j];
            i++;
            j--;
        }
    }

    //--------------------------ALGORITMO PRINCIPAL-----------------------------
    public static void main(String[] args) {
        int m[][] = new int[3][3];
        //0 Para la diagonal que va desde la parte superior izquierda hasta la parte inferior derecha
        //1 Para la diagonal que va desde la parte superior derecha hasta la parte inferior izquierda
        int suma[] = new int[2];

        generarMatriz(m);
        mostrarMatriz(m);
        sumarDiagonales(m, suma);

        System.out.println("la suma de una diagonal es: " + suma[0] + " la otra suma de la otra diagonal es " + suma[1]);

    }

}
