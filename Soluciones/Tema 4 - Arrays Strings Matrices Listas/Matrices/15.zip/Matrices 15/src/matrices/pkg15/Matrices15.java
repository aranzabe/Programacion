/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrices.pkg15;

import java.util.Scanner;

/**
 *
 * @author laura
 */
public class Matrices15 {

    //------------------------------GENERAR MATRIZ-----------------------------
    public static void generarMatriz(int m[][]) {

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {

                m[i][j] = (int) (Math.random() * 5);

            }
        }
    }
    //------------------------------MOSTRAR MATRIZ-----------------------------

    public static void mostrarMatriz(int m[][]) {

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {

                System.out.print(m[i][j] + " ");

            }
            
            System.out.println("");
        }
    }
    
    //---------------------PEDIR INTERCAMBIO FILAS A USUARIO--------------------

    public static void pedirIntercambioFilasUsuario(int m[][], int intercambio[]) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Dime la fila que quieres intercambiar");
        intercambio[0] = sc.nextInt();
        System.out.println("¿Por cual la quieres intercambiar?");
        intercambio[1] = sc.nextInt();
    }

    
    //------------------PEDIR INTERCAMBIO COLUMNAS A USUARIO--------------------
    public static void pedirIntercambioColumnasUsuario(int m[][], int intercambio[]) {

        Scanner sc = new Scanner(System.in);
        boolean intercambioColumna = false;

        System.out.println("¿Quieres intercambiar tambien dos columnas? true/false");
        intercambioColumna = sc.nextBoolean();

        if (intercambioColumna) {
            System.out.println("Dime que columna quieres cambiar");
            intercambio[2] = sc.nextInt();
            System.out.println("¿Por cual la quieres cambiar?");
            intercambio[3] = sc.nextInt();
            intercambioColumna = false;
        }

    }

    //------------------------------INTERCAMBIAR FILAS--------------------------
    public static void intercambiarFilas(int m[][], int intercambio[]) {

        int guardar[][] = new int[m.length][m[0].length];

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {

                guardar[intercambio[1]][j] = m[intercambio[1]][j];
                m[intercambio[1]][j] = m[intercambio[0]][j];
                m[intercambio[0]][j] = guardar[intercambio[1]][j];

            }
        }
    }

    //------------------------------ALGORITMO PRINCIPAL-------------------------
    public static void main(String[] args) {
        int m[][] = new int[2][3];
        //en 0 y 1 se deposita las filas a intercambiar, en el  y 3 las columnas
        int intercambio[] = new int[4];

        generarMatriz(m);
        mostrarMatriz(m);
        pedirIntercambioFilasUsuario(m, intercambio);
        pedirIntercambioColumnasUsuario(m, intercambio);
        intercambiarFilas(m, intercambio);
        mostrarMatriz(m);
    }

}
