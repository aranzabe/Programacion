/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_matrices10;

import java.util.Scanner;

/**
 *
 * @author usuariob
 */
public class DJC_Matrices10 {

    /**
     * Este módulo pide la dimensión de la matriz, con control de errores
     */
    public static int pedirDimension() {
        int dim;
        Scanner sc = new Scanner(System.in);

        do {
            System.out.println("Dime de qué dimensión quieres la matriz. Tiene que ser mayor que 1:");
            dim = sc.nextInt();
            if (dim < 2) {
                System.out.println("Número incorrecto");
            }
        } while (dim < 2);
        return dim;
    }

    /**
     * Este módulo genera una matriz de una dimensión dada con valores
     * aleatorios del 1 al 10
     */
    public static int[][] generarMatriz(int dim) {
        int m[][] = new int[dim][dim];

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                m[i][j] = (int) ((Math.random() * 10) + 1);
            }
        }
        return m;
    }

    /**
     * Este módulo muestra una matriz en pantalla
     */
    public static void mostrarMatriz(int m[][]) {
        System.out.println("Matriz:");
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                System.out.print(m[i][j] + "  ");
            }
            System.out.println("");
        }
    }

    /**
     * Este módulo almacena en un vector la suma de los valores de cada fila de
     * una matriz dada
     */
    public static int[] sumarFilas(int m[][]){
        int suma[] = new int[m.length];
        
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                suma[i] = suma[i] + m[i][j];
            }
        }
        return suma;
    }
    
    /**
     * Este módulo almacena en un vector la suma de los valores de cada fila de
     * una matriz dada
     */
    public static int[] sumarColumnas(int m[][]){
        int suma[] = new int[m[0].length];
        
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                suma[j] = suma[j] + m[i][j];
            }
        }
        return suma;
    }
    
    /**
     * Este módulo muestra un vector
     */
    public static void mostrarVector(int v[]){
        for (int i = 0; i < v.length; i++) {
            System.out.print(v[i] + " ");
        }
        System.out.println("");
    }
    
    /**
     * Este módulo almacena en un vector la suma de los valores de cada fila de
     * una matriz dada
     */
    public static void sumarFilasColumnas(int m[][], int sumaF[], int sumaC[]){
        
        
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                sumaC[j] = sumaC[j] + m[i][j];
                sumaF[i] = sumaF[i] + m[i][j];
            }
        }
    }
    
    /*------------------------------------------------------------------------*/
 /*----------------------------ALGORITMO PRINCIPAL----------------------------*/
 /*---------------------------------------------------------------------------*/
    public static void main(String[] args) {
        int dim;
        int matriz[][];
        int sumaF[], sumaC[];

        dim = pedirDimension();
        matriz = generarMatriz(dim);
        mostrarMatriz(matriz);
        sumaF = sumarFilas(matriz);
        System.out.println("Sumas de las filas:");
        mostrarVector(sumaF);
        sumaC = sumarColumnas(matriz);
        System.out.println("Sumas de las columnas:");
        mostrarVector(sumaC);
    }

}
