/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_matrices03;

/**
 *
 * @author usuariob
 */
public class DJC_Matrices03 {

    /**
     * Este módulo genera una matriz con números aleatorios entre 1 y 100
     */
    public static void generarMatriz(int m[][]){
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                m[i][j] = (int) (Math.random() * 100) + 1;
            }
        }
    }
    
    /**
     * Este módulo muestra una matriz
     */
    public static void mostrarMatriz(int m[][]){
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                System.out.print(m[i][j] + "  ");
            }
            System.out.println("");
        }
    }
    
    /**
     * Este módulo devuelve el número de pares que hay en una matriz
     */
    public static int encontrarPares(int m[][]){
        int pares = 0;
        
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                if (m[i][j] % 2 == 0){
                    pares++;
                }
            }
        }
        return pares;
    }
    /*------------------------------------------------------------------------*/
 /*----------------------------ALGORITMO PRINCIPAL----------------------------*/
 /*---------------------------------------------------------------------------*/
    public static void main(String[] args) {
        int matriz[][] = new int [3][5];
        int pares;
        
        generarMatriz(matriz);
        System.out.println("Matriz:");
        mostrarMatriz(matriz);
        pares = encontrarPares(matriz);
        System.out.println("Hay " + pares + " números pares en la matriz");
    }
    
}
