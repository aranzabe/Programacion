/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrices.pkg5;

/**
 *
 * @author laura
 */
public class Matrices5 {

    //-----------------------------GENERAR MATRIZ------------------------------
    public static void generarMatriz(int m[][]) {

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                m[i][j] = (int) (Math.random() * 10);

            }

        }
    }
    //-----------------------------MOSTRAR MATRIZ------------------------------

    public static void mostrarMatriz(int m[][]) {

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                System.out.print(m[i][j] + " ");
            }
            System.out.println("");

        }
    }

    //-----------------------------GENERAR MAX Y MIN ------------------------------
    public static void mostrarMaximoyMinimo(int m[][], int numero[]) {
        
        numero[1] = m[0][0];
        
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {

                if (numero[0] < m[i][j]) {
                    numero[0] = m[i][j];
                }
                if (numero[1] > m[i][j]) {
                    numero[1] = m[i][j];
                }

            }

        }

    }
    //-----------------------------GENERAR SUMA TOTAL------------------------------

    public static int hacerSumaTotal(int m[][], int cont[]) {
        int suma = 0;

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {

                suma = suma + m[i][j];
                cont[0]++;
            }
        }

        return suma;
    }
    //-----------------------------GENERAR MEDIA------------------------------

    public static float hacerMediaTotal(int m[][], int cont[], int suma) {
        float media;

        media = (float) suma / cont[0];

        return media;
    }

    //-----------------------------ALGORITMO PRINCIPAL------------------------------
    public static void main(String[] args) {
        int m[][] = new int[2][3];
        int suma;
        float media;
        int cont[] = new int[1];
        //en numeroMaxyMin[0] se almacena el maximo y en numeroMaxyMin[1]el minimo
        int numeroMaxyMin[] = new int[2];

        generarMatriz(m);
        mostrarMatriz(m);
        mostrarMaximoyMinimo(m, numeroMaxyMin);
        suma = hacerSumaTotal(m, cont);
        media = hacerMediaTotal(m, cont, suma);

        System.out.println("*El numero maximo es: " + numeroMaxyMin[0] + " y el minimo es " + numeroMaxyMin[1]);
        System.out.println("*La suma total es: " + suma + " y hay " + cont[0] + " numeros");
        System.out.println("*Entonces, la media total es: " + media);
    }

}
