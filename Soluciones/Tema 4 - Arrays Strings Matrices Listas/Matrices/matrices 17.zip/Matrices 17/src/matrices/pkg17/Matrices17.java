/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrices.pkg17;

import java.util.Scanner;

/**
 *
 * @author laura
 */
public class Matrices17 {

//--------------------------------GENERAR PANEL OCULTO----------------------
    public static void generarPanelOculto(char panel[][]) {

        for (int i = 0; i < panel.length; i++) {
            for (int j = 0; j < panel[0].length; j++) {
                panel[i][j] = '*';

            }

        }

    }
//--------------------------------ELEGIR POSICION MOSCA----------------------

    public static void elegirPosicionMosca(char panel[][], int posicion[]) {

        //0 fila, 1 columna
        posicion[0] = (int) (Math.random() * panel.length);
        posicion[1] = (int) (Math.random() * panel.length);

    }
//--------------------------------MOSTRAR VECTOR----------------------

    public static void mostrarVector(int posicion[]) {

        for (int i = 0; i < posicion.length; i++) {

            System.out.println(posicion[i] + " ");
        }
        System.out.println("");
    }
//--------------------------------POSICIONAR MOSCA----------------------

    public static void posicionarMosca(char panel[][], char mosca, int posicion[]) {

        panel[posicion[0]][posicion[1]] = mosca;

    }
//--------------------------------MOSTRAR PANEL----------------------

    public static void mostrarPanel(char panel[][]) {

        for (int i = 0; i < panel.length; i++) {
            for (int j = 0; j < panel[0].length; j++) {

                System.out.print(panel[i][j] + " ");

            }
            System.out.println("");

        }
    }

    //--------------------------------COMPROBAR RESULTADOS----------------------
    public static int comprobarResultados(int f, int c, char panel[][], char mosca) {

        int resultado = 0;
        int i = f;
        int j = c;

        //RESULTADO GANADOR
        if (panel[f][c] == 'M') {
            resultado = 1;
            //RESULTADO DE HABER ESTADO CERCA
        } else {
            while (i < panel.length && j < panel[0].length) {
                if (panel[i][j] == 'M') {
                    resultado = 2;
                }
                i++;
                j++;
            }
            i = f;
            j = c;

            while (j < panel[0].length) {
                if (panel[i][j] == 'M') {
                    resultado = 2;
                }
                j++;
            }

            i = f;
            j = c;

            while (i >= 0 && j < panel[0].length) {
                if (panel[i][j] == 'M') {
                    resultado = 2;
                }
                i--;
                j++;
            }

            i = f;
            j = c;

            while (i < panel.length) {
                if (panel[i][j] == 'M') {
                    resultado = 2;
                }
                i++;
            }

            i = f;
            j = c;

            while (i >= 0) {
                if (panel[i][j] == 'M') {
                    resultado = 2;
                }
                i--;

            }

            i = f;
            j = c;

            while (j >= 0) {
                if (panel[i][j] == 'M') {
                    resultado = 2;
                }
                j--;
            }

            i = f;
            j = c;

            while (i >= 0 && j >= 0) {
                if (panel[i][j] == 'M') {
                    resultado = 2;
                }
                i--;
                j--;
            }

            i = f;
            j = c;

            while (i < panel.length && j >= 0) {
                if (panel[i][j] == 'M') {
                    resultado = 2;
                }
                i++;
                j--;
            }

        }
        
         //RESULTADO DE HABER ESTADO LEJOS
        if (resultado != 1 && resultado != 2) {
            resultado = 3;
        }

        return resultado;
    }

//--------------------------------ALGORITMO PRINCIPAL---------------------------
    public static void main(String[] args) {
        char panelOculto[][] = new char[4][4];
        int posicionMosca[] = new int[2];
        int resultado;
        char mosca = 'M';
        int f;
        int c;
        int cont = 0;
        Scanner sc = new Scanner(System.in);

        generarPanelOculto(panelOculto);
        elegirPosicionMosca(panelOculto, posicionMosca);
        //mostrarVector(posicionMosca);
        posicionarMosca(panelOculto, mosca, posicionMosca);
        mostrarPanel(panelOculto);

        do {
            System.out.println("¿En que fila crees que esta la mosca?");
            f = sc.nextInt();
            System.out.println("¿Y que columna?");
            c = sc.nextInt();

            resultado = comprobarResultados(f, c, panelOculto, mosca);

            if (resultado == 1) {
                System.out.println("Has ganado");

            }
            if (resultado == 2) {
                System.out.println("Uy, muy cerca has estado de atraparla... esta se ira a otro sitio");
                generarPanelOculto(panelOculto);
                elegirPosicionMosca(panelOculto, posicionMosca);
                posicionarMosca(panelOculto, mosca, posicionMosca);
                cont++;

            }
            if (resultado == 3) {
                System.out.println("Ni te has acercado");
                cont++;
            }

            if (cont == 6) {
                System.out.println("Has perdido la mosca estaba: ");
                mostrarPanel(panelOculto);
            }

        } while (cont < 6 && resultado != 1);

    }

}
