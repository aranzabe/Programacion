/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejer14_mat;

import java.util.Scanner;

/**
 *
 * @author Malena
 */
public class Ejer14_mat {

    /*Escribir un programa que lea una matriz A de dimensión N x N y compruebe si es
    o no simétrica. Una matriz se dice que es simétrica si A i,j = A j,i para todo i, j dentro de
    los límites de la matriz.*/
    
    public static void generarMatriz (int m[][]){
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                m[i][j] = (int) (Math.random() * 10);
            }
        }
    }
    
    public static void mostrarMatriz (int m[][]){
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                System.out.print(m[i][j] + " ");
            }
            System.out.println("");
        }
    }
    
    public static boolean esSimetrica (int m[][]){
        boolean simetrica = true;
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                if (m[i][j] != m[j][i]){
                    simetrica = false;
                }
            }   
        }
        return simetrica;
    }
    public static void main(String[] args) {
//        int matriz [][] = new int [3][3];
        int matriz[][] = {{5,1,3},{1,8,2},{3,2,5}};
        boolean simetr;
        Scanner sc = new Scanner (System.in);
        
        System.out.println("Vamos a comprobar si la matriz es simetrica");
        //generarMatriz (matriz);
        mostrarMatriz (matriz);
        simetr = esSimetrica (matriz);
        if (simetr){
            System.out.println("La matriz es simetrica.");
        } else {
            System.out.println("Esta matriz no es simetrica.");
        }
    }
}
