/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrices.pkg16.ajedrez;

import java.util.Scanner;

/**
 *
 * @author alvar
 */
public class Matrices16Ajedrez {

    static void rellenarMatriz(char[][] m) {
        
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[i].length; j++) {
                if ((i + j) % 2 == 0) {
                    m[i][j] = 'b';
                }else{
                    m[i][j] = 'n';
                }
            }
        }
    }
    
    static void mostrarMatriz(char[][] m) {
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[i].length; j++) {
                System.out.print(m[i][j] + "  ");
            }
            System.out.println("");
        }
    }
    
    static void colocarTorre(char[][] m, int p1, int p2) {
        int aux1 = p1, aux2 = p2;
        
        m[p1][p2] = 'T';
        
        while (p1 > 0) {
            p1--;
            m[p1][p2] = '*';
        }
        p1 = aux1;
        while (p2 > 0) {
            p2--;
            m[p1][p2] = '*';
        }
        p2 = aux2;
        while (p1 < m.length - 1) {
            p1++;
            m[p1][p2] = '*';
        }
        p1 = aux1;
        while (p2 < m.length - 1) {
            p2++;
            m[p1][p2] = '*';
        }
    }
    
    static void colocarAlfil(char[][] m, int p1, int p2) {
        int aux1 = p1, aux2 = p2;
        
        m[p1][p2] = 'A';
        
        while (p1 > 0 && p2 > 0) {
            p1--;
            p2--;
            m[p1][p2] = '*';
        }
        p1 = aux1;
        p2 = aux2;
        
        while (p1 > 0 && p2 < m.length - 1) {
            p1--;
            p2++;
            m[p1][p2] = '*';
        }
        p1 = aux1;
        p2 = aux2;
        
        while (p1 < m.length - 1 && p2 < m.length - 1) {
            p1++;
            p2++;
            m[p1][p2] = '*';
        }
        p1 = aux1;
        p2 = aux2;
        
        while (p1 < m.length - 1 && p2 > 0) {
            p1++;
            p2--;
            m[p1][p2] = '*';
        }
    }
    
    static void colocarDama(char[][] m, int p1, int p2) {
        colocarTorre(m, p1, p2);
        colocarAlfil(m, p1, p2);
        m[p1][p2] = 'D';
    }
    
    static void colocarCaballo(char[][] m, int p1, int p2) {
        m[p1][p2] = 'C';
        if (p1 - 1 > 0 && p2 - 2 > 0) {
            m[p1-1][p2-2] = '*';
        }
        
        if (p1 - 2 > 0 && p2 - 1 > 0) {
            m[p1-2][p2-1] = '*';
        }
        
        if (p1 + 2 < m.length - 1 && p2 - 1 > 0) {
            m[p1+2][p2-1] = '*';
        }
        
        if (p1 + 2 < m.length - 1 && p2 + 1 < m.length - 1) {
            m[p1+2][p2+1] = '*';
        }
        
        if (p1 + 1 < m.length - 1 && p2 + 2 < m.length - 1) {
            m[p1+1][p2+2] = '*';
        }
        
        if (p1 + 1 < m.length - 1 && p2 - 2 > 0) {
            m[p1+1][p2-2] = '*';
        }
        
        if (p1 - 2 > 0 && p2 + 1 < m.length - 1) {
            m[p1-2][p2+1] = '*';
        }
        
        if (p1 - 1 > 0 - 1 && p2 + 2 < m.length - 1) {
            m[p1-1][p2+2] = '*';
        }
        
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        char opcion, m[][] = new char[8][8];
        int p1, p2;
        
        rellenarMatriz(m);
        mostrarMatriz(m);
        System.out.println("Que pieza quieres colocar? t = torre. a = alfil. d = dama. c = caballo.");
        opcion = sc.next().charAt(0);
        System.out.println("En qué posición quieres poner la pieza? de la 0 a la 7");
        p1= sc.nextInt();
        p2= sc.nextInt();
        switch (opcion) {
            case 't':
                colocarTorre(m, p1, p2);
                mostrarMatriz(m);
                break;
            case 'a':
                colocarAlfil(m, p1, p2);
                mostrarMatriz(m);
                break;
            case 'd':
                colocarDama(m, p1, p2);
                mostrarMatriz(m);
                break;
            case 'c':
                colocarCaballo(m, p1, p2);
                mostrarMatriz(m); 
                break;
            default: System.out.println("Opción incorrecta.");
        }
        System.out.println("Hasta pronto.");
    }
    
}
