/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_matrices11;

import java.util.Scanner;

/**
 *
 * @author usuariob
 */
public class DJC_Matrices11 {

    /**
     * Este módulo pide la dimensión de la matriz, con control de errores
     */
    public static int pedirDimension() {
        int dim;
        Scanner sc = new Scanner(System.in);

        do {
            System.out.println("Dime de qué dimensión quieres la matriz. Tiene que ser mayor que 1:");
            dim = sc.nextInt();
            if (dim < 2) {
                System.out.println("Número incorrecto");
            }
        } while (dim < 2);
        return dim;
    }

    /**
     * Este módulo genera una matriz de una dimensión dada con valores
     * aleatorios del 1 al 10
     */
    public static int[][] generarMatriz(int dim) {
        int m[][] = new int[dim][dim];

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                m[i][j] = (int) ((Math.random() * 10) + 1);
            }
        }
        return m;
    }

    /**
     * Este módulo muestra una matriz en pantalla
     */
    public static void mostrarMatriz(int m[][]) {
        System.out.println("Matriz:");
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                System.out.print(m[i][j] + "  ");
            }
            System.out.println("");
        }
    }

    /**
     * Este módulo almacena en un vector los valores de la suma de cada diagonal
     */
    public static int[] sumarDiagonal(int m[][]) {
        int suma[] = new int[2];
        int i, j;

        for (i = 0; i < m.length; i++) {
            suma[0] = suma[0] + m[i][i];
        }

        i = 0;
        for (j = (m[0].length - 1); j >= 0; j--) {
            suma[1] = suma[1] + m[i][j];
            i++;
        }

        return suma;
    }

    /**
     * Este módulo muestra un vector
     */
    public static void mostrarVector(int v[]) {
        for (int i = 0; i < v.length; i++) {
            System.out.print(v[i] + " ");
        }
        System.out.println("");
    }

    /*------------------------------------------------------------------------*/
 /*----------------------------ALGORITMO PRINCIPAL----------------------------*/
 /*---------------------------------------------------------------------------*/
    public static void main(String[] args) {
        int dimension;
        int matriz[][];
        int sumaDiagonal[];

        dimension = pedirDimension();
        matriz = generarMatriz(dimension);
        mostrarMatriz(matriz);
        sumaDiagonal = sumarDiagonal(matriz);
        System.out.println("Suma de las diagonales:");
        mostrarVector(sumaDiagonal);
    }

}
