/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_matrices05;

/**
 *
 * @author danie
 */
public class DJC_Matrices05 {

    /**
     * Este módulo genera una matriz con valores aleatorios del 1 al 50
     */
    public static void generarMatriz(int m[][]) {
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                m[i][j] = (int) (Math.random() * 50) + 1;
            }
        }
    }

    /**
     * Este módulo muestra una matriz
     */
    public static void mostrarMatriz(int m[][]) {
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                System.out.print(m[i][j] + "  ");
            }
            System.out.println("");
        }
    }

    /**
     * Este módulo devuelve el valor máximo de una matriz
     *
     * @param m
     * @return
     */
    public static int calculaMax(int m[][]) {
        int max = m[0][0];

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                if (m[i][j] > max) {
                    max = m[i][j];
                }
            }
        }
        return max;
    }

    /**
     *
     * @param m
     * @return
     */
    public static int calculaMax(int m[][], int pos[]) {
        int max = m[0][0];
        pos[0] = 0;
        pos[1] = 0;
        
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                if (m[i][j] > max) {
                    max = m[i][j];
                    pos[0] = i;
                    pos[1] = j;
                }
            }
        }
        return max;
    }

    /**
     * Este módulo devuelve el valor mínimo de una matriz
     */
    public static int calculaMin(int m[][]) {
        int min = m[0][0];

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                if (m[i][j] < min) {
                    min = m[i][j];
                }
            }
        }
        return min;
    }

    /**
     * Este módulo devuelve la media de los valores de una matriz
     */
    public static float calculaMedia(int m[][]) {
        int suma = 0;
        float media;

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                suma = suma + m[i][j];
            }
        }
        media = (float) (suma / (m.length * m[0].length));
        return media;
    }

    /*------------------------------------------------------------------------*/
 /*--------------------------ALGORITMO PRINCIPAL---------------------------*/
 /*------------------------------------------------------------------------*/
    public static void main(String[] args) {
        int matriz[][] = new int[3][5];

        generarMatriz(matriz);
        mostrarMatriz(matriz);
        System.out.println("El valor máximo de la matriz es: "
                + calculaMax(matriz));
        System.out.println("El valor mínimo de la matriz es: "
                + calculaMin(matriz));
        System.out.println("La media de los valores es: "
                + calculaMedia(matriz));
    }

}
