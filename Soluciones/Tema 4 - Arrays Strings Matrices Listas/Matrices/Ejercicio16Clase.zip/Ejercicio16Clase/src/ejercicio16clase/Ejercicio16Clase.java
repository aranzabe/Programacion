/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio16clase;

import java.util.Scanner;

/**
 *
 * @author faranzabe
 */
public class Ejercicio16Clase {

    //------------------------------MOSTRAR MATRIZ-----------------------------
    public static void mostrarMatriz(char m[][]) {

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {

                System.out.print(m[i][j] + " ");

            }

            System.out.println("");
        }
    }

    //------------------------------MOSTRAR MATRIZ-----------------------------
    public static void iniciarMatriz(char m[][]) {

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                if ((i + j) % 2 == 0) {
                    m[i][j] = 'B';
                } else {
                    m[i][j] = 'N';
                }
            }
        }
    }

    private static void colocarTorre(char[][] tablero, int f, int c) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private static void colocarAlfil(char[][] tablero, int f, int c) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        char tablero[][] = new char[8][8];
        int f, c, opc;
        Scanner sc = new Scanner(System.in);

        do {
            iniciarMatriz(tablero);
            mostrarMatriz(tablero);
            System.out.println("1.- Colocar torre.");
            System.out.println("2.- Colocar alfil.");
            System.out.println("3.- Colocar dama.");
            System.out.println("4.- Colocar caballo.");
            System.out.println("5.- Salir.");
            opc = sc.nextInt();
            switch (opc) {
                case 1:
                    f = sc.nextInt();
                    c = sc.nextInt();
                    colocarTorre(tablero, f, c);
                    mostrarMatriz(tablero);
                    break;
                case 2:
                    f = sc.nextInt();
                    c = sc.nextInt();
                    colocarAlfil(tablero, f, c);
                    mostrarMatriz(tablero);
                    break;
            }

        } while (opc != 5);

    }

}
