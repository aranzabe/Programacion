/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_matrices04;

import java.util.Scanner;

/**
 *
 * @author usuariob
 */
public class DJC_Matrices04 {

    /**
     * Este módulo pide una dimensión mayor que 1
     */
    public static int pedirDimension() {
        int dim;
        Scanner sc = new Scanner(System.in);

        do {
            System.out.print("Dame una dimensión mayor que 1 para la matriz: ");
            dim = sc.nextInt();
            if (dim < 2) {
                System.out.println("La matriz tiene que ser más grande");
            }
        } while (dim < 2);
        return dim;
    }

    /**
     * Este módulo genera una matriz con números aleatorios del 1 al 10
     */
    public static int[][] generarMatriz(int dim) {
        int m[][] = new int[dim][dim];

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                m[i][j] = (int) (Math.random() * 10) + 1;
            }
        }
        return m;
    }

    /**
     * Este módulo muestra una matriz
     */
    public static void mostrarMatriz(int m[][]) {
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                System.out.print(m[i][j] + "  ");
            }
            System.out.println("");
        }
    }

    /**
     * Este módulo devuelve un vector que almacena la cantidad de números pares
     * en la posición 0 y la de números impares en la posición 1
     */
    public static int[] encontrarParesImpares(int m[][]) {
        int parImpar[] = new int[2];

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                if (m[i][j] % 2 == 0) {
                    parImpar[0]++;
                } else {
                    parImpar[1]++;
                }
            }
        }
        return parImpar;
    }

    /**
     * Este módulo devuelve un vector que almacena la suma de los valores pares
     * en la posición 0 y la de los números impares en la posición 1
     */
    public static int[] calcularSumaParImpar(int m[][]) {
        int suma[] = new int[2];

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                if (m[i][j] % 2 == 0) {
                    suma[0] = suma[0] + m[i][j];
                } else {
                    suma[1] = suma[1] + m[i][j];
                }
            }
        }
        return suma;
    }

    /**
     * Este módulo devuelve un vector que almacena el número de posiciones pares
     * de la matriz en su posición 0 y las impares en su posición 1
     */
    public static int[] encontrarPosParesImpares(int m[][]) {
        int pos[] = new int[2];

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                if ((i + j) % 2 == 0) {
                    pos[0]++;
                } else {
                    pos[1]++;
                }
            }
        }
        return pos;
    }

    /**
     * Este módulo devuelve un vector que almacena la suma de los valores en
     * posiciones pares de la matriz en su posición 0 y la de los impraes en su
     * posición 1
     */
    public static int[] calcularSumaPosParImpar(int m[][]){
        int suma[] = new int[2];
        
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                if ((i + j) % 2 == 0){
                    suma[0] = suma[0] + m[i][j];
                } else {
                    suma[1] = suma[1] + m[i][j];
                }
            }
        }
        return suma;
    }
    /*------------------------------------------------------------------------*/
 /*----------------------------ALGORITMO PRINCIPAL----------------------------*/
 /*---------------------------------------------------------------------------*/
    public static void main(String[] args) {
        int matriz[][];
        int dimension;
        int paresImpares[], posParesImpares[];
        int sumaParImpar[], sumaPosParImpar[];

        dimension = pedirDimension();
        matriz = generarMatriz(dimension);
        mostrarMatriz(matriz);
        paresImpares = encontrarParesImpares(matriz);
        sumaParImpar = calcularSumaParImpar(matriz);
        System.out.println("Suma de los pares: " + sumaParImpar[0]);
        System.out.println("Media: " + (float) sumaParImpar[0] / paresImpares[0]);
        System.out.println("Suma de los impares: " + sumaParImpar[1]);
        System.out.println("Media: " + (float) sumaParImpar[1] / paresImpares[1]);
        posParesImpares = encontrarPosParesImpares(matriz);
        sumaPosParImpar = calcularSumaPosParImpar(matriz);
        System.out.println("Suma de los números en posiciones pares: " + sumaPosParImpar[0]);
        System.out.println("Media: " + (float) sumaPosParImpar[0] / posParesImpares[0]);
        System.out.println("Suma de los números en posiciones impares: " + sumaPosParImpar[1]);
        System.out.println("Media: " + (float) sumaPosParImpar[1] / posParesImpares[1]);
    }

}
