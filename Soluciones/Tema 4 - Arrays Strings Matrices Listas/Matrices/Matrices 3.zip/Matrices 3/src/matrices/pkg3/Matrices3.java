/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrices.pkg3;

/**
 *
 * @author laura
 */
public class Matrices3 {

    public static void generarMatriz(int m[][]) {

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                m[i][j] = (int) (Math.random() * 10+1);

            }

        }

    }

    public static void mostrarMatriz(int m[][]) {

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                System.out.print(+m[i][j] + " ");

            }
            System.out.println("");

        }

    }

    public static int valoresPares(int m[][]) {

        int pares = 0;

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {

                if (m[i][j] % 2 == 0) {
                    pares++;
                }
            }

        }

        return pares;
    }

    public static void main(String[] args) {
        int m[][] = new int[2][3];
        int pares;

        generarMatriz(m);
        mostrarMatriz(m);
        pares = valoresPares(m);
        
        System.out.println("El numero de pares es: " +pares);
    }

}
