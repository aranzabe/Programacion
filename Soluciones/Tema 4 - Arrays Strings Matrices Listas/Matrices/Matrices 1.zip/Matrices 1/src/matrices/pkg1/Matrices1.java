/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrices.pkg1;

/**
 *
 * @author laura
 */
public class Matrices1 {

    /*------------------------------------GENERAR MATRIZ-----------------------*/
    public static void GenerarMatriz(int m[][]) {

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                m[i][j] = (int) (Math.random() * 10);
            }
        }
    }

    /*------------------------------------MOSTRAR MATRIZ-----------------------*/
    public static void mostrarMatriz(int m[][]) {
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                System.out.print(m[i][j] + "  ");
            }
            System.out.println("");
        }
    }

    /*------------------------------------GENERAR SUMA--------------------------*/
    public static void GenerarSuma(int m1[][], int m2[][], int suma[][]) {
        for (int i = 0; i < m2.length; i++) {//filas
            for (int j = 0; j < m2[0].length; j++) {//columnas
                suma[i][j] = m1[i][j] + m2[i][j];
            }
        }
    }
    //Sobrecargamos la función.
    /*------------------------------------GENERAR SUMA función --------------------------*/
    public static int[][] GenerarSuma(int m1[][], int m2[][]) {
        int suma[][] = new int[m1.length][m1[0].length];
        for (int i = 0; i < m2.length; i++) {//filas
            for (int j = 0; j < m2[0].length; j++) {//columnas
                suma[i][j] = m1[i][j] + m2[i][j];
            }
        }
        return suma;
    }

    public static void main(String[] args) {
        int matriz1[][] = new int[2][3];//filas, columnas
        int matriz2[][] = new int[2][3];
        int suma[][] = new int[2][3];

        GenerarMatriz(matriz1);
        mostrarMatriz(matriz1);
        System.out.println("----------");
        GenerarMatriz(matriz2);
        mostrarMatriz(matriz2);
        System.out.println("----------");
        //GenerarSuma(matriz1, matriz2, suma);
        suma = GenerarSuma(matriz1, matriz2);
        mostrarMatriz(suma);

    }

}
