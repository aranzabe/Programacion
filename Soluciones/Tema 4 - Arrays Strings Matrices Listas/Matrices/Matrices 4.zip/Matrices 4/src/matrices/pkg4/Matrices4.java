/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrices.pkg4;

/**
 *
 * @author laura
 */
public class Matrices4 {

    //----------------------------------GENERAR MATRIZ----------------------------
    public static void generarMatriz(int m[][]) {

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                m[i][j] = (int) (Math.random() * 10);

            }

        }

    }
    //----------------------------------MOSTRAR MATRIZ----------------------------

    public static void mostrarMatriz(int m[][]) {

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {

                System.out.print(m[i][j] + " ");
            }
            System.out.println("");

        }
    }
    //----------------------------------GENERAR SUMA------------------------------

    public static void Suma(int m[][], int suma[], int cont[]) {

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                if (m[i][j] % 2 == 0) {
                    suma[0] = suma[0] + m[i][j];
                    cont[0]++;
                } else {
                    suma[1] = suma[1] + m[i][j];
                    cont[1]++;
                }
                if (i + j % 2 == 0) {
                    suma[2] = suma[2] + m[i][j];
                    cont[2]++;
                } else {
                    suma[3] = suma[3] + m[i][j];
                    cont[3]++;
                }
            }
        }
    }
    
    
    public static float [] calculaTodo(int m[][], int suma[], int cont[]) {
        float media[] = new float[4];
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                if (m[i][j] % 2 == 0) {
                    suma[0] = suma[0] + m[i][j];
                    cont[0]++;
                } else {
                    suma[1] = suma[1] + m[i][j];
                    cont[1]++;
                }
                if (i + j % 2 == 0) {
                    suma[2] = suma[2] + m[i][j];
                    cont[2]++;
                } else {
                    suma[3] = suma[3] + m[i][j];
                    cont[3]++;
                }
            }
        }
        media[0] = (float) suma[0] / cont[0];
        media[1] = (float) suma[1] / cont[1];
        media[2] = (float) suma[2] / cont[2];
        media[3] = (float) suma[3] / cont[3];
        return media;
    }
    //----------------------------------GENERAR MEDIA-----------------------------

    public static void Media(float media[], int cont[], int suma[]) {

        media[0] = (float) suma[0] / cont[0];
        media[1] = (float) suma[1] / cont[1];
        media[2] = (float) suma[2] / cont[2];
        media[3] = (float) suma[3] / cont[3];

    }

    //---------------------------------SUMA POSICIONES----------------------------
    public static void sumaPosiciones(int m[][], int suma[], int cont[]) {

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {

                if (i + j % 2 == 0) {

                    suma[2] = suma[2] + m[i][j];
                    cont[2]++;
                } else {
                    suma[3] = suma[3] + m[i][j];
                    cont[3]++;
                }
            }

        }

    }

    //----------------------------------ALGORITMO PRINCIPAL-----------------------
    public static void main(String[] args) {
        int m[][] = new int[2][3];
        int suma[] = new int[4];
        float media[] = new float[4];
        int cont[] = new int[4];

        generarMatriz(m);
        mostrarMatriz(m);
        Suma(m, suma, cont);
        sumaPosiciones(m, suma, cont);
        Media(media, cont, suma);

        System.out.println("La suma de los pares es " + suma[0] + " la de los impares " + suma[1]);
        System.out.println("La media de los pares es " + media[0] + " la de los impares " + media[1]);
        
        System.out.println("La suma de las posiciones pares es " +suma[2] +" la de los impares es " +suma[3]);
        System.out.println("La media de las posiciones pares es " +media[2] +" la de los impares es " +media[3]);

    }

}
