/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrices.pkg12;

/**
 *
 * @author laura
 */
public class Matrices12 {
 //------------------------------GENERAR MATRIZ-----------------------------
    public static void generarMatriz(int m[][]) {

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {

                m[i][j] = (int) (Math.random() * 10);
            }

        }
    }
 //------------------------------MOSTRAR MATRIZ-----------------------------
    public static void mostrarMatriz(int m[][]) {

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {

                System.out.print(m[i][j] + " ");
            }
            System.out.println("");

        }
    }
 //------------------------------TRANSPONER MATRIZ-----------------------------
    public static void transponerMatriz(int m[][], int m2[][]) {

        for (int i = 0; i < m[0].length; i++) {
            for (int j = 0; j < m.length; j++) {

                m2[j][i] = m[i][j];
            }

        }
    }
 //------------------------------ALGORITMO PRINCIPAL-----------------------------
    public static void main(String[] args) {
        int m[][] = new int[4][4];
        int matrizTranspuesta[][] = new int[4][m[0].length];

        generarMatriz(m);
        mostrarMatriz(m);
        transponerMatriz(m, matrizTranspuesta);
        System.out.println("");
        mostrarMatriz(matrizTranspuesta);
    }

}
