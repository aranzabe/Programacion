/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemploinicial;

/**
 *
 * @author faranzabe
 */
public class EjemploInicial {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Lista lis = new Lista();
        ListaLetras ll = new ListaLetras();

        ll.addDato('a');
        ll.addDatoFinal('b');
        ll.addDatoFinal('c');
        System.out.println(ll);
        System.out.println("Tiene " + ll.cuantosElementos());
        
//        lis.addDatoFinal(3);
//        lis.addDatoFinal(2);
//        lis.addDatoFinal(27);
//        System.out.println(lis);
//        for (int i = 0; i < lis.cuantosElementos(); i++) {
//            System.out.println(lis.getPos(i));
//        }
//        lis.setPos(2, 180);
//        System.out.println("La posicion 2 vale: " + lis.getPos(2));
//        System.out.println(lis);
    }

}
