/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemploinicial;

/**
 *
 * @author faranzabe
 */
public class Lista {

    //******************* Clase auxiliar ***********************
    private class Nodo {

        private int dato;
        private Nodo sig;

        public Nodo(int dato) {
            this.dato = dato;
            this.sig = null;
        }

    }
    //********* Fin de la declaración clase auxiliar *************
    private Nodo l;

    public Lista() {
        this.l = null;
    }

    public void addDato(int i) {
        Nodo nuevo = new Nodo(i);
        
        if (this.l == null) {
            this.l = nuevo;
        }
        else {
            nuevo.sig = l;
            this.l = nuevo;
        }
    }
    
    public void addDatoFinal(int i) {
        Nodo nuevo = new Nodo(i);
        
        if (this.l == null) {
            this.l = nuevo;
        }
        else if (this.l.sig == null){
            this.l.sig = nuevo;
        } else {
            Nodo penultimo = this.l;
            while (penultimo.sig != null){
                penultimo = penultimo.sig;
            }
            penultimo.sig = nuevo;
        }
    }
    
    public void addDatoFinal2(int i) {
        Nodo nuevo = new Nodo(i);
        Nodo ultimo = this.l;
        
        if (this.l == null) {
            this.l = nuevo;
        }
        else {
            while (ultimo.sig != null){
                ultimo = ultimo.sig;
            }
            ultimo.sig = nuevo;
        }
    }
    
    public void borrarDatoInicial(){
        Nodo segundo = this.l.sig;
        this.l = null;
        this.l = segundo;
    }
    
    public void borrarDatoFinal(){
        Nodo ultimo = this.l;
        Nodo penultimo = null;
        
        while (ultimo.sig != null){
            penultimo = ultimo;
            ultimo = ultimo.sig;
        }
        ultimo = null;
        penultimo.sig = null;
    }

    @Override
    public String toString() {
        String cad = "";
        cad = "l --> ";
        Nodo aux = this.l;
        while (aux != null) {
            cad += aux.dato + " --> ";
            aux = aux.sig;
        }
        cad += " null";
        return cad;
    }

}
