/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio4;

/**
 *
 * @author faranzabe
 */
public class AulaL {

    private Lista ordenadores;
    private String codAula;

    public AulaL() {
        this.codAula = "";
        this.ordenadores = new Lista();
    }

    public AulaL(String codAula) {
        this.codAula = codAula;
        this.ordenadores = new Lista();
    }

    /**
     * Devolverá true si conseguimos añadir el ordenador a la clase.
     *
     * @param o
     * @return
     */
    public void addOrdenador(Ordenador o) {
        this.ordenadores.addDatoFinal(o);
    }

    public int getCuantos() {
        return this.ordenadores.cuantosElementos();
    }

    @Override
    public String toString() {
        String dev = "Aula: " + this.codAula + "\n[\n";
        for (int i = 0; i < this.ordenadores.cuantosElementos(); i++) {
            if (this.ordenadores.getPos(i) != null) {
                dev += this.ordenadores.getPos(i).toString() + "\n";
            }

        }
        dev = dev + "]";
        return dev;
    }

//    public boolean removeOrdenador(String numSerie) {
//        boolean borrado = false;
//        int i = 0;
//
//        while (i < this.ordenadores.cuantosElementos() && !borrado) {
//            if (this.ordenadores.getPos(i) != null) {
//                if (this.ordenadores.getPos(i).getNumSerie().equals(numSerie)) {
//                    ordenadores.setPos(i, nuevoValor)
//                    borrado = true;
//                }
//            }
//            i++;
//        }
//        return borrado;
//    }
    
//    public boolean removeOrdenador(Ordenador oborrar) {
//        boolean borrado = false;
//        int i = 0;
//
//        while (i < this.ordenadores.length && !borrado) {
//            if (this.ordenadores[i] != null) {
//                if (this.ordenadores[i].equals(oborrar)) {
//                    ordenadores[i] = null;
//                    borrado = true;
//                }
//            }
//            i++;
//        }
//        return borrado;
//    }
    public boolean modifyOrdenador(String numSerie, Ordenador o2) {
        boolean cambiado = false;
        int i = 0;

        while (i < this.ordenadores.cuantosElementos() && !cambiado) {
            if (this.ordenadores.getPos(i) != null) {
                if (ordenadores.getPos(i).getNumSerie().equals(numSerie)) {
                    ordenadores.setPos(i, o2);
                    cambiado = true;
                }
            }
            i++;
        }
        return cambiado;
    }

    public boolean modifyOrdenador(String numSerie, int HD, int RAM) {
        boolean cambiado = false;
        int i = 0;
        Ordenador o = new Ordenador();

        while (i < this.ordenadores.cuantosElementos() && !cambiado) {
            if (this.ordenadores.getPos(i) != null) {
                if (ordenadores.getPos(i).getNumSerie().equals(numSerie)) {
                    o.setNumSerie(numSerie);
                    o.setHD(HD);
                    o.setRAM(RAM);
                    ordenadores.setPos(i, o);
                    cambiado = true;
                }
            }
            i++;
        }
        return cambiado;
    }

    void borrarPosicion(int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
