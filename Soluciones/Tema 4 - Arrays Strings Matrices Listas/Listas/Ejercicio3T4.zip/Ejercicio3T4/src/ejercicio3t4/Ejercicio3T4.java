/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio3t4;

/**
 *
 * @author faranzabe
 */
public class Ejercicio3T4 {

    public static Lista factoriaLista(int n){
        Lista l = new Lista();
        for (int i = 0; i < n; i++) {
            l.addDatoFinal((int) (Math.random()*10));
        }
        return l;
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Lista v1 = factoriaLista(3);
        Lista v2 = factoriaLista(3);
        Lista vs = new Lista();
        
        System.out.println("v1: " + v1);
        System.out.println("v2: " + v2);
        
        for (int i = 0; i < v1.cuantosElementos(); i++) {
            int suma = v1.getPos(i) + v2.getPos(i);
            vs.addDatoFinal(suma);
        }
        System.out.println(vs);
    }
    
}
