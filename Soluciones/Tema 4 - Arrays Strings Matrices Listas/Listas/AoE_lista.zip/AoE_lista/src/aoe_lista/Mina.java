/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aoe_lista;

/**
 *
 * @author Malena
 */
public class Mina {

    private int items;
    private Lista aldeanos;
    private String tipo;

    public Mina() {
        this.aldeanos = new Lista();
        this.tipo = "";
        this.items = items;
    }

    public Mina(int items, String tipo) {
        this.items = items;
        this.tipo = tipo;
        this.aldeanos = new Lista();
    }

    public void addAldeano(Aldeano a) {
        if (a != null) {
            this.aldeanos.addDato(a);
        }
    }

    @Override
    public String toString() {
        String dev = "Aula: " + this.aldeanos + "\n[\n";
        for (int i = 0; i < this.aldeanos.cuantosElementos(); i++) {
            if (this.aldeanos.getPos(i) != null) {
                dev += this.aldeanos.getPos(i).toString() + "\n";
            }

        }
        dev = dev + "]";
        return dev;
    }

    public void diaTrabajo() {
        for (int i = 0; i < this.aldeanos.cuantosElementos(); i++) {
            if (this.aldeanos.getPos(i) != null) {
                if (this.items > 0) {
                    this.items--; //se resta un oro de la mina
                    this.aldeanos.getPos(i).getCiv().sumar1Oro(1); // y se suma al almacen de los aldeanos
                }
            }
        }
    }

    public boolean ataqueCura(CivilizacionL civ) {
        boolean atacado = false;
        for (int i = 0; i < this.aldeanos.cuantosElementos(); i++) {
            if (this.aldeanos.getPos(i) != null) {
                if (!this.aldeanos.getPos(i).getCiv().getNombre().equals(civ.getNombre())) {
                    this.aldeanos.getPos(i).setCiv(civ);
                    atacado = true;
                }
            }
        }
        return atacado;
    }

}
