/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aoe_lista;

/**
 *
 * @author Malena
 */
public class Civilizacion {
    private String nombre;
    private String nombreRey;
    private Aldeano aldeanos[];
    private int almacenOro;

    public Civilizacion() {
        this.nombre = "";
        this.nombreRey = "";
    }   
    
    public Civilizacion(String nombre, String nombreRey) {
        this.nombre = nombre;
        this.nombreRey = nombreRey;
        this.aldeanos = new Aldeano[10];
    }

    public String getNombre() {
        return nombre;
    }

    public String getNombreRey() {
        return nombreRey;
    }

    public int getAlmacenOro() {
        return almacenOro;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setNombreRey(String nombreRey) {
        this.nombreRey = nombreRey;
    }

    public void setAlmacenOro(int almacenOro) {
        this.almacenOro = almacenOro;
    }
    
    public boolean addAldeano(Aldeano a){
        boolean añadido = false;
        int i = 0;
        while(i < this.aldeanos.length && !añadido){
            if(this.aldeanos[i] == null){
                    this.aldeanos[i] = a;
                    añadido = true;
            }
            i++;
        }
        return añadido;
    }

    @Override
    public String toString() {
        String cad = "";
        cad = "Nombre: " + this.nombre + "\n";
        cad = cad + "Rey: " + this.nombreRey + "\n";
        cad = cad + "Oro: " + this.almacenOro + "\n";
        
        for (int i = 0; i < this.aldeanos.length; i++) {
            if(this.aldeanos[i] != null){
                cad = cad + this.aldeanos[i].toString() + "\n";
            }
        }
        return cad;
    }
    
    public void sumar1Oro(int i){
        this.almacenOro = this.almacenOro + i;
    }
    
    public Aldeano quitarAldeanoCiv(){
        Aldeano a = null;
        boolean encontrado = false;
        int i = 0;
        while (!encontrado && i < this.aldeanos.length){
            if(this.aldeanos[i] != null){
                a = this.aldeanos[i];
                this.aldeanos[i] = null;
                encontrado = true;
            }
            i++;
        }
        return a;
    }
    
}
