/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aoe_lista;

/**
 *
 * @author Malena
 */
public class Aldeano {
    private CivilizacionL civ;
    private int salud;

    public Aldeano() {
    }

    public Aldeano(int salud) {
        this.salud = salud;
    }

    public Aldeano(CivilizacionL civ, int salud) {
        this.civ = civ;
        this.salud = salud;
    }

    public CivilizacionL getCiv() {
        return civ;
    }

    public int getSalud() {
        return salud;
    }

    public void setCiv(CivilizacionL civ) {
        this.civ = civ;
    }

    public void setSalud(int salud) {
        this.salud = salud;
    }

    @Override
    public String toString() {
        return "Aldeano{" + "civ=" + civ.getNombre() + ", salud=" + salud + '}';
    }

    
    
    
}
