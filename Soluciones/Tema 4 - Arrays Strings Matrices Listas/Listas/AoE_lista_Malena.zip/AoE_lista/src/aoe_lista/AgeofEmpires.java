/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aoe_lista;

/**
 *
 * @author Malena
 */
public class AgeofEmpires {

    /**
     * @param args the command line arguments
     */
    
    public static Aldeano factoriaAldeano(CivilizacionL civ, int salud){
        Aldeano a = new Aldeano(civ, salud);
        return a;
    }
    
    public static CivilizacionL factoriaCivilizacion(String nombre, String nombreRey, int salud){
        CivilizacionL civ = new CivilizacionL (nombre, nombreRey);
        
            Aldeano a = factoriaAldeano(civ, salud);
            civ.addAldeano(a);
            
        return civ;
    }
    
    public static Mina factoriaMina(int items, String tipo){
        Mina mina = new Mina (items, tipo);
        return mina;
    }
    
    
    public static void main(String[] args) throws InterruptedException {
        CivilizacionL esp = factoriaCivilizacion("Españoles", "Isabel I", 200);
        CivilizacionL biz = factoriaCivilizacion("Bizantinos", "Bizantino II", 250);
        Mina mina = factoriaMina(500, "ORO");
        System.out.println("Partimos de la siguiente situacion actual: ");
        System.out.println(esp);
        System.out.println(biz);
        System.out.println(mina);
        
        int tiempo = 0;
        
        while(tiempo < 300){
            
            mina.diaTrabajo();
            
            if(tiempo % 2 == 0){
                int alea = (int) (Math.random() * 100);
                if(alea <= 40){
                    //tenemos que poner a nulo un aldeano en la civilizacion para poder meterlo en la mina.
                    Aldeano a = esp.quitarAldeanoCiv();
                    mina.addAldeano(a);
                }
                
                if(alea <= 20){
                    Aldeano a = biz.quitarAldeanoCiv();
                    mina.addAldeano(a);
                }
            }
            
            if(tiempo % 5 == 0){
                if(mina.ataqueCura(biz)){
                    System.out.println("Un cura bizantino se ha llevado a un aldeano español para formar parte de su ejercito.");
                }else{
                    System.out.println("El cura no ha encontrado a ningun español.");
                }
            }
            
            System.out.println("-------------------------------------");
            System.out.println(esp);
            System.out.println(biz);
            System.out.println(mina);
            Thread.sleep(1000);
            tiempo++;
        }
        
        
        
    }
    
}
