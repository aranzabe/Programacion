/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aoe_lista;

/**
 *
 * @author Malena
 */
public class CivilizacionL {
    
    private String nombre;
    private String nombreRey;
    private Lista aldeanos;
    private int almacenOro;

    public CivilizacionL() {
        this.nombre = "";
        this.nombreRey = "";
    }   
    
    public CivilizacionL(String nombre, String nombreRey) {
        this.nombre = nombre;
        this.nombreRey = nombreRey;
        this.aldeanos = new Lista();
    }

    public String getNombre() {
        return nombre;
    }

    public String getNombreRey() {
        return nombreRey;
    }

    public int getAlmacenOro() {
        return almacenOro;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setNombreRey(String nombreRey) {
        this.nombreRey = nombreRey;
    }

    public void setAlmacenOro(int almacenOro) {
        this.almacenOro = almacenOro;
    }
    
    public void addAldeano(Aldeano a){
        this.aldeanos.addDato(a);
    }

    @Override
    public String toString() {
        String dev = "Aula: " + this.aldeanos + "\n[\n";
        for (int i = 0; i < this.aldeanos.cuantosElementos(); i++) {
            if (this.aldeanos.getPos(i) != null) {
                dev += this.aldeanos.getPos(i).toString() + "\n";
            }

        }
        dev = dev + "]";
        return dev;
    }
    
    public void sumar1Oro(int i){
        this.almacenOro = this.almacenOro + i;
    }
    
    public boolean quitarAldeanoCiv(int pos){
        return this.aldeanos.borrarPosicion(pos);
        }
}
