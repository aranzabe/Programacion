/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio4;

/**
 *
 * @author faranzabe
 */
public class AulaLista {

    private ListaOrdenadores ordenadores;
    private String codAula;

    public AulaLista() {
        this.codAula = "";
        this.ordenadores = new ListaOrdenadores();
    }

    public AulaLista(String codAula) {
        this.codAula = codAula;
        this.ordenadores = new ListaOrdenadores();
    }

//    public AulaLista(String codAula, int max) {
//        this.codAula = codAula;
//        this.ordenadores = null;
//    }
    /**
     * Devolverá true si conseguimos añadir el ordenador a la clase.
     *
     * @param o
     * @return
     */
    public void addOrdenador(Ordenador o) {
        this.ordenadores.addDatoFinal(o);
    }

    public int getCuantos() {
        int cont = 0;
        for (int i = 0; i < this.ordenadores.cuantosElementos(); i++) {
            if (this.ordenadores.getPos(i) != null) {
                cont++;
            }
        }
        return cont;
    }

//    public int getMaximo(){
//        return this.ordenadores.length;
//    }
    @Override
    public String toString() {
        String dev = "Aula: " + this.codAula + "\n[\n";
        for (int i = 0; i < this.ordenadores.cuantosElementos(); i++) {
            if (this.ordenadores.getPos(i) != null) {
                dev += this.ordenadores.getPos(i).toString() + "\n";
            }

        }
        dev = dev + "]";
        return dev;
    }

    public boolean removeOrdenador(String numSerie) {
        boolean borrado = false;
        int i = ordenadores.buscarPosicion(numSerie);

        if (i != -1) {
            ordenadores.borrarPosicion(i);
            borrado = true;
        }
        return borrado;
    }

//    public boolean removeOrdenador(Ordenador oborrar) {
//        boolean borrado = false;
//        int i = 0;
//
//        while (i < this.ordenadores.length && !borrado) {
//            if (this.ordenadores[i] != null) {
//                if (this.ordenadores[i].equals(oborrar)) {
//                    ordenadores[i] = null;
//                    borrado = true;
//                }
//            }
//            i++;
//        }
//        return borrado;
//    }
    public boolean modifyOrdenador(String numSerie, Ordenador o2) {
        boolean cambiado = false;
        int i = 0;

        while (i < this.ordenadores.cuantosElementos() && !cambiado) {
            if (this.ordenadores.getPos(i) != null) {
                if (ordenadores.getPos(i).getNumSerie().equals(numSerie)) {
                    ordenadores.setPos(i, o2);
                    cambiado = true;
                }
            }
            i++;
        }
        return cambiado;
    }

    public boolean modifyOrdenador(String numSerie, int HD, int RAM) {
        boolean cambiado = false;
        int i = 0;

        while (i < this.ordenadores.cuantosElementos() && !cambiado) {
            if (this.ordenadores.getPos(i) != null) {
                if (ordenadores.getPos(i).getNumSerie().equals(numSerie)) {
                    ordenadores.getPos(i).setHD(HD);
                    ordenadores.getPos(i).setRAM(RAM);
                    cambiado = true;
                }
            }
            i++;
        }
        return cambiado;
    }
}
