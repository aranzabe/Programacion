/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_objetos06serpiente;

/**
 *
 * @author danie
 */
public class DJC_Objetos06Serpiente {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        SerpienteL s = new SerpienteL();
        int cod = 0;
        int prob;
        while (s.sigueViva()) {
            System.out.println(s);
            s.cumpleSerpiente();
            prob = (int) (Math.random() * 100);
            if (s.getEdad() < 10) {
                if (prob < 80) {
                    s.creceSerpiente();
                    cod = 1;
                } else {
                    s.mudaPiel();
                    cod = 2;
                }
            } else {
                if (prob < 90) {
                    s.decreceSerpiente();
                    cod = 3;
                } else {
                    s.mudaPiel();
                    cod = 2;
                }
            }
            switch (cod) {
                case 1:
                    System.out.println("La serpiente está creciendo...");
                    break;
                case 2:
                    System.out.println("La serpiente está mudando la piel...");
                    break;
                case 3:
                    System.out.println("La serpiente está decreciendo...");
            }
            Thread.sleep(1000);
        }
        System.out.println("Hasta siempre, Serpiente");
    }

}
