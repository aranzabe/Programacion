/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ageofempires.Listas;

import ageofempires.Listas.AldeanoL;
import ageofempires.Listas.CivilizacionL;
import ageofempires.Listas.Lista;

/**
 *
 * @author laura
 */
public class MinaL {

    private String tipo;
    private int items;
    private Lista alds;

    public MinaL() {
        this.tipo = "";
    }

    public MinaL(String tipo, int items) {
        this.tipo = tipo;
        this.items = items;
        this.alds = null;
    }

    public void addAldeano(AldeanoL a) {
       alds.addDatoFinal(a);
    }

    @Override
    public String toString() {
        String cad = "";
        cad += "Tipo: " + this.tipo + "\n";
        cad += "Items: " + this.items + "\n";
        for (int i = 0; i < this.alds.cuantosElementos(); i++) {
            if (this.alds.getPos(i) != null) {
                cad += this.alds.getPos(i).toString() + "\n";
            }
        }
        return cad;
    }

    public void diaTrabajo() {
        for (int i = 0; i < this.alds.cuantosElementos(); i++) {
            if (this.alds.getPos(i) != null) {
                if (this.items > 0) {
                    this.items--;
                    this.alds.getPos(i).getCiv().incOro(1);
                    //this.alds[i].getCiv().setAlmacenOro(this.alds[i].getCiv().getAlmacenOro()+1);
                }
            }
        }
    }

    public int getCuantosAldeanos() {
        return this.alds.cuantosElementos();
    }

    public AldeanoL getAldeano(int i) {
        return this.alds.getPos(i);
    }

    public void restarItem() {
        this.items--;
    }

    public boolean quedanItems() {
        return this.items > 0;
    }

    public boolean ataqueCura(CivilizacionL civ) {
        boolean conseguido = false;

        for (int i = 0; i < this.alds.cuantosElementos(); i++) {
            if (this.alds.getPos(i)==null) {
                //if (this.alds[i].getCiv() != civ)
                //if (!this.alds[i].getCiv().getNombre().equals(civ.getNombre())) {
                if (!this.alds.getPos(i).getCiv().equals(civ)) {
                    this.alds.getPos(i).setCiv(civ);
                    conseguido = true;
                }
            }
        }
        return conseguido;
    }

}
