/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ageofempires.Listas;

import ageofempires.Listas.CivilizacionL;

/**
 *
 * @author laura
 */
public class AldeanoL {
    
    private int indicadorSalud;
    private CivilizacionL civ;

    public AldeanoL() {
    }

    public AldeanoL(int indicadorSalud) {
        this.indicadorSalud = indicadorSalud;
    }

    public AldeanoL(int indicadorSalud, CivilizacionL civ) {
        this.indicadorSalud = indicadorSalud;
        this.civ = civ;
    }

    public int getIndicadorSalud() {
        return indicadorSalud;
    }

    public void setIndicadorSalud(int indicadorSalud) {
        this.indicadorSalud = indicadorSalud;
    }

    public CivilizacionL getCiv() {
        return civ;
    }

    public void setCiv(CivilizacionL civ) {
        this.civ = civ;
    }

    @Override
    public String toString() {
        return "Aldeano{" + "indicadorSalud=" + indicadorSalud + ", civ=" + civ.getNombre() + '}';
    }
    
    
    
    
}
