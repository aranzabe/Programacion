/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ageofempires.Listas;

import ageofempires.Listas.Lista;

/**
 *
 * @author laura
 */
public class CivilizacionL {

    private Lista alds;
    private String nombre;
    private String nombreRey;
    private int almacenOro;
    private int almacenPiedra;

    public CivilizacionL() {
        this.nombre = "";
        this.nombreRey = "";
    }

    public CivilizacionL(String nombre, String nombreRey) {
        this.nombre = nombre;
        this.nombreRey = nombreRey;
        this.alds = null;
    }

    public String getNombre() {
        return nombre;
    }

    public String getNombreRey() {
        return nombreRey;
    }

    public int getAlmacenOro() {
        return almacenOro;
    }

    public int getAlmacenPiedra() {
        return almacenPiedra;
    }

    public void setAlmacenOro(int almacenOro) {
        this.almacenOro = almacenOro;
    }

    public void setAlmacenPiedra(int almacenPiedra) {
        this.almacenPiedra = almacenPiedra;
    }

    public void addAldeano(AldeanoL a) {
       this.alds.addDatoFinal(a);
    }

    @Override
    public String toString() {
        String cad = "";
        cad = "Nombre: " + this.nombre + "\n";
        cad += "Rey: " + this.nombreRey + "\n";
        cad += "Oro: " + this.almacenOro + "\n";
        cad += "Piedra: " + this.almacenPiedra + "\n";
        for (int i = 0; i < this.alds.cuantosElementos(); i++) {
            if (this.alds.getPos(i)==null) {
                cad += this.alds.getPos(i).toString() + "\n";
            }
        }
        return cad;
    }

    public AldeanoL getAldeano() {
        AldeanoL a = null;
        boolean encontrado = false;
        int i = 0;

        while (!encontrado && i < this.alds.cuantosElementos()) {
            if (this.alds.getPos(i)== null) {
                a = this.alds.getPos(i);
                this.alds.setPos(i, a);
                encontrado = true;
            }
            i++;
        }
        return a;
    }

    public int getMaxAldeanos() {
        return this.alds.cuantosElementos();
    }

    public void incOro(int i) {
        this.almacenOro += i;
    }
    
    public boolean equals(CivilizacionL c){
        return c.getNombre().equals(this.nombre);
    }

}
