/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ageofempires;

/**
 *
 * @author laura
 */
public class Aldeano {
    
    private int indicadorSalud;
    private Civilizacion civ;

    public Aldeano() {
    }

    public Aldeano(int indicadorSalud) {
        this.indicadorSalud = indicadorSalud;
    }

    public Aldeano(int indicadorSalud, Civilizacion civ) {
        this.indicadorSalud = indicadorSalud;
        this.civ = civ;
    }

    public int getIndicadorSalud() {
        return indicadorSalud;
    }

    public void setIndicadorSalud(int indicadorSalud) {
        this.indicadorSalud = indicadorSalud;
    }

    public Civilizacion getCiv() {
        return civ;
    }

    public void setCiv(Civilizacion civ) {
        this.civ = civ;
    }

    @Override
    public String toString() {
        return "Aldeano{" + "indicadorSalud=" + indicadorSalud + ", civ=" + civ.getNombre() + '}';
    }
    
    
    
    
}
