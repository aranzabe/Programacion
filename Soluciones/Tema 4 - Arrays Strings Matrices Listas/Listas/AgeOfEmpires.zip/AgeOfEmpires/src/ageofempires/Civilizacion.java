/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ageofempires;

/**
 *
 * @author laura
 */
public class Civilizacion {

    private Aldeano alds[];
    private String nombre;
    private String nombreRey;
    private int almacenOro;
    private int almacenPiedra;

    public Civilizacion() {
        this.nombre = "";
        this.nombreRey = "";
    }

    public Civilizacion(String nombre, String nombreRey) {
        this.nombre = nombre;
        this.nombreRey = nombreRey;
        this.alds = new Aldeano[4];
    }

    public String getNombre() {
        return nombre;
    }

    public String getNombreRey() {
        return nombreRey;
    }

    public int getAlmacenOro() {
        return almacenOro;
    }

    public int getAlmacenPiedra() {
        return almacenPiedra;
    }

    public void setAlmacenOro(int almacenOro) {
        this.almacenOro = almacenOro;
    }

    public void setAlmacenPiedra(int almacenPiedra) {
        this.almacenPiedra = almacenPiedra;
    }

    public boolean addAldeano(Aldeano a) {
        int i = 0;
        boolean insertado = false;
        while (i < this.alds.length && !insertado) {
            if (this.alds[i] == null) {
                this.alds[i] = a;
                insertado = true;
            }
            i++;
        }
        return insertado;
    }

    @Override
    public String toString() {
        String cad = "";
        cad = "Nombre: " + this.nombre + "\n";
        cad += "Rey: " + this.nombreRey + "\n";
        cad += "Oro: " + this.almacenOro + "\n";
        cad += "Piedra: " + this.almacenPiedra + "\n";
        for (int i = 0; i < this.alds.length; i++) {
            if (this.alds[i] != null) {
                cad += this.alds[i].toString() + "\n";
            }
        }
        return cad;
    }

    public Aldeano getAldeano() {
        Aldeano a = null;
        boolean encontrado = false;
        int i = 0;

        while (!encontrado && i < this.alds.length) {
            if (this.alds[i] != null) {
                a = this.alds[i];
                this.alds[i] = null;
                encontrado = true;
            }
            i++;
        }
        return a;
    }

    public int getMaxAldeanos() {
        return this.alds.length;
    }

    public void incOro(int i) {
        this.almacenOro += i;
    }
    
    public boolean equals(Civilizacion c){
        return c.getNombre().equals(this.nombre);
    }

}
