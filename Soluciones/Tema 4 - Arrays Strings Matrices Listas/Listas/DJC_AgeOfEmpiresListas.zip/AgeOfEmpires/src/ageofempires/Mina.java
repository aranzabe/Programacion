/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ageofempires;

/**
 *
 * @author laura
 */
public class Mina {

    private String tipo;
    private int items;
    private Aldeano alds[];

    public Mina() {
        this.tipo = "";
    }

    public Mina(String tipo, int items) {
        this.tipo = tipo;
        this.items = items;
        this.alds = new Aldeano[20];
    }

    public boolean addAldeano(Aldeano a) {
        int i = 0;
        boolean insertado = false;
        while (i < this.alds.length && !insertado) {
            if (this.alds[i] == null) {
                this.alds[i] = a;
                insertado = true;
            }
            i++;
        }
        return insertado;
    }

    @Override
    public String toString() {
        String cad = "";
        cad += "Tipo: " + this.tipo + "\n";
        cad += "Items: " + this.items + "\n";
        for (int i = 0; i < this.alds.length; i++) {
            if (this.alds[i] != null) {
                cad += this.alds[i].toString() + "\n";
            }
        }
        return cad;
    }

    public void diaTrabajo() {
        for (int i = 0; i < this.alds.length; i++) {
            if (this.alds[i] != null) {
                if (this.items > 0) {
                    this.items--;
                    this.alds[i].getCiv().incOro(1);
                    //this.alds[i].getCiv().setAlmacenOro(this.alds[i].getCiv().getAlmacenOro()+1);
                }
            }
        }
    }

    public int getCuantosAldeanos() {
        return this.alds.length;
    }

    public Aldeano getAldeano(int i) {
        return this.alds[i];
    }

    public void restarItem() {
        this.items--;
    }

    public boolean quedanItems() {
        return this.items > 0;
    }

    public boolean ataqueCura(Civilizacion civ) {
        boolean conseguido = false;

        for (int i = 0; i < this.alds.length; i++) {
            if (this.alds[i] != null) {
                //if (this.alds[i].getCiv() != civ)
                //if (!this.alds[i].getCiv().getNombre().equals(civ.getNombre())) {
                if (!this.alds[i].getCiv().equals(civ)) {
                    this.alds[i].setCiv(civ);
                    conseguido = true;
                }
            }
        }
        return conseguido;
    }

}
