/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ageofempires;

/**
 *
 * @author laura
 */
public class AgeOfEmpires {

    public static Aldeano factoriaAldeano(int vida, Civilizacion c) {
        Aldeano a = new Aldeano(vida, c);
        return a;
    }

    public static Civilizacion factoriaCivilizacion(String nombre, String nombreR, int vida) {
        Civilizacion c = new Civilizacion(nombre, nombreR);
        boolean insertado = true;
        do {
            Aldeano a = factoriaAldeano(vida, c);
            insertado = c.addAldeano(a);
        } while (insertado);
        return c;
    }

    public static Civilizacion factoriaCivilizacion2(String nombre, String nombreR, int vida) {
        Civilizacion c = new Civilizacion(nombre, nombreR);
        for (int i = 0; i < c.getMaxAldeanos(); i++) {
            Aldeano a = factoriaAldeano(vida, c);
            c.addAldeano(a);
        }
        return c;
    }

    public static Mina factoriaMina(String tipo, int items) {
        Mina m = new Mina(tipo, items);
        return m;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        Civilizacion esp = factoriaCivilizacion("Españoles", "Isabel I", 200);
        Civilizacion biz = factoriaCivilizacion("Bizantino", "Constantino II", 150);
        int tiempo = 0;
        Mina mina = factoriaMina("ORO", 500);

        System.out.println("Situación inicial.");
        System.out.println(esp);
        System.out.println(biz);
        System.out.println(mina);

        while (tiempo <= 300) {

            //Opción A)
            //mina.diaTrabajo();
            //Opción B)
            int cuantosAldeanosMina = mina.getCuantosAldeanos();
            for (int i = 0; i < cuantosAldeanosMina; i++) {
                Aldeano aMina = mina.getAldeano(i);
                if (aMina != null) {
                    if (mina.quedanItems()) {
                        mina.restarItem();
                        aMina.getCiv().incOro(1);
                    }
                }

            }

            if (tiempo % 2 == 0) {
                int alea = (int) (Math.random() * 100);
                if (alea <= 40) {
                    Aldeano a = esp.getAldeano();
                    mina.addAldeano(a);
                }
                if (alea <= 20) {
                    Aldeano a = biz.getAldeano();
                    mina.addAldeano(a);
                }
            }
            if (tiempo % 5 == 0) {
                //Opción A)
                boolean conseguido = false;
                cuantosAldeanosMina = mina.getCuantosAldeanos();
                for (int i = 0; i < cuantosAldeanosMina; i++) {
                    Aldeano aMina = mina.getAldeano(i);
                    if (aMina != null) {
                        if (!aMina.getCiv().equals(biz)) {
                            aMina.setCiv(biz);
                            conseguido = true;
                        }
                    }
                }
                if (conseguido) {
                    System.out.println("Se ha convertido a un español.");
                } else {
                    System.out.println("No se ha encontrado a nadie a quien convertir.");
                }
                
                //Opción B)
//                if (mina.ataqueCura(biz)) {
//                    System.out.println("Se ha convertido a un español.");
//                } else {
//                    System.out.println("No se ha encontrado a nadie a quien convertir.");
//                }
            }

            System.out.println("--------------------------");
            System.out.println(esp);
            System.out.println(biz);
            System.out.println(mina);
            Thread.sleep(1000);
            tiempo++;
        }

    }

}
