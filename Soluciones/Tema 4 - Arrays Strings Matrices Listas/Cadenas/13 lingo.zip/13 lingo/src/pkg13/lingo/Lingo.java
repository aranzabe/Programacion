/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg13.lingo;

import java.util.Scanner;

/**
 *
 * @author laura
 */
public class Lingo {

    public static String PedirPalabra() {
        String palabra;
        boolean correcto = false;
        Scanner sc = new Scanner(System.in);

        do {
            System.out.println("Dame una palabra de 5 letras, sin numero y sin tilde:");
            palabra = sc.nextLine();
            palabra = palabra.toLowerCase();
            correcto = esCorrecto(palabra);
        } while (!correcto);

        return palabra.toLowerCase();
    }

    public static boolean esCorrecto(String palabra) {
        boolean correcto = false;
        int i = 0;

        if (palabra.length() == 5) {
            correcto = true;
            while (correcto && i < palabra.length()) {
                if (palabra.charAt(i) > 96 && palabra.charAt(i) < 123) {
                    correcto = true;
                    i++;

                } else {
                    correcto = false;
                }
            }
        }

        return correcto;
    }

    public static String GenerarPista(String PalabraJugador, String PalabraOculta) {

        String pista = "";

        for (int i = 0; i < PalabraOculta.length(); i++) {
            for (int j = 0; j < PalabraOculta.length(); j++) {
                if(PalabraOculta.charAt(i)==PalabraJugador.charAt(j)){
                    if (i == j) {
                    
                    
                }
                }
                
            }

        }

        return pista;
    }

    public static void main(String[] args) {
        String PalabraOculta;
        String Pista = "-----";
        String PalabraJugador;
        int intento = 5;
        boolean victoria;

        PalabraOculta = PedirPalabra();
        do {
            PalabraJugador = PedirPalabra();
            Pista = GenerarPista(PalabraJugador, PalabraOculta);
            victoria = GenerarResultado(PalabraOculta, PalabraJugador);
            if (!victoria) {
                intento--;
            }
        } while (!victoria && intento > 0);

        if (victoria == true) {
            System.out.println("Has acertado");
        } else {
            System.out.println("No has acertado, la palabra es " + PalabraOculta);
        }

    }

}
