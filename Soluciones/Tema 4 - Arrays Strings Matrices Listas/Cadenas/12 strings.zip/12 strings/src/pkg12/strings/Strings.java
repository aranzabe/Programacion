/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg12.strings;

import java.util.Scanner;

/**
 *
 * @author laura
 */
public class Strings {

    public static String pedirPalabraOculta() {
        String palabraOculta;
        boolean correcto;
        Scanner sc = new Scanner(System.in);

        do {
            System.out.println("Dame una palabra: ");
            palabraOculta = sc.nextLine();

            correcto = esCorrecto(palabraOculta);
            if (!correcto) {
                System.out.println("Pon una palabra valida, solo puede contener letras mayusculas sin tilde");
            }
        } while (!correcto);

        return palabraOculta.toUpperCase();
    }

    public static boolean esCorrecto(String palabraOculta) {
        boolean correcto = true;
        int i = 0;

        while (i < palabraOculta.length() && correcto) {
            if (palabraOculta.charAt(i) > 64 && palabraOculta.charAt(i) < 91) {
                correcto = true;
                i++;
            } else {
                correcto = false;
            }
        }

        return correcto;
    }

    public static String pedirPalabraJugador(int longitud) {
        String palabraJugador = "";

        for (int i = 0; i < longitud; i++) {

            palabraJugador = palabraJugador + "*";
        }

        return palabraJugador;
    }

    public static boolean quieresResolver() {
        char respuesta;
        boolean resolv;
        Scanner sc = new Scanner(System.in);

        System.out.println("¿Quieres resolver?: ");
        respuesta = sc.nextLine().charAt(0);

        if (respuesta == 's' || respuesta == 'S') {
            resolv = true;
        } else {
            resolv = false;
        }

        return resolv;
    }

    public static String pedirResultado() {
        String resultado;
        Scanner sc = new Scanner(System.in);

        System.out.println("Dime el resultado; ");
        resultado = sc.nextLine();

        return resultado.toUpperCase();
    }

    public static char pedirLetra() {
        char letra;
        Scanner sc = new Scanner(System.in);

        System.out.println("Dame una letra: ");
        letra = sc.nextLine().charAt(0);

        return letra;
    }

    public static boolean comprobarLetra(char letra, String palabraOculta) {

        boolean estalaletra = false;

        for (int i = 0; i < palabraOculta.length(); i++) {

            if (letra == palabraOculta.charAt(i)) {
                estalaletra = true;
            }

        }

        return estalaletra;
    }

    public static String ponerLetra(char letra, String palabraOculta, String palabraJugadorOriginal) {

        String palabraJugadorNueva = "";

        for (int i = 0; i < palabraJugadorOriginal.length(); i++) {
            if (palabraJugadorOriginal.charAt(i) == '*') {
                if (letra == palabraOculta.charAt(i)) {
                    palabraJugadorNueva = palabraJugadorNueva + letra;
                } else {
                    palabraJugadorNueva = palabraJugadorNueva + '*';
                }
            } else {
                palabraJugadorNueva = palabraJugadorNueva + palabraJugadorOriginal.charAt(i);

            }

        }

        return palabraJugadorNueva;
    }

    public static void main(String[] args) {
        String palabraOculta;
        String palabraJugador;
        String palabraFinal;
        char letra;
        boolean estaLaLetra;
        boolean victoria = false;
        int intento = 7;

        palabraOculta = pedirPalabraOculta();
        palabraJugador = pedirPalabraJugador(palabraOculta.length());

        do {
            System.out.println(palabraJugador);
            System.out.println("los intentos son: " + intento);
            if (quieresResolver()) {
                palabraFinal = pedirResultado();

                if (palabraFinal.equals(palabraOculta)) {
                    victoria = true;
                } else {
                    victoria = false;
                    System.out.println("No, no es esa palabra");
                    intento--;
                }

            } else {
                letra = pedirLetra();
                estaLaLetra = comprobarLetra(letra, palabraOculta);

                if (estaLaLetra == true) {
                    palabraJugador = ponerLetra(letra, palabraOculta, palabraJugador);

                } else {
                    System.out.println("Esa letra no esta");
                    intento--;
                }
            }

        } while (intento > 0 && !victoria);

        if (victoria) {
            System.out.println("Has ganado");
        } else {
            System.out.println("Has perdido y la solucion es: " + palabraOculta);
        }
    }

}
