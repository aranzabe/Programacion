/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package letras;

import java.util.Scanner;

/**
 *
 * @author faranzabe
 */
public class Letras {

    static void pedirCAdena(String cad) {
        cad = "iokljfdsf0";
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        char letra = 'A';
        System.out.println(letra);
        if (letra >= 97 && letra <= 122) {
            System.out.println("Es minúscula.");
        } else {
            System.out.println("No lo son");
        }
    }

}
