/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ej.pkg4;

import java.util.Scanner;

/**
 *
 * @author laura
 */
public class Ej4 {
    
    public static String pedirCaracter() {
        String caracter;
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Dime el caracter que quieres contar: ");
        caracter = sc.nextLine();
        
        return caracter;
    }
    
    public static String pedirCadena() {
        String cad;
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Dame una cadena: ");
        cad = sc.nextLine();
        
        return cad;
    }
    
    public static int contCaracteres(String caracter, String cad) {
        int cont = 0;
        
        for (int i = 0; i < cad.length(); i++) {
            
            if (cad.charAt(i) == caracter.charAt(0)) {
                cont++;
            }
            
        }
        
        return cont;
    }
    
    public static void main(String[] args) {
        String cad;
        String caracter;
        int contador;
        
        cad = pedirCadena();
        caracter = pedirCaracter();
        contador = contCaracteres(caracter, cad);
        
        System.out.println("En esta cadena hay " + contador + " caracteres de "
                + "la letra: " + caracter);
        
    }
    
}
