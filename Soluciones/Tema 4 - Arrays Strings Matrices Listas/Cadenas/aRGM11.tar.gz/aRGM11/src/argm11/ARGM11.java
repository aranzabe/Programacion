/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package argm11;

import java.util.Scanner;

/**
 *
 * @author usuarioa
 */
public class ARGM11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String cadena;
        Scanner sc=new Scanner(System.in);
        boolean comprobar;
        int enteroCad;
        System.out.println("Dime una cadena de numeros: ");
        cadena=sc.nextLine();
        
        comprobar=cadenaComprobar(cadena);
        
        if(comprobar){
            enteroCad=cadenaAentero(cadena);
            System.out.println("La cadena ya es un entero: " + enteroCad);
        }
        else System.out.println("La cadena no es valida para pasarla a entero");
        
    }

    static boolean cadenaComprobar(String cad) {
        int i;
        boolean op=false;
        for(i=cad.length()-1;i>=0;i--){
            if(cad.charAt(i)=='0' ||cad.charAt(i)=='1'||cad.charAt(i)=='2' ||cad.charAt(i)=='3' ||
                    cad.charAt(i)=='4' ||cad.charAt(i)=='5' ||cad.charAt(i)=='6' || cad.charAt(i)=='7' ||
                    cad.charAt(i)=='8' ||cad.charAt(i)=='9') op=true;
            else{
                op=false;
                i=0;
            }
        }
        return op ;
        
    }

    static int cadenaAentero(String cadena) {
        int cad;
        cad=Integer.parseInt(cadena);
        return cad;
    }
    
}
