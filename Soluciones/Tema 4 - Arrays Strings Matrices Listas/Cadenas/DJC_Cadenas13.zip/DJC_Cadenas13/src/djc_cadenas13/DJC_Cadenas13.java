/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_cadenas13;

import java.util.Scanner;

/**
 *
 * @author danie
 */
public class DJC_Cadenas13 {

    /**
     * Este módulo pide una palabra al usuario. Llama a un módulo de control de
     * errores
     */
    public static String pedirPalabra() {
        String palabra;
        boolean correcto;
        Scanner sc = new Scanner(System.in);

        do {
            System.out.println("Dame una palabra de cinco letras, sin tildes ni números:");
            palabra = sc.nextLine();
            palabra = palabra.toLowerCase();
            correcto = esCorrecto(palabra);
            if (!correcto) {
                System.out.println("La palabra no es correcta");
            }
        } while (!correcto);
        return palabra;
    }

    /**
     * Este módulo comprueba si la palabra cumple ciertas condiciones
     */
    public static boolean esCorrecto(String palabra) {
        boolean correcto = false;
        int i = 0;

        if (palabra.length() == 5) {
            correcto = true;
            while (i < palabra.length() && correcto) {
                if (palabra.charAt(i) < 97 || palabra.charAt(i) > 122) {
                    correcto = false;
                } else {
                    i++;
                }
            }
        }
        return correcto;
    }

    /**
     * Este módulo genera la pista. Se comprueba letra por letra la palabra
     * introducida por el Jugador 2 mediante otro módulo
     */
    public static String generarPista(String palabraOculta, String palabraJugador) {
        String pista = "";
        int caso;
        /*
        caso = 1 --> La letra está en las dos palabras y en la misma posición
        caso = 2 --> La letra está en las dos palabras y en distinta posición
        caso = 3 --> La letra no está en la palabra oculta
         */

        for (int i = 0; i < palabraJugador.length(); i++) {
            caso = comprobarLetra(palabraJugador.charAt(i), palabraOculta, i);
            switch (caso) {
                case 1:
                    pista = pista + palabraJugador.charAt(i);
                    break;
                case 2:
                    pista = pista + "*";
                    break;
                case 3:
                    pista = pista + "-";
            }
        }
        return pista;
    }

    /**
     * Este módulo comprueba una letra de la palabra del jugador con las letras
     * de la palabra oculta
     */
    public static int comprobarLetra(char letra, String palabra, int pos){
        int caso = 3;
        int i = 0;
        
        while (i < palabra.length() && caso != 1) {
            if (letra == palabra.charAt(i)){
                if (i == pos){
                    caso = 1;
                } else {
                    caso = 2;
                }
            }
            i++;
        }
        return caso;
    }
    
    /**
     * Este módulo comprueba si el jugador ha ganado
     */
    /*-------------------------------------------------------------------------------------------------*/
 /*---------------------------------------ALGORITMO PRINCIPAL---------------------------------------*/
 /*-------------------------------------------------------------------------------------------------*/
    public static void main(String[] args) {
        String palabraOculta;
        String pista = "-----";
        String palabraJugador;
        int intento = 5;
        boolean victoria = false;

        System.out.println("Juego del Lingo");
        System.out.println("Jugador 1 - Tienes que darme una palabra para que el jugador 2 intente adivinarla.");
        palabraOculta = pedirPalabra();
        do {
            System.out.println("Tienes " + intento + " intentos");
            System.out.println("Pista: " + pista);
            System.out.println("Jugador 2 - Intenta adivinar la palabra.");
            palabraJugador = pedirPalabra();
            pista = generarPista(palabraOculta, palabraJugador);
            victoria = palabraOculta.equals(palabraJugador);
            if (!victoria) {
                intento--;
            }
        } while (intento > 0 && !victoria);
        if (victoria) {
            System.out.println("Has acertado la palabra oculta");
        } else {
            System.out.println("No has acertado");
            System.out.println("La palabra oculta era: " + palabraOculta);
        }
    }

}
