/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package argm3;

import java.util.Scanner;

/**
 *
 * @author usuarioa
 */
public class ARGM3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String cadena;
        Scanner sc =new Scanner(System.in);
        int cuantas;
        
        System.out.print("Dime una cadena; ");
        cadena=sc.nextLine();
        
        cuantas=cuantasVocales(cadena);
        System.out.println("TIENE "  + cuantas + " vocales.");
    }

    private static int cuantasVocales(String cadena) {
        int cuantas=0;
        for(int i=cadena.length()-1;i>=0;i--){
             if ((cadena.charAt(i)=='a') || (cadena.charAt(i)=='e') || (cadena.charAt(i)=='i') || (cadena.charAt(i)=='o') || (cadena.charAt(i)=='u')){ 
        cuantas++;
  }
        }
        return cuantas;
    }
    
}
