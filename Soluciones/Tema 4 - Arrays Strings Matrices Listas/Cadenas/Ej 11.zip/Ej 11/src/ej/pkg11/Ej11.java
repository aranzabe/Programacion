/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ej.pkg11;

import java.util.Scanner;

/**
 *
 * @author laura
 */
public class Ej11 {

    static boolean esCorrecto(String numCad) {
        boolean comprob = true;

        for (int i = 0; i < numCad.length(); i++) {
            if (!Character.isDigit(numCad.charAt(i))) {
                comprob = false;
            }
        }
        return comprob;
    }

    static int pedirEntero() {
        int num;
        Scanner sc = new Scanner(System.in);
        String cad;
        boolean esValido;

        do {
            System.out.print("Dame un número: ");
            cad = sc.nextLine();
            esValido = esCorrecto(cad);
            if (!esValido) {
                System.out.println("Número incorrecto, ponga otro.");
            }
        } while (!esValido);
        num = Integer.parseInt(cad);
        return num;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int n;

        n = pedirEntero();
        System.out.println(n);
    }

}
