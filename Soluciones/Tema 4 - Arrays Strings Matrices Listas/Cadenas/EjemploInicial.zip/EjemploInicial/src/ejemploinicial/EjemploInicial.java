/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemploinicial;

import java.util.Scanner;

/**
 *
 * @author faranzabe
 */
public class EjemploInicial {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String cadena;
        cadena = "HOLA";
        String cad2 = "Buenos días";
        int n = 9;
        char letra;
        Scanner sc = new Scanner(System.in);
        
        letra = sc.nextLine().charAt(0);
        System.out.println("Letra que has pulsado: " + letra);

        System.out.println(cadena);
        System.out.println(cadena.length());
        System.out.println(cad2 + " de longitud " + cad2.length());
        for (int i = 0; i < cad2.length(); i++) {
            System.out.println(cad2.charAt(i));
        }
        System.out.println(cadena.toLowerCase());
        System.out.println(cad2.toUpperCase());
        cad2 = cad2.toUpperCase();
        System.out.println(cad2);
        System.out.print("Dame una cadena: ");
        cadena = sc.nextLine();
        System.out.print("Dame otra cadena: ");
        cad2 = sc.nextLine();
        if (cad2.equalsIgnoreCase(cadena)) {
            System.out.println("Son iguales");
        } else {
            System.out.println("No lo son");
        }
        if (cadena.compareTo(cad2) == 0) {
            System.out.println("Son iguales");
        }
        if (cadena.compareTo(cad2) < 0) {
            System.out.println(cadena + " es menor alfabeticamente que " + cad2);
        }
        if (cadena.compareTo(cad2) > 0) {
            System.out.println(cadena + " es mayor alfabeticamente que " + cad2);
        }
    }

}
