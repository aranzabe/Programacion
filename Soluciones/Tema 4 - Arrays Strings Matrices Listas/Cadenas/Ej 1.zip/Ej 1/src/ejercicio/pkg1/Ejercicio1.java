/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg1;

import java.util.Scanner;

/**
 *
 * @author laura
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String cad1;
        String cad2;
        Scanner sc = new Scanner(System.in);

        System.out.println("Dame una cadena: ");
        cad1 = sc.nextLine();
        System.out.println("Dame otra cadena: ");
        cad2 = sc.nextLine();

        if (cad1.equals(cad2)) {
            System.out.println("Son iguales");
        } else {
            System.out.println("No son igual");
        }

        /*Esto sirve para mostrar  el numero de letras que tiene un String
        System.out.println(cad2.length());
        System.out.println(cad1.length());
         */
        if (cad1.length() != cad2.length()) {
            System.out.println("Tienen distinto numero de digitos, la primera"
                    + "palabra tiene: " + cad1.length() + " y la segunda: " + cad2.length());
        } else {
            System.out.println(" Tienen el mismo numero de digitos" + cad1.length());
        }

        if (cad1.compareTo(cad2) < 0) {
            System.out.println("cad 1 es mayor que cad 2 alfabeticamente");
        }
        if (cad1.compareTo(cad2) > 0) {
            System.out.println("cad 2 es mayor  que cad 1 alfabeticamente");
        }
    }
}
