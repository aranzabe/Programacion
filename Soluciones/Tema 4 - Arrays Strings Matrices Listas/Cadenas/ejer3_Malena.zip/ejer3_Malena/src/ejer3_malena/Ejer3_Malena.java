/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejer3_malena;

import java.util.Scanner;

/**
 *
 * @author Malena
 */
public class Ejer3_Malena {

    /*Dada una cadena mostrar por pantalla la cantidad de vocales que tiene.
    Ejemplo:
        Entrada: cad = "Hola DAW1"
        Salida: La cantidad de vocales es 3*/

    public static void main(String[] args) {
        String palabra;
        int cont = 0;
        Scanner sc = new Scanner (System.in);
        
        System.out.println("Dame una palabra y te diré cuantas vocales tiene");
        palabra = sc.nextLine();
        
        for(int i = 0; i < palabra.length(); i++) {
            
            if ((palabra.charAt(i)=='a') || (palabra.charAt(i)=='A') || (palabra.charAt(i)=='e') || (palabra.charAt(i)=='E') || (palabra.charAt(i)=='i') || (palabra.charAt(i)=='I') || (palabra.charAt(i)=='o') || (palabra.charAt(i)=='O') ||(palabra.charAt(i)=='u') || (palabra.charAt(i)=='U')){ 
                cont++;
            }
            
        }
        System.out.println("la palabra " + palabra + " tiene dentro " + cont + " vocales");
    }
       
        
}
    
