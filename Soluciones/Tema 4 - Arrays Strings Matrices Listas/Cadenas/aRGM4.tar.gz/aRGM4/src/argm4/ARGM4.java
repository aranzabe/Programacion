/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package argm4;

import java.util.Scanner;

/**
 *
 * @author usuarioa
 */
public class ARGM4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String cad;
        char car;
        int cuantas;
        System.out.println("Dime una cadena: ");
        cad=sc.nextLine();
        System.out.println("Dime un caracter: ");
        car=sc.nextLine().charAt(0);
        
        cuantas=cuantasCar(cad,car);
        System.out.println("Tiene " + cuantas +" el caracter " + car + " en la cadena "
                + cad );
    }

    static int cuantasCar(String cad, char carac) {
        int cont=0;
        int i;
        for(i=cad.length()-1;i>=0;i--){
            if(cad.charAt(i)==carac) cont++;
        }
        
        return cont;
    }
    
}
