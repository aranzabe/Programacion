/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ej1.strings;

import java.util.Scanner;

/**
 *
 * @author Portatil Alvaro
 */
public class Ej1Strings {

    /**
     * @param args the command line arguments
     */
    
    public static int contarCaracteres(String cadena){
        int contador=0;
        for (int i = 0; i < cadena.length(); i++) {
            contador++;
        }
        return contador;
    }
    public static void main(String[] args) {
        Scanner cad1 = new Scanner(System.in);
        System.out.println("Vamos a comparar cadenas,\nEscribeme una cadena");
        String cadena1 = cad1.nextLine();
        System.out.println("Escribe otra cadena de caracteres");
        String cadena2 = cad1.nextLine();
        
        if (cadena1.equals(cadena2)) {
            System.out.println("Son Iguales");
        }else{
            System.out.println("No son iguales");
        }

        
        if (cadena1.charAt(1)>cadena2.charAt(1)) {
            System.out.println("cadena1 es mayor alfabeticamente");
        }
        if (cadena1.charAt(1)<cadena2.charAt(1)) {
            System.out.println("cadena2 es mayor alfabeticamente");
        }else{
            System.out.println("cadena1 y cadena2 empiezan por la misma letra");
        }
        
        int contador1=contarCaracteres(cadena1);
        int contador2=contarCaracteres(cadena2);
        
        if (contador1==contador2){
            System.out.println("Tienen el mismo numero de caracteres: " + contador1);
        }else{
            System.out.println("Cadena1 tiene: "+contador1+" caracteres y cadena2 tiene: "+contador2+" Caracteres, No tienen la misma longitud.");
        }
            

        
    }
    
}
