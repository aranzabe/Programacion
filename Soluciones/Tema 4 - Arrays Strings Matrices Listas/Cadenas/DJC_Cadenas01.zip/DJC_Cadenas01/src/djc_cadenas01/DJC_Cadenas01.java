/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_cadenas01;

import java.util.Scanner;

/**
 *
 * @author usuariob
 */
public class DJC_Cadenas01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String cad1, cad2;
        Scanner sc = new Scanner(System.in);

        System.out.print("Dame una cadena: ");
        cad1 = sc.nextLine();
        System.out.print("Dame otra cadena: ");
        cad2 = sc.nextLine();

        System.out.println(cad1 + " tiene " + cad1.length() + " caracteres");
        System.out.println(cad2 + " tiene " + cad2.length() + " caracteres");

        if (cad1.length() > cad2.length()) {
            System.out.println("La primera es mayor en longitud.");
        }
        if (cad1.length() < cad2.length()) {
            System.out.println("La primera es menor en longitud.");
        }
        if (cad1.length() == cad2.length()) {
            System.out.println("La primera es menor en longitud.");
        }
        

        if (cad1.compareTo(cad2) == 0) {
            System.out.println("Las cadenas son iguales alfabéticamente");
        } else if (cad1.compareTo(cad2) < 0) {
            System.out.println(cad1 + " es menor alfabéticamente que " + cad2);
        } else {
            System.out.println(cad1 + " es mayor alfabéticamente que ");
        }
    }

}
