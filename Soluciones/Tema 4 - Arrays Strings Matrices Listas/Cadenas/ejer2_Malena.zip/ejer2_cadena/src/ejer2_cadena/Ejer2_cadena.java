/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejer2_cadena;

import java.util.Scanner;

/**
 *
 * @author Malena
 */
public class Ejer2_cadena {

/*Crea un programa en Java que solicite al usuario la introducción de una cadena de
caracteres y devuelva esta cadena invertida. Convierte la cadena resultante en
mayúsculas.*/

    
    public static void main(String[] args) {
        String cad1;
        String cadinvertida;
        Scanner sc = new Scanner (System.in);
        
        System.out.println("Introduzca una cadena");
        cad1 = sc.nextLine();
        
        System.out.println("ahora mostraremos la cadena pero de forma invertida");
        
        StringBuilder invertida = new StringBuilder (cad1);
        cadinvertida = invertida.reverse().toString();
        
        System.out.println("la cadena original es : " + cad1);
        System.out.println("la cadena invertida es : " + cadinvertida);
    }
    
}
