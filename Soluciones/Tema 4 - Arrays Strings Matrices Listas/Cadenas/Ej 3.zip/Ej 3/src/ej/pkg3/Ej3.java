/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ej.pkg3;

import java.util.Scanner;

/**
 *
 * @author laura
 */
public class Ej3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String cad;
        int contvocales = 0;

        Scanner sc = new Scanner(System.in);

        System.out.println("Dame una cadena: ");
        cad = sc.nextLine();

        for (int i = 0; i < cad.length(); i++) {
            if (cad.charAt(i) == 'a') {
                contvocales++;
            }
            if (cad.charAt(i) == 'e') {
                contvocales++;
            }
            if (cad.charAt(i) == 'i') {
                contvocales++;
            }
            if (cad.charAt(i) == 'o') {
                contvocales++;
            }
            if (cad.charAt(i) == 'u') {
                contvocales++;
            }
        }
        System.out.println(cad + " tiene: " + contvocales + " vocales");
    }

}
