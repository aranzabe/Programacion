/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package argm2;

import java.util.Scanner;

/**
 *
 * @author usuarioa
 */
public class ARGM2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String c1,invC1;
        
        System.out.println("Dime una cadena: ");
        c1=sc.nextLine();
        
        invC1=invertir(c1);
        System.out.println(invC1);
        
        System.out.println("Convertir en mayuscula " + c1.toUpperCase());
    }

    static String invertir(String c1) {
        String laotra="";
        
        for(int i=c1.length()-1;i>=0;i--){
          laotra= laotra + c1.charAt(i);
        }
        return laotra;
        
    }
    
}
