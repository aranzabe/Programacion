/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_cadenas07;

import java.util.Scanner;

/**
 *
 * @author usuariob
 */
public class DJC_Cadenas07 {

    /**
     * Este módulo controla si se ha introducido un teléfono de longitud
     * correcta
     */
    public static boolean esCorrectaLongitud(String tfno) {
        boolean correcto = true;

        if (tfno.length() != 11) {
            correcto = false;
        }
        return correcto;
    }

    /**
     * Este módulo controla si se ha introducido un teléfono con sólo números
     */
    public static boolean esCorrectoNumero(String tfno) {
        boolean correcto = true;
        int i = 0;

        while (i < tfno.length() && correcto) {
            if (!Character.isDigit(tfno.charAt(i))) {
                correcto = false;
            } else {
                i++;
            }
        }
        return correcto;
    }

    /**
     * Este módulo pide un número por teclado
     */
    public static String pedirTfno() {
        String tfno;
        boolean correcto1, correcto2;
        Scanner sc = new Scanner(System.in);

        do {
            System.out.print("Dame tu número de teléfono con el prefijo de pais (11 dígitos): ");
            tfno = sc.nextLine();
            correcto1 = esCorrectaLongitud(tfno);
            correcto2 = esCorrectoNumero(tfno);
            if (!correcto1){
                System.out.println("Número no válido: longitud incorrecta");
            }
            if (!correcto2){
                System.out.println("Número no válido: has metido una letra");
            }
        } while (!correcto1 || !correcto2);
        return tfno;
    }

    /**
     * Este módulo convierte el teléfono pedido a otro formato
     */
    public static String cambiarFormato(String tfno1){
        String tfno2;
        
        tfno2 = "+(" + tfno1.substring(0, 2) + ")-" + tfno1.substring(2,5) + "-" + tfno1.substring(5,11);
        return tfno2;
    }
    /*-----------------------------------------------------------------------*/
 /*-----------------------ALGORITMO PRINCIPAL-----------------------------*/
 /*-----------------------------------------------------------------------*/
    public static void main(String[] args) {
        String tfno;
        String tfnoFormato;
        
        tfno = pedirTfno();
        tfnoFormato = cambiarFormato(tfno);
        
        System.out.println("Tu teléfono es: " + tfnoFormato);
    }

}
