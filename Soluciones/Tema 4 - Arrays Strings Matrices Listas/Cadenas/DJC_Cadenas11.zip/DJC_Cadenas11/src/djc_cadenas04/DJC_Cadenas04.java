/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_cadenas04;

import java.util.Scanner;

/**
 *
 * @author usuariob
 */
public class DJC_Cadenas04 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*Pide un número por teclado; utiliza las cadenas y sus propiedades para
        comprobar que el número es correcto. Caso de ser correcto se debe convertir en
        entero para poder operarlo posteriormente.*/
        String numCad;
        int num, i = 0;
        boolean correcto;
        Scanner sc = new Scanner(System.in);

        do {
            correcto = true;
            System.out.print("Dame un número: ");
            numCad = sc.nextLine();
            while (i < numCad.length() && correcto) {
                if (Character.isDigit(numCad.charAt(i)) == false){
                    correcto = false;
                    System.out.println("Número incorrecto");
                } else {
                    i++;
                }
            }
        } while (!correcto);

        num = Integer.parseInt(numCad);

        System.out.println("Tu número es: " + num);
    }

}
