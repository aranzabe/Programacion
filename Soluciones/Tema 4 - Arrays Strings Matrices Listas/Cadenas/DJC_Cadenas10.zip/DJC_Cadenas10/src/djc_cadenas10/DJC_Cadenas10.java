/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_cadenas10;

import java.util.Scanner;

/**
 *
 * @author danie
 */
public class DJC_Cadenas10 {

    /**
     * Este módulo pide un mensaje. Incluye corrección de errores
     */
    public static String pedirMensaje() {
        String cad;
        boolean correcta;
        Scanner sc = new Scanner(System.in);

        do {
            System.out.println("Dame un mensaje. Sólo puede contener letras mayúsculas sin tilde y números");
            cad = sc.nextLine();
            correcta = esCorrecta(cad);
            if (!correcta) {
                System.out.println("El mensaje no es válido");
            }
        } while (!correcta);
        return cad;
    }

    /**
     * Este módulo comprueba si la cadena es correcta
     */
    public static boolean esCorrecta(String cad) {
        boolean correcta = true;
        int i = 0;

        while (i < cad.length() && correcta) {
            if ((cad.charAt(i) > 47 && cad.charAt(i) < 58) || (cad.charAt(i) > 64 && cad.charAt(i) < 91) || (cad.charAt(i) > 96 && cad.charAt(i) < 123)) {
            } else {
                correcta = false;
            }
            i++;
        }
        return correcta;
    }

    /**
     * Este módulo traduce el mensaje
     */
    public static String traducirMensaje(String cad) {
        String traducido = "";
        
        cad = cad.toUpperCase();
        for (int i = 0; i < cad.length(); i++) {
            switch (cad.charAt(i)) {
                case '9':
                    traducido = traducido + "0";
                    break;
                case 'Z':
                    traducido = traducido + "A";
                    break;
                default:
                    traducido = traducido + (char) (cad.charAt(i) + 1);
            }
        }
        return traducido;
    }

    /*-----------------------------------------------------------------------*/
    /*------------------------ALGORITMO PRINCIPAL----------------------------*/
    /*-----------------------------------------------------------------------*/
    public static void main(String[] args) {
        String mensajeOriginal, mensajeCesar;

        mensajeOriginal = pedirMensaje();
        mensajeCesar = traducirMensaje(mensajeOriginal);
        System.out.println("Tu mensaje codificado es el siguiente:");
        System.out.println(mensajeCesar);
    }

}
