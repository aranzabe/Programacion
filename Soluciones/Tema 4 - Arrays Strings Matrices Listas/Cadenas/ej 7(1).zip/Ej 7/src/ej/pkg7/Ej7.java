/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ej.pkg7;

import java.util.Scanner;

/**
 *
 * @author laura
 */
public class Ej7 {

    static boolean esCorrecto(String cad) {
        boolean comprob = true;

        for (int i = 0; i < cad.length(); i++) {
            if (!Character.isDigit(cad.charAt(i))) {
                comprob = false;
            }
        }
        return comprob;
    }

    public static String pedirCadena() {
        String cad;
        boolean contValido;
        boolean correcto;
        Scanner sc = new Scanner(System.in);

        do {
            System.out.println("Dame una cadena de numeros: ");
            cad = sc.nextLine();
            contValido = contadorCadena(cad);
            correcto = esCorrecto(cad);
        } while (contValido == false || correcto == false);

        return cad;
    }

    public static boolean contadorCadena(String cad) {
        int numeromaximo = 11;
        int cont = 0;
        boolean valido = true;

        for (int i = 0; i < cad.length(); i++) {
            cont++;
        }
        if (cont != numeromaximo) {
            valido = false;
        }

        return valido;
    }

    public static void main(String[] args) {
        String cad;

        cad = pedirCadena();
    }

}
