/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package argm7;

import java.util.Scanner;

/**
 *
 * @author usuarioa
 */
public class ARGM7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String cad, cadena="";
        boolean comprobar;
        int longitud;
        System.out.println("Dime una cadena Telefonica: ");
        cad = sc.nextLine();

        
        comprobar = cadenaComprobar(cad);
        longitud = cad.length();

        System.out.println(longitud);
        if (comprobar && longitud == 11) {
            cadena = convertirNumero2(cad);
            System.out.println("La nueva cadena es : " + cadena);
        } else {
            System.out.println("No es un numero de telefono, prueba otra vez");
        }

    }

    static boolean cadenaComprobar(String cad) {
        int i;
        boolean op = false;
        for (i = cad.length() - 1; i >= 0; i--) {
            /**
             * if(cad.charAt(i)=='0' ||cad.charAt(i)=='1'||cad.charAt(i)=='2'
             * ||cad.charAt(i)=='3' || cad.charAt(i)=='4' ||cad.charAt(i)=='5'
             * ||cad.charAt(i)=='6' || cad.charAt(i)=='7' || cad.charAt(i)=='8'
             * ||cad.charAt(i)=='9') op=true;
             *
             */
            if (Character.isDigit(cad.charAt(i))) {
                op = true;
            } else {
                op = false;
                i = 0;
            }
        }
        return op;
    }

    static String convertirNumero(String cad) {
        int i;
        String sol = "(+";
        for (i = 0; i <= cad.length() - 1; i++) {

            if (i == 2) {
                sol = sol + ")-" + cad.charAt(i);
            } else {
                if (i == 5) {
                    sol = sol + "-" + cad.charAt(i);
                } else {
                    sol = sol + cad.charAt(i);
                }
            }

        }

        return sol;
    }

    static String convertirNumero2(String cad) {
        int i;
        String sol = "(+";
        sol = sol + cad.substring(0, 2) + ")-";
        sol = sol + cad.substring(2, 5) + "-";
        sol = sol + cad.substring(5);

        return sol;
    }

}
