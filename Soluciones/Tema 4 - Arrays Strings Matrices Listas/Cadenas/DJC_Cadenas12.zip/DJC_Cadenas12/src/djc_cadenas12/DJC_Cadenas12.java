/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djc_cadenas12;

import java.util.Scanner;

/**
 *
 * @author danie
 */
public class DJC_Cadenas12 {

    /**
     * Esta función pide una palabra y comprueba si es correcta mediante otro
     * módulo
     */
    public static String pedirPalabra() {
        String palabra;
        boolean correcto;
        Scanner sc = new Scanner(System.in);

        do {
            System.out.println("Jugador 1 - Dime una palabra para que el jugador 2 intente adivinarla. Sólo puede contener letras mayúsculas sin tilde");
            palabra = sc.nextLine();
            correcto = esCorrecto(palabra);
            if (!correcto) {
                System.out.println("Palabra incorrecta. Inténtalo de nuevo");
            }
        } while (!correcto);
        return palabra.toUpperCase();
    }

    /**
     * Este módulo devuelve true si la palabra sólo tiene letras mayúsculas
     */
    public static boolean esCorrecto(String cadena) {
        boolean correcto = true;
        int i = 0;

        while (i < cadena.length() && correcto) {
            if (cadena.charAt(i) > 64 && cadena.charAt(i) < 91) {
                i++;
            } else {
                correcto = false;
            }
        }
        return correcto;
    }

    /**
     * Esta función inicia el tablero del jugador, poniendo * en todos los
     * caracteres
     */
    public static String iniciarTableroJugador(int tam) {
        String palabra = "";

        for (int i = 0; i < tam; i++) {
            palabra = palabra + "*";
        }
        return palabra;
    }

    /**
     * Este módulo pregunta al usuario si quiere resolver o no la palabra.
     * Devuelve true si quiere resolverla
     */
    public static boolean quiereResolver() {
        char respuesta;
        boolean resolver = false;
        Scanner sc = new Scanner(System.in);

        do {
            System.out.print("¿Quieres resolver (s/n)? ");
            respuesta = sc.nextLine().charAt(0);
            if (respuesta != 's' && respuesta != 'S' && respuesta != 'n' && respuesta != 'N') {
                System.out.println("No te he entendido bien");
            } else {
                if (respuesta == 's' || respuesta == 'S') {
                    resolver = true;
                }
                if (respuesta == 'n' || respuesta == 'N') {
                    resolver = false;
                }
            }
        } while (respuesta != 's' && respuesta != 'S' && respuesta != 'n' && respuesta != 'N');
        return resolver;
    }

    /**
     * Este módulo pide la respuesta final. Llama a la función de control de
     * errores
     */
    public static String pedirResultado() {
        String palabra;
        boolean correcto;
        Scanner sc = new Scanner(System.in);

        do {
            System.out.println("Dime la palabra final. Recuerda que sólo haya letras mayúsculas y minúsculas sin tilde.");
            palabra = sc.nextLine();
            correcto = esCorrecto(palabra);
            if (!correcto) {
                System.out.println("Palabra incorrecta. Inténtalo de nuevo");
            }
        } while (!correcto);
        return palabra.toUpperCase();
    }

    /**
     * Este módulo pide una letra al usuario. Incluye control de errores
     */
    public static char pedirLetra() {
        char letra;
        boolean correcto;
        Scanner sc = new Scanner(System.in);

        do {
            System.out.println("Dame una letra");
            letra = sc.nextLine().charAt(0);
            if (letra > 64 && letra < 91) {
                correcto = true;
            } else {
                correcto = false;
                System.out.println("Letra incorrecta. Inténtalo de nuevo");
            }
        } while (!correcto);
        return letra;
    }

    /**
     * Este módulo devuelve true si la letra introducida por el jugador está en
     * la palabra oculta
     */
    public static boolean estaLaLetra(char letra, String palabra) {
        boolean esta = false;
        int i = 0;

        while (i < palabra.length() && !esta) {
            if (letra == palabra.charAt(i)) {
                esta = true;
            } else {
                i++;
            }
        }
        return esta;
    }

    /**
     * Este módulo pone en la palabra del jugador la letra que se le ha pedido
     * al usuario en la misma posición en que está en la palabra oculta
     */
    public static String ponerLetras(char letra, String palabraOculta, String palabraJugadorOriginal){
        String palabraJugadorNueva = "";
        
        for (int i = 0; i < palabraOculta.length(); i++) {
            if (palabraJugadorOriginal.charAt(i) == '*'){
                if (letra == palabraOculta.charAt(i)){
                    palabraJugadorNueva = palabraJugadorNueva + letra;
                } else {
                    palabraJugadorNueva = palabraJugadorNueva + "*";
                }
            } else {
                palabraJugadorNueva = palabraJugadorNueva + palabraJugadorOriginal.charAt(i);
            }
        }
        return palabraJugadorNueva;
    }
    
    /*-------------------------------------------------------------------------------------------------*/
 /*---------------------------------------ALGORITMO PRINCIPAL---------------------------------------*/
 /*-------------------------------------------------------------------------------------------------*/
    public static void main(String[] args) {
        String palabraOculta;
        String palabraJugador;
        String palabraFinal;
        char letra;
        int intentos = 7;
        boolean victoria = false;

        System.out.println("El ahorcado");
        palabraOculta = pedirPalabra();
        palabraJugador = iniciarTableroJugador(palabraOculta.length());
        do {
            System.out.print("Jugador 2 - Tu palabra: ");
            System.out.println(palabraJugador);
            System.out.println("Tienes " + intentos + " intentos");
            if (!quiereResolver()) {
                letra = pedirLetra();
                if (estaLaLetra(letra, palabraOculta)) {
                    System.out.println("La letra " + letra + " está en la palabra oculta");
                    palabraJugador = ponerLetras(letra, palabraOculta, palabraJugador);
                } else {
                    System.out.println("La letra " + letra + " no está en la palabra oculta");
                    intentos--;
                }
            } else {
                palabraFinal = pedirResultado();
                if (palabraFinal.equals(palabraOculta)) {
                    victoria = true;
                } else {
                    System.out.println("Ésa no es la palabra oculta");
                    intentos--;
                }
            }
        } while (intentos != 0 && !victoria);
        if (victoria) {
            System.out.println("Has ganado");
        } else {
            System.out.println("Has perdido");
            System.out.println("La palabra oculta era: " + palabraOculta);
        }
    }

}
